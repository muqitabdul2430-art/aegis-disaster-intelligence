"""AEGIS test harness.

Environment is pinned *before* the application is imported so the suite runs
deterministic, offline and against a throw-away database:

*   no live network calls (AEGIS_ENABLE_LIVE_NETWORK=false)
*   no background scheduler, no ingestion on startup
*   demo scenarios off (AEGIS_DEMO_MODE=off) — tests create exactly the fixtures
    they need, so nothing can pass by accident on seeded sample data
*   a temporary SQLite file, deleted with the session
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="aegis-tests-"))

os.environ["AEGIS_ENVIRONMENT"] = "test"
os.environ["AEGIS_DATABASE_URL"] = f"sqlite:///{_TMP / 'aegis-test.db'}"
os.environ["AEGIS_ENABLE_LIVE_NETWORK"] = "false"
os.environ["AEGIS_SCHEDULER_ENABLED"] = "false"
os.environ["AEGIS_INGEST_ON_STARTUP"] = "false"
os.environ["AEGIS_DEMO_MODE"] = "off"
os.environ["AEGIS_JWT_SECRET"] = "test-secret-not-for-production"
os.environ["AEGIS_DEMO_PASSWORD"] = "aegis-test-password"
os.environ["AEGIS_RATE_LIMIT_READ_PER_MIN"] = "100000"
os.environ["AEGIS_RATE_LIMIT_WRITE_PER_MIN"] = "100000"
os.environ["AEGIS_RATE_LIMIT_ASSISTANT_PER_MIN"] = "100000"
os.environ["AEGIS_RATE_LIMIT_REPORT_SUBMIT_PER_MIN"] = "100000"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402


@pytest.fixture(scope="session")
def client() -> TestClient:
    from app.main import app

    with TestClient(app) as c:      # triggers startup (seed users/sources only)
        yield c


def _login(client: TestClient, email: str, password: str = "aegis-test-password") -> str:
    res = client.post("/api/auth/login", json={"email": email, "password": password})
    assert res.status_code == 200, res.text
    return res.json()["token"]["access_token"]


@pytest.fixture(scope="session")
def admin_headers(client: TestClient) -> dict:
    return {"Authorization": f"Bearer {_login(client, 'admin@aegis.local')}"}


@pytest.fixture(scope="session")
def analyst_headers(client: TestClient) -> dict:
    return {"Authorization": f"Bearer {_login(client, 'analyst@aegis.local')}"}


@pytest.fixture()
def citizen_token(client: TestClient) -> str:
    """A fresh citizen account per test (registration is open by default)."""
    import uuid

    email = f"citizen-{uuid.uuid4().hex[:8]}@example.com"
    res = client.post("/api/auth/register", json={"email": email, "password": "citizen-passphrase-1", "display_name": "Citizen"})
    assert res.status_code in (200, 201), res.text
    return res.json()["token"]["access_token"]


@pytest.fixture()
def citizen_headers(citizen_token: str) -> dict:
    return {"Authorization": f"Bearer {citizen_token}"}


@pytest.fixture()
def db_session():
    """Direct DB access for unit tests (tables are created on first use)."""
    from app.db import SessionLocal, init_db

    init_db()
    with SessionLocal() as s:
        yield s
