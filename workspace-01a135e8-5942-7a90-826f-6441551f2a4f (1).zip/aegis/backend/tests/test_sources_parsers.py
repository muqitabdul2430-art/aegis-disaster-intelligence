"""Source connectors: parsing is deterministic and never invents fields.

Fixtures below are trimmed but structurally faithful copies of each provider's
payload, so the parsers are exercised without any network access.
"""
from __future__ import annotations

import datetime
import json

from app.sources.http import SourceFetch


def _fetch(source: str, data) -> SourceFetch:
    return SourceFetch(ok=True, status_code=200, data=data, url=f"https://example.test/{source}", latency_ms=1)


USGS = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "id": "us6000test",
            "properties": {"mag": 6.2, "magType": "mww", "place": "120 km SSW of Somewhere",
                           "time": 1760000000000, "tsunami": 1, "status": "reviewed",
                           "url": "https://earthquake.usgs.gov/earthquakes/eventpage/us6000test"},
            "geometry": {"type": "Point", "coordinates": [78.51, 12.31, 10.0]},
        },
        {   # malformed entry must be skipped, not guessed at
            "type": "Feature", "id": "broken", "properties": {"mag": None},
            "geometry": {"type": "Point", "coordinates": [1.0, 2.0]},
        },
    ],
}

GDACS = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [86.7, 20.1]},
            "properties": {
                "eventtype": "TC", "eventid": 1001335, "alertlevel": "Orange",
                "name": "Tropical Cyclone TEST-26", "country": "India",
                "fromdate": "2026-10-12T00:00:00", "todate": "2026-10-14T00:00:00",
                "datemodified": "2026-10-13T06:00:00",
                "url": {"report": "https://www.gdacs.org/report.aspx?eventid=1001335&eventtype=TC"},
            },
        }
    ],
}

NHC = {"activeStorms": [{
    "id": "al072026", "name": "RACHEL", "classification": "HU", "intensity": "85",
    "pressure": "972", "latitudeNumeric": 21.4, "longitudeNumeric": -64.6,
    "lastUpdate": "2026-10-13T11:00:00Z",
    "movementDir": "300", "movementSpeed": "12",
    "publicAdvisory": {"advNum": "024a", "url": "https://www.nhc.noaa.gov/text/MIATCPAT1.shtml"},
}]}

TSUNAMI_XML = """<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:geo="http://www.w3.org/2003/01/geo/wgs84_pos#">
  <entry>
    <id>urn:test:1</id>
    <title>Tsunami Information Statement Number 1</title>
    <updated>2026-10-13T12:30:00Z</updated>
    <geo:lat>38.9</geo:lat>
    <geo:long>148.2</geo:long>
    <summary>&lt;strong&gt;Preliminary Magnitude:&lt;/strong&gt;6.9&amp;nbsp;&lt;strong&gt;Category:&lt;/strong&gt;Information
      &lt;strong&gt;Affected Region:&lt;/strong&gt;Kermadec Islands region</summary>
    <link rel="related" type="text/html" href="https://www.tsunami.gov/events/PAAQ/2026/"/>
  </entry>
</feed>"""


def test_usgs_parser_extracts_and_skips_malformed():
    from app.sources import usgs_earthquake as usgs

    signals = usgs.parse(_fetch("usgs_earthquake", USGS))
    assert len(signals) == 1
    s = signals[0]
    assert s.hazard_hint == "earthquake"
    assert s.magnitude == 6.2
    assert s.lat == 12.31 and s.lon == 78.51
    assert s.external_id == "us6000test"
    assert s.confidence > 60                       # 'reviewed' outranks 'automatic'
    assert s.source_url.startswith("https://earthquake.usgs.gov")
    # a payload with no usable geometry must yield nothing rather than a zero-coordinate event
    broken = usgs.parse(_fetch("usgs_earthquake", {"features": [{"properties": {"mag": 5.0}}]}))
    assert broken == []


def test_gdacs_parser_maps_alert_levels_and_keeps_source_url():
    from app.sources import gdacs as gdacs_mod

    signals = gdacs_mod.parse(_fetch("gdacs", GDACS))
    assert len(signals) == 1
    s = signals[0]
    assert s.hazard_hint == "cyclone"          # GDACS eventtype TC → cyclone
    assert s.lat == 20.1 and s.lon == 86.7
    assert "1001335" in (s.external_id or "")
    assert s.source_url and "gdacs.org" in s.source_url


def test_nhc_parser_reads_position_and_intensity():
    from app.sources import nhc as nhc_mod

    signals = nhc_mod.parse(_fetch("nhc", NHC))
    assert len(signals) == 1
    s = signals[0]
    assert s.hazard_hint == "cyclone"
    assert s.lat == 21.4 and s.lon == -64.6                   # 21.4N 64.6W
    assert s.magnitude == 85.0 and s.magnitude_unit.startswith("kt")
    assert "RACHEL" in (s.place or "").upper()


def test_tsunami_atom_parser_reads_without_network():
    from app.sources import noaa_tsunami as tsn

    signals = tsn.parse(_fetch("noaa_tsunami", TSUNAMI_XML), centre="PAAQ")
    assert signals, "the Atom feed must parse into at least one bulletin"
    s = signals[0]
    assert s.hazard_hint == "tsunami"
    assert s.lat == 38.9 and s.lon == 148.2
    assert s.place == "Kermadec Islands region"        # region extracted from the bulletin
    assert s.magnitude == 6.9, "the bulletin magnitude must be carried through when stated"
    assert "Information" in (s.payload or {}).get("summary", "") or (s.payload or {}).get("category") == "Information"


def test_observation_fingerprint_is_stable(db_session):
    """The same provider record must dedupe to the same fingerprint across runs."""
    from app.ingest import store_observations
    from app.sources.base import RawSignal

    signal = RawSignal(source_key="usgs_earthquake", external_id="us6000dup", hazard_hint="earthquake",
                       lat=12.31, lon=78.51, observed_at="2026-10-13T10:00:00Z", magnitude=5.4,
                       # ISO string on purpose: ingestion must coerce it, not crash
                       magnitude_unit="Mmww", source_url="https://earthquake.usgs.gov/earthquakes/eventpage/us6000dup")

    new1, rows1 = store_observations(db_session, [signal])
    db_session.flush()
    first = rows1[0]
    new2, rows2 = store_observations(db_session, [signal])   # returns only newly inserted rows
    db_session.commit()

    assert new1 == 1 and len(rows1) == 1, "the first insert stores the observation"
    assert new2 == 0 and rows2 == [], "re-ingesting an identical provider record must not duplicate it"
    assert len(first.fingerprint or "") == 40           # sha256 truncated for indexing
    assert first.observed_at == datetime.datetime(2026, 10, 13, 10, 0), "ISO strings must be coerced, not crashed on"
