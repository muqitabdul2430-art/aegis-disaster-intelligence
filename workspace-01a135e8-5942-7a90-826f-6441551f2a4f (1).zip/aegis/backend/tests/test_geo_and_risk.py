"""Deterministic maths: distance, footprints, geocoding helpers, risk scoring."""
from __future__ import annotations

import math

import pytest


def test_haversine_matches_known_distances():
    from app.services import geo

    # Hyderabad → Visakhapatnam is ~505 km great-circle
    d = geo.haversine_km(17.385, 78.4867, 17.6868, 83.2185)
    assert 480 < d < 530

    assert geo.haversine_km(0, 0, 0, 0) == pytest.approx(0.0, abs=1e-9)
    # antipodal points ≈ half the Earth's circumference
    half_circumference = math.pi * 6371.0088
    assert geo.haversine_km(0, 0, 0, 180) == pytest.approx(half_circumference, rel=1e-6)


def test_circle_polygon_is_closed_and_bounded():
    from app.services import geo

    poly = geo.circle_polygon(17.4, 78.5, 30.0)
    assert poly["type"] == "Polygon"
    ring = poly["coordinates"][0]
    assert ring[0] == ring[-1], "GeoJSON rings must close"
    lons = [c[0] for c in ring]
    lats = [c[1] for c in ring]
    assert min(lats) < 17.4 < max(lats)
    assert min(lons) < 78.5 < max(lons)
    assert max(lats) - min(lats) > 0.4   # ≥ ~25 km north-south for a 30 km radius


def test_place_label_is_traceable_or_honest():
    from app.services import geo

    # Known large city should resolve to a real gazetteer entry
    label = geo.place_label(17.385, 78.4867)
    assert isinstance(label, str) and label
    # Remote ocean point must still return something usable, never an invention claim
    remote = geo.place_label(-40.0, -25.0)
    assert isinstance(remote, str) and remote


def test_bbox_helpers_and_point_containment():
    from app.services import geo

    box = (10.0, 20.0, 30.0, 40.0)                      # (min_lat, min_lon, max_lat, max_lon)
    assert geo.point_in_bbox(15.0, 25.0, box) is True
    assert geo.point_in_bbox(5.0, 25.0, box) is False

    gj = geo.bbox_to_geojson(*box)
    assert gj["type"] == "Polygon"
    ring = gj["coordinates"][0]
    assert ring[0] == ring[-1]
    assert ring[0] == [20.0, 10.0]                      # GeoJSON is (lon, lat)

    around = geo.bbox_around(17.385, 78.4867, 25.0)
    assert around[0] < 17.385 < around[2] and around[1] < 78.4867 < around[3]
    assert around[2] - around[0] > 0.3                  # ≥ ~25 km north-south span


def test_polygon_area_and_offset_geometry():
    from app.services import geo

    poly = geo.circle_polygon(0.0, 0.0, 100.0)
    area = geo.polygon_area_km2(poly)
    # a 100 km-radius disc is ~31 416 km²; the polygon approximation is within 2%
    assert 30_000 < area < 32_500

    lat, lon = geo.offset_point(17.0, 78.0, 90.0, 100.0)   # 100 km due east
    assert abs(lat - 17.0) < 0.05
    assert 78.8 < lon < 79.1
    assert 95 < geo.haversine_km(17.0, 78.0, lat, lon) < 105


def test_risk_scoring_is_deterministic_and_explained(db_session):
    from app.agents import risk_agent as risk_mod
    from app.agents.base import AgentContext
    from app import models
    from app.util import now

    inc = models.Incident(
        id="inc_test_risk_1", code="AEGIS-TEST-0001", title="Test flood", category="flood",
        status="active", verification_status="corroborated", severity=4, confidence=80.0,
        lat=17.0, lon=78.0, region="Test region", country="India", country_iso3="IND",
        started_at=now(), data_origin="live", primary_source_key="usgs_earthquake",
    )
    db_session.add(inc)          # the assessment is persisted and FK-linked to the incident
    db_session.flush()
    ctx = AgentContext(db=db_session, agent_name="test")
    area = {"kind": "estimated", "radius_km": 40.0, "area_km2": 5026.0, "population_estimate": 250000,
            "method": "test", "geojson": None}

    first = risk_mod.risk_agent.assess(db_session, inc, ctx, weather=None, area=area, facilities=[])
    second = risk_mod.risk_agent.assess(db_session, inc, ctx, weather=None, area=area, facilities=[])

    assert first["risk_score"] == pytest.approx(second["risk_score"])
    assert 0 <= first["risk_score"] <= 100
    assert first["risk_level"] in {"minimal", "low", "moderate", "high", "extreme"}
    assert first["methodology_version"] == "risk-v1.0"
    from sqlalchemy import select
    from app import models

    stored = db_session.scalar(select(models.RiskAssessment).where(models.RiskAssessment.incident_id == inc.id)
                               .order_by(models.RiskAssessment.created_at.desc()))
    assert stored is not None and stored.risk_score == first["risk_score"], "assessments must be persisted for audit"

    # every factor must be explainable: value + weight + contribution + provenance
    factors = first["factors"]
    assert factors, "a risk score with no stated factors would be un-auditable"
    for f in factors:
        assert {"factor", "value", "contribution", "note"} <= set(f)
    # component weights must sum to 1.0 and match the documented flood weights
    weights = {c["component"]: c["weight"] for c in first["weights"]}
    assert abs(sum(weights.values()) - 1.0) < 1e-9
    assert weights == risk_mod.WEIGHTS["flood"]
    # each component contribution must equal weight * score (explainable arithmetic)
    for c in first["weights"]:
        assert c["contribution"] == pytest.approx(c["weight"] * c["score"], abs=0.02)  # stored rounded to 2 dp
