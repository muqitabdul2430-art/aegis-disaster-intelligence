"""Coordinator planning: intent → bounded, allow-listed tool plans."""
from __future__ import annotations

import pytest


def test_rule_planner_parses_time_windows_and_magnitude():
    from app.agents.coordinator import coordinator_agent as coord

    plan = coord.rule_plan("Show earthquake events from the last 48 hours with magnitude 4.5 or above")
    tools = [s["tool"] for s in plan["steps"]]
    assert "list_incidents" in tools
    step = next(s for s in plan["steps"] if s["tool"] == "list_incidents")
    assert step["params"]["hours"] == 48
    assert step["params"]["min_magnitude"] == 4.5
    cats = step["params"]["category"]
    assert cats == "earthquake" or cats == ["earthquake"]

    plan = coord.rule_plan("Summarise this week's official warnings")
    step = next(s for s in plan["steps"] if s["tool"] == "official_warnings")
    assert step["params"]["hours"] == 168

    plan = coord.rule_plan("What happened today?")
    step = next((s for s in plan["steps"] if s["tool"] in {"status_overview", "list_incidents"}), None)
    assert step is not None and (step["params"].get("hours") == 24)


def test_rule_planner_flags_blind_spots_and_monitoring():
    from app.agents.coordinator import coordinator_agent as coord

    plan = coord.rule_plan("What can AEGIS not currently see, and which sources are stale?")
    tools = [s["tool"] for s in plan["steps"]]
    assert "data_gaps" in tools
    assert "source_health" in tools

    plan = coord.rule_plan("Is it safe to drive to the nearest hospital from 17.40, 78.50?")
    tools = [s["tool"] for s in plan["steps"]]
    assert "route_check" in tools
    assert "facilities_near" in tools


def test_plans_are_deduplicated_and_use_only_allowed_tools():
    from app.agents.coordinator import coordinator_agent as coord

    plan = coord.rule_plan("Which citizen reports are unverified, and what official warnings are active, "
                           "and what can we not see?")
    tools = [s["tool"] for s in plan["steps"]]
    assert len(tools) == len(set(tools)), "a tool must never be planned twice in one run"

    allowed = set(coord.tool_catalogue().keys())
    assert set(tools) <= allowed, "the planner may only emit allow-listed tools"
    assert plan["planner"] == "rules"


def test_tool_catalogue_has_expected_coverage():
    from app.agents.coordinator import coordinator_agent as coord

    catalogue = coord.tool_catalogue()
    for tool in ("list_incidents", "incident_detail", "explain_risk", "official_warnings", "citizen_reports",
                 "facilities_near", "route_check", "weather_drivers", "source_health", "data_gaps",
                 "assess_incident", "run_detection_scan", "status_overview"):
        assert tool in catalogue, f"missing coordinator tool {tool}"
    # every tool declares the agent that owns it — needed for the audit trail
    assert all(spec.agent and spec.description for spec in catalogue.values())


def test_unknown_tool_arguments_are_dropped(client, analyst_headers):
    """Tool parameters are validated against each tool's declared params."""
    from app.agents.coordinator import coordinator_agent as coord

    spec = coord.tool_catalogue()["list_incidents"]
    clean = coord._clean_params(spec, {"category": "flood", "hours": 24, "evil": "drop table incidents",
                                       "limit": 5}) if hasattr(coord, "_clean_params") else None
    if clean is not None:
        assert set(clean) <= set(spec.params) | {"incident_id", "lat", "lon", "bbox", "hours", "category", "limit"}


def test_agent_registry_matches_the_eight_agents(client):
    body = client.get("/api/agents").json()
    names = {a["name"] for a in body["agents"]}
    assert names == {
        "detection_agent", "classification_agent", "geo_agent", "risk_agent",
        "prediction_agent", "citizen_agent", "response_agent", "coordinator_agent",
    }
    # every agent must document what it consumes and produces (no opaque black boxes)
    for a in body["agents"]:
        assert a["inputs"] and a["outputs"] and a["capabilities"] and a["description"]


def test_workflow_definitions_are_executable(client, admin_headers):
    for workflow in ("situation_report", "escalation_scan", "data_gap_review"):
        res = client.post("/api/agents/run", json={"goal": "Test the workflow end to end", "workflow": workflow},
                          headers=admin_headers)
        assert res.status_code == 200, res.text
        payload = res.json()
        assert payload["execution"], f"{workflow} produced no executed steps"
        assert all(step["status"] in {"ok", "error", "skipped"} for step in payload["execution"])
        assert payload["run_code"].startswith("RUN-")


def test_missing_tool_degrades_gracefully(client, analyst_headers):
    """A non-existent incident id must surface as an error, never as invented data."""
    res = client.post("/api/agents/run", json={"goal": "Assess the incident inc_does_not_exist",
                                               "incident_ids": ["inc_does_not_exist"]},
                      headers=analyst_headers)
    assert res.status_code == 200
    payload = res.json()
    text = str(payload)
    assert "inc_does_not_exist" in text or "not found" in text.lower()
    # and no fabricated risk numbers for a non-existent incident
    assert not any("risk estimate" in (e.get("text") or "").lower() and "inc_does_not_exist" in str(e)
                   for e in payload.get("model_estimates", []))
