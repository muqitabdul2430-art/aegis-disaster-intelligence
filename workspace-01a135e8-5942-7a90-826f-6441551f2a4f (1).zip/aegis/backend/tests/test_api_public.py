"""Public API contract: what an unauthenticated visitor and a citizen may see."""
from __future__ import annotations


def test_health_reports_per_component_status(client):
    body = client.get("/api/health").json()
    assert body["status"] in {"ok", "degraded"}
    assert body["version"]
    checks = body["checks"]
    assert "database" in checks and checks["database"]["status"] == "ok"
    assert "data_sources" in checks                     # source freshness is reported, not assumed
    assert "llm" in checks and "network" in checks


def test_landing_endpoints_expose_policy(client):
    hazards = client.get("/api/hazards").json()
    assert {h["key"] for h in hazards["hazards"]} >= {"earthquake", "tsunami", "cyclone", "flood",
                                                     "wildfire", "landslide", "industrial_fire"}
    rm = hazards["risk_methodology"]
    assert rm["version"] == "risk-v1.0" and rm["formula"] and rm["limitations"]

    safety = client.get("/api/safety").json()
    assert safety["statement"] and safety["principles"] and safety["privacy"]
    assert any(c["region"] == "India" for c in safety["contacts"])

    cfg = client.get("/api/system/config").json()
    assert "llm_assistant" in cfg["features"]
    # secrets must never be exposed: only booleans about presence
    assert all(isinstance(v, bool) for v in cfg["credentials_configured"].values())


def test_source_catalogue_is_honest_about_capability(client):
    body = client.get("/api/sources/catalog").json()
    by_key = {s["key"]: s for s in body["sources"]}
    assert by_key["usgs_earthquake"]["capability"] == "live_now"
    assert by_key["nasa_firms"]["auth_mode"] == "api_key"
    assert by_key["nasa_firms"]["credential_env"] == "AEGIS_FIRMS_MAP_KEY"
    # link-only sources must exist and be labelled as such, never faked
    assert any(s["capability"] == "link_only" for s in body["sources"])
    assert isinstance(body["network"]["live_network_enabled"], bool)


def test_incident_filters_are_server_side(client):
    all_incidents = client.get("/api/incidents?limit=50").json()
    assert "incidents" in all_incidents and "total" in all_incidents

    quakes = client.get("/api/incidents?category=earthquake&limit=50").json()
    assert all(i["category"] == "earthquake" for i in quakes["incidents"])

    severe = client.get("/api/incidents?min_severity=5&limit=50").json()
    assert all(i["severity"] >= 5 for i in severe["incidents"])

    empty = client.get("/api/incidents?category=tsunami&min_severity=5&hours=1&limit=50").json()
    assert empty["incidents"] == [], "an empty result must be reported as empty, not padded with samples"


def test_assistant_answer_labels_evidence_classes(client):
    res = client.post("/api/assistant/ask", json={"question": "What official warnings are active right now?",
                                                  "context": {}})
    assert res.status_code == 200, res.text
    body = res.json()
    assert body.get("answer")
    for key in ("verified_facts", "model_estimates", "unverified_reports", "data_gaps", "sources"):
        assert key in body, f"assistant payload must separate {key}"
    # the answer must expose the plan, the executed tools and the retrieval note
    assert body.get("execution"), "an assistant answer without its tool execution would be unauditable"
    assert body.get("retrieval_note") and body.get("separation_note")
    # it must never claim to be an official warning service
    text = (body["answer"] + " " + (body.get("disclaimer") or "")).lower()
    assert "not an official" in text or "official warning" in text


def test_report_tracking_requires_a_code(client):
    assert client.get("/api/reports/track/RPT-NOPE").status_code in (403, 404)
    # the raw report queue (with coordinates and contact opt-in) is analyst-only
    assert client.get("/api/reports").status_code in (401, 403)
