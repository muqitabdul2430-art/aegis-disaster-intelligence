"""Citizen reporting: validation, anti-abuse, privacy handling and analyst review."""
from __future__ import annotations

import io

from sqlalchemy import select

PNG = (b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + b"\x00" * 64)   # header is enough for the validator


def _submit(client, photo=None, **over):
    data = {
        "description": "Knee-deep water across the main road near the bus depot; two vehicles stalled.",
        "category": "flood", "lat": "17.4120", "lon": "78.5050", "location_source": "gps",
    }
    data.update(over)
    files = {"photo": photo} if photo else None
    return client.post("/api/reports", data=data, files=files)


def test_validation_rejects_out_of_range_and_short_input(client):
    bad_lat = client.post("/api/reports", data={"description": "x" * 25, "lat": "99", "lon": "78.5"})
    assert bad_lat.status_code == 422
    detail = bad_lat.json()["detail"]
    assert detail["errors"] and "lat" in detail["errors"][0]
    assert detail["note"]

    assert _submit(client, description="too short").status_code == 422
    assert _submit(client, location_source="telepathy").status_code == 422
    assert _submit(client, lat="17.4", lon="999").status_code == 422


def test_submission_is_unverified_and_trackable(client, db_session):
    from app import models

    res = _submit(client)
    assert res.status_code == 201, res.text
    body = res.json()
    assert body["public_code"].startswith("RPT-")
    assert body["status"] in {"submitted", "unverified", "pending", "duplicate"}
    assert body.get("privacy_note")

    # stored as unverified citizen input — never silently promoted to a fact
    row = db_session.scalar(select(models.CitizenReport).where(models.CitizenReport.public_code == body["public_code"]))
    assert row is not None
    assert row.status in {"submitted", "unverified"}, "a fresh report is never pre-verified"
    assert row.linked_incident_id is None

    # the reporter can track it with the code alone
    tracked = client.get(f"/api/reports/track/{body['public_code']}")
    assert tracked.status_code == 200
    tracked_body = tracked.json()
    assert tracked_body.get("public_code") == body["public_code"] or tracked_body.get("report")


def test_duplicate_reports_are_detected_not_stored_twice(client, db_session):
    from app import models

    # unique coordinates so unrelated reports cannot interfere with this check
    first = _submit(client, lat="18.6011", lon="73.9011",
                    description="AEGIS duplicate-detection probe one: blocked culvert overflowing badly.")
    assert first.status_code == 201
    second = _submit(client, lat="18.6012", lon="73.9012",
                     description="AEGIS duplicate-detection probe two: blocked culvert overflowing badly.")
    assert second.status_code == 201
    body = second.json()
    assert body["status"] == "duplicate", "a near-identical report from the same place must be flagged"
    assert body.get("duplicate_of") or body.get("matched_code") or "match" in str(body).lower()

    rows = db_session.scalars(select(models.CitizenReport).where(
        models.CitizenReport.lat.between(18.60, 18.61),
        models.CitizenReport.lon.between(73.90, 73.92))).all()
    live = [r for r in rows if r.status != "duplicate"]
    assert len(live) == 1, "only one report may be actionable; the echo must be marked duplicate"
    assert all(r.linked_incident_id is None for r in rows), \
        "an unverified report may not be attached to an incident without human review"


def test_privacy_reduces_coordinates_and_hashes_identity(client, db_session):
    from app import models

    res = client.post("/api/reports", data={
        "description": "Photos taken from the terrace: smoke column above the industrial estate.",
        "category": "industrial_fire", "lat": "17.45123", "lon": "78.52123",
        "location_source": "gps", "reporter_ref": "device-abc-123",
    })
    assert res.status_code == 201
    row = db_session.scalar(select(models.CitizenReport)
                            .where(models.CitizenReport.public_code == res.json()["public_code"]))
    assert row is not None
    # public-facing precision is reduced; the raw identity is not stored as a plain string
    assert abs(row.lat - 17.45123) < 0.001 and abs(row.lon - 78.52123) < 0.001   # stored for response
    assert "device-abc-123" not in (row.reporter_hash or "")
    assert row.reporter_hash and len(row.reporter_hash) >= 16


def test_photo_type_and_size_are_enforced(client):
    png = _submit(client, lat="18.701", lon="73.801",
                  photo=("flood.png", io.BytesIO(PNG), "image/png"))
    assert png.status_code == 201, png.text          # a real image is accepted
    assert png.json().get("photo_available") in (True, None)

    exe = _submit(client, lat="18.702", lon="73.802",
                  photo=("payload.exe", io.BytesIO(b"MZ\x90\x00"), "application/x-msdownload"))
    assert exe.status_code == 415, "non-image uploads must be refused"

    big = _submit(client, lat="18.703", lon="73.803",
                  photo=("huge.jpg", io.BytesIO(b"\xff\xd8\xff" + b"0" * (7 * 1024 * 1024)), "image/jpeg"))
    assert big.status_code == 413, "oversized uploads must be refused before hitting storage"


def test_analyst_review_can_attach_report_to_incident(client, analyst_headers, db_session):
    from app import models
    from app.util import now

    inc = models.Incident(id="inc_test_report_1", code="AEGIS-TEST-REPORT-1", title="Test flood incident",
                          category="flood", status="active", verification_status="corroborated", severity=3,
                          confidence=70.0, lat=17.412, lon=78.505, region="Test", country="India",
                          country_iso3="IND", started_at=now(), data_origin="live")
    db_session.add(inc)
    db_session.commit()

    res = client.post("/api/reports", data={
        "description": "Road submerged near the depot; water is still rising along the service lane.",
        "category": "flood", "lat": "17.4125", "lon": "78.5045", "location_source": "gps"})
    report_id = db_session.scalar(select(models.CitizenReport.id).where(
        models.CitizenReport.public_code == res.json()["public_code"]))
    assert report_id

    review = client.post(f"/api/reports/{report_id}/review",
                         json={"action": "link", "incident_id": inc.id,
                               "note": "Matched to the district flood incident; corroborates the gauge reading."},
                         headers=analyst_headers)
    assert review.status_code == 200, review.text

    db_session.expire_all()
    row = db_session.get(models.CitizenReport, report_id)
    assert row.linked_incident_id == inc.id
    # the analyst decision is audited
    audit = db_session.scalars(select(models.AuditLog).where(models.AuditLog.entity_id == report_id)).all()
    assert audit
    # …and a citizen may not do this
    assert client.post(f"/api/reports/{report_id}/review", json={"action": "reject"},
                       headers=None).status_code in (401, 403)


def test_photo_is_analyst_only(client, analyst_headers, db_session):
    from app import models

    res = _submit(client, lat="18.704", lon="73.804",
                  photo=("flood.png", io.BytesIO(PNG), "image/png"),
                  description="Photograph attached to this report for analyst review only.")
    assert res.status_code == 201, res.text
    report_id = db_session.scalar(select(models.CitizenReport.id).where(
        models.CitizenReport.public_code == res.json()["public_code"]))
    anon = client.get(f"/api/reports/{report_id}/photo")
    assert anon.status_code in (401, 403), "citizen photos must never be publicly retrievable"
