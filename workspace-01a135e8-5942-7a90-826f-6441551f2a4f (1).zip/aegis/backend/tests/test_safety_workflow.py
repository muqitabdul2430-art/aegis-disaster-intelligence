"""Safety-critical behaviour.

These are the tests that matter most for a platform like AEGIS: nothing may
publish itself, official warnings may not be "approved" by AEGIS, unverified
citizen input stays unverified, and privileged actions require the right role.
"""
from __future__ import annotations

import pytest
from sqlalchemy import select


def _make_incident(db, **over):
    from app import models
    from app.util import now

    data = dict(
        id="inc_test_alert_1", code="AEGIS-TEST-ALERT-1", title="Test storm surge", category="cyclone",
        status="active", verification_status="corroborated", severity=5, confidence=85.0,
        lat=19.3, lon=85.8, region="Off Odisha coast", country="India", country_iso3="IND",
        started_at=now(), data_origin="live", primary_source_key="nhc",
    )
    data.update(over)
    inc = models.Incident(**data)
    db.add(inc)
    db.flush()
    return inc


def test_draft_alert_refuses_to_draft_without_escalation(db_session):
    """No escalation ⇒ no draft. AEGIS must not manufacture warnings."""
    from app.agents import prediction_agent as pred

    inc = _make_incident(db_session)
    risk = {"risk_score": 40.0, "risk_level": "moderate", "hazard_score": 50.0, "exposure_score": 30.0,
            "vulnerability_score": 55.0, "methodology_version": "risk-v1.0", "confidence": 70.0}
    trend = {"direction": "stable", "note": "no significant change", "samples": 3}
    forecast = {"available": False, "items": []}

    assert pred.prediction_agent.draft_alert(db_session, inc, risk, trend, forecast, None) is None


def test_draft_alert_is_pending_review_and_labelled(db_session):
    """An escalation produces a DRAFT — never a published advisory."""
    from app.agents import prediction_agent as pred
    from app import models

    inc = _make_incident(db_session, id="inc_test_alert_2", code="AEGIS-TEST-ALERT-2")
    risk = {"risk_score": 74.0, "risk_level": "high", "hazard_score": 88.0, "exposure_score": 61.0,
            "vulnerability_score": 55.0, "methodology_version": "risk-v1.0", "confidence": 72.0}
    trend = {"direction": "escalating", "note": "risk up 11 pts over 2 assessments", "samples": 3}
    forecast = {"available": True, "items": [{"label": "NHC advisory 024a", "url": "https://www.nhc.noaa.gov/"}]}

    alert = pred.prediction_agent.draft_alert(db_session, inc, risk, trend, forecast, None)
    assert alert is not None
    assert alert.status == "pending_review", "drafts must await a human decision"
    assert alert.review_required is True
    assert alert.alert_kind == "ai_advisory"
    assert alert.reviewed_by is None and alert.reviewed_at is None
    # the body must carry the safety framing and the traceable basis
    assert "NOT AN OFFICIAL WARNING" in alert.body
    assert "model estimate" in alert.body
    assert inc.code in alert.body
    assert alert.instructions, "protective actions must come from the published guidance table"

    # a second identical escalation must not spam duplicate drafts
    again = pred.prediction_agent.draft_alert(db_session, inc, risk, trend, forecast, None)
    assert again is None

    # and it must be visible to analysts in the review queue
    rows = db_session.scalars(select(models.Alert).where(models.Alert.status == "pending_review")).all()
    assert alert.id in {r.id for r in rows}


def test_publishing_requires_a_note(db_session):
    """The schema refuses a publish decision without a reviewer note."""
    from app.schemas import AlertReviewRequest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        AlertReviewRequest(decision="publish", note="ok")
    assert AlertReviewRequest(decision="publish", note="Authorised by duty officer A. Rao after comparing NHC advisory 024a.")


def test_official_alerts_cannot_be_approved_by_aegis(client, db_session, analyst_headers):
    """Official warnings are ingest-only: AEGIS may not endorse, edit or publish them."""
    from app import models
    from app.util import now

    alert = models.Alert(
        id="alt_test_official_1", alert_kind="official_ingested", severity="severe", hazard="tsunami",
        title="Tsunami Information — test", body="Official text, unaltered.", area_text="Test ocean",
        issued_at=now(), authority="NOAA/NWS Pacific Tsunami Warning Center", source_key="noaa_tsunami",
        source_url="https://www.tsunami.gov/", confidence=95.0, status="published", review_required=False,
        generated_by="ingest", data_origin="live",
    )
    db_session.add(alert)
    db_session.commit()

    res = client.post(f"/api/alerts/{alert.id}/review",
                      json={"decision": "publish", "note": "attempting to endorse an official product"},
                      headers=analyst_headers)
    assert res.status_code == 409
    assert "official" in res.json()["detail"].lower()

    db_session.expire_all()
    assert db_session.get(models.Alert, alert.id).status == "published", "the ingested alert must be untouched"


def test_publish_flow_end_to_end(client, db_session, analyst_headers):
    """Draft → analyst publish with note → visible in the public feed + audited."""
    from app import models
    from app.util import now

    alert = models.Alert(
        id="alt_test_publish_1", incident_id=None, alert_kind="ai_advisory", severity="high", hazard="cyclone",
        title="High risk — test advisory", body="AEGIS DRAFT ADVISORY — NOT AN OFFICIAL WARNING.",
        instructions=["Follow official guidance"], area_text="Test area", lat=19.3, lon=85.8,
        issued_at=now(), source_key="aegis_prediction_agent", confidence=70.0,
        status="pending_review", review_required=True, generated_by="prediction_agent", data_origin="live",
    )
    db_session.add(alert)
    db_session.commit()

    pending = client.get("/api/alerts/pending", headers=analyst_headers).json()
    assert any(a["id"] == alert.id for a in pending["alerts"])

    res = client.post(f"/api/alerts/{alert.id}/review",
                      json={"decision": "publish", "notify_channels": ["in_app"],
                            "note": "Reviewed against the current bulletin; approving in-app publication only."},
                      headers=analyst_headers)
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["alert"]["status"] == "published"
    assert body["alert"]["review_required"] is False
    assert "NOT an official" in body["note"] or "not an official" in body["note"].lower()

    # audit trail records who did it and why
    db_session.expire_all()
    audit = db_session.scalar(select(models.AuditLog).where(models.AuditLog.entity_id == alert.id,
                                                           models.AuditLog.action == "alert.publish"))
    assert audit is not None and audit.reason.startswith("Reviewed against")

    # citizens (and guests) now see it; drafts were never visible to them
    anon = client.get("/api/alerts").json()
    assert any(a["id"] == alert.id for a in anon["alerts"])


def test_citizen_cannot_take_operator_actions(client, citizen_headers, db_session, analyst_headers):
    from app import models
    from app.util import now

    incident = _make_incident(db_session, id="inc_test_rbac_1", code="AEGIS-TEST-RBAC-1")
    db_session.commit()

    assert client.post(f"/api/incidents/{incident.id}/verify", json={"verification_status": "human_verified",
                                                                     "note": "citizen attempt"},
                       headers=citizen_headers).status_code == 403
    assert client.post("/api/agents/run", json={"goal": "run the whole system"}, headers=citizen_headers).status_code == 403
    assert client.post("/api/sources/ingest", json={}, headers=citizen_headers).status_code == 403
    # but the same calls succeed for an analyst
    ok = client.post("/api/agents/run", json={"goal": "Summarise the current situation"}, headers=analyst_headers)
    assert ok.status_code == 200, ok.text
    assert ok.json()["execution"], "an agent run must report its executed steps"
    # agent runs are audited
    audit = db_session.scalars(select(models.AuditLog).where(models.AuditLog.action == "agent.run")).all()
    assert audit, "agent runs must be audited"
    assert audit is not None


def test_agent_run_separates_fact_from_estimate(client, admin_headers):
    res = client.post("/api/agents/run", json={"goal": "What is happening right now and what can we not see?"},
                      headers=admin_headers)
    assert res.status_code == 200, res.text
    payload = res.json()
    # the four buckets must always be present and explicitly separated
    for key in ("verified_facts", "model_estimates", "unverified_reports", "data_gaps", "separation_note"):
        assert key in payload, f"agent run payload missing {key}"
    assert payload["separation_note"]
    for est in payload["model_estimates"]:
        assert "estimate" in (est.get("text") or "").lower(), "estimates must be labelled as estimates"
