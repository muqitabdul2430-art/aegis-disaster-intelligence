"""AEGIS application entrypoint.

Serves:
*   REST API              → /api/*  (OpenAPI docs at /api/docs)
*   Built SPA             → /       (from backend/static, produced by `npm run build`
                                    in frontend/; the output directory is used instead of
                                    Vite's default `dist/` so the compiled UI persists
                                    in the repository workspace)
*   Offline basemap data  → /data/*  (Natural Earth country polygons + populated places,
                                    public domain, so the map works without internet)
*   No-build fallback     → /       (a small self-contained status page when no build
                                    exists yet, which never pretends the full app is up)
"""
from __future__ import annotations

import logging
import time
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import REPO_DIR, settings
from .routers import agents_api, alerts, assistant, auth, dashboard, geo, incidents, reports, sources, system

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s — %(message)s",
)
log = logging.getLogger("aegis")

app = FastAPI(
    title="AEGIS API",
    version=settings.version,
    description=(
        "AEGIS — Agentic AI Multi-Disaster Intelligence & Early-Warning Platform.\n\n"
        "Decision support only: AEGIS is not an official warning service. Official warnings are displayed with their "
        "issuing authority; AEGIS risk values are labelled model estimates."
    ),
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Response-Time-ms", "X-AEGIS-Version"],
)


@app.middleware("http")
async def timing_and_errors(request: Request, call_next):
    t0 = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception as exc:  # noqa: BLE001
        log.exception("unhandled error on %s %s", request.method, request.url.path)
        return JSONResponse(status_code=500, content={
            "error": "internal_error",
            "message": f"{exc.__class__.__name__}: AEGIS hit an unexpected error. The failure has been logged.",
            "path": request.url.path,
        })
    response.headers["X-Response-Time-ms"] = f"{(time.perf_counter() - t0) * 1000:.1f}"
    response.headers["X-AEGIS-Version"] = settings.version
    return response


for router in (auth.router, dashboard.router, incidents.router, geo.router, agents_api.router,
               assistant.router, reports.router, alerts.router, sources.router, system.router):
    app.include_router(router)


@app.get("/api", include_in_schema=False)
def api_root():
    return {
        "app": "AEGIS", "version": settings.version, "docs": "/api/docs",
        "endpoints": sorted({r.path for r in app.routes if getattr(r, "path", "").startswith("/api")}),
        "safety": "Decision-support platform. Not an official warning service.",
    }


@app.on_event("startup")
def _startup() -> None:
    from . import scheduler
    from .seed import bootstrap

    info = bootstrap()
    log.info("bootstrap complete: %s", {k: (len(v) if isinstance(v, list) else v) for k, v in info.items()})
    if settings.scheduler_enabled:
        scheduler.start()
    log.info("AEGIS %s ready (demo_mode=%s, llm=%s, live_network=%s, ui=%s)",
             settings.version, settings.demo_mode, settings.llm_enabled, settings.enable_live_network,
             "built" if BUILT_UI else "no-build-fallback")


@app.on_event("shutdown")
def _shutdown() -> None:
    from . import scheduler

    scheduler.stop()


# --------------------------------------------------------------------------- #
# Frontend hosting
# --------------------------------------------------------------------------- #
BUILD_DIR = Path(settings.frontend_dist)          # backend/static by default
SOURCE_DATA = REPO_DIR / "frontend" / "public" / "data"
BUILT_UI = (BUILD_DIR / "index.html").exists()

# Offline basemap data (public domain Natural Earth extracts) — served either way.
if (BUILD_DIR / "data").exists():
    app.mount("/data", StaticFiles(directory=BUILD_DIR / "data"), name="data")
elif SOURCE_DATA.exists():
    app.mount("/data", StaticFiles(directory=SOURCE_DATA), name="data")

if BUILT_UI:
    if (BUILD_DIR / "assets").exists():
        app.mount("/assets", StaticFiles(directory=BUILD_DIR / "assets"), name="assets")

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(BUILD_DIR / "index.html")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa_or_asset(full_path: str):
        if full_path.startswith("api/"):
            return JSONResponse(status_code=404, content={"error": "not_found", "path": f"/{full_path}"})
        candidate = BUILD_DIR / full_path
        if candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(BUILD_DIR / "index.html")

else:
    FALLBACK_HTML = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>AEGIS — API is running, UI not built</title>
<style>
 :root{color-scheme:dark}
 body{margin:0;background:#050a16;color:#e2e8f0;font:14px/1.6 Inter,system-ui,Segoe UI,Roboto,sans-serif;display:grid;place-items:center;min-height:100vh}
 .card{max-width:720px;padding:28px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:#0a1224}
 h1{margin:0 0 6px;font-size:20px}code{background:#132240;padding:1px 5px;border-radius:5px;font-size:12px}
 a{color:#22d3ee}ul{margin:8px 0 0 18px;padding:0}.muted{color:#94a3b8;font-size:12px}
 .pill{display:inline-block;border:1px solid rgba(34,211,238,.35);background:rgba(34,211,238,.08);color:#67e8f9;border-radius:999px;padding:2px 9px;font-size:11px;margin-bottom:12px}
</style></head><body><div class="card">
<span class="pill">API ONLINE · UI NOT BUILT</span>
<h1>AEGIS backend is running</h1>
<p>The compiled interface was not found at <code>backend/static</code>. Build it once with:</p>
<pre><code>cd frontend &amp;&amp; npm install &amp;&amp; npm run build</code></pre>
<p class="muted">Then reload this page. Meanwhile the API is fully usable:</p>
<ul>
  <li><a href="/api/docs">Interactive API documentation</a></li>
  <li><a href="/api/health">Health &amp; source status</a></li>
  <li><a href="/api/incidents">Active incidents</a></li>
  <li><a href="/api/dashboard/summary">Dashboard aggregate</a></li>
  <li><a href="/api/alerts">Alerts (official + AEGIS advisories)</a></li>
</ul>
<p class="muted" style="margin-top:14px">AEGIS is a decision-support platform, not an official warning service.
Official warnings come only from the issuing authority.</p>
</div></body></html>"""

    @app.get("/", include_in_schema=False)
    def fallback_index():
        return HTMLResponse(FALLBACK_HTML)

    @app.get("/{full_path:path}", include_in_schema=False)
    def fallback(full_path: str):
        if full_path.startswith("api/"):
            return JSONResponse(status_code=404, content={"error": "not_found", "path": f"/{full_path}"})
        if full_path in {"index.html", ""}:
            return HTMLResponse(FALLBACK_HTML)
        return JSONResponse(status_code=404, content={
            "error": "not_found",
            "message": "The interface has not been built in this deployment. Run `npm run build` in frontend/.",
            "api_docs": "/api/docs",
        })
