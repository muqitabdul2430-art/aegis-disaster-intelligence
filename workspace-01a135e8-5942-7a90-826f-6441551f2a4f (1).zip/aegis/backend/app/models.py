"""AEGIS relational model.

Mirrors scripts/postgis_schema.sql (PostgreSQL + PostGIS production schema).
Design notes
------------
*   Every fact carries provenance: `source_key`, `source_url`, `data_origin`
    ('live' | 'demo'), `observed_at` and an ingestion timestamp.
*   Verification status is a first-class, audited field so the UI can always
    separate: confirmed events, preliminary detections, model estimates and
    unverified citizen reports.
*   Agent work is persisted (agent_runs / agent_tasks) including tool calls,
    enabling a full execution timeline and traceability.
"""
from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def utcnow() -> dt.datetime:
    """Naive UTC now — single convention across all engines."""
    return dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


# --------------------------------------------------------------------------- #
# Users / access control
# --------------------------------------------------------------------------- #
class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("usr"))
    email: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200), default="")
    org: Mapped[str] = mapped_column(String(200), default="")
    role: Mapped[str] = mapped_column(String(20), default="citizen")  # citizen|analyst|admin
    password_hash: Mapped[str] = mapped_column(String(256))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    last_login_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


# --------------------------------------------------------------------------- #
# Data source registry + sync health
# --------------------------------------------------------------------------- #
class DataSource(Base):
    __tablename__ = "data_sources"

    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    provider: Mapped[str] = mapped_column(String(120), default="")
    homepage: Mapped[str] = mapped_column(String(400), default="")
    docs_url: Mapped[str] = mapped_column(String(400), default="")
    license: Mapped[str] = mapped_column(String(200), default="")
    categories: Mapped[list] = mapped_column(JSON, default=list)   # disaster types covered
    auth_mode: Mapped[str] = mapped_column(String(40), default="none")  # none|api_key|token|registration
    credential_env: Mapped[str] = mapped_column(String(80), default="")
    status: Mapped[str] = mapped_column(String(30), default="unknown")  # ok|degraded|error|stale|disabled|no_credentials|unknown
    last_attempt_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    last_ok_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    records_last_fetch: Mapped[int] = mapped_column(Integer, default=0)
    total_records: Mapped[int] = mapped_column(Integer, default=0)
    reliability_note: Mapped[str] = mapped_column(Text, default="")
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)


class SourceSyncLog(Base):
    __tablename__ = "source_sync_logs"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("syn"))
    source_key: Mapped[str] = mapped_column(String(60), index=True)
    started_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="running")  # running|ok|error|no_credentials|skipped
    records: Mapped[int] = mapped_column(Integer, default=0)
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    message: Mapped[str | None] = mapped_column(Text, nullable=True)


# --------------------------------------------------------------------------- #
# Raw observations (immutable-ish sensor/source records)
# --------------------------------------------------------------------------- #
class Observation(Base):
    __tablename__ = "observations"
    __table_args__ = (UniqueConstraint("source_key", "fingerprint", name="uq_obs_fingerprint"),)

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("obs"))
    source_key: Mapped[str] = mapped_column(String(60), index=True)
    external_id: Mapped[str] = mapped_column(String(160), default="")
    fingerprint: Mapped[str] = mapped_column(String(200), index=True)
    hazard_hint: Mapped[str] = mapped_column(String(40), default="unknown")
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    place: Mapped[str] = mapped_column(String(300), default="")
    country: Mapped[str] = mapped_column(String(120), default="")
    magnitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    magnitude_unit: Mapped[str] = mapped_column(String(30), default="")
    observed_at: Mapped[dt.datetime] = mapped_column(DateTime, index=True)
    ingested_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    source_url: Mapped[str] = mapped_column(String(500), default="")
    data_origin: Mapped[str] = mapped_column(String(10), default="live")  # live|demo
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)  # 0-100 source/instrument confidence
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    incident_id: Mapped[str | None] = mapped_column(ForeignKey("incidents.id"), nullable=True, index=True)


# --------------------------------------------------------------------------- #
# Incidents
# --------------------------------------------------------------------------- #
class Incident(Base):
    __tablename__ = "incidents"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("inc"))
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)  # human readable, e.g. AEGIS-EQ-000123
    title: Mapped[str] = mapped_column(String(300))
    category: Mapped[str] = mapped_column(String(40), index=True)  # wildfire|cyclone|flood|tsunami|landslide|earthquake|industrial_fire|unknown
    # lifecycle
    status: Mapped[str] = mapped_column(String(30), default="active", index=True)  # active|monitoring|closed|archived
    # how well established the event is
    verification_status: Mapped[str] = mapped_column(String(40), default="preliminary_detection", index=True)
    # preliminary_detection | corroborated | human_verified | officially_confirmed | rejected | unverified_citizen
    severity: Mapped[int] = mapped_column(Integer, default=1)  # 1-5
    confidence: Mapped[float] = mapped_column(Float, default=40.0)  # 0-100

    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    depth_km: Mapped[float | None] = mapped_column(Float, nullable=True)
    region: Mapped[str] = mapped_column(String(300), default="")
    country: Mapped[str] = mapped_column(String(120), default="")
    country_iso3: Mapped[str] = mapped_column(String(6), default="")

    started_at: Mapped[dt.datetime] = mapped_column(DateTime, index=True)
    last_update_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    closed_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)

    summary: Mapped[str] = mapped_column(Text, default="")
    detection_agent: Mapped[str] = mapped_column(String(60), default="detection_agent")
    classification_agent: Mapped[str] = mapped_column(String(60), default="")
    classification_note: Mapped[str] = mapped_column(Text, default="")
    is_ambiguous: Mapped[bool] = mapped_column(Boolean, default=False)  # needs human review
    primary_source_key: Mapped[str] = mapped_column(String(60), default="")
    source_keys: Mapped[list] = mapped_column(JSON, default=list)
    source_urls: Mapped[list] = mapped_column(JSON, default=list)
    data_origin: Mapped[str] = mapped_column(String(10), default="live", index=True)
    merged_into_id: Mapped[str | None] = mapped_column(ForeignKey("incidents.id"), nullable=True)
    tags: Mapped[list] = mapped_column(JSON, default=list)
    external_refs: Mapped[dict] = mapped_column(JSON, default=dict)  # e.g. {"gdacs": "1001335", "usgs": "us6000u214"}

    verified_by: Mapped[str | None] = mapped_column(String(40), nullable=True)
    verified_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)

    observations: Mapped[list["Observation"]] = relationship(back_populates=None, primaryjoin="Observation.incident_id == Incident.id", viewonly=True)


class IncidentEvidence(Base):
    __tablename__ = "incident_evidence"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("evd"))
    incident_id: Mapped[str] = mapped_column(ForeignKey("incidents.id"), index=True)
    kind: Mapped[str] = mapped_column(String(40), default="observation")  # observation|official_alert|citizen_report|forecast|derived
    source_key: Mapped[str] = mapped_column(String(60), default="")
    source_url: Mapped[str] = mapped_column(String(500), default="")
    title: Mapped[str] = mapped_column(String(300), default="")
    excerpt: Mapped[str] = mapped_column(Text, default="")
    observed_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    data_origin: Mapped[str] = mapped_column(String(10), default="live")
    added_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    added_by: Mapped[str] = mapped_column(String(60), default="system")


class AffectedArea(Base):
    __tablename__ = "affected_areas"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("aar"))
    incident_id: Mapped[str] = mapped_column(ForeignKey("incidents.id"), index=True)
    label: Mapped[str] = mapped_column(String(200), default="")
    geometry_geojson: Mapped[dict] = mapped_column(JSON, default=dict)
    area_km2: Mapped[float | None] = mapped_column(Float, nullable=True)
    radius_km: Mapped[float | None] = mapped_column(Float, nullable=True)
    population_estimate: Mapped[int | None] = mapped_column(Integer, nullable=True)
    population_method: Mapped[str] = mapped_column(String(200), default="")
    method: Mapped[str] = mapped_column(String(200), default="")
    is_estimate: Mapped[bool] = mapped_column(Boolean, default=True)   # always true unless authoritative polygon
    authority: Mapped[str] = mapped_column(String(200), default="")    # issuing authority when authoritative
    source_key: Mapped[str] = mapped_column(String(60), default="")
    method_version: Mapped[str] = mapped_column(String(30), default="geo-v1")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)


# --------------------------------------------------------------------------- #
# Risk assessment (explainable, versioned)
# --------------------------------------------------------------------------- #
class RiskAssessment(Base):
    __tablename__ = "risk_assessments"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("rsk"))
    incident_id: Mapped[str] = mapped_column(ForeignKey("incidents.id"), index=True)
    risk_level: Mapped[str] = mapped_column(String(20), default="moderate")  # minimal|low|moderate|high|extreme
    risk_score: Mapped[float] = mapped_column(Float, default=0.0)  # 0-100
    hazard_score: Mapped[float] = mapped_column(Float, default=0.0)
    exposure_score: Mapped[float] = mapped_column(Float, default=0.0)
    vulnerability_score: Mapped[float] = mapped_column(Float, default=0.0)
    confidence: Mapped[float] = mapped_column(Float, default=40.0)
    factors: Mapped[list] = mapped_column(JSON, default=list)  # [{factor, value, weight, contribution, note, source}]
    methodology_version: Mapped[str] = mapped_column(String(30), default="risk-v1.0")
    narrative: Mapped[str] = mapped_column(Text, default="")
    limitations: Mapped[str] = mapped_column(Text, default="")
    agent: Mapped[str] = mapped_column(String(60), default="risk_agent")
    llm_used: Mapped[bool] = mapped_column(Boolean, default=False)
    data_origin: Mapped[str] = mapped_column(String(10), default="live")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)


# --------------------------------------------------------------------------- #
# Citizen reports
# --------------------------------------------------------------------------- #
class CitizenReport(Base):
    __tablename__ = "citizen_reports"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("rep"))
    public_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    category: Mapped[str] = mapped_column(String(40), default="unknown")
    description: Mapped[str] = mapped_column(Text)
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    location_accuracy_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    location_source: Mapped[str] = mapped_column(String(40), default="manual")
    place: Mapped[str] = mapped_column(String(300), default="")
    photo_path: Mapped[str | None] = mapped_column(String(300), nullable=True)
    photo_sha256: Mapped[str | None] = mapped_column(String(80), nullable=True)
    # privacy: reporter identity is stored only as a salted hash + optional opt-in contact
    reporter_hash: Mapped[str] = mapped_column(String(80), default="")
    contact_optin: Mapped[str | None] = mapped_column(String(200), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="submitted", index=True)
    # submitted|duplicate|under_review|verified|rejected|linked
    priority: Mapped[str] = mapped_column(String(20), default="normal")  # normal|high|critical
    flags: Mapped[list] = mapped_column(JSON, default=list)  # spam/duplicate/triage flags
    duplicate_of_id: Mapped[str | None] = mapped_column(ForeignKey("citizen_reports.id"), nullable=True)
    linked_incident_id: Mapped[str | None] = mapped_column(ForeignKey("incidents.id"), nullable=True)
    review_notes: Mapped[str] = mapped_column(Text, default="")
    reviewed_by: Mapped[str | None] = mapped_column(String(40), nullable=True)
    reviewed_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    data_origin: Mapped[str] = mapped_column(String(10), default="live")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)


# --------------------------------------------------------------------------- #
# Alerts + notifications + acknowledgements
# --------------------------------------------------------------------------- #
class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("alt"))
    incident_id: Mapped[str | None] = mapped_column(ForeignKey("incidents.id"), nullable=True, index=True)
    alert_kind: Mapped[str] = mapped_column(String(30), default="ai_advisory")
    # official_ingested | ai_advisory | citizen_derived | system
    severity: Mapped[str] = mapped_column(String(20), default="moderate")  # minor|moderate|severe|extreme
    hazard: Mapped[str] = mapped_column(String(40), default="unknown")
    title: Mapped[str] = mapped_column(String(300))
    body: Mapped[str] = mapped_column(Text, default="")
    instructions: Mapped[list] = mapped_column(JSON, default=list)  # recommended protective actions
    area_text: Mapped[str] = mapped_column(String(400), default="")
    area_geojson: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    issued_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    effective_from: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    authority: Mapped[str] = mapped_column(String(200), default="")  # issuing authority (official alerts only)
    source_key: Mapped[str] = mapped_column(String(60), default="")
    source_url: Mapped[str] = mapped_column(String(500), default="")
    confidence: Mapped[float] = mapped_column(Float, default=50.0)
    status: Mapped[str] = mapped_column(String(30), default="draft", index=True)
    # draft|pending_review|approved|published|rejected|expired
    review_required: Mapped[bool] = mapped_column(Boolean, default=True)
    reviewed_by: Mapped[str | None] = mapped_column(String(40), nullable=True)
    reviewed_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    review_note: Mapped[str] = mapped_column(Text, default="")
    generated_by: Mapped[str] = mapped_column(String(60), default="")
    llm_used: Mapped[bool] = mapped_column(Boolean, default=False)
    data_origin: Mapped[str] = mapped_column(String(10), default="live")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    external_id: Mapped[str] = mapped_column(String(160), default="")


class AlertAcknowledgement(Base):
    __tablename__ = "alert_acknowledgements"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("ack"))
    alert_id: Mapped[str] = mapped_column(ForeignKey("alerts.id"), index=True)
    user_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    acknowledged_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    note: Mapped[str] = mapped_column(Text, default="")
    status_at_ack: Mapped[str] = mapped_column(String(30), default="published")


class NotificationLog(Base):
    __tablename__ = "notifications"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("ntf"))
    alert_id: Mapped[str] = mapped_column(ForeignKey("alerts.id"), index=True)
    channel: Mapped[str] = mapped_column(String(20))  # email|sms|push|webhook|in_app
    target: Mapped[str] = mapped_column(String(200), default="")
    status: Mapped[str] = mapped_column(String(20), default="queued")  # queued|sent|failed|not_configured
    detail: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    sent_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)


# --------------------------------------------------------------------------- #
# Agent execution records
# --------------------------------------------------------------------------- #
class AgentRun(Base):
    __tablename__ = "agent_runs"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("run"))
    run_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    goal: Mapped[str] = mapped_column(Text, default="")
    trigger: Mapped[str] = mapped_column(String(30), default="manual")  # manual|schedule|ingest|user_query|api
    status: Mapped[str] = mapped_column(String(20), default="running", index=True)
    # running|completed|completed_with_errors|failed|awaiting_approval|cancelled
    plan: Mapped[list] = mapped_column(JSON, default=list)
    summary: Mapped[str] = mapped_column(Text, default="")
    report: Mapped[dict] = mapped_column(JSON, default=dict)
    llm_mode: Mapped[str] = mapped_column(String(30), default="rules")  # rules|llm
    llm_model: Mapped[str] = mapped_column(String(80), default="")
    requested_by: Mapped[str | None] = mapped_column(String(40), nullable=True)
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=False)
    approved_by: Mapped[str | None] = mapped_column(String(40), nullable=True)
    approved_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    started_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    finished_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    data_origin: Mapped[str] = mapped_column(String(10), default="live")


class AgentTask(Base):
    __tablename__ = "agent_tasks"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("tsk"))
    run_id: Mapped[str] = mapped_column(ForeignKey("agent_runs.id"), index=True)
    step_index: Mapped[int] = mapped_column(Integer, default=0)
    agent: Mapped[str] = mapped_column(String(60), index=True)
    objective: Mapped[str] = mapped_column(String(400), default="")
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|running|ok|error|skipped|timeout
    input: Mapped[dict] = mapped_column(JSON, default=dict)
    output: Mapped[dict] = mapped_column(JSON, default=dict)
    tool_calls: Mapped[list] = mapped_column(JSON, default=list)
    sources_used: Mapped[list] = mapped_column(JSON, default=list)
    findings: Mapped[list] = mapped_column(JSON, default=list)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    retries: Mapped[int] = mapped_column(Integer, default=0)
    started_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)


# --------------------------------------------------------------------------- #
# Monitoring watchlist + audit trail
# --------------------------------------------------------------------------- #
class WatchRegion(Base):
    __tablename__ = "watch_regions"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("wat"))
    name: Mapped[str] = mapped_column(String(200))
    min_lat: Mapped[float] = mapped_column(Float)
    min_lon: Mapped[float] = mapped_column(Float)
    max_lat: Mapped[float] = mapped_column(Float)
    max_lon: Mapped[float] = mapped_column(Float)
    categories: Mapped[list] = mapped_column(JSON, default=list)
    owner_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("aud"))
    at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    actor: Mapped[str] = mapped_column(String(80), default="system")
    actor_role: Mapped[str] = mapped_column(String(20), default="system")
    action: Mapped[str] = mapped_column(String(80), index=True)
    entity_type: Mapped[str] = mapped_column(String(40), default="")
    entity_id: Mapped[str] = mapped_column(String(60), default="")
    before: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    after: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    reason: Mapped[str] = mapped_column(Text, default="")
