"""ORM → API dictionaries. One place decides what the client may see.

Privacy rules applied here:
*   Citizen reports expose coordinates rounded to ~1 km on public endpoints;
    full precision is returned only to analyst/admin principals.
*   Reporter identifiers are never serialised (only a salted hash exists).
"""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .util import iso


def incident_out(inc: models.Incident, risk: models.RiskAssessment | None = None, *,
                 areas: list[models.AffectedArea] | None = None, alert_count: int | None = None,
                 evidence_count: int | None = None, detail: bool = False) -> dict:
    out = {
        "id": inc.id,
        "code": inc.code,
        "title": inc.title,
        "category": inc.category,
        "status": inc.status,
        "verification_status": inc.verification_status,
        "severity": inc.severity,
        "confidence": round(inc.confidence, 1),
        "lat": inc.lat,
        "lon": inc.lon,
        "depth_km": inc.depth_km,
        "region": inc.region,
        "country": inc.country,
        "country_iso3": inc.country_iso3,
        "started_at": iso(inc.started_at),
        "last_update_at": iso(inc.last_update_at),
        "summary": inc.summary,
        "classification_note": inc.classification_note,
        "is_ambiguous": inc.is_ambiguous,
        "primary_source_key": inc.primary_source_key,
        "source_keys": inc.source_keys or [],
        "source_urls": inc.source_urls or [],
        "data_origin": inc.data_origin,
        "tags": inc.tags or [],
        "external_refs": inc.external_refs or {},
        "detection_agent": inc.detection_agent,
        "classification_agent": inc.classification_agent,
        "verified_by": inc.verified_by,
        "verified_at": iso(inc.verified_at),
        "risk": ({"score": risk.risk_score, "level": risk.risk_level, "hazard_score": risk.hazard_score,
                  "exposure_score": risk.exposure_score, "vulnerability_score": risk.vulnerability_score,
                  "confidence": risk.confidence, "methodology_version": risk.methodology_version,
                  "assessed_at": iso(risk.created_at), "estimate": True} if risk else None),
        "is_demo": inc.data_origin == "demo",
    }
    if areas is not None:
        out["affected_areas"] = [area_out(a) for a in areas]
    if alert_count is not None:
        out["alert_count"] = alert_count
    if evidence_count is not None:
        out["evidence_count"] = evidence_count
    if detail:
        out["limitations"] = (risk.limitations if risk else None)
    return out


def area_out(a: models.AffectedArea) -> dict:
    return {
        "id": a.id,
        "label": a.label,
        "geojson": a.geometry_geojson,
        "area_km2": a.area_km2,
        "radius_km": a.radius_km,
        "population_estimate": a.population_estimate,
        "population_method": a.population_method,
        "method": a.method,
        "is_estimate": a.is_estimate,
        "authority": a.authority or None,
        "source_key": a.source_key,
        "method_version": a.method_version,
        "created_at": iso(a.created_at),
        "label_kind": "estimate" if a.is_estimate else "authoritative",
    }


def observation_out(o: models.Observation, *, include_payload: bool = True) -> dict:
    return {
        "id": o.id,
        "source_key": o.source_key,
        "external_id": o.external_id,
        "hazard_hint": o.hazard_hint,
        "lat": o.lat,
        "lon": o.lon,
        "place": o.place,
        "country": o.country,
        "magnitude": o.magnitude,
        "magnitude_unit": o.magnitude_unit,
        "observed_at": iso(o.observed_at),
        "ingested_at": iso(o.ingested_at),
        "source_url": o.source_url,
        "data_origin": o.data_origin,
        "confidence": o.confidence,
        "incident_id": o.incident_id,
        "payload": o.payload if include_payload else None,
    }


def evidence_out(e: models.IncidentEvidence) -> dict:
    return {
        "id": e.id, "kind": e.kind, "source_key": e.source_key, "source_url": e.source_url, "title": e.title,
        "excerpt": e.excerpt, "observed_at": iso(e.observed_at), "confidence": e.confidence,
        "data_origin": e.data_origin, "added_at": iso(e.added_at), "added_by": e.added_by,
    }


def risk_out(r: models.RiskAssessment, *, include_factors: bool = True) -> dict:
    weights = next((f.get("value") for f in (r.factors or []) if f.get("factor") == "_weights"), [])
    factors = [f for f in (r.factors or []) if f.get("factor") != "_weights"]
    return {
        "id": r.id, "incident_id": r.incident_id, "risk_score": r.risk_score, "risk_level": r.risk_level,
        "hazard_score": r.hazard_score, "exposure_score": r.exposure_score,
        "vulnerability_score": r.vulnerability_score, "confidence": r.confidence,
        "factors": factors if include_factors else None, "weights": weights,
        "methodology_version": r.methodology_version, "narrative": r.narrative, "limitations": r.limitations,
        "agent": r.agent, "llm_used": r.llm_used, "data_origin": r.data_origin, "created_at": iso(r.created_at),
        "estimate": True,
    }


def alert_out(a: models.Alert, *, incident: models.Incident | None = None, acknowledged: bool = False,
              ack_count: int | None = None) -> dict:
    return {
        "id": a.id, "incident_id": a.incident_id,
        "incident_code": incident.code if incident else None,
        "alert_kind": a.alert_kind,
        "is_official": a.alert_kind == "official_ingested",
        "is_demo": a.data_origin == "demo",
        "severity": a.severity, "hazard": a.hazard, "title": a.title, "body": a.body,
        "instructions": a.instructions or [], "area_text": a.area_text, "area_geojson": a.area_geojson,
        "lat": a.lat, "lon": a.lon, "issued_at": iso(a.issued_at), "effective_from": iso(a.effective_from),
        "expires_at": iso(a.expires_at), "authority": a.authority or None, "source_key": a.source_key,
        "source_url": a.source_url, "confidence": a.confidence, "status": a.status,
        "review_required": a.review_required, "reviewed_by": a.reviewed_by, "reviewed_at": iso(a.reviewed_at),
        "review_note": a.review_note, "generated_by": a.generated_by, "llm_used": a.llm_used,
        "created_at": iso(a.created_at), "acknowledged": acknowledged, "ack_count": ack_count,
        "publishable": a.status == "published" and (a.alert_kind == "official_ingested" or not a.review_required),
    }


def report_out(r: models.CitizenReport, *, privileged: bool = False) -> dict:
    return {
        "id": r.id, "public_code": r.public_code, "category": r.category, "description": r.description,
        "lat": r.lat if privileged else round(r.lat, 2),
        "lon": r.lon if privileged else round(r.lon, 2),
        "coordinates_precision": "exact (analyst view)" if privileged else "~1 km (public view)",
        "location_source": r.location_source, "location_accuracy_m": r.location_accuracy_m, "place": r.place,
        "status": r.status, "priority": r.priority, "flags": r.flags or [],
        "duplicate_of_id": r.duplicate_of_id, "linked_incident_id": r.linked_incident_id,
        "confidence": r.confidence, "created_at": iso(r.created_at), "reviewed_at": iso(r.reviewed_at),
        "reviewed_by": r.reviewed_by if privileged else None, "review_notes": r.review_notes if privileged else "",
        "photo_available": bool(r.photo_path), "photo_url": (f"/api/reports/{r.id}/photo" if r.photo_path else None),
        "data_origin": r.data_origin,
        "verified": r.status == "verified",
        "contact_on_file": bool(r.contact_optin) if privileged else False,
    }


def agent_run_out(run: models.AgentRun, tasks: list[models.AgentTask] | None = None) -> dict:
    return {
        "id": run.id, "run_code": run.run_code, "goal": run.goal, "trigger": run.trigger, "status": run.status,
        "plan": run.plan or [], "summary": run.summary, "report": run.report or {},
        "llm_mode": run.llm_mode, "llm_model": run.llm_model,
        "requested_by": run.requested_by, "requires_approval": run.requires_approval,
        "approved_by": run.approved_by, "approved_at": iso(run.approved_at),
        "started_at": iso(run.started_at), "finished_at": iso(run.finished_at), "duration_ms": run.duration_ms,
        "error": run.error, "data_origin": run.data_origin,
        "tasks": [agent_task_out(t) for t in tasks] if tasks is not None else None,
    }


def agent_task_out(t: models.AgentTask) -> dict:
    return {
        "id": t.id, "run_id": t.run_id, "step_index": t.step_index, "agent": t.agent, "objective": t.objective,
        "status": t.status, "input": t.input, "output_summary": _output_summary(t.output),
        "tool_calls": t.tool_calls or [], "sources_used": t.sources_used or [], "findings": t.findings or [],
        "error": t.error, "retries": t.retries, "started_at": iso(t.started_at), "finished_at": iso(t.finished_at),
        "latency_ms": t.latency_ms,
    }


def _output_summary(output: dict | None) -> dict:
    if not isinstance(output, dict):
        return {}
    keep = ("count", "found", "ok", "error", "headline", "verified_facts", "model_estimates",
            "unverified_reports", "data_gaps", "sources", "recommended_next_steps", "requires_human_approval")
    return {k: output.get(k) for k in keep if k in output} or {"keys": list(output.keys())[:12]}


def source_out(s: models.DataSource, *, sync: models.SourceSyncLog | None = None) -> dict:
    return {
        "key": s.key, "name": s.name, "provider": s.provider, "homepage": s.homepage, "docs_url": s.docs_url,
        "license": s.license, "categories": s.categories or [], "auth_mode": s.auth_mode,
        "credential_env": s.credential_env or None, "status": s.status,
        "last_attempt_at": iso(s.last_attempt_at), "last_ok_at": iso(s.last_ok_at), "last_error": s.last_error,
        "latency_ms": s.latency_ms, "records_last_fetch": s.records_last_fetch, "total_records": s.total_records,
        "reliability_note": s.reliability_note, "is_demo": s.is_demo,
        "staleness_minutes": (round((models.utcnow() - s.last_ok_at).total_seconds() / 60, 1)
                              if s.last_ok_at else None),
        "last_sync": ({"status": sync.status, "records": sync.records, "duration_ms": sync.duration_ms,
                       "finished_at": iso(sync.finished_at), "message": sync.message} if sync else None),
    }


def watch_region_out(w: models.WatchRegion) -> dict:
    return {"id": w.id, "name": w.name, "min_lat": w.min_lat, "min_lon": w.min_lon,
            "max_lat": w.max_lat, "max_lon": w.max_lon, "categories": w.categories or [], "active": w.active,
            "created_at": iso(w.created_at)}


def audit_out(a: models.AuditLog) -> dict:
    return {"id": a.id, "at": iso(a.at), "actor": a.actor, "actor_role": a.actor_role, "action": a.action,
            "entity_type": a.entity_type, "entity_id": a.entity_id, "before": a.before, "after": a.after,
            "reason": a.reason}


def latest_risk_map(db: Session, incident_ids: list[str]) -> dict[str, models.RiskAssessment]:
    if not incident_ids:
        return {}
    out: dict[str, models.RiskAssessment] = {}
    for r in db.scalars(select(models.RiskAssessment).where(models.RiskAssessment.incident_id.in_(incident_ids))
                        .order_by(models.RiskAssessment.created_at.asc())):
        out[r.incident_id] = r
    return out
