"""In-process token-bucket rate limiting.

Deliberately dependency-free (no Redis needed to run AEGIS), and explicitly
documented as per-process: for multi-worker deployments put a shared limiter
(Redis/API gateway) in front, or set AEGIS_* limits accordingly.
"""
from __future__ import annotations

import time
from collections import defaultdict

from fastapi import HTTPException, Request, status

from .config import settings

_buckets: dict[str, tuple[float, float]] = defaultdict(lambda: (0.0, 0.0))  # key → (tokens, last_refill)


def _client_key(request: Request, scope: str) -> str:
    fwd = request.headers.get("x-forwarded-for", "")
    ip = fwd.split(",")[0].strip() if fwd else (request.client.host if request.client else "unknown")
    return f"{scope}:{ip}"


def check(request: Request, scope: str, limit: int) -> None:
    """Token bucket: `limit` requests per 60 s per client per scope."""
    if limit <= 0:
        return
    key = _client_key(request, scope)
    capacity = float(limit)
    rate = capacity / 60.0
    now = time.monotonic()
    tokens, last = _buckets[key]
    if last == 0.0:
        tokens, last = capacity, now
    tokens = min(capacity, tokens + (now - last) * rate)
    if tokens < 1.0:
        retry_after = int((1.0 - tokens) / rate) + 1
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS,
                            f"Rate limit reached for this endpoint ({limit}/min). Retry in ~{retry_after}s.",
                            headers={"Retry-After": str(retry_after)})
    _buckets[key] = (tokens - 1.0, now)


def read_limit(request: Request) -> None:
    check(request, "read", settings.rate_limit_read_per_min)


def write_limit(request: Request) -> None:
    check(request, "write", settings.rate_limit_write_per_min)


def assistant_limit(request: Request) -> None:
    check(request, "assistant", settings.rate_limit_assistant_per_min)


def reset() -> None:
    _buckets.clear()
