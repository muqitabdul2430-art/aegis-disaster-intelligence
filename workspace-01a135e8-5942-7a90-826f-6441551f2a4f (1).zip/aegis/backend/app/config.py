"""Central configuration for AEGIS.

All configuration is environment based (12-factor). See ../../.env.example.
Secrets (API keys, JWT secret, LLM keys) are read here on the SERVER only and
are never returned to the browser by any endpoint.
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent
BACKEND_DIR = BASE_DIR.parent
REPO_DIR = BACKEND_DIR.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="AEGIS_", extra="ignore")

    # ---- core ----
    app_name: str = "AEGIS"
    version: str = "0.4.0"
    environment: str = "development"
    debug: bool = True

    # ---- database ----
    # SQLite is the zero-config default so the stack boots anywhere.
    # For production set e.g. postgresql+psycopg://user:pass@host:5432/aegis
    # (see scripts/postgis_schema.sql for the PostGIS schema).
    database_url: str = f"sqlite:///{BACKEND_DIR / 'aegis.db'}"
    db_echo: bool = False

    # ---- security ----
    jwt_secret: str = "change-me-in-production-aegis"
    jwt_algorithm: str = "HS256"
    jwt_ttl_minutes: int = 720
    demo_password: str = "aegis-demo-2026"  # seeded demo accounts (change!)
    allow_registration: bool = True
    cors_origins: str = "*"

    # ---- rate limiting (in-memory token bucket per client) ----
    rate_limit_read_per_min: int = 240
    rate_limit_write_per_min: int = 40
    rate_limit_assistant_per_min: int = 12
    # citizen report submissions per client per minute (anti-abuse; one report per
    # person is rare during an emergency, so this stays deliberately low)
    rate_limit_report_submit_per_min: int = 10

    # ---- ingestion / background jobs ----
    ingest_on_startup: bool = True
    scheduler_enabled: bool = True
    ingest_interval_minutes: int = 10          # fast sources (USGS, GDACS, NHC, tsunami)
    ingest_interval_slow_minutes: int = 60     # weather / forecast feeds
    http_timeout_seconds: float = 20.0
    http_retries: int = 2
    http_user_agent: str = "AEGIS-Disaster-Intelligence/0.4 (open-source demo; contact: set AEGIS_HTTP_USER_AGENT)"

    # ---- credentials for optional / gated sources ----
    firms_map_key: str = ""          # NASA FIRMS MAP_KEY (firms.modaps.eosdis.nasa.gov/api)
    earthdata_token: str = ""        # NASA Earthdata login token (some GIBS/CMR endpoints)
    mosdac_token: str = ""           # ISRO MOSDAC (registration required)
    cdse_client_id: str = ""         # Copernicus Data Space (optional)
    cdse_client_secret: str = ""
    enable_live_network: bool = True  # set false for fully offline deployments

    # ---- LLM (optional) ----
    # Any OpenAI-compatible chat-completions endpoint works:
    #   OpenAI   -> https://api.openai.com/v1
    #   Groq     -> https://api.groq.com/openai/v1
    #   OpenRouter -> https://openrouter.ai/api/v1
    #   Ollama   -> http://localhost:11434/v1
    llm_api_key: str = ""
    llm_base_url: str = "https://api.openai.com/v1"
    llm_model: str = "gpt-4o-mini"
    llm_timeout_seconds: float = 45.0
    llm_max_retries: int = 1
    llm_temperature: float = 0.1

    # ---- demonstration data ----
    # force  -> always seed labelled demo records (offline demos)
    # auto   -> seed only if live ingestion produced nothing (default)
    # off    -> never seed
    demo_mode: str = "auto"

    # ---- routing (off by default: no current road-hazard data => no route claims) ----
    enable_osrm_routing: bool = False
    osrm_base_url: str = "https://router.project-osrm.org"

    # ---- frontend hosting ----
    serve_frontend: bool = True
    # Built SPA output. Vite is configured to emit into backend/static (not the
    # default dist/) so the compiled UI survives workspace snapshots.
    frontend_dist: str = str(REPO_DIR / "backend" / "static")

    @property
    def llm_enabled(self) -> bool:
        return bool(self.llm_api_key.strip())

    @property
    def cors_origin_list(self) -> list[str]:
        if self.cors_origins.strip() == "*":
            return ["*"]
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    # Small convenience: allow DATABASE_URL (no prefix) as well.
    if os.environ.get("DATABASE_URL"):
        s.database_url = os.environ["DATABASE_URL"]
    return s


settings = get_settings()
