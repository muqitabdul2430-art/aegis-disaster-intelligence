"""Demonstration dataset — CLEARLY LABELLED.

Purpose: let an offline / freshly-installed AEGIS show a complete, honest
workflow (detection → classification → geography → risk → alert draft) without
any live provider.  Every record created here carries `data_origin = "demo"`
and source key `demo_feed`, and every alert is titled "DEMONSTRATION DATA".
Nothing in this module can be mistaken for a live observation or an official
warning: the API, the UI and the assistant all surface the demo flag.

The geospatial maths, risk scoring and classification rules that run on these
inputs are the SAME production code paths used for live data.
"""
from __future__ import annotations

import logging
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .agents.classification_agent import classification_agent
from .agents.geo_agent import geo_agent
from .agents.prediction_agent import PROTECTIVE_ACTIONS
from .agents.risk_agent import risk_agent
from .services import geo
from .util import now

log = logging.getLogger("aegis.demo")

DEMO_SOURCE_KEY = "demo_feed"

SCENARIOS: list[dict] = [
    {
        "category": "wildfire",
        "title": "Demonstration: forest fire complex (satellite hotspot cluster)",
        "lat": 30.152, "lon": 79.043, "place": "Chamoli district, Uttarakhand (demo)",
        "country": "India", "iso3": "IND", "severity": 3, "verification": "preliminary_detection",
        "confidence": 62.0,
        "started_hours_ago": 19,
        "summary": ("DEMO DATA. Simulated cluster of VIIRS-style thermal anomalies in a forested slope area. "
                    "Illustrates how AEGIS groups hotspot pixels and why satellite hotspots alone cannot confirm an "
                    "active wildfire (agricultural burning, gas flares and industry are look-alikes)."),
        "tags": ["demo", "satellite_hotspot_cluster"],
        "obs": [{
            "hazard_hint": "wildfire", "external_id": "demo-firms-cluster-001",
            "magnitude": 46.0, "magnitude_unit": "FRP MW", "confidence": 62.0,
            "payload": {"instrument": "VIIRS_SNPP_NRT (simulated)", "cluster_size": 14, "confidence_label": "nominal",
                        "frp_mw": 46.0, "demo": True},
        }],
        "evidence": [("observation", "14 VIIRS-style thermal anomalies clustered within ~11 km over 19 h; cluster FRP ≈ 46 MW "
                                     "(SIMULATED DEMO OBSERVATION)"),
                     ("derived", "Terrain: steep forested slope; fire-weather proxy not available in demo mode")],
    },
    {
        "category": "cyclone",
        "title": "Demonstration: tropical cyclone approach, Bay of Bengal",
        "lat": 16.82, "lon": 87.35, "place": "Bay of Bengal, off Odisha coast (demo)",
        "country": "India", "iso3": "IND", "severity": 4, "verification": "corroborated",
        "confidence": 88.0,
        "started_hours_ago": 40,
        "summary": ("DEMO DATA. Simulated official-agency style position/intensity report for a cyclone approaching the "
                    "northwest Bay of Bengal with a modelled wind-field footprint. Used to demonstrate official-product "
                    "handling and the AEGIS refusal to re-draw official forecast tracks."),
        "tags": ["demo", "official_product", "coastal"],
        "obs": [{
            "hazard_hint": "cyclone", "external_id": "demo-tc-2026-01",
            "magnitude": 120.0, "magnitude_unit": "km/h (max sustained wind, simulated official)",
            "confidence": 88.0,
            "payload": {"classification": "HU", "classification_text": "Hurricane/Typhoon-equivalent (SIMULATED)",
                        "intensity_kmh": 120.0, "intensity_kt": 65.0, "pressure_mb": 975,
                        "movement_dir_deg": 315, "movement_speed_kt": 9, "official": True, "demo": True,
                        "authority": "DEMONSTRATION DATA — not a real issuing authority"},
        }],
        "evidence": [("observation", "Simulated position 16.82N 87.35E, max sustained winds 120 km/h, pressure 975 mb"),
                     ("derived", "Wind-field footprint estimate: 90 km + 55 km per severity band")],
    },
    {
        "category": "flood",
        "title": "Demonstration: riverine flood warning area, Brahmaputra valley",
        "lat": 26.21, "lon": 92.62, "place": "Nagaon district, Assam (demo)",
        "country": "India", "iso3": "IND", "severity": 4, "verification": "officially_confirmed",
        "confidence": 84.0,
        "started_hours_ago": 62,
        "summary": ("DEMO DATA. Simulated multi-day rainfall event with river levels above warning mark. Shows how AEGIS "
                    "combines a multi-hazard alert feed with modelled rainfall and settlement exposure."),
        "tags": ["demo", "official_alert_level", "riverine"],
        "obs": [{
            "hazard_hint": "flood", "external_id": "demo-fl-2026-07",
            "magnitude": None, "magnitude_unit": "", "confidence": 84.0,
            "payload": {"alert_level": "Orange", "eventtype": "FL", "eventid": "demo-fl-2026-07", "severity": {"severitytext": "Flood (simulated)"},
                        "demo": True},
        }],
        "evidence": [("observation", "Simulated GDACS-style Orange flood alert with affected-country metadata (DEMO)"),
                     ("derived", "Modelled rainfall driver unavailable in demo mode — exposure estimate only")],
    },
    {
        "category": "tsunami",
        "title": "Demonstration: tsunami advisory, Andaman arc",
        "lat": 10.62, "lon": 92.42, "place": "Andaman Sea (demo)",
        "country": "India", "iso3": "IND", "severity": 4, "verification": "officially_confirmed",
        "confidence": 92.0,
        "started_hours_ago": 9,
        "summary": ("DEMO DATA. Simulated tsunami advisory bulletin accompanying a large offshore earthquake. Shows the "
                    "bulletin-ingestion path, authority attribution and the coastal evacuation guidance module."),
        "tags": ["demo", "official_product", "coastal"],
        "obs": [{
            "hazard_hint": "tsunami", "external_id": "demo-ts-2026-03",
            "magnitude": 7.6, "magnitude_unit": "M (simulated preliminary)", "confidence": 92.0,
            "payload": {"category": "Advisory", "official": True, "demo": True,
                        "authority": "DEMONSTRATION DATA — not a real issuing authority",
                        "title": "Simulated tsunami advisory",
                        "message_text": "DEMONSTRATION BULLETIN. A simulated magnitude 7.6 offshore earthquake has "
                                        "produced a simulated tsunami advisory for the Andaman and Nicobar coasts. "
                                        "This text exists only to exercise AEGIS ingestion and display paths."},
        }],
        "evidence": [("official_alert", "Simulated tsunami Advisory bulletin ingested verbatim (DEMO)"),
                     ("observation", "Simulated M7.6 offshore earthquake solution")],
    },
    {
        "category": "landslide",
        "title": "Demonstration: landslide risk corridor, Western Ghats",
        "lat": 11.681, "lon": 76.132, "place": "Wayanad district, Kerala (demo)",
        "country": "India", "iso3": "IND", "severity": 3, "verification": "unverified_citizen",
        "confidence": 45.0,
        "started_hours_ago": 6,
        "summary": ("DEMO DATA. Built from a simulated citizen report of a slope failure near a hill road. Demonstrates "
                    "how unverified citizen intelligence is displayed, triaged and kept separate from verified events."),
        "tags": ["demo", "citizen_derived", "needs_human_review"],
        "obs": [],
        "evidence": [("citizen_report", "Simulated citizen report: 'Road blocked by debris after continuous rain; "
                                        "two vehicles stuck, people are safe' (DEMO)")],
        "citizen_report": {
            "description": "DEMO REPORT: Hill road blocked by a debris slide after continuous heavy rain; two vehicles "
                           "stuck, occupants safe. Water still flowing across the road.",
            "category": "landslide", "priority": "high",
        },
    },
    {
        "category": "earthquake",
        "title": "Demonstration: M5.4 shallow earthquake (Himalayan belt)",
        "lat": 28.24, "lon": 84.72, "place": "Gorkha region, Nepal (demo)",
        "country": "Nepal", "iso3": "NPL", "severity": 3, "verification": "corroborated",
        "confidence": 90.0, "started_hours_ago": 3,
        "summary": ("DEMO DATA. Simulated seismic solution with depth and a magnitude-based affected-area estimate. "
                    "Demonstrates the severity mapping and the macroseismic-style footprint approximation."),
        "tags": ["demo", "seismic"],
        "obs": [{
            "hazard_hint": "earthquake", "external_id": "demo-eq-2026-114",
            "magnitude": 5.4, "magnitude_unit": "Mww (simulated)", "confidence": 90.0,
            "payload": {"status": "reviewed (simulated)", "depth_km": 12.0, "tsunami_flag": 0, "demo": True,
                        "title": "M 5.4 - 22 km NNE of demo location"},
        }],
        "evidence": [("observation", "Simulated seismic solution: Mww 5.4, depth 12 km, 24 stations (DEMO)"),
                     ("derived", "Footprint estimate from severity band 3 (base 12 km + 32 km)")],
    },
    {
        "category": "industrial_fire",
        "title": "Demonstration: industrial fire at a chemical storage site",
        "lat": 17.686, "lon": 83.218, "place": "Visakhapatnam, Andhra Pradesh (demo)",
        "country": "India", "iso3": "IND", "severity": 4, "verification": "unverified_citizen",
        "confidence": 52.0, "started_hours_ago": 1,
        "summary": ("DEMO DATA. Simulated citizen reports of a fire with heavy black smoke at an industrial storage site, "
                    "plus nearby thermal-anomaly signal. Demonstrates industrial-fire disambiguation, hazmat guidance and "
                    "the human-review gate on a high-priority unverified report."),
        "tags": ["demo", "industrial", "needs_human_review", "hazmat"],
        "obs": [{
            "hazard_hint": "industrial_fire", "external_id": "demo-firms-industrial-002",
            "magnitude": 88.0, "magnitude_unit": "FRP MW", "confidence": 58.0,
            "payload": {"instrument": "VIIRS_SNPP_NRT (simulated)", "frp_mw": 88.0, "demo": True},
        }],
        "evidence": [("observation", "Simulated high-FRP thermal anomaly co-located with an industrial area (DEMO)"),
                     ("citizen_report", "Simulated reports of dense smoke and a strong chemical smell (DEMO, UNVERIFIED)")],
        "citizen_report": {
            "description": "DEMO REPORT: Thick black smoke rising from the storage yard area; strong chemical smell "
                           "spreading towards the residential colony. People are moving away from the gate.",
            "category": "industrial_fire", "priority": "critical",
        },
    },
]


def demo_mode_active(db: Session) -> dict:
    live = db.scalar(select(models.Incident.id).where(models.Incident.data_origin == "live"))
    demo = db.scalar(select(models.Incident.id).where(models.Incident.data_origin == "demo"))
    return {"live_incidents": bool(live), "demo_incidents": bool(demo)}


def should_seed(db: Session, mode: str | None = None) -> bool:
    """Demo seeding policy: force = always, auto = only when nothing to show, off = never."""
    from .config import settings

    mode = (mode or settings.demo_mode or "auto").lower()
    if mode == "off":
        return False
    has_live = bool(db.scalar(select(models.Incident.id).where(models.Incident.data_origin == "live")))
    has_demo = bool(db.scalar(select(models.Incident.id).where(models.Incident.data_origin == "demo")))
    if mode == "force":
        return not has_demo
    # auto: seed only if there is neither live data nor an existing demo dataset
    return (not has_live) and (not has_demo)


def seed_demo(db: Session) -> dict:
    """Create the labelled demonstration dataset (idempotent)."""
    from .config import settings

    mode = settings.demo_mode or "auto"
    if mode == "off" or not should_seed(db, mode):
        return {"seeded": False, "reason": "demo seeding disabled or data already present",
                "mode": mode}

    ds = db.get(models.DataSource, DEMO_SOURCE_KEY)
    if ds is None:
        db.add(models.DataSource(
            key=DEMO_SOURCE_KEY, name="AEGIS demonstration feed (labelled sample data)",
            provider="AEGIS project", homepage="", docs_url="", license="CC0 (project-generated sample data)",
            categories=["wildfire", "cyclone", "flood", "tsunami", "landslide", "earthquake", "industrial_fire"],
            auth_mode="none", status="ok", is_demo=True,
            reliability_note="NOT A REAL SOURCE. Clearly labelled demonstration records used when no live feed is "
                             "available. Never present these as live observations or official warnings.",
            last_ok_at=now(), records_last_fetch=len(SCENARIOS),
        ))
    created = []
    for sc in SCENARIOS:
        if db.scalar(select(models.Incident.id).where(models.Incident.title == sc["title"])):
            continue
        started = now() - timedelta(hours=sc["started_hours_ago"])
        code = f"DEMO-{sc['category'][:3].upper()}-{models.new_id('x').split('_')[-1][:5].upper()}"
        inc = models.Incident(
            code=code, title=sc["title"], category=sc["category"], status="active",
            verification_status=sc["verification"], severity=sc["severity"], confidence=sc["confidence"],
            lat=sc["lat"], lon=sc["lon"], region=sc["place"], country=sc["country"], country_iso3=sc["iso3"],
            started_at=started, last_update_at=started + timedelta(minutes=30),
            summary=sc["summary"], detection_agent="detection_agent (demo input)",
            primary_source_key=DEMO_SOURCE_KEY, source_keys=[DEMO_SOURCE_KEY],
            source_urls=["https://github.com/ (AEGIS demo dataset — no external URL)"],
            data_origin="demo", tags=sc["tags"], is_ambiguous=sc["verification"] in {"unverified_citizen"},
            external_refs={DEMO_SOURCE_KEY: sc["obs"][0]["external_id"] if sc["obs"] else "citizen-demo"},
        )
        db.add(inc)
        db.flush()

        for o in sc["obs"]:
            db.add(models.Observation(
                source_key=DEMO_SOURCE_KEY, external_id=o["external_id"],
                fingerprint=f"demo:{sc['category']}:{o['external_id']}",
                hazard_hint=o["hazard_hint"], lat=sc["lat"], lon=sc["lon"], place=sc["place"],
                country=sc["country"], magnitude=o["magnitude"], magnitude_unit=o["magnitude_unit"],
                observed_at=started, source_url="", data_origin="demo", confidence=o["confidence"],
                payload=o["payload"], incident_id=inc.id,
            ))
        for kind, excerpt in sc["evidence"]:
            db.add(models.IncidentEvidence(
                incident_id=inc.id, kind=kind, source_key=DEMO_SOURCE_KEY if kind != "citizen_report" else "citizen",
                source_url="", title=f"{kind.replace('_', ' ').title()} (demo)", excerpt=excerpt,
                observed_at=started + timedelta(minutes=10), confidence=sc["confidence"], data_origin="demo",
                added_by="demo_seed",
            ))

        report_id = None
        if sc.get("citizen_report"):
            cr = sc["citizen_report"]
            rep = models.CitizenReport(
                public_code=f"RPT-DEMO-{models.new_id('x').split('_')[-1][:4].upper()}",
                category=cr["category"], description=cr["description"],
                lat=sc["lat"] + 0.004, lon=sc["lon"] - 0.003, place=sc["place"],
                status="under_review", priority=cr["priority"], flags=["demo_record"],
                reporter_hash="demo", linked_incident_id=inc.id, confidence=25.0, data_origin="demo",
                created_at=started + timedelta(minutes=5),
            )
            db.add(rep)
            db.flush()
            report_id = rep.id

        # real classification + geospatial + risk computations on demo inputs
        try:
            classification_agent.apply(db, inc, None)
            geo_report = geo_agent.context_report(db, inc, None, radius_km=25.0, include_facilities=False)
            risk_agent.assess(db, inc, None,
                              weather={"ok": False, "error": "demo mode: live weather drivers disabled"},
                              area=geo_report["area"], facilities=geo_report["facilities"])
        except Exception as exc:  # noqa: BLE001
            log.warning("demo processing failed for %s: %s", inc.code, exc)

        # labelled demo alert (published for UI demonstration; never an official warning)
        actions = PROTECTIVE_ACTIONS.get(sc["category"], PROTECTIVE_ACTIONS["unknown"])["actions"]
        if sc["severity"] >= 3:
            alert = models.Alert(
                incident_id=inc.id,
                alert_kind="demo_advisory",
                severity={3: "moderate", 4: "severe", 5: "extreme"}.get(sc["severity"], "moderate"),
                hazard=sc["category"],
                title=f"DEMONSTRATION DATA — {sc['title'].replace('Demonstration: ', '')}",
                body=("THIS IS LABELLED DEMONSTRATION DATA, NOT AN OFFICIAL WARNING.\n\n"
                      f"Scenario: {sc['title']}\nLocation: {sc['place']} ({sc['lat']:.3f}, {sc['lon']:.3f})\n"
                      f"Verification status: {sc['verification'].replace('_', ' ')}\n\n"
                      "This advisory exists so the alert centre, acknowledgement tracking and human-review workflow can "
                      "be exercised without live data. No external notification is ever sent for demo alerts."),
                instructions=actions,
                area_text=sc["place"], lat=sc["lat"], lon=sc["lon"], issued_at=started + timedelta(minutes=20),
                authority="DEMONSTRATION DATA — no issuing authority",
                source_key=DEMO_SOURCE_KEY, source_url="", confidence=sc["confidence"],
                status="published", review_required=False, generated_by="demo_seed", data_origin="demo",
                external_id=f"demo-alert:{inc.code}",
            )
            db.add(alert)

        # one high-risk scenario gets a pending draft to exercise the approval gate
        if sc["category"] == "industrial_fire":
            db.add(models.Alert(
                incident_id=inc.id, alert_kind="ai_advisory", severity="severe", hazard=sc["category"],
                title="DEMONSTRATION: draft advisory awaiting authorised review",
                body=("AEGIS DRAFT ADVISORY (DEMONSTRATION DATA). Generated by the prediction agent from the demo "
                      "incident risk assessment. Publishing requires an authorised analyst/admin decision — this draft "
                      "demonstrates that gate."),
                instructions=actions,
                area_text=sc["place"], lat=sc["lat"], lon=sc["lon"], issued_at=now(),
                authority="", source_key=DEMO_SOURCE_KEY, confidence=52.0, status="pending_review",
                review_required=True, generated_by="prediction_agent", data_origin="demo",
                external_id=f"demo-draft:{inc.code}",
            ))
        created.append({"incident_id": inc.id, "code": inc.code, "category": sc["category"], "report_id": report_id})
    db.flush()
    db.add(models.AuditLog(actor="demo_seed", actor_role="system", action="demo.seed", entity_type="system",
                           entity_id="-", after={"created": created},
                           reason="labelled demonstration dataset (no live feed available)"))
    db.flush()
    log.info("seeded %d demo incidents", len(created))
    return {"seeded": True, "incidents": created, "label": "DEMONSTRATION DATA"}
