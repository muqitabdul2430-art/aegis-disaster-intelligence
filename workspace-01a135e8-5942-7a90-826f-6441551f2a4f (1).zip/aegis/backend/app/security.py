"""Authentication, role-based access control and platform-security helpers.

*   Passwords: PBKDF2-HMAC-SHA256 with per-user salt (no plaintext, no reversible storage).
*   Sessions: signed JWT (HS256) with short TTL; secret from environment only.
*   Roles: `citizen` < `analyst` < `admin`.  Consequential actions (publishing an
    alert, verifying an incident, triggering ingestion) require analyst/admin.
*   Registration is open by default but configurable; citizen submissions are
    rate limited and privacy-preserving (see agents/citizen_agent.py).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import os
import time
from dataclasses import dataclass

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .config import settings
from .db import get_db
from .util import now

log = logging.getLogger("aegis.security")

bearer = HTTPBearer(auto_error=False)
ROLE_ORDER = {"citizen": 1, "analyst": 2, "admin": 3}


# --------------------------------------------------------------------------- #
# Password hashing
# --------------------------------------------------------------------------- #
def hash_password(password: str, *, iterations: int = 180_000) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return f"pbkdf2_sha256${iterations}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, iters, salt_b64, hash_b64 = encoded.split("$")
        if algo != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iters))
        return hmac.compare_digest(dk, expected)
    except Exception:  # noqa: BLE001
        return False


# --------------------------------------------------------------------------- #
# Tokens
# --------------------------------------------------------------------------- #
def create_token(user: models.User) -> dict:
    exp = int(time.time()) + settings.jwt_ttl_minutes * 60
    payload = {"sub": user.id, "email": user.email, "role": user.role, "name": user.name, "exp": exp, "iat": int(time.time())}
    token = jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)
    return {"access_token": token, "token_type": "bearer", "expires_at": exp, "role": user.role, "name": user.name,
            "email": user.email, "user_id": user.id}


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except jwt.ExpiredSignatureError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session expired — please sign in again.") from exc
    except jwt.PyJWTError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid authentication token.") from exc


@dataclass
class Principal:
    """Authenticated (or anonymous) actor."""

    id: str | None
    email: str | None
    name: str
    role: str
    authenticated: bool

    def at_least(self, role: str) -> bool:
        return ROLE_ORDER.get(self.role, 0) >= ROLE_ORDER.get(role, 99)

    def as_dict(self) -> dict:
        return {"id": self.id, "email": self.email, "name": self.name, "role": self.role,
                "authenticated": self.authenticated}


ANONYMOUS = Principal(id=None, email=None, name="Guest", role="citizen", authenticated=False)


def principal_from_request(request: Request, db: Session) -> Principal:
    creds: HTTPAuthorizationCredentials | None = bearer  # placeholder to keep type checkers calm
    auth = request.headers.get("authorization") or ""
    if not auth.lower().startswith("bearer "):
        return ANONYMOUS
    token = auth.split(" ", 1)[1].strip()
    try:
        payload = decode_token(token)
    except HTTPException:
        return ANONYMOUS
    user = db.get(models.User, payload.get("sub"))
    if user is None or not user.is_active:
        return ANONYMOUS
    return Principal(id=user.id, email=user.email, name=user.name, role=user.role, authenticated=True)


def get_principal(request: Request, db: Session = Depends(get_db)) -> Principal:
    return principal_from_request(request, db)


def require_user(request: Request, db: Session = Depends(get_db)) -> Principal:
    p = principal_from_request(request, db)
    if not p.authenticated:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Authentication required.",
                            headers={"WWW-Authenticate": "Bearer"})
    return p


def require_role(role: str):
    def _dep(request: Request, db: Session = Depends(get_db)) -> Principal:
        p = principal_from_request(request, db)
        if not p.authenticated:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Authentication required.")
        if not p.at_least(role):
            raise HTTPException(status.HTTP_403_FORBIDDEN,
                                f"This action requires the '{role}' role (your role: {p.role}). "
                                "Consequential actions are restricted to authorised personnel.")
        return p

    return _dep


require_analyst = require_role("analyst")
require_admin = require_role("admin")


def authenticate(db: Session, email: str, password: str) -> models.User | None:
    user = db.scalar(select(models.User).where(models.User.email == email.strip().lower()))
    if user is None or not user.is_active or not verify_password(password, user.password_hash):
        return None
    user.last_login_at = now()
    db.flush()
    return user
