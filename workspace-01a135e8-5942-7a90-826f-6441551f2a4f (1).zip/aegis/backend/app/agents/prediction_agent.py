"""Agent 5 — Prediction & Early-Warning Agent.

What it does
------------
*   Trend analysis from stored history (risk score deltas, severity changes,
    observation cadence) — computed, not guessed.
*   Uses AUTHORITATIVE forecast products where they exist: NHC advisory/forecast
    product links for cyclones (the official track is never re-drawn by AEGIS),
    GDACS alert levels, and Open-Meteo model fields for rainfall/wind drivers.
*   Where no official forecast exists, it may publish an explicit AEGIS
    *extrapolation* (linear persistence of the official position/intensity trend)
    that is labelled as such, with the uncertainty stated.
*   Emits DRAFT alerts + protective actions.  Drafts require human authorisation
    before they can become public (see routers/alerts.py); AEGIS agents can never
    issue a public warning by themselves.

Honesty rules enforced in code:
*   No official warning text is ever paraphrased into a new "official" alert.
*   Predictive accuracy is never claimed: alerts carry `confidence` and a
    `validation_note` explaining that AEGIS forecasts are not skill-validated.
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..services import geo
from ..services import weather as wx_service
from ..util import clamp, now
from .base import AgentContext, BaseAgent

log = logging.getLogger("aegis.agents.prediction")

# Official protective-action guidance per hazard. These are standard, publicly
# documented safety actions; the authoritative source is named so users are
# always pointed to the responsible agency.
PROTECTIVE_ACTIONS: dict[str, dict[str, Any]] = {
    "earthquake": {
        "authority": "NDMA (India) / FEMA & USGS (US) / your national civil-protection agency",
        "actions": [
            "Drop, Cover, Hold On — get under sturdy furniture and protect your head and neck.",
            "Stay away from windows, exterior walls and unsecured tall furniture.",
            "If outdoors, move to open ground away from buildings, poles and power lines.",
            "Aftershocks are likely; do not re-enter damaged structures until cleared by authorities.",
            "Follow instructions from your local disaster management authority; in India call 112.",
        ],
        "source_url": "https://ndma.gov.in/",
    },
    "tsunami": {
        "authority": "NOAA Tsunami Warning Centers / INCOIS Indian Tsunami Early Warning Centre",
        "actions": [
            "If you feel strong shaking near the coast or the sea recedes, evacuate immediately to high ground or inland.",
            "Do not wait for an official warning if natural signs are present.",
            "Move at least 3 km inland or 30 m above sea level (follow local signage where available).",
            "Stay away from the coast until the responsible tsunami warning centre issues an all-clear.",
            "Monitor official bulletins (tsunami.gov; INCOIS for the Indian Ocean).",
        ],
        "source_url": "https://www.tsunami.gov/",
    },
    "cyclone": {
        "authority": "IMD RSMC New Delhi / NOAA NHC / your national meteorological service",
        "actions": [
            "Follow the official evacuation orders of your district administration (in India, IMD + SDMA bulletins).",
            "Secure loose objects, windows and roof sheets; move to a sturdy shelter or the designated cyclone shelter.",
            "Store drinking water, food, medicines, torch and radio for at least 72 hours.",
            "Stay indoors during the lull as the eye passes — winds return from the opposite direction.",
            "Avoid the coast, rivers and mud houses; do not touch downed power lines.",
        ],
        "source_url": "https://rsmcnewdelhi.imd.gov.in/",
    },
    "flood": {
        "authority": "NDMA / state SDMA and central water authorities (CWC in India); your national flood agency",
        "actions": [
            "Do not walk, swim or drive through flood water — 15 cm of moving water can knock you over.",
            "Move valuables and electrical equipment above expected water level; switch off mains power.",
            "Evacuate early if advised; routes can close quickly and night evacuation is far more dangerous.",
            "Drink only boiled or treated water — contamination is common during floods.",
            "Watch for official CWC/IMD river-level bulletins and district advisories.",
        ],
        "source_url": "https://ndma.gov.in/",
    },
    "wildfire": {
        "authority": "State forest department / national forest service; local fire service",
        "actions": [
            "Follow evacuation orders immediately; leave early and use designated routes.",
            "Close windows and vents; set air-conditioning to recirculate to reduce smoke intake.",
            "Keep N95 masks available — smoke exposure affects everyone, especially children and people with asthma.",
            "Do not attempt to defend a property unless trained and directed by the fire service.",
            "Report new smoke/fire sightings to the local fire or forest control room.",
        ],
        "source_url": "https://fsi.nic.in/",
    },
    "landslide": {
        "authority": "Geological Survey of India (landslide hazard) / state disaster management authority",
        "actions": [
            "Move away from steep slopes, gullies and the toe of slopes during and after heavy rain.",
            "Watch for cracking walls, tilting trees/poles, unusual rumbling or muddy water — leave immediately.",
            "Avoid travelling on hill roads during intense rainfall; expect closed sections.",
            "Report slope movement to the local administration; do not return until cleared by engineers.",
        ],
        "source_url": "https://www.gsi.gov.in/",
    },
    "industrial_fire": {
        "authority": "Local fire service and factory inspectorate / pollution control board",
        "actions": [
            "Move upwind and uphill of the smoke plume; close windows and switch off ventilation intakes.",
            "Keep at least 500 m from the incident perimeter unless you are a responder.",
            "If you experience breathing difficulty, seek medical help and note the exposure time.",
            "Do not consume produce, water or food that may have been exposed to fallout.",
            "Follow the incident commander's instructions; do not enter the site.",
        ],
        "source_url": "https://ndma.gov.in/",
    },
    "unknown": {
        "authority": "Your local disaster management authority",
        "actions": [
            "Monitor official channels (in India: SACHET alerts / district control room, dial 112).",
            "Prepare a go-bag and agree a family meeting point.",
            "Do not act on unverified forwarded messages.",
        ],
        "source_url": "https://sachet.ndma.gov.in/",
    },
}

ESCALATION_RISK_DELTA = 8.0     # points of risk score increase that trigger an escalation draft
DEESCALATION_RISK_DELTA = -10.0


class PredictionAgent(BaseAgent):
    name = "prediction_agent"
    description = ("Detects risk trends and escalation, assembles official forecast products, produces labelled "
                   "AEGIS extrapolations and drafts early-warning alerts for human authorisation.")
    capabilities = ["trend_analysis", "escalation_detection", "official_forecast_linkage", "alert_drafting"]

    # ------------------------------------------------------------------ #
    def trend(self, db: Session, incident: models.Incident) -> dict[str, Any]:
        """Historical trend from stored assessments + observations."""
        assessments = list(db.scalars(
            select(models.RiskAssessment).where(models.RiskAssessment.incident_id == incident.id)
            .order_by(models.RiskAssessment.created_at.asc())
        ))
        observations = list(db.scalars(
            select(models.Observation).where(models.Observation.incident_id == incident.id)
            .order_by(models.Observation.observed_at.asc())
        ))
        series = [{"at": a.created_at.isoformat() + "Z", "risk_score": a.risk_score, "risk_level": a.risk_level,
                   "hazard": a.hazard_score, "exposure": a.exposure_score} for a in assessments]
        delta = None
        direction = "insufficient_history"
        if len(assessments) >= 2:
            delta = round(assessments[-1].risk_score - assessments[-2].risk_score, 1)
            direction = "escalating" if delta >= ESCALATION_RISK_DELTA else (
                "de-escalating" if delta <= DEESCALATION_RISK_DELTA else "stable")
        recent = [o for o in observations if (now() - o.observed_at).total_seconds() <= 6 * 3600]
        older = [o for o in observations if 6 * 3600 < (now() - o.observed_at).total_seconds() <= 24 * 3600]
        return {
            "risk_series": series[-12:],
            "risk_delta": delta,
            "direction": direction,
            "observation_cadence": {"last_6h": len(recent), "previous_18h": len(older)},
            "assessment_count": len(assessments),
            "note": ("Trend requires at least two assessments; AEGIS reports 'insufficient_history' rather than guessing."
                     if len(assessments) < 2 else
                     f"Risk changed by {delta:+.1f} points since the previous assessment ({direction})."),
        }

    # ------------------------------------------------------------------ #
    def official_forecast(self, db: Session, incident: models.Incident) -> dict[str, Any]:
        """Attach the authoritative forecast products that exist for this hazard."""
        out: dict[str, Any] = {"available": False, "items": [], "extrapolation": None}
        observations = list(db.scalars(select(models.Observation).where(models.Observation.incident_id == incident.id)
                                       .order_by(models.Observation.observed_at.desc()).limit(8)))

        if incident.category == "cyclone":
            nhc = next((o for o in observations if o.source_key == "nhc"), None)
            if nhc:
                p = nhc.payload or {}
                advisory = (p.get("forecast_advisory") or {}).get("url")
                out.update({
                    "available": True,
                    "authority": "NOAA National Hurricane Center",
                    "items": [{
                        "kind": "official_forecast_track",
                        "label": f"NHC forecast advisory {((p.get('forecast_advisory') or {}).get('advNum'))} "
                                 f"(issued {((p.get('forecast_advisory') or {}).get('issuance'))})",
                        "url": advisory,
                        "note": "Official NHC forecast. Use the NHC cone/track graphics for decisions — AEGIS does not re-draw it.",
                    }],
                })
                heading = p.get("movement_dir_deg")
                speed = p.get("movement_speed_kt")
                if isinstance(heading, (int, float)) and isinstance(speed, (int, float)):
                    pts = []
                    for h in (6, 12, 24):
                        dist = speed * 1.852 * h
                        lat, lon = geo.offset_point(incident.lat, incident.lon, heading, dist)
                        pts.append({"hour": h, "lat": round(lat, 3), "lon": round(lon, 3)})
                    out["extrapolation"] = {
                        "kind": "AEGIS_EXTRAPOLATION",
                        "method": (f"Linear persistence of the OFFICIAL NHC position and motion vector "
                                   f"({speed:.0f} kt towards {geo.compass(heading)}). This ignores steering changes, "
                                   f"intensification and land interaction — it is NOT an official track and has no "
                                   f"validated skill score."),
                        "points": pts,
                        "confidence": 35.0,
                        "label": "AEGIS extrapolation — not an official forecast",
                    }
            gdacs = next((o for o in observations if o.source_key == "gdacs"), None)
            if gdacs:
                out["items"].append({
                    "kind": "official_alert_level",
                    "label": f"GDACS alert level {(gdacs.payload or {}).get('alert_level')} (JRC)",
                    "url": gdacs.source_url,
                    "note": "Authoritative multi-hazard alert level maintained by JRC.",
                })
                out["available"] = True
        elif incident.category == "tsunami":
            out["items"].append({
                "kind": "official_bulletin",
                "label": "NOAA Tsunami Warning Center bulletin feed",
                "url": "https://www.tsunami.gov/",
                "note": "AEGIS ingests the bulletin text and authority; the centre's travel-time maps are authoritative.",
            })
            out["items"].append({
                "kind": "official_bulletin",
                "label": "INCOIS Indian Tsunami Early Warning Centre",
                "url": "https://tsunami.incois.gov.in/",
                "note": "Authoritative for the Indian Ocean basin.",
            })
            out["authority"] = "NOAA NTWC/PTWC; INCOIS (Indian Ocean)"
            out["available"] = True

        # Model-based driver outlook for all hazards
        wx = wx_service.forecast(incident.lat, incident.lon)
        if wx.get("ok"):
            out["model_outlook"] = {
                "source": wx["source"], "source_url": wx["source_url"],
                "label": "MODEL OUTPUT (Open-Meteo aggregated NWP), not measurements",
                "summary": wx["summary"],
            }
        return out

    # ------------------------------------------------------------------ #
    def draft_alert(self, db: Session, incident: models.Incident, risk: dict[str, Any], trend: dict[str, Any],
                    forecast: dict[str, Any], ctx: AgentContext | None) -> models.Alert | None:
        """Create a DRAFT alert. Publishing requires a human analyst/admin decision."""
        level = risk.get("risk_level", "moderate")
        if level not in {"high", "extreme"} and trend.get("direction") != "escalating":
            return None

        hazard = incident.category if incident.category in PROTECTIVE_ACTIONS else "unknown"
        guide = PROTECTIVE_ACTIONS[hazard]
        existing = db.scalar(select(models.Alert).where(
            models.Alert.incident_id == incident.id,
            models.Alert.alert_kind == "ai_advisory",
        ).order_by(models.Alert.created_at.desc()))
        if existing and existing.status in {"draft", "pending_review"} and existing.severity == level:
            return None  # avoid duplicate drafts for the same escalation state

        area = geo.circle_polygon(incident.lat, incident.lon,
                                  clamp(10 + 12 * incident.severity, 10, 120))
        evidence_lines = [
            f"Risk score {risk['risk_score']:.0f}/100 ({level}) from AEGIS {risk.get('methodology_version')} "
            f"(hazard {risk['hazard_score']:.0f} / exposure {risk['exposure_score']:.0f} / vulnerability {risk['vulnerability_score']:.0f})",
            f"Verification status of the underlying event: {incident.verification_status.replace('_', ' ')}",
            f"Primary source: {incident.primary_source_key}",
            f"Trend: {trend.get('note')}",
        ]
        if forecast.get("available"):
            evidence_lines.append("Official forecast products linked: " +
                                  "; ".join(i["label"] for i in forecast.get("items", [])[:2]))
        body = (
            "AEGIS DRAFT ADVISORY — NOT AN OFFICIAL WARNING.\n\n"
            f"Incident {incident.code}: {incident.title}\n"
            f"Location: {incident.region or geo.place_label(incident.lat, incident.lon)} "
            f"({incident.lat:.3f}, {incident.lon:.3f})\n"
            f"AEGIS assessed risk: {risk['risk_score']:.0f}/100 ({level.upper()}) — model estimate.\n\n"
            "Basis (traceable evidence):\n- " + "\n- ".join(evidence_lines) + "\n\n"
            f"Authoritative guidance belongs to {guide['authority']}. Do not publish this draft until an "
            "authorised officer has reviewed it against the current official bulletin."
        )
        alert = models.Alert(
            incident_id=incident.id, alert_kind="ai_advisory", severity=level, hazard=hazard,
            title=f"{level.title()} risk — {incident.title}",
            body=body, instructions=guide["actions"], area_text=incident.region or "",
            area_geojson=area, lat=incident.lat, lon=incident.lon,
            issued_at=now(), effective_from=now(),
            authority="", source_key="aegis_prediction_agent", source_url=guide["source_url"],
            confidence=risk.get("confidence", 40.0), status="pending_review", review_required=True,
            generated_by=self.name, llm_used=bool(risk.get("llm_used")), data_origin=incident.data_origin,
        )
        db.add(alert)
        db.flush()
        if ctx:
            ctx.add_finding(f"Draft advisory created (status: pending_review) for {incident.code} — "
                            f"{level} risk. Human authorisation required before publication.",
                            kind="alert_draft", source="aegis_prediction_agent",
                            extra={"incident_id": incident.id, "alert_id": alert.id, "requires_approval": True})
        return alert

    # ------------------------------------------------------------------ #
    def run(self, db: Session, ctx: AgentContext, *, incident_ids: list[str], draft_alerts: bool = True,
            risks: dict[str, dict] | None = None) -> dict[str, Any]:
        incidents = list(db.scalars(select(models.Incident).where(models.Incident.id.in_(incident_ids))))
        results, drafts = [], []
        with ctx.tool("prediction_and_early_warning", {"incidents": len(incidents), "draft_alerts": draft_alerts}) as t:
            for inc in incidents:
                if ctx.timed_out():
                    t["status"] = "timeout"
                    t["error"] = "deadline exceeded during prediction"
                    break
                tr = self.trend(db, inc)
                fc = self.official_forecast(db, inc)
                risk = (risks or {}).get(inc.id)
                if risk is None:
                    last = db.scalar(select(models.RiskAssessment).where(models.RiskAssessment.incident_id == inc.id)
                                     .order_by(models.RiskAssessment.created_at.desc()))
                    risk = {"risk_score": last.risk_score if last else 30.0,
                            "risk_level": last.risk_level if last else "moderate",
                            "confidence": last.confidence if last else 40.0,
                            "hazard_score": last.hazard_score if last else 30.0,
                            "exposure_score": last.exposure_score if last else 30.0,
                            "vulnerability_score": last.vulnerability_score if last else 30.0,
                            "methodology_version": last.methodology_version if last else "risk-v1.0",
                            "llm_used": bool(last.llm_used) if last else False}
                alert = self.draft_alert(db, inc, risk, tr, fc, ctx) if draft_alerts else None
                if alert:
                    drafts.append({"alert_id": alert.id, "incident_id": inc.id, "severity": alert.severity,
                                   "status": alert.status})
                results.append({
                    "incident_id": inc.id, "code": inc.code, "trend": tr, "forecast": fc,
                    "risk_snapshot": risk,
                    "escalation": tr.get("direction") == "escalating",
                    "forecast_validation_note": ("AEGIS does not claim predictive skill for its extrapolations. "
                                                 "Official forecast products are linked and attributed."),
                })
            t["source"] = "aegis_prediction_model"
            t["summary"] = (f"{len(results)} outlook(s); {len(drafts)} draft alert(s) awaiting human review; "
                            f"{sum(1 for r in results if r['escalation'])} escalating")
        return {"agent": self.name, "outlooks": results, "drafts": drafts}


prediction_agent = PredictionAgent()
