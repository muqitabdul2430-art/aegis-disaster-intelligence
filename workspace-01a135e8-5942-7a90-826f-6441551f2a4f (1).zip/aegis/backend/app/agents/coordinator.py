"""Agent 8 — Intelligence Coordinator.

*   Understands a user/operational goal (rule-based planner + optional LLM intent
    parsing constrained to an allow-listed tool catalogue).
*   Builds an execution plan, runs the specialised agents through real tool
    functions, tracks status/errors/timings per step.
*   Combines outputs into an intelligence brief that keeps VERIFIED FACTS,
    MODEL ESTIMATES and UNVERIFIED REPORTS strictly separated.
*   Flags any consequential action (publishing an alert, external notification)
    as requiring explicit human approval — the coordinator cannot perform them.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Callable

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import models
from ..config import settings
from ..llm import llm_client
from ..services import facilities as fac_service
from ..services import geo
from ..services import weather as wx_service
from ..util import clamp, now
from . import detection_agent as det_mod
from . import geo_agent as geo_mod
from . import prediction_agent as pred_mod
from . import response_agent as resp_mod
from . import risk_agent as risk_mod
from .base import AgentContext, AGENT_TIMEOUT_SECONDS, BaseAgent, new_run_code

log = logging.getLogger("aegis.agents.coordinator")


@dataclass
class ToolSpec:
    agent: str
    name: str
    description: str
    fn: Callable[..., dict]
    params: dict[str, str]


class CoordinatorAgent(BaseAgent):
    name = "coordinator_agent"
    description = ("Plans and executes multi-agent workflows, tracks execution status and assembles the final "
                   "intelligence brief with explicit evidence separation.")
    capabilities = ["intent_parsing", "planning", "orchestration", "report_synthesis", "approval_gating"]

    # ------------------------------------------------------------------ #
    # Tool catalogue (the ONLY functions the coordinator may invoke)
    # ------------------------------------------------------------------ #
    def tool_catalogue(self) -> dict[str, ToolSpec]:
        return {
            "status_overview": ToolSpec(
                "coordinator_agent", "status_overview",
                "Aggregate counts of active incidents, official warnings, citizen reports and data-source health.",
                self.tool_status_overview,
                {"category": "hazard filter", "bbox": "[min_lat,min_lon,max_lat,max_lon]", "hours": "lookback window"}),
            "list_incidents": ToolSpec(
                "coordinator_agent", "list_incidents",
                "List incidents with filters (category, bbox, time window, minimum severity, verification status).",
                self.tool_list_incidents,
                {"category": "hazard", "bbox": "bbox", "hours": "int", "min_severity": "1-5", "limit": "int",
                 "verification_status": "string"}),
            "incident_detail": ToolSpec(
                "detection_agent", "incident_detail",
                "Full record for one incident: evidence, observations, risk, alerts, affected areas.",
                self.tool_incident_detail, {"incident_id": "ID or code"}),
            "explain_risk": ToolSpec(
                "risk_agent", "explain_risk",
                "Explain the risk score of an incident factor by factor (recomputes if no assessment exists).",
                self.tool_explain_risk, {"incident_id": "ID or code"}),
            "official_warnings": ToolSpec(
                "prediction_agent", "official_warnings",
                "Official warnings/bulletins ingested from authoritative feeds, with issuing authority and time.",
                self.tool_official_warnings, {"category": "hazard", "bbox": "bbox", "hours": "int"}),
            "facilities_near": ToolSpec(
                "geo_agent", "facilities_near",
                "Critical facilities near a location or incident (OpenStreetMap Overpass).",
                self.tool_facilities_near, {"incident_id": "ID", "lat": "float", "lon": "float", "radius_km": "float"}),
            "citizen_reports": ToolSpec(
                "citizen_agent", "citizen_reports",
                "Recent citizen reports with status/priority (always unverified unless status=verified).",
                self.tool_citizen_reports, {"status": "string", "bbox": "bbox", "limit": "int"}),
            "route_check": ToolSpec(
                "response_agent", "route_check",
                "Corridor hazard check + optional routing between two points; never certifies safety.",
                self.tool_route_check, {"incident_id": "ID", "from_lat": "float", "from_lon": "float",
                                        "to_lat": "float", "to_lon": "float"}),
            "weather_drivers": ToolSpec(
                "prediction_agent", "weather_drivers",
                "Model forecast drivers (rain, wind, soil moisture, fire weather) at a location.",
                self.tool_weather_drivers, {"lat": "float", "lon": "float", "incident_id": "ID"}),
            "run_detection_scan": ToolSpec(
                "detection_agent", "run_detection_scan",
                "Re-run detection over recent observations (bounded) and return new candidate incidents.",
                self.tool_run_detection_scan, {"hours": "int", "categories": "list", "bbox": "bbox"}),
            "assess_incident": ToolSpec(
                "geo_agent+risk_agent+prediction_agent", "assess_incident",
                "Refresh geospatial context, risk assessment and prediction/early-warning outlook for an incident.",
                self.tool_assess_incident, {"incident_id": "ID"}),
            "source_health": ToolSpec(
                "coordinator_agent", "source_health",
                "Status, last-success time and error of every integrated data source.",
                self.tool_source_health, {}),
            "data_gaps": ToolSpec(
                "coordinator_agent", "data_gaps",
                "What AEGIS cannot currently see: unconfigured sources, stale feeds, missing datasets.",
                self.tool_data_gaps, {}),
        }

    def tool_help(self) -> str:
        lines = []
        for name, spec in self.tool_catalogue().items():
            params = ", ".join(f"{k}" for k in spec.params) or "no params"
            lines.append(f"- tool `{name}` (agent: {spec.agent}): {spec.description} params: {params}")
        return "\n".join(lines)

    # ------------------------------------------------------------------ #
    # Tool implementations
    # ------------------------------------------------------------------ #
    def _scope(self, stmt, *, category=None, bbox=None, hours=None, min_severity=None, verification_status=None):
        from datetime import timedelta

        if category:
            cats = category if isinstance(category, (list, tuple)) else [category]
            stmt = stmt.where(models.Incident.category.in_(list(cats)))
        if bbox and len(bbox) == 4:
            stmt = stmt.where(models.Incident.lat.between(bbox[0], bbox[2]),
                              models.Incident.lon.between(bbox[1], bbox[3]))
        if hours:
            stmt = stmt.where(models.Incident.last_update_at >= now() - timedelta(hours=float(hours)))
        if min_severity:
            stmt = stmt.where(models.Incident.severity >= int(min_severity))
        if verification_status:
            stmt = stmt.where(models.Incident.verification_status == verification_status)
        return stmt

    def tool_list_incidents(self, db: Session, *, category=None, bbox=None, hours=None, min_severity=None,
                            verification_status=None, min_magnitude=None, limit: int = 20,
                            status_in=("active", "monitoring")) -> dict:
        """List incidents matching the filters (category, window, severity, magnitude, verification)."""
        stmt = select(models.Incident)
        if status_in:
            stmt = stmt.where(models.Incident.status.in_(tuple(status_in)))
        stmt = self._scope(stmt, category=category, bbox=bbox, hours=hours, min_severity=min_severity,
                           verification_status=verification_status)
        if min_magnitude:
            stmt = stmt.where(models.Incident.id.in_(
                select(models.Observation.incident_id).where(models.Observation.magnitude >= float(min_magnitude))))
        rows = list(db.scalars(stmt.order_by(models.Incident.severity.desc(),
                                            models.Incident.last_update_at.desc()).limit(min(limit, 100))))
        latest_risk = {}
        if rows:
            ids = [r.id for r in rows]
            for r in db.scalars(select(models.RiskAssessment).where(models.RiskAssessment.incident_id.in_(ids))
                                .order_by(models.RiskAssessment.created_at.asc())):
                latest_risk[r.incident_id] = r
        return {
            "count": len(rows),
            "incidents": [self._incident_brief(i, latest_risk.get(i.id)) for i in rows],
            "filter": {"category": category, "bbox": bbox, "hours": hours, "min_severity": min_severity,
                       "verification_status": verification_status, "min_magnitude": min_magnitude},
            "data_origin": sorted({i.data_origin for i in rows}) or ["none"],
        }

    @staticmethod
    def _incident_brief(i: models.Incident, risk: models.RiskAssessment | None = None) -> dict:
        return {
            "incident_id": i.id, "code": i.code, "title": i.title, "category": i.category,
            "status": i.status, "verification_status": i.verification_status, "severity": i.severity,
            "confidence": round(i.confidence, 1), "lat": i.lat, "lon": i.lon, "region": i.region,
            "country": i.country, "started_at": i.started_at.isoformat() + "Z",
            "last_update_at": i.last_update_at.isoformat() + "Z",
            "sources": i.source_keys or [], "source_urls": (i.source_urls or [])[:4],
            "data_origin": i.data_origin,
            "risk": ({"score": risk.risk_score, "level": risk.risk_level, "methodology": risk.methodology_version,
                      "estimate": True} if risk else None),
            "ambiguous": i.is_ambiguous,
        }

    def tool_incident_detail(self, db: Session, *, incident_id: str) -> dict:
        """Full incident record: evidence, observations, risk, alerts, areas."""
        inc = self._resolve_incident(db, incident_id)
        if inc is None:
            return {"found": False, "error": f"incident '{incident_id}' not found"}
        evidence = list(db.scalars(select(models.IncidentEvidence).where(models.IncidentEvidence.incident_id == inc.id))
                        .order_by(models.IncidentEvidence.observed_at.desc().nullslast()))
        observations = list(db.scalars(select(models.Observation).where(models.Observation.incident_id == inc.id)
                                       .order_by(models.Observation.observed_at.desc()).limit(40)))
        risks = list(db.scalars(select(models.RiskAssessment).where(models.RiskAssessment.incident_id == inc.id)
                                .order_by(models.RiskAssessment.created_at.desc()).limit(5)))
        alerts = list(db.scalars(select(models.Alert).where(models.Alert.incident_id == inc.id)
                                 .order_by(models.Alert.issued_at.desc()).limit(10)))
        areas = list(db.scalars(select(models.AffectedArea).where(models.AffectedArea.incident_id == inc.id)))
        reports = list(db.scalars(select(models.CitizenReport).where(models.CitizenReport.linked_incident_id == inc.id)
                                  .order_by(models.CitizenReport.created_at.desc()).limit(15)))
        return {
            "found": True,
            "incident": self._incident_brief(inc, risks[0] if risks else None) | {
                "summary": inc.summary, "classification_note": inc.classification_note,
                "primary_source_key": inc.primary_source_key, "tags": inc.tags or [],
                "external_refs": inc.external_refs or {}, "depth_km": inc.depth_km,
                "verified_at": inc.verified_at.isoformat() + "Z" if inc.verified_at else None,
                "verified_by": inc.verified_by,
            },
            "evidence": [{"kind": e.kind, "source": e.source_key, "title": e.title, "excerpt": e.excerpt,
                          "observed_at": e.observed_at.isoformat() + "Z" if e.observed_at else None,
                          "confidence": e.confidence, "url": e.source_url, "data_origin": e.data_origin}
                         for e in evidence[:25]],
            "observations": [{"source": o.source_key, "external_id": o.external_id, "lat": o.lat, "lon": o.lon,
                              "magnitude": o.magnitude, "unit": o.magnitude_unit,
                              "observed_at": o.observed_at.isoformat() + "Z", "url": o.source_url,
                              "payload": {k: v for k, v in (o.payload or {}).items()
                                          if k in {"status", "alert_level", "depth_km", "tsunami_flag", "category",
                                                   "classification", "intensity_kmh", "severity"}},
                              "confidence": o.confidence} for o in observations[:20]],
            "risk_assessments": [{"id": r.id, "score": r.risk_score, "level": r.risk_level,
                                  "hazard": r.hazard_score, "exposure": r.exposure_score,
                                  "vulnerability": r.vulnerability_score, "methodology": r.methodology_version,
                                  "narrative": r.narrative, "limitations": r.limitations,
                                  "llm_used": r.llm_used, "created_at": r.created_at.isoformat() + "Z",
                                  "factors": r.factors} for r in risks[:2]],
            "alerts": [{"id": a.id, "kind": a.alert_kind, "severity": a.severity, "title": a.title,
                        "status": a.status, "authority": a.authority, "issued_at": a.issued_at.isoformat() + "Z",
                        "instructions": a.instructions, "source_url": a.source_url} for a in alerts],
            "affected_areas": [{"label": a.label, "area_km2": a.area_km2, "radius_km": a.radius_km,
                                "population_estimate": a.population_estimate, "is_estimate": a.is_estimate,
                                "authority": a.authority, "method": a.method} for a in areas],
            "citizen_reports": [{"public_code": r.public_code, "status": r.status, "priority": r.priority,
                                 "category": r.category, "place": r.place, "linked": bool(r.linked_incident_id),
                                 "created_at": r.created_at.isoformat() + "Z"} for r in reports],
            "caveats": [
                "Detections are candidate events unless verification_status is corroborated/human_verified/officially_confirmed.",
                "Risk scores are AEGIS model estimates (see methodology + limitations).",
                "Citizen reports are unverified unless status=verified by an analyst.",
            ],
        }

    def tool_explain_risk(self, db: Session, *, incident_id: str) -> dict:
        """Explain factor-by-factor why an incident scores the way it does."""
        inc = self._resolve_incident(db, incident_id)
        if inc is None:
            return {"found": False, "error": f"incident '{incident_id}' not found"}
        last = db.scalar(select(models.RiskAssessment).where(models.RiskAssessment.incident_id == inc.id)
                         .order_by(models.RiskAssessment.created_at.desc()))
        source = "stored"
        if last is None:
            res = risk_mod.risk_agent.assess(db, inc, None, persist=True)
            last = db.scalar(select(models.RiskAssessment).where(models.RiskAssessment.id == res["assessment_id"]))
            source = "recomputed_now"
        factors = [f for f in (last.factors or []) if f.get("factor") != "_weights"]
        weights = next((f.get("value") for f in (last.factors or []) if f.get("factor") == "_weights"), [])
        return {
            "found": True, "incident": self._incident_brief(inc, last), "risk_source": source,
            "score": last.risk_score, "level": last.risk_level,
            "components": {"hazard": last.hazard_score, "exposure": last.exposure_score,
                           "vulnerability": last.vulnerability_score},
            "weights": weights,
            "factors": sorted(factors, key=lambda f: -abs(f.get("contribution", 0))),
            "narrative": last.narrative, "limitations": last.limitations,
            "methodology_version": last.methodology_version, "llm_used": last.llm_used,
            "estimate": True,
        }

    def tool_official_warnings(self, db: Session, *, category=None, bbox=None, hours: int = 72, limit: int = 20) -> dict:
        """Official warnings with issuing authority and timestamp."""
        from datetime import timedelta

        since = now() - timedelta(hours=hours)
        stmt = select(models.Alert).where(models.Alert.alert_kind == "official_ingested",
                                          models.Alert.issued_at >= since)
        if category:
            cats = category if isinstance(category, (list, tuple)) else [category]
            stmt = stmt.where(models.Alert.hazard.in_(list(cats)))
        if bbox and len(bbox) == 4:
            stmt = stmt.where(models.Alert.lat.between(bbox[0], bbox[2]), models.Alert.lon.between(bbox[1], bbox[3]))
        rows = list(db.scalars(stmt.order_by(models.Alert.issued_at.desc()).limit(min(limit, 50))))
        pending = list(db.scalars(select(models.Alert).where(models.Alert.alert_kind == "ai_advisory",
                                                              models.Alert.status == "pending_review")
                                  .order_by(models.Alert.created_at.desc()).limit(10)))
        return {
            "count": len(rows),
            "official_warnings": [{
                "id": a.id, "title": a.title, "authority": a.authority, "hazard": a.hazard, "severity": a.severity,
                "issued_at": a.issued_at.isoformat() + "Z", "source": a.source_key, "source_url": a.source_url,
                "body_excerpt": (a.body or "")[:700], "instructions": a.instructions or [],
                "status": a.status, "data_origin": a.data_origin,
            } for a in rows],
            "note": ("Official warnings are ingested verbatim from the issuing authority and are never paraphrased, "
                     "regenerated or superseded by AEGIS."),
            "ai_drafts_pending_human_review": [{
                "id": a.id, "title": a.title, "severity": a.severity, "incident_id": a.incident_id,
                "note": "AEGIS draft — NOT published, NOT an official warning. Requires authorised human review.",
            } for a in pending],
        }

    def tool_facilities_near(self, db: Session, *, incident_id: str | None = None, lat: float | None = None,
                            lon: float | None = None, radius_km: float = 25.0) -> dict:
        """Critical facilities near a point or an incident (OpenStreetMap)."""
        if incident_id:
            inc = self._resolve_incident(db, incident_id)
            if inc is None:
                return {"ok": False, "error": f"incident '{incident_id}' not found"}
            lat, lon = inc.lat, inc.lon
        if lat is None or lon is None:
            return {"ok": False, "error": "provide incident_id or lat/lon"}
        data = fac_service.nearby_facilities(float(lat), float(lon), float(radius_km))
        data["query_point"] = {"lat": float(lat), "lon": float(lon)}
        data["caution"] = ("OpenStreetMap facilities are community-mapped: presence does not guarantee the facility is "
                           "open, staffed or usable. Confirm with local authorities.")
        return data

    def tool_citizen_reports(self, db: Session, *, status: str | None = None, bbox=None, limit: int = 20,
                            hours: int = 168) -> dict:
        """Recent citizen reports (unverified unless an analyst verified them)."""
        from datetime import timedelta

        stmt = select(models.CitizenReport).where(models.CitizenReport.created_at >= now() - timedelta(hours=hours))
        if status:
            stmt = stmt.where(models.CitizenReport.status == status)
        if bbox and len(bbox) == 4:
            stmt = stmt.where(models.CitizenReport.lat.between(bbox[0], bbox[2]),
                              models.CitizenReport.lon.between(bbox[1], bbox[3]))
        rows = list(db.scalars(stmt.order_by(models.CitizenReport.created_at.desc()).limit(min(limit, 60))))
        return {
            "count": len(rows),
            "reports": [{"public_code": r.public_code, "status": r.status, "priority": r.priority,
                         "category": r.category, "place": r.place,
                         "lat": round(r.lat, 2), "lon": round(r.lon, 2),  # coarse coords in assistant output
                         "created_at": r.created_at.isoformat() + "Z", "flags": r.flags or [],
                         "linked_incident_id": r.linked_incident_id,
                         "verified": r.status == "verified",
                         "excerpt": (r.description or "")[:180]} for r in rows],
            "note": ("Citizen reports are UNVERIFIED unless status='verified'. They never trigger public alerts "
                     "without human review. Exact coordinates are withheld here; full precision is analyst-only."),
        }

    def tool_route_check(self, db: Session, *, incident_id: str, from_lat: float, from_lon: float,
                         to_lat: float | None = None, to_lon: float | None = None) -> dict:
        """Corridor hazard check + optional routing; never certifies a route as safe."""
        inc = self._resolve_incident(db, incident_id)
        if inc is None:
            return {"ok": False, "error": f"incident '{incident_id}' not found"}
        return resp_mod.response_agent.route_assessment(
            db, inc, from_lat=float(from_lat), from_lon=float(from_lon),
            to_lat=float(to_lat if to_lat is not None else inc.lat),
            to_lon=float(to_lon if to_lon is not None else inc.lon))

    def tool_weather_drivers(self, db: Session, *, lat: float | None = None, lon: float | None = None,
                             incident_id: str | None = None) -> dict:
        """Model forecast drivers at a location (model output, not measurements)."""
        if incident_id:
            inc = self._resolve_incident(db, incident_id)
            if inc is None:
                return {"ok": False, "error": f"incident '{incident_id}' not found"}
            lat, lon = inc.lat, inc.lon
        if lat is None or lon is None:
            return {"ok": False, "error": "provide incident_id or lat/lon"}
        wx = wx_service.forecast(float(lat), float(lon))
        if not wx.get("ok"):
            return {"ok": False, "error": wx.get("error"), "note": "Weather model unavailable"}
        return {"ok": True, "label": wx["label"], "source": wx["source"], "source_url": wx["source_url"],
                "summary": wx["summary"], "fetched_at": wx["fetched_at"],
                "flood_driver": wx_service.flood_drivers(wx), "wind_driver": wx_service.wind_drivers(wx),
                "fire_weather_driver": wx_service.heat_dryness_drivers(wx),
                "landslide_driver": wx_service.landslide_drivers(wx)}

    def tool_run_detection_scan(self, db: Session, *, hours: int = 24, categories=None, bbox=None) -> dict:
        """Re-run detection over recent observations (bounded)."""
        ctx = AgentContext(db=db, agent_name="detection_agent")
        result = det_mod.detection_agent.run(db, ctx, hours=int(hours), categories=categories, bbox=bbox)
        result["tool_calls"] = ctx.tool_calls
        return result

    def tool_assess_incident(self, db: Session, *, incident_id: str, radius_km: float = 25.0) -> dict:
        """Refresh geospatial context, risk assessment and outlook for one incident."""
        inc = self._resolve_incident(db, incident_id)
        if inc is None:
            return {"ok": False, "error": f"incident '{incident_id}' not found"}
        ctx = AgentContext(db=db, agent_name="assess_incident")
        from .classification_agent import classification_agent

        classification = classification_agent.apply(db, inc, ctx)
        geo_report = geo_mod.geo_agent.context_report(db, inc, ctx, radius_km=radius_km)
        risk = risk_mod.risk_agent.assess(db, inc, ctx, weather=None, area=geo_report["area"],
                                          facilities=geo_report["facilities"])
        trend = pred_mod.prediction_agent.trend(db, inc)
        forecast = pred_mod.prediction_agent.official_forecast(db, inc)
        return {"ok": True, "incident": self._incident_brief(inc), "classification": classification,
                "geospatial": geo_report, "risk": risk, "trend": trend, "forecast": forecast,
                "tool_calls": ctx.tool_calls, "findings": ctx.findings}

    def tool_status_overview(self, db: Session, *, category=None, bbox=None, hours: int = 48) -> dict:
        """Aggregate situation overview across incidents, warnings, reports and sources."""
        incidents = self.tool_list_incidents(db, category=category, bbox=bbox, hours=hours, limit=12)
        warnings = self.tool_official_warnings(db, category=category, bbox=bbox, hours=hours)
        reports = self.tool_citizen_reports(db, bbox=bbox, limit=10)
        by_cat = db.execute(select(models.Incident.category, func.count()).where(
            models.Incident.status.in_(("active", "monitoring"))).group_by(models.Incident.category)).all()
        by_verif = db.execute(select(models.Incident.verification_status, func.count()).where(
            models.Incident.status.in_(("active", "monitoring"))).group_by(models.Incident.verification_status)).all()
        return {
            "window_hours": hours,
            "active_incidents": incidents["count"],
            "top_incidents": incidents["incidents"][:8],
            "official_warnings": warnings["count"],
            "official_warning_items": warnings["official_warnings"][:6],
            "citizen_reports": reports["count"],
            "distribution_by_category": {k: v for k, v in by_cat},
            "distribution_by_verification": {k: v for k, v in by_verif},
            "data_origin_mix": incidents["data_origin"],
        }

    def tool_source_health(self, db: Session, **_) -> dict:
        """Status, freshness and errors for every integrated data source."""
        rows = list(db.scalars(select(models.DataSource).order_by(models.DataSource.key)))
        return {
            "count": len(rows),
            "sources": [{
                "key": s.key, "name": s.name, "provider": s.provider, "role": s.role if hasattr(s, "role") else None,
                "status": s.status, "auth_mode": s.auth_mode, "credential_env": s.credential_env,
                "last_ok_at": s.last_ok_at.isoformat() + "Z" if s.last_ok_at else None,
                "last_attempt_at": s.last_attempt_at.isoformat() + "Z" if s.last_attempt_at else None,
                "last_error": s.last_error, "latency_ms": s.latency_ms, "records": s.records_last_fetch,
                "is_demo": s.is_demo, "note": s.reliability_note,
            } for s in rows],
        }

    def tool_data_gaps(self, db: Session, **_) -> dict:
        """Explicitly report what AEGIS cannot currently see."""
        rows = list(db.scalars(select(models.DataSource)))
        gaps = []
        for s in rows:
            if s.status == "no_credentials":
                gaps.append({"source": s.key, "gap": "credentials required", "fix": f"set {s.credential_env}",
                             "impact": s.reliability_note})
            elif s.status in {"error", "degraded", "stale"}:
                gaps.append({"source": s.key, "gap": s.status, "detail": s.last_error or "no recent successful fetch",
                             "impact": s.reliability_note})
        return {
            "gaps": gaps,
            "structural_limitations": [
                "No live road-closure / bridge-status feed: AEGIS cannot certify travel routes.",
                "No sub-national vulnerability index: vulnerability uses a hazard-level static prior.",
                "Population exposure uses a static ~2011 gazetteer, not a live census.",
                "Landslide, industrial-fire and urban-flood detection have no dedicated public sensor feed; they rely on "
                "citizen reports, GDACS and derived signals.",
                "No radar nowcast ingestion (e.g. IMD radar mosaic) in this build.",
            ],
        }

    # ------------------------------------------------------------------ #
    @staticmethod
    def _resolve_incident(db: Session, identifier: str) -> models.Incident | None:
        if not identifier:
            return None
        inc = db.get(models.Incident, identifier)
        if inc:
            return inc
        return db.scalar(select(models.Incident).where(models.Incident.code == identifier))

    # ------------------------------------------------------------------ #
    # Planning
    # ------------------------------------------------------------------ #
    def rule_plan(self, goal: str) -> dict[str, Any]:
        """Deterministic planner — runs with or without an LLM."""
        import re as _re

        g = (goal or "").lower()
        steps: list[dict] = []
        # parse explicit time windows ("last 48 hours", "past 3 days", "today")
        window_hours = None
        m_win = _re.search(r"(?:last|past|previous|next)\s+(\d{1,3})\s*(hour|hr|day|week)", g)
        if m_win:
            n, unit = int(m_win.group(1)), m_win.group(2)
            window_hours = n * {"hour": 1, "hr": 1, "day": 24, "week": 168}[unit]
        elif "today" in g:
            window_hours = 24
        elif "this week" in g:
            window_hours = 168
        m_mag = _re.search(r"magnitude\s*([0-9]+(?:\.[0-9]+)?)", g)
        min_magnitude = float(m_mag.group(1)) if m_mag else None
        cats = [c for c in ["wildfire", "cyclone", "flood", "tsunami", "landslide", "earthquake", "industrial_fire"]
                if c.replace("_", " ") in g or c in g]
        if any(w in g for w in ["cyclone", "storm", "hurricane", "typhoon", "toofan"]):
            cats.append("cyclone")
        if any(w in g for w in ["fire", "smoke"]):
            cats.extend(["wildfire", "industrial_fire"])
        if any(w in g for w in ["quake", "tremor", "seismic"]):
            cats.append("earthquake")
        cats = sorted(set(cats))

        # Every operational question starts from the current situation picture.
        wants_overview = (
            not any(w in g for w in ["data source", "coverage", "gap", "limitation", "health", "cannot see",
                                     "can't see", "blind"])
            or any(w in g for w in ["hazard", "incident", "active", "situation", "overview", "status", "now",
                                    "warning", "alert"])
        )
        if wants_overview:
            steps.append({"tool": "status_overview",
                          "why": "Anchor the answer in the current situation picture (active incidents, warnings, "
                                 "reports, source health).",
                          "params": {"category": cats or None, "hours": window_hours or 72}})

        if any(w in g for w in ["why", "explain", "reason", "high risk", "rating"]):
            steps.append({"tool": "explain_risk", "why": "The question asks for the reasoning behind a risk rating."})
            if not any(w in g for w in ["incident", "aegis-", "inc_"]):
                steps.insert(0, {"tool": "list_incidents", "why": "Need to identify the incident being discussed.",
                                 "params": {"category": cats or None, "limit": 5}})
        # explicit "show/list the events" requests
        if cats or any(w in g for w in ["show", "list", "events from", "which incidents", "how many"]) or min_magnitude:
            params: dict = {"limit": 12}
            if cats:
                params["category"] = cats
            if window_hours:
                params["hours"] = window_hours
            if min_magnitude:
                params["min_magnitude"] = min_magnitude
            steps.append({"tool": "list_incidents",
                          "why": "The question asks for specific events, so retrieve the matching incident records.",
                          "params": params})

        if any(w in g for w in ["warning", "alert", "bulletin", "advisory", "official", "confirm", "verif"]):
            steps.append({"tool": "official_warnings", "why": "Official warnings must come from the issuing authority.",
                          "params": {"category": cats or None, "hours": window_hours or 72}})
            steps.append({"tool": "list_incidents", "why": "Show each incident's verification status so confirmed and "
                                                           "preliminary events are not conflated.",
                          "params": {"category": cats or None, "hours": 168, "limit": 12}})
        if any(w in g for w in ["nearby", "facilit", "hospital", "shelter", "camp", "resources"]):
            steps.append({"tool": "facilities_near", "why": "Response question requires mapped facilities."})
        if any(w in g for w in ["route", "evacuat", "travel", "reach", "safe to drive"]):
            steps.append({"tool": "route_check", "why": "Movement question: corridor hazard check (safety is never certified)."})
        if any(w in g for w in ["weather", "rain", "wind", "forecast", "monsoon"]):
            steps.append({"tool": "weather_drivers", "why": "Hazard drivers come from model forecast fields."})
        if any(w in g for w in ["citizen report", "citizen", "public submission", "people saying", "unverified",
                                "submitted by", "reports from the public"]):
            steps.append({"tool": "citizen_reports", "why": "Citizen reports are unverified and must be labelled."})
        wants_gaps = bool(_re.search(
            r"(what|which|anything)[^?]*\b(can(?:not|'?t)|cannot|not|missing|blind|gap|unavailable|unconfigured|stale)\b"
            r"[^?]*\b(see|detect|know|monitor|cover|source|data|feed|integration)\b", g)) or any(
            w in g for w in ["data source", "source health", "coverage", "gap", "what can you see", "blind spot",
                             "limitation", "stale", "cannot see", "can't see", "cant see", "cannot detect",
                             "missing data", "unavailable"])
        if wants_gaps:
            if not any(s["tool"] == "source_health" for s in steps):
                steps.append({"tool": "source_health", "why": "Report integration health."})
            if not any(s["tool"] == "data_gaps" for s in steps):
                steps.append({"tool": "data_gaps", "why": "Report what cannot be seen."})
        if any(w in g for w in ["scan", "detect", "new event", "recent detection"]):
            steps.append({"tool": "run_detection_scan", "why": "Fresh detection pass requested.", "params": {"hours": 24}})
        if any(w in g for w in ["assess", "reassess", "update risk", "refresh"]):
            steps.append({"tool": "assess_incident", "why": "Explicit reassessment request."})

        if not steps:
            # Default: situation overview + warnings + gaps.
            steps = [
                {"tool": "status_overview", "why": "Default entry point for a general situation question.",
                 "params": {"category": cats or None, "hours": 72}},
                {"tool": "official_warnings", "why": "Always surface official warnings and their authority.",
                 "params": {"category": cats or None, "hours": 72}},
                {"tool": "data_gaps", "why": "State what AEGIS cannot see before analysis."},
            ]
            if cats:
                steps.insert(1, {"tool": "list_incidents", "why": "Filter by the hazard mentioned.",
                                 "params": {"category": cats, "limit": 6}})
        seen: set[str] = set()
        deduped = []
        for st in steps:
            if st["tool"] in seen:
                continue
            seen.add(st["tool"])
            deduped.append(st)
        steps = deduped
        return {"planner": "rules", "categories": cats, "steps": steps,
                "reasoning": f"Rule-based plan selected {len(steps)} tool step(s) from the question wording."}

    def llm_plan(self, goal: str, incident_ids: list[str]) -> dict[str, Any] | None:
        """Optional LLM intent parsing, strictly allow-listed."""
        if not llm_client.enabled:
            return None
        res = llm_client.intent_json(goal, self.tool_help())
        if not (res.ok and res.data):
            return None
        allowed = set(self.tool_catalogue().keys())
        steps = []
        for raw in res.data.get("tools", [])[:6]:
            tool = str(raw.get("tool") or "").strip()
            if tool not in allowed:
                log.warning("LLM proposed unknown tool '%s' — dropped", tool)
                continue
            params = raw.get("params") or {}
            params = {k: v for k, v in params.items() if k in self.tool_catalogue()[tool].params or k == "incident_id"}
            if incident_ids and not params.get("incident_id") and tool in {"explain_risk", "incident_detail",
                                                                           "assess_incident", "route_check"}:
                params["incident_id"] = incident_ids[0]
            steps.append({"tool": tool, "why": f"LLM plan: {str(raw.get('reasoning') or '')[:200]}", "params": params})
        if not steps:
            return None
        return {"planner": "llm", "steps": steps, "intent": res.data.get("intent"),
                "reasoning": res.data.get("reasoning", ""), "model": res.model, "latency_ms": res.latency_ms,
                "llm_used": True}

    # ------------------------------------------------------------------ #
    def run(
        self,
        db: Session,
        *,
        goal: str,
        trigger: str = "manual",
        user: models.User | None = None,
        params: dict | None = None,
        persist_run: bool = True,
    ) -> dict[str, Any]:
        params = params or {}
        started = time.perf_counter()
        ctx = AgentContext(db=db, agent_name=self.name, deadline=time.perf_counter() + AGENT_TIMEOUT_SECONDS)

        run = models.AgentRun(
            run_code=new_run_code(), goal=goal[:1000], trigger=trigger, status="running",
            llm_mode="llm" if llm_client.enabled else "rules",
            llm_model=(llm_client.model if llm_client.enabled else ""),
            requested_by=getattr(user, "id", None),
        )
        if persist_run:
            db.add(run)
            db.flush()
        ctx.run = run

        # 1) identify candidate incidents the question may refer to
        mentioned_ids = [i for i in params.get("incident_ids", []) if i]
        explicit = _extract_incident_reference(goal)
        if explicit:
            inc = self._resolve_incident(db, explicit)
            if inc:
                mentioned_ids.append(inc.id)
        elif not mentioned_ids:
            probe = self.tool_list_incidents(db, limit=3, hours=168)
            mentioned_ids = [i["incident_id"] for i in probe["incidents"]]

        # 2) plan
        plan = None
        if params.get("force_planner") == "rules":
            plan = self.rule_plan(goal)
        else:
            plan = self.llm_plan(goal, mentioned_ids) or self.rule_plan(goal)
        steps = plan["steps"]
        if persist_run:
            run.plan = steps

        # 3) execute
        tool_map = self.tool_catalogue()
        results: dict[str, Any] = {}
        executed = []
        for idx, step in enumerate(steps):
            if ctx.timed_out():
                executed.append({"tool": step["tool"], "status": "skipped", "error": "run deadline exceeded"})
                break
            spec = tool_map.get(step["tool"])
            task = models.AgentTask(
                run_id=run.id if persist_run else "", step_index=idx, agent=(spec.agent if spec else step["tool"]),
                objective=step.get("why", "")[:400], status="running", input={"params": _safe(step.get("params") or {})},
                started_at=now(),
            )
            if persist_run:
                db.add(task)
                db.flush()
            t0 = time.perf_counter()
            if spec is None:
                task.status = "error"
                task.error = f"tool '{step['tool']}' not in allow-list"
                executed.append({"tool": step["tool"], "status": "error", "error": task.error})
                continue
            call_params = dict(step.get("params") or {})
            if mentioned_ids and spec.name in {"explain_risk", "incident_detail", "assess_incident", "route_check",
                                               "facilities_near", "weather_drivers"}:
                call_params.setdefault("incident_id", mentioned_ids[0])
            call_params = _clean_params(call_params, spec)
            try:
                with ctx.tool(f"{spec.agent}:{spec.name}", call_params) as t:
                    output = spec.fn(db, **call_params)
                    t["summary"] = _summarise_output(spec.name, output)
                    t["source"] = output.get("source") if isinstance(output, dict) else None
                task.status = "ok"
                task.output = _safe(output)
                results[step["tool"]] = output
                executed.append({"tool": step["tool"], "agent": spec.agent, "status": "ok",
                                 "latency_ms": int((time.perf_counter() - t0) * 1000),
                                 "summary": _summarise_output(spec.name, output)})
            except Exception as exc:  # noqa: BLE001
                log.exception("coordinator tool %s failed", step["tool"])
                task.status = "error"
                task.error = f"{exc.__class__.__name__}: {exc}"
                results[step["tool"]] = {"error": task.error}
                executed.append({"tool": step["tool"], "agent": spec.agent, "status": "error", "error": task.error})
            finally:
                task.finished_at = now()
                task.latency_ms = int((time.perf_counter() - t0) * 1000)
                task.tool_calls = ctx.tool_calls[-4:]
                if persist_run:
                    db.flush()

        # 4) synthesise the brief
        report = self.synthesise(goal, results, plan, executed, ctx)
        if persist_run:
            run.status = "completed" if all(e["status"] == "ok" for e in executed) else "completed_with_errors"
            run.summary = report["headline"]
            run.report = _safe(report)
            run.finished_at = now()
            run.duration_ms = int((time.perf_counter() - started) * 1000)
            run.llm_mode = "llm" if (plan.get("llm_used") or ctx.llm_used or report.get("llm_used")) else "rules"
            db.flush()
        report["run_id"] = run.id if persist_run else None
        report["run_code"] = run.run_code if persist_run else None
        report["plan"] = plan
        report["execution"] = executed
        report["findings"] = ctx.findings
        report["tool_calls"] = ctx.tool_calls
        report["duration_ms"] = int((time.perf_counter() - started) * 1000)
        return report

    # ------------------------------------------------------------------ #
    def synthesise(self, goal: str, results: dict, plan: dict, executed: list[dict], ctx: AgentContext) -> dict:
        """Assemble the brief: verified facts / estimates / unverified, gaps, sources, approvals."""
        verified: list[dict] = []
        estimates: list[dict] = []
        unverified: list[dict] = []
        gaps: list[dict] = []
        sources: dict[str, dict] = {}
        next_steps: list[str] = []
        approvals: list[dict] = []

        def note_source(key: str, url: str | None = None, at: str | None = None) -> None:
            if not key:
                return
            entry = sources.setdefault(key, {"source": key, "url": url, "last_data_at": at})
            entry["url"] = entry.get("url") or url
            entry["last_data_at"] = _max_iso(entry.get("last_data_at"), at)

        ov = results.get("status_overview") or {}
        for inc in (ov.get("top_incidents") or []):
            item = {"kind": "incident", "code": inc["code"], "incident_id": inc["incident_id"],
                    "text": f"{inc['title']} — {inc['category']}, severity {inc['severity']}/5, "
                            f"{inc['verification_status'].replace('_', ' ')}",
                    "at": inc["last_update_at"], "region": inc.get("region")}
            (verified if inc["verification_status"] in {"officially_confirmed", "human_verified", "corroborated"}
             else estimates).append(item)
            for s in inc.get("sources", []):
                note_source(s, (inc.get("source_urls") or [None])[0], inc["last_update_at"])
            if inc.get("risk"):
                estimates.append({"kind": "risk_estimate", "code": inc["code"],
                                  "text": f"AEGIS risk estimate {inc['risk']['score']:.0f}/100 "
                                          f"({inc['risk']['level']}) — methodology {inc['risk']['methodology']} (model estimate)",
                                  "incident_id": inc["incident_id"], "estimate": True})

        for w in (results.get("official_warnings") or {}).get("official_warnings", [])[:8]:
            verified.append({"kind": "official_warning", "text": f"{w['title']} — issued by {w['authority']}",
                             "at": w["issued_at"], "url": w["source_url"], "alert_id": w["id"]})
            note_source(w.get("source"), w.get("source_url"), w.get("issued_at"))
        for d in (results.get("official_warnings") or {}).get("ai_drafts_pending_human_review", []):
            approvals.append({"action": "review_ai_alert_draft", "alert_id": d["id"], "title": d["title"],
                              "reason": "AEGIS-generated advisory must not be published without authorised human review.",
                              "severity": d["severity"]})

        for r in (results.get("citizen_reports") or {}).get("reports", [])[:8]:
            unverified.append({"kind": "citizen_report",
                               "text": f"{r['public_code']}: {r['excerpt']}… ({r['place'] or 'location not resolved'}) "
                                       f"[{r['status']}]",
                               "at": r["created_at"], "verified": r["verified"]})
            note_source("citizen", None, r["created_at"])

        gaps.extend((results.get("data_gaps") or {}).get("gaps", []))
        for lim in (results.get("data_gaps") or {}).get("structural_limitations", []):
            gaps.append({"source": "structural", "gap": lim})
        for s in (results.get("source_health") or {}).get("sources", []):
            if s["status"] != "ok":
                gaps.append({"source": s["key"], "gap": s["status"], "detail": s["last_error"]})
            note_source(s["key"], None, s["last_success"] if "last_success" in s else s.get("last_ok_at"))

        detail = results.get("incident_detail") or {}
        if detail.get("found"):
            inc = detail["incident"]
            for ev in detail.get("evidence", [])[:6]:
                bucket = verified if ev["kind"] == "official_alert" else estimates
                bucket.append({"kind": f"evidence:{ev['kind']}", "text": f"{ev['title']} [{ev['source']}]",
                               "at": ev.get("observed_at"), "url": ev.get("url")})
                note_source(ev.get("source"), ev.get("url"), ev.get("observed_at"))
        for rep in (results.get("assess_incident") or {}).get("findings", [])[:10] if results.get("assess_incident") else []:
            bucket = unverified if rep.get("kind") == "citizen_report" else estimates
            bucket.append({"kind": rep.get("kind", "finding"), "text": rep.get("finding"), "at": rep.get("at"),
                           "source": rep.get("source"), "estimate": rep.get("kind") in {"estimate", "classification"}})

        er = results.get("explain_risk") or {}
        if er.get("found"):
            top = [f for f in er.get("factors", [])][:6]
            estimates.append({
                "kind": "risk_explanation",
                "text": f"{er['incident']['code']}: risk {er['score']:.0f}/100 ({er['level']}); dominant factors — "
                        + "; ".join(f"{f['factor']} {f.get('contribution', 0):+.0f}" for f in top),
                "incident_id": er["incident"]["incident_id"], "estimate": True})

        fac = results.get("facilities_near") or {}
        if fac.get("ok"):
            note_source("openstreetmap", fac.get("source_url"))
            verified.append({"kind": "facilities",
                             "text": f"{fac.get('count', 0)} mapped facilit(ies) within {fac.get('radius_km')} km "
                                     f"(OpenStreetMap; completeness varies — confirm with authorities)"})
        rc = results.get("route_check") or {}
        if rc:
            estimates.append({"kind": "route_assessment",
                              "text": f"Corridor check: {rc.get('verdict')} ({rc.get('hazards_in_corridor') and len(rc['hazards_in_corridor'])} hazard(s) near corridor)",
                              "estimate": True})
            next_steps.append("Confirm any movement plan with local responders; AEGIS does not certify route safety.")

        if not next_steps:
            next_steps = [
                "Open the incident in the Intelligence Center for the full evidence trail and limitations.",
                "Cross-check official bulletins from the responsible agency before acting.",
                "Submit a citizen report if you have direct observations of the situation.",
            ]

        # ---- headline (LLM if available, otherwise deterministic) ---- #
        payload = {
            "question": goal,
            "verified_facts": verified[:12],
            "model_estimates": estimates[:12],
            "unverified_reports": unverified[:8],
            "data_gaps": gaps[:8],
            "execution": executed,
        }
        llm_used = False
        headline = ""
        if llm_client.enabled:
            res = llm_client.narrative(payload, question=goal)
            if res.ok and res.text:
                headline = res.text.strip()
                llm_used = True
                ctx.llm_used = True
        if not headline:
            n_inc = (results.get("status_overview") or {}).get("active_incidents")
            n_warn = (results.get("official_warnings") or {}).get("count")
            bits = []
            if n_inc is not None:
                bits.append(f"{n_inc} active incident(s) in scope")
            if n_warn is not None:
                bits.append(f"{n_warn} official warning(s) in the last 72 h")
            if unverified:
                bits.append(f"{len(unverified)} unverified citizen report(s)")
            if gaps:
                bits.append(f"{len(gaps)} data gap(s)/limitation(s)")
            headline = (f"AEGIS ran {len(executed)} tool step(s). " + ("; ".join(bits) + ". " if bits else "")
                        + "All risk values are AEGIS model estimates; official statements are quoted with their authority.")
            if not llm_client.enabled:
                headline += (" (Deterministic reasoning layer active — configure AEGIS_LLM_API_KEY for natural-language "
                             "summaries; retrieval and scoring are identical either way.)")

        return {
            "headline": headline,
            "verified_facts": verified,
            "model_estimates": estimates,
            "unverified_reports": unverified,
            "data_gaps": gaps,
            "sources": list(sources.values()),
            "recommended_next_steps": next_steps,
            "requires_human_approval": approvals,
            "separation_note": ("This brief separates official/verified information from AEGIS model estimates and "
                                "unverified citizen submissions. AEGIS does not issue official warnings."),
            "llm_used": llm_used,
            "llm_note": ("Narrative composed by the configured LLM strictly from the retrieved evidence."
                         if llm_used else
                         "Narrative composed by the deterministic template layer from retrieved evidence."),
        }


def _clean_params(params: dict, spec: ToolSpec) -> dict:
    allowed = set(spec.params) | {"incident_id", "lat", "lon", "bbox", "hours", "category", "limit",
                                  "min_severity", "verification_status", "status", "radius_km", "from_lat",
                                  "from_lon", "to_lat", "to_lon", "incident_ids", "force_planner"}
    out = {}
    for k, v in params.items():
        if k in allowed and v is not None:
            out[k] = v
    # normalise bbox lists
    if isinstance(out.get("bbox"), list) and len(out["bbox"]) == 4:
        try:
            out["bbox"] = tuple(float(x) for x in out["bbox"])
        except (TypeError, ValueError):
            out.pop("bbox")
    for k in ("lat", "lon", "radius_km", "from_lat", "from_lon", "to_lat", "to_lon"):
        if k in out:
            try:
                out[k] = float(out[k])
            except (TypeError, ValueError):
                out.pop(k)
    for k in ("hours", "limit", "min_severity"):
        if k in out:
            try:
                out[k] = int(out[k])
            except (TypeError, ValueError):
                out.pop(k)
    return out


def _safe(obj: Any, depth: int = 0) -> Any:
    """Make tool outputs JSON-safe and bounded in size."""
    if depth > 6:
        return "..."
    if isinstance(obj, dict):
        return {str(k): _safe(v, depth + 1) for k, v in list(obj.items())[:40]}
    if isinstance(obj, (list, tuple)):
        return [_safe(v, depth + 1) for v in obj[:40]]
    if isinstance(obj, (str,)):
        return obj[:2000]
    if isinstance(obj, (int, float, bool)) or obj is None:
        return obj
    return str(obj)[:400]


def _summarise_output(name: str, output: dict) -> str:
    if not isinstance(output, dict):
        return "ok"
    if "error" in output and output.get("error"):
        return f"error: {str(output['error'])[:120]}"
    for key in ("count", "found", "ok", "incidents_created"):
        if key in output:
            if key == "found":
                return "record found" if output[key] else "no record found"
            if key == "incidents_created":
                return f"{len(output[key] or [])} new candidate incident(s)"
            if key == "ok":
                continue
            return f"{output[key]} record(s)"
    if "packages" in output:
        return f"{len(output['packages'])} package(s)"
    return "ok"


def _max_iso(a: str | None, b: str | None) -> str | None:
    if not a:
        return b
    if not b:
        return a
    return max(a, b)


def _extract_incident_reference(text: str) -> str | None:
    import re

    for pat in (r"(AEGIS-[A-Z]{3}-\d{6}-[A-Z0-9]{5})", r"\b(inc_[0-9a-f]{6,})\b"):
        m = re.search(pat, text or "", re.I)
        if m:
            return m.group(1)
    return None


coordinator_agent = CoordinatorAgent()
