"""Agent 1 — Disaster Detection Agent.

Inputs : observations already normalised from provider feeds (satellite, seismic,
         weather, official alert feeds) — see app/ingest.py.
Does   : identifies unusual signals, associates them with place/time, groups
         related observations into candidate incidents, and correlates across
         independent sources.
Outputs: structured detection results with source references and confidence.
         A detection is NEVER presented as a confirmed event: verification
         starts at `preliminary_detection` / `corroborated`.
"""
from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any, Iterable

from sqlalchemy import and_, select
from sqlalchemy.orm import Session

from .. import models
from ..services import geo
from ..util import clamp, now
from .base import AgentContext, BaseAgent

log = logging.getLogger("aegis.agents.detection")

# Thresholds are documented, conservative and applied uniformly.
MIN_MAGNITUDE_SIGNIFICANT = 4.5     # M4.5+ is the global "notable" threshold
FIRMS_CLUSTER_CELL_DEG = 0.10       # ~11 km grid cell for hotspot clustering
FIRMS_MIN_DETECTIONS = 3            # <3 detections => single hotspot, not a fire complex
CORRELATION_KM = 400.0              # quake ↔ tsunami bulletin correlation radius
CORRELATION_HOURS = 6.0             # quake ↔ tsunami bulletin correlation window


class DetectionAgent(BaseAgent):
    name = "detection_agent"
    description = ("Scans newly ingested observations, suppresses duplicates, groups related signals into "
                   "candidate incidents and correlates independent sources.")
    capabilities = ["observation_scan", "duplicate_suppression", "cross_source_correlation", "incident_creation"]

    # ------------------------------------------------------------------ #
    def scan_observations(
        self,
        db: Session,
        *,
        hours: int = 24,
        categories: Iterable[str] | None = None,
        bbox: tuple[float, float, float, float] | None = None,
        include_linked: bool = False,
        limit: int = 800,
    ) -> list[models.Observation]:
        """Recent observations that are candidates for detection."""
        since = now() - timedelta(hours=hours)
        stmt = select(models.Observation).where(models.Observation.observed_at >= since)
        if categories:
            stmt = stmt.where(models.Observation.hazard_hint.in_(list(categories)))
        if not include_linked:
            stmt = stmt.where(models.Observation.incident_id.is_(None))
        if bbox:
            min_lat, min_lon, max_lat, max_lon = bbox
            stmt = stmt.where(and_(
                models.Observation.lat >= min_lat, models.Observation.lat <= max_lat,
                models.Observation.lon >= min_lon, models.Observation.lon <= max_lon,
            ))
        stmt = stmt.order_by(models.Observation.observed_at.desc()).limit(limit)
        return list(db.scalars(stmt))

    # ------------------------------------------------------------------ #
    def correlate_new_observations(
        self,
        db: Session,
        observations: list[models.Observation],
        ctx: AgentContext | None = None,
    ) -> dict[str, Any]:
        """Correlate fresh observations with existing incidents.

        * a tsunami bulletin near an earthquake in time+space corroborates BOTH
          (independent authority + independent instrument);
        * repeat observations from the same provider series update the existing
          incident instead of creating a new one;
        * everything else is returned for new-incident creation.
        """
        linked: list[tuple[str, str]] = []
        unmatched: list[models.Observation] = []
        for obs in observations:
            incident = self._match_existing_incident(db, obs)
            if incident is None:
                unmatched.append(obs)
                continue
            self._attach_observation(db, incident, obs, ctx)
            linked.append((incident.id, obs.id))
        return {"linked": linked, "unmatched": unmatched}

    # ------------------------------------------------------------------ #
    def _match_existing_incident(self, db: Session, obs: models.Observation) -> models.Incident | None:
        payload = obs.payload or {}
        # 1) exact provider identity (idempotent re-ingest / episode updates)
        if obs.external_id:
            series = str(payload.get("eventid") or payload.get("event_id") or obs.external_id)
            candidates = db.scalars(
                select(models.Incident).where(models.Incident.status.in_(("active", "monitoring")))
            ).all()
            for inc in candidates:
                refs = inc.external_refs or {}
                if refs.get(obs.source_key) and str(refs[obs.source_key]) == str(series):
                    return inc
                if refs.get("usgs") and obs.source_key == "usgs_earthquake" and str(refs["usgs"]) == str(obs.external_id):
                    return inc
            # provider event id stored directly
            if obs.source_key == "usgs_earthquake":
                found = db.scalar(select(models.Incident).where(
                    models.Incident.category == "earthquake",
                    models.Incident.status.in_(("active", "monitoring")),
                    models.Incident.lat.between(obs.lat - 0.2, obs.lat + 0.2),
                    models.Incident.lon.between(obs.lon - 0.2, obs.lon + 0.2),
                ))
                if found and str((found.external_refs or {}).get("usgs")) == str(obs.external_id):
                    return found

        # 2) tsunami bulletin ↔ earthquake correlation (cross-source)
        if obs.hazard_hint == "tsunami":
            window = obs.observed_at - timedelta(hours=CORRELATION_HOURS)
            quakes = db.scalars(
                select(models.Incident).where(
                    models.Incident.category == "earthquake",
                    models.Incident.started_at >= window,
                    models.Incident.lat.between(obs.lat - 6, obs.lat + 6),
                    models.Incident.lon.between(obs.lon - 6, obs.lon + 6),
                )
            ).all()
            best, best_d = None, None
            for q in quakes:
                d = geo.haversine_km(obs.lat, obs.lon, q.lat, q.lon)
                if d <= CORRELATION_KM and (best_d is None or d < best_d):
                    best, best_d = q, d
            if best is not None:
                return best

        # 3) cyclone / flood / fire episodes from the same provider series
        if obs.hazard_hint in {"cyclone", "flood", "wildfire", "drought", "volcano"} and obs.source_key == "gdacs":
            return None
        if obs.source_key == "nhc" and obs.external_id:
            found = db.scalar(select(models.Incident).where(
                models.Incident.category == "cyclone",
                models.Incident.status.in_(("active", "monitoring")),
                models.Incident.lat.between(obs.lat - 10, obs.lat + 10),
                models.Incident.lon.between(obs.lon - 10, obs.lon + 10),
            ))
            return found
        return None

    def _attach_observation(self, db: Session, incident: models.Incident, obs: models.Observation,
                            ctx: AgentContext | None) -> None:
        obs.incident_id = incident.id
        refs = dict(incident.external_refs or {})
        if obs.external_id:
            refs[obs.source_key] = str((obs.payload or {}).get("eventid") or obs.external_id)
        incident.external_refs = refs
        keys = list(incident.source_keys or [])
        if obs.source_key not in keys:
            keys.append(obs.source_key)
        incident.source_keys = keys
        urls = list(incident.source_urls or [])
        if obs.source_url and obs.source_url not in urls:
            urls.append(obs.source_url)
        incident.source_urls = urls
        incident.last_update_at = max(incident.last_update_at, obs.observed_at)

        # upgrade verification when an independent authority/instrument agrees
        if len(keys) >= 2 and incident.verification_status == "preliminary_detection":
            incident.verification_status = "corroborated"
            incident.confidence = clamp(max(incident.confidence, obs.confidence or 60.0) + 6.0, 0, 100)
            note = ("Corroborated by independent sources: " + ", ".join(keys))
            incident.classification_note = (incident.classification_note + " " + note).strip()
            if ctx:
                ctx.add_finding(note, kind="correlation", source=obs.source_key,
                                confidence=incident.confidence, extra={"incident_id": incident.id})

        # official-issued bulletins raise verification for that incident's hazard
        is_official = bool((obs.payload or {}).get("official")) or obs.source_key in {"nhc", "noaa_tsunami"}
        if is_official and not any(e.kind == "official_alert" and e.source_key == obs.source_key and e.excerpt == (obs.payload or {}).get("message_text", "")[:1500]
                                   for e in db.scalars(select(models.IncidentEvidence).where(models.IncidentEvidence.incident_id == incident.id))):
            db.add(models.IncidentEvidence(
                incident_id=incident.id, kind="official_alert", source_key=obs.source_key,
                source_url=obs.source_url, title=(obs.payload or {}).get("title") or f"{obs.source_key} bulletin",
                excerpt=(obs.payload or {}).get("message_text", "")[:1500],
                observed_at=obs.observed_at, confidence=obs.confidence, data_origin=obs.data_origin,
                added_by=self.name,
            ))
        if obs.hazard_hint == "tsunami" and incident.category == "earthquake":
            incident.tags = sorted(set((incident.tags or []) + ["tsunami_bulletin", "tsunami_correlated"]))
            if is_official:
                incident.verification_status = "officially_confirmed" if (obs.payload or {}).get("category", "").lower() == "warning" else incident.verification_status
        db.add(models.IncidentEvidence(
            incident_id=incident.id, kind="observation", source_key=obs.source_key, source_url=obs.source_url,
            title=f"{obs.hazard_hint} observation from {obs.source_key}",
            excerpt=_observation_digest(obs), observed_at=obs.observed_at, confidence=obs.confidence,
            data_origin=obs.data_origin, added_by=self.name,
        ))

    # ------------------------------------------------------------------ #
    def create_incidents(
        self,
        db: Session,
        observations: list[models.Observation],
        ctx: AgentContext | None = None,
    ) -> list[models.Incident]:
        """Turn unmatched observations into candidate incidents."""
        created: list[models.Incident] = []
        fires: list[models.Observation] = []
        for obs in observations:
            if obs.source_key == "nasa_firms":
                fires.append(obs)
                continue
            incident = self._incident_from_observation(db, obs, ctx)
            if incident:
                created.append(incident)
        if fires:
            created.extend(self._cluster_fire_detections(db, fires, ctx))
        return created

    def _incident_from_observation(self, db: Session, obs: models.Observation,
                                   ctx: AgentContext | None) -> models.Incident | None:
        payload = obs.payload or {}
        category = obs.hazard_hint if obs.hazard_hint in {
            "earthquake", "tsunami", "cyclone", "flood", "wildfire", "landslide", "industrial_fire",
        } else "unknown"

        # tsunami bulletins: "Information" statements usually say NO tsunami is expected —
        # record them as evidence but do not raise a hazard incident unless a Warning/Advisory/Watch
        if category == "tsunami":
            cat_text = str(payload.get("category", "")).lower()
            if cat_text == "information":
                return None

        magnitude = obs.magnitude
        if category == "earthquake" and magnitude is not None and magnitude < MIN_MAGNITUDE_SIGNIFICANT:
            return None

        confidence = float(obs.confidence or 55.0)
        place = obs.place or geo.place_label(obs.lat, obs.lon)
        country = obs.country or ""
        region = place

        # severity from hazard-specific, documented thresholds
        severity = _severity_for(category, magnitude, payload)

        verification = "preliminary_detection"
        if payload.get("official"):
            verification = "officially_confirmed" if category in {"cyclone", "tsunami"} else "corroborated"
        if obs.source_key == "gdacs" and payload.get("alert_level") in {"Orange", "Red"}:
            verification = "corroborated"

        code = models.new_id("x")  # placeholder to keep code uniqueness simple
        incident = models.Incident(
            code=f"AEGIS-{category[:3].upper()}-{now().strftime('%y%m%d')}-{code.split('_')[-1][:5].upper()}",
            title=_title_for(category, obs, place),
            category=category,
            status="active",
            verification_status=verification,
            severity=severity,
            confidence=confidence,
            lat=obs.lat, lon=obs.lon,
            depth_km=(payload.get("depth_km") if isinstance(payload.get("depth_km"), (int, float)) else None),
            region=region, country=country, country_iso3=str(payload.get("iso3") or ""),
            started_at=obs.observed_at, last_update_at=obs.observed_at,
            summary=_summary_for(category, obs, severity),
            detection_agent=self.name,
            is_ambiguous=category == "unknown",
            primary_source_key=obs.source_key,
            source_keys=[obs.source_key],
            source_urls=[obs.source_url] if obs.source_url else [],
            data_origin=obs.data_origin,
            external_refs={obs.source_key: str(payload.get("eventid") or obs.external_id)},
            tags=_tags_for(obs),
        )
        db.add(incident)
        db.flush()
        obs.incident_id = incident.id
        db.add(models.IncidentEvidence(
            incident_id=incident.id, kind="observation", source_key=obs.source_key, source_url=obs.source_url,
            title=f"Primary detection — {obs.source_key}",
            excerpt=_observation_digest(obs), observed_at=obs.observed_at, confidence=obs.confidence,
            data_origin=obs.data_origin, added_by=self.name,
        ))
        if ctx:
            ctx.add_finding(f"Detected candidate {category} incident {incident.code} from {obs.source_key}",
                            kind="detection", source=obs.source_key, confidence=confidence,
                            extra={"incident_id": incident.id, "lat": obs.lat, "lon": obs.lon})
        log.info("created incident %s (%s, sev %s) from %s", incident.code, category, severity, obs.source_key)
        return incident

    # ------------------------------------------------------------------ #
    def _cluster_fire_detections(self, db: Session, fires: list[models.Observation],
                                 ctx: AgentContext | None) -> list[models.Incident]:
        """Cluster thermal anomalies into fire complexes (>= FIRMS_MIN_DETECTIONS)."""
        cells: dict[tuple[int, int], list[models.Observation]] = {}
        for obs in fires:
            cells.setdefault((int(obs.lat / FIRMS_CLUSTER_CELL_DEG), int(obs.lon / FIRMS_CLUSTER_CELL_DEG)), []).append(obs)

        created = []
        singles = []
        for (cy, cx), group in cells.items():
            if len(group) < FIRMS_MIN_DETECTIONS:
                singles.extend(group)
                continue
            lat = sum(o.lat for o in group) / len(group)
            lon = sum(o.lon for o in group) / len(group)
            first, last = min(o.observed_at for o in group), max(o.observed_at for o in group)
            conf = sum((o.confidence or 50) for o in group) / len(group)
            frp = sum((o.payload or {}).get("frp_mw") and float((o.payload or {}).get("frp_mw") or 0) or 0 for o in group)
            place = geo.place_label(lat, lon)
            incident = models.Incident(
                code=f"AEGIS-WIL-{now().strftime('%y%m%d')}-{models.new_id('x').split('_')[-1][:5].upper()}",
                title=f"Fire complex — {len(group)} VIIRS thermal detections near {place.split(' of ')[-1]}",
                category="wildfire", status="active",
                verification_status="preliminary_detection",   # satellite hotspots ≠ confirmed wildfire
                severity=3 if len(group) >= 10 else 2,
                confidence=clamp(conf, 0, 100),
                lat=lat, lon=lon, region=place,
                started_at=first, last_update_at=last,
                summary=(f"{len(group)} VIIRS/FIRMS thermal anomalies clustered within ~11 km over {(last - first).total_seconds() / 3600:.1f} h "
                         f"(cluster FRP ≈ {frp:.0f} MW). Satellite hotspots are a fire *signal*: they can also be gas flares, "
                         f"agricultural burning or industrial heat sources."),
                detection_agent=self.name,
                is_ambiguous=len(group) < 10,
                primary_source_key="nasa_firms",
                source_keys=["nasa_firms"],
                source_urls=["https://firms.modaps.eosdis.nasa.gov/map/"],
                external_refs={"firms_cluster": f"{cy}:{cx}"},
                tags=["satellite_hotspot_cluster"],
            )
            db.add(incident)
            db.flush()
            for obs in group[:200]:
                obs.incident_id = incident.id
            grid = _cell_polygon(cy, cx)
            db.add(models.AffectedArea(
                incident_id=incident.id, label="Thermal-anomaly cluster cell (11 km grid)",
                geometry_geojson=grid, area_km2=geo.polygon_area_km2(grid), radius_km=8.0,
                method=f"VIIRS 375 m hotspots binned to a {FIRMS_CLUSTER_CELL_DEG}° grid cell; not a measured fire perimeter",
                is_estimate=True, source_key="nasa_firms",
            ))
            db.add(models.IncidentEvidence(
                incident_id=incident.id, kind="observation", source_key="nasa_firms",
                source_url="https://firms.modaps.eosdis.nasa.gov/map/",
                title=f"{len(group)} VIIRS thermal anomalies",
                excerpt=f"First: {first.isoformat()}Z  Last: {last.isoformat()}Z  Mean confidence: {conf:.0f}/100  Cluster FRP: {frp:.0f} MW",
                observed_at=last, confidence=conf, added_by=self.name,
            ))
            created.append(incident)
        if singles and ctx:
            ctx.add_finding(f"{len(singles)} isolated thermal anomaly/anomalies below the {FIRMS_MIN_DETECTIONS}-detection "
                            f"cluster threshold — retained as raw observations, no incident raised.",
                            kind="suppression", source="nasa_firms")
        return created

    # ------------------------------------------------------------------ #
    def run(self, db: Session, ctx: AgentContext, *, hours: int = 24,
            categories: list[str] | None = None,
            bbox: tuple[float, float, float, float] | None = None, limit: int = 800) -> dict[str, Any]:
        """Full detection pass. Returns structured results with source references."""
        with ctx.tool("scan_observations", {"hours": hours, "categories": categories, "bbox": bbox}) as t:
            observations = self.scan_observations(db, hours=hours, categories=categories, bbox=bbox, limit=limit)
            t["source"] = "aegis_observations"
            t["summary"] = f"{len(observations)} unlinked observation(s) in the last {hours}h"
        with ctx.tool("correlate_and_create_incidents", {"candidates": len(observations)}) as t:
            corr = self.correlate_new_observations(db, observations, ctx)
            created = self.create_incidents(db, corr["unmatched"], ctx)
            db.flush()
            t["source"] = "aegis_pipeline"
            t["summary"] = f"linked {len(corr['linked'])} observation(s) to existing incidents; created {len(created)} candidate incident(s)"
        return {
            "agent": self.name,
            "observations_scanned": len(observations),
            "observations_linked": len(corr["linked"]),
            "incidents_created": [i.id for i in created],
            "incidents_created_codes": [i.code for i in created],
            "findings": ctx.findings,
            "verification_note": ("All created incidents start as candidate detections. Verification status is only "
                                  "promoted by corroboration (independent source) or official confirmation."),
        }


# --------------------------------------------------------------------------- #
def _severity_for(category: str, magnitude: float | None, payload: dict) -> int:
    """Documented severity mapping (1-5). Mirrors risk_agent aggregation."""
    if category == "earthquake" and magnitude is not None:
        if magnitude >= 7.0:
            return 5
        if magnitude >= 6.0:
            return 4
        if magnitude >= 5.0:
            return 3
        return 2
    if category == "tsunami":
        cat = str(payload.get("category", "")).lower()
        return {"warning": 5, "advisory": 4, "watch": 3}.get(cat, 2)
    if category == "cyclone":
        wind_kmh = payload.get("intensity_kmh") or payload.get("severity")
        if isinstance(wind_kmh, str):
            wind_kmh = None
        if isinstance(wind_kmh, (int, float)):
            if wind_kmh >= 178:
                return 5
            if wind_kmh >= 119:
                return 4
            if wind_kmh >= 63:
                return 3
            return 2
    if category == "flood":
        alert = payload.get("alert_level")
        return {"Red": 5, "Orange": 4, "Green": 2}.get(alert, 3)
    if category == "wildfire":
        return 2
    if category in {"landslide", "industrial_fire"}:
        return 3
    return 2


def _title_for(category: str, obs: models.Observation, place: str) -> str:
    m = obs.magnitude
    label = category.replace("_", " ").title()
    if category == "earthquake" and m is not None:
        return f"M{m:.1f} earthquake — {place}"
    if category == "cyclone" and obs.place:
        return f"{obs.place} ({place})"
    if m is not None and obs.magnitude_unit:
        return f"{label} — {m:g} {obs.magnitude_unit} — {place}"
    return f"{label} — {place}"


def _summary_for(category: str, obs: models.Observation, severity: int) -> str:
    base = {
        "earthquake": f"Seismic event detected by {obs.source_key.replace('_', ' ')}.",
        "tsunami": f"Official tsunami bulletin ingested from {obs.source_key}.",
        "cyclone": "Tropical cyclone position report ingested from the official basin monitoring centre.",
        "flood": "Flood signal from multi-hazard alert feed (GDACS) — see linked official products.",
        "wildfire": "Thermal anomaly cluster flagged as a candidate wildfire signal.",
        "landslide": "Possible landslide reported/derived — requires local verification.",
        "industrial_fire": "Possible industrial fire signal — requires local verification.",
    }.get(category, "Candidate hazard detection.")
    return f"{base} Severity band {severity}/5 assigned by the documented AEGIS threshold table. Verification: candidate detection."


def _tags_for(obs: models.Observation) -> list[str]:
    payload = obs.payload or {}
    tags = [obs.source_key]
    if payload.get("official"):
        tags.append("official_product")
    if payload.get("alert_level"):
        tags.append(f"gdacs_{str(payload['alert_level']).lower()}")
    if payload.get("status"):
        tags.append(f"usgs_{payload['status']}")
    if int(payload.get("tsunami_flag") or 0) == 1:
        tags.append("usgs_tsunami_flag")
    return tags


def _observation_digest(obs: models.Observation) -> str:
    p = obs.payload or {}
    bits = [f"{obs.source_key} #{obs.external_id}"]
    if obs.magnitude is not None:
        bits.append(f"{obs.magnitude:g} {obs.magnitude_unit}".strip())
    if p.get("depth_km") is not None:
        bits.append(f"depth {p['depth_km']} km")
    if p.get("alert_level"):
        bits.append(f"GDACS alert {p['alert_level']}")
    if p.get("status"):
        bits.append(f"status={p['status']}")
    bits.append(f"observed {obs.observed_at.isoformat()}Z")
    if obs.source_url:
        bits.append(obs.source_url)
    return " · ".join(bits)


def _cell_polygon(cy: int, cx: int) -> dict:
    s, w = cy * FIRMS_CLUSTER_CELL_DEG, cx * FIRMS_CLUSTER_CELL_DEG
    return {"type": "Polygon", "coordinates": [[[w, s], [w + FIRMS_CLUSTER_CELL_DEG, s],
                                                [w + FIRMS_CLUSTER_CELL_DEG, s + FIRMS_CLUSTER_CELL_DEG],
                                                [w, s + FIRMS_CLUSTER_CELL_DEG], [w, s]]]}


detection_agent = DetectionAgent()
