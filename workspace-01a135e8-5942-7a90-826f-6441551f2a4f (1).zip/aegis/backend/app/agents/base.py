"""Agent framework: context, tool-call tracing, bounded execution.

Every agent action is executed by real backend code (database queries, HTTP
calls to providers, deterministic models).  When an agent runs inside a
coordinator workflow, each tool call is persisted in `agent_tasks.tool_calls`
so the UI can show a complete, auditable execution timeline.
"""
from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Callable

from sqlalchemy.orm import Session

from .. import models
from ..util import now

log = logging.getLogger("aegis.agents")

# Bound execution: prevents runaway agent loops and runaway provider load.
AGENT_TIMEOUT_SECONDS = 90.0
MAX_TOOL_CALLS_PER_TASK = 24


@dataclass
class AgentContext:
    db: Session
    run: models.AgentRun | None = None
    task: models.AgentTask | None = None
    agent_name: str = ""
    tool_calls: list[dict] = field(default_factory=list)
    findings: list[dict] = field(default_factory=list)
    sources_used: set[str] = field(default_factory=set)
    started: float = field(default_factory=time.perf_counter)
    deadline: float | None = None
    llm_used: bool = False

    # -------------------------------------------------------------- #
    @contextmanager
    def tool(self, name: str, args: dict | None = None):
        """Record a tool call: what was called, with what inputs, what came back."""
        call = {
            "tool": name,
            "args": _sanitize(args or {}),
            "status": "running",
            "started_at": now().isoformat(timespec="seconds") + "Z",
        }
        if len(self.tool_calls) >= MAX_TOOL_CALLS_PER_TASK:
            call["status"] = "skipped"
            call["error"] = f"tool-call budget exceeded ({MAX_TOOL_CALLS_PER_TASK})"
            self.tool_calls.append(call)
            yield {"skipped": True, "reason": "tool budget exceeded"}
            return
        if self.deadline and time.perf_counter() > self.deadline:
            call["status"] = "skipped"
            call["error"] = "agent deadline exceeded"
            self.tool_calls.append(call)
            yield {"skipped": True, "reason": "deadline exceeded"}
            return
        self.tool_calls.append(call)
        t0 = time.perf_counter()
        holder: dict[str, Any] = {}
        try:
            yield holder
            call["status"] = holder.get("status", "ok")
            call["summary"] = holder.get("summary")
            if holder.get("source"):
                self.sources_used.add(holder["source"])
        except Exception as exc:  # noqa: BLE001
            call["status"] = "error"
            call["error"] = f"{exc.__class__.__name__}: {exc}"
            log.warning("agent %s tool %s failed: %s", self.agent_name, name, exc)
            holder["error"] = call["error"]
        finally:
            call["latency_ms"] = int((time.perf_counter() - t0) * 1000)

    def add_finding(self, text: str, kind: str = "fact", source: str | None = None,
                    confidence: float | None = None, extra: dict | None = None) -> dict:
        f = {"finding": text, "kind": kind, "source": source, "confidence": confidence, "at": now().isoformat(timespec="seconds") + "Z"}
        if source:
            self.sources_used.add(source)
        if extra:
            f.update(extra)
        self.findings.append(f)
        return f

    @property
    def elapsed_ms(self) -> int:
        return int((time.perf_counter() - self.started) * 1000)

    def timed_out(self) -> bool:
        return self.deadline is not None and time.perf_counter() > self.deadline

    def persist(self) -> None:
        if self.task is not None:
            self.task.tool_calls = self.tool_calls
            self.task.findings = self.findings
            self.task.sources_used = sorted(self.sources_used)
        if self.run is not None and self.llm_used:
            self.run.llm_used = True  # type: ignore[attr-defined]


def _sanitize(args: dict) -> dict:
    """Never persist secrets or raw PII into the audit trail."""
    out = {}
    for k, v in args.items():
        if k.lower() in {"api_key", "token", "password", "authorization", "contact"}:
            out[k] = "[redacted]"
        elif isinstance(v, (str, int, float, bool)) or v is None:
            out[k] = v[:300] if isinstance(v, str) else v
        elif isinstance(v, (list, tuple)):
            out[k] = list(v)[:20]
        elif isinstance(v, dict):
            out[k] = {kk: (vv if isinstance(vv, (int, float, bool)) or vv is None else str(vv)[:120]) for kk, vv in list(v.items())[:20]}
        else:
            out[k] = str(v)[:120]
    return out


class BaseAgent:
    name: str = "base"
    description: str = ""
    capabilities: list[str] = []
    tools: dict[str, Callable[..., dict]] = {}

    def tool_help(self) -> str:
        lines = [f"- {self.name}: {self.description}"]
        for tname, fn in self.tools.items():
            doc = (fn.__doc__ or "").strip().splitlines()[0] if fn.__doc__ else ""
            lines.append(f"    • tool `{tname}`: {doc}")
        return "\n".join(lines)


def tool_budget_ok(ctx: AgentContext) -> bool:
    return len(ctx.tool_calls) < MAX_TOOL_CALLS_PER_TASK


def new_run_code() -> str:
    return f"RUN-{now().strftime('%Y%m%d-%H%M%S')}-{models.new_id('x').split('_')[-1][:4].upper()}"
