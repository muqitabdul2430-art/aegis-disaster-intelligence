"""Agent 7 — Emergency Response Support Agent.

Assembles response-relevant information for an incident: official guidance and
contacts, nearby facilities, and — only when current road/hazard information is
actually available — candidate movement options.

Safety rules implemented in code:
*   Official emergency guidance always outranks AEGIS-generated suggestions;
    each guidance item names its issuing authority.
*   AEGIS will NOT say a route is safe.  Routes are only computed when routing is
    explicitly enabled AND a straight-line corridor check finds no active hazard
    intersecting the path; even then the output is labelled
    "unverified — confirm with responders".
*   Road closures, bridge status and flood depth are not available from the
    integrated sources, so the default response is a straight-line distance and
    a clear statement of what is unknown.
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..config import settings
from ..services import facilities as fac_service
from ..services import geo
from ..sources.http import request_json
from .base import AgentContext, BaseAgent
from .prediction_agent import PROTECTIVE_ACTIONS

log = logging.getLogger("aegis.agents.response")

EMERGENCY_CONTACTS = [
    {"region": "India", "numbers": [{"label": "Emergency (all services)", "number": "112"},
                                    {"label": "Ambulance", "number": "108"},
                                    {"label": "Fire", "number": "101"},
                                    {"label": "Police", "number": "100"},
                                    {"label": "Disaster management (NDMA control room)", "number": "1078"}],
     "authority": "NDMA / Government of India", "url": "https://ndma.gov.in/"},
    {"region": "United States", "numbers": [{"label": "Emergency", "number": "911"},
                                            {"label": "Poison control", "number": "1-800-222-1222"}],
     "authority": "FEMA / local emergency management", "url": "https://www.ready.gov/"},
    {"region": "International", "numbers": [{"label": "Local emergency number", "number": "check local listings"}],
     "authority": "Your national civil-protection authority", "url": "https://www.ifrc.org/"},
]

FACILITY_ROLE = {
    "hospital": "Nearest trauma/medical capacity — confirm it is accepting patients before travelling.",
    "clinic": "Primary care / minor injury point.",
    "fire_station": "Fire and rescue response; report new fire/smoke sightings here.",
    "police": "Law-and-order, road closures and missing-person reports.",
    "shelter": "Mapped shelter — verify it is open with the district administration.",
    "community_centre": "Potential gathering/relief point (not an official shelter).",
    "ambulance": "Emergency medical dispatch base.",
    "pharmacy": "Medicines and basic supplies.",
    "government": "District administration / control room contact point.",
    "water": "Water point.",
    "fuel": "Fuel — often unavailable during outages; expect queues.",
}


class ResponseAgent(BaseAgent):
    name = "response_agent"
    description = ("Presents official emergency guidance and contacts, nearby response facilities, and — only with "
                   "current road/hazard data — candidate movement options with explicit uncertainty.")
    capabilities = ["official_guidance", "facility_roles", "route_assessment", "uncertainty_reporting"]

    # ------------------------------------------------------------------ #
    def guidance(self, db: Session, incident: models.Incident | None, category: str | None = None) -> dict[str, Any]:
        cat = (incident.category if incident else category) or "unknown"
        guide = PROTECTIVE_ACTIONS.get(cat, PROTECTIVE_ACTIONS["unknown"])
        official_alerts = []
        if incident:
            alerts = db.scalars(
                select(models.Alert).where(models.Alert.incident_id == incident.id,
                                           models.Alert.alert_kind == "official_ingested",
                                           models.Alert.status == "published")
                .order_by(models.Alert.issued_at.desc()).limit(5)
            ).all()
            official_alerts = [{
                "title": a.title, "authority": a.authority, "issued_at": a.issued_at.isoformat() + "Z",
                "source_url": a.source_url, "body_excerpt": (a.body or "")[:600],
            } for a in alerts]
        return {
            "hazard": cat,
            "guidance_authority": guide["authority"],
            "guidance_source_url": guide["source_url"],
            "actions": guide["actions"],
            "official_alerts_in_force": official_alerts,
            "precedence_note": ("Official instructions from the responsible authority always take precedence over "
                                "AEGIS-generated guidance. If an official order conflicts with anything here, follow "
                                "the official order."),
            "contacts": EMERGENCY_CONTACTS,
        }

    # ------------------------------------------------------------------ #
    def facilities_support(self, incident: models.Incident, radius_km: float = 25.0) -> dict[str, Any]:
        data = fac_service.nearby_facilities(incident.lat, incident.lon, radius_km)
        if not data.get("ok"):
            return {"ok": False, "error": data.get("error"), "note": data.get("note"),
                    "source": "OpenStreetMap / Overpass API"}
        grouped: dict[str, list[dict]] = {}
        for f in data["facilities"]:
            grouped.setdefault(f["class"], []).append(f)
        items = []
        for cls, rows in sorted(grouped.items(), key=lambda kv: -len(kv[1])):
            items.append({
                "class": cls,
                "role": FACILITY_ROLE.get(cls, "Mapped facility — role not classified."),
                "count": len(rows),
                "closest": sorted(rows, key=lambda r: r["distance_km"])[:4],
            })
        return {"ok": True, "source": data["source"], "license": data.get("license"),
                "radius_km": radius_km, "groups": items, "completeness_warning": data.get("osm_completeness_warning")}

    # ------------------------------------------------------------------ #
    def route_assessment(self, db: Session, incident: models.Incident, *, from_lat: float, from_lon: float,
                         to_lat: float, to_lon: float, ctx: AgentContext | None = None) -> dict[str, Any]:
        """Assess whether AEGIS can responsibly comment on movement."""
        straight_km = round(geo.haversine_km(from_lat, from_lon, to_lat, to_lon), 2)
        hazards_in_corridor = self._hazards_in_corridor(db, from_lat, from_lon, to_lat, to_lon)
        base = {
            "straight_line_km": straight_km,
            "hazards_in_corridor": hazards_in_corridor,
            "routing_enabled": settings.enable_osrm_routing,
            "current_road_data": False,
            "status": "unverified",
            "verdict": ("AEGIS cannot confirm that any route is safe: road closures, bridge status, debris and "
                        "flood depth are not available from the integrated data sources."),
        }
        if hazards_in_corridor:
            base.update({
                "status": "hazard_intersects_corridor",
                "verdict": ("At least one active hazard lies within 25 km of the straight-line corridor. Treat this "
                            "movement as HIGH RISK. Do not attempt without confirmation from responders."),
            })
            if ctx:
                ctx.add_finding(f"Route check: {len(hazards_in_corridor)} active hazard(s) near the corridor "
                                f"({straight_km} km straight line). No safety claim made.",
                                kind="route_assessment", source="aegis_route_check")
            return base

        if not settings.enable_osrm_routing:
            base["verdict"] = (
                "No active hazards detected near the straight-line corridor, but AEGIS has no live road-closure feed "
                "and routing is disabled in this deployment, so NO safety claim is made. Confirm routes with local "
                "authorities before travelling."
            )
            return base

        res = request_json(
            f"{settings.osrm_base_url.rstrip('/')}/route/v1/driving/{from_lon},{from_lat};{to_lon},{to_lat}",
            params={"overview": "full", "geometries": "geojson", "steps": "false"},
            timeout=15.0, retries=1,
        )
        if not res.ok or not isinstance(res.data, dict) or not res.data.get("routes"):
            base.update({"status": "routing_unavailable", "error": res.error,
                         "verdict": "Routing service unavailable — no route advice can be given."})
            return base
        route = res.data["routes"][0]
        base.update({
            "status": "candidate_route_unverified",
            "route_km": round(route.get("distance", 0) / 1000.0, 2),
            "route_minutes": round(route.get("duration", 0) / 60.0, 1),
            "geometry": route.get("geometry"),
            "verdict": ("Candidate driving route computed. AEGIS STILL cannot certify it as safe: road closures, "
                        "congestion, debris and flood depth are unknown. Confirm with responders (in India dial 112)."),
            "routing_source": f"OSRM demo server ({settings.osrm_base_url}) — demo capacity, not for operational use",
        })
        if ctx:
            ctx.add_finding(f"Candidate route computed ({base['route_km']} km); safety not certified.",
                            kind="route_assessment", source="osrm")
        return base

    def _hazards_in_corridor(self, db: Session, from_lat: float, from_lon: float, to_lat: float,
                             to_lon: float, buffer_km: float = 25.0) -> list[dict]:
        from ..agents.geo_agent import estimate_radius_km

        incidents = db.scalars(select(models.Incident).where(models.Incident.status == "active")).all()
        hits = []
        for inc in incidents:
            radius, _ = estimate_radius_km(inc.category, inc.severity, inc.confidence)
            d = _point_to_segment_km(inc.lat, inc.lon, from_lat, from_lon, to_lat, to_lon)
            if d <= max(buffer_km, radius):
                hits.append({"incident_id": inc.id, "code": inc.code, "category": inc.category,
                             "severity": inc.severity, "distance_to_corridor_km": round(d, 1),
                             "estimated_footprint_km": radius,
                             "cross_reference": "estimated footprint intersects the straight-line corridor"})
        return hits

    # ------------------------------------------------------------------ #
    def run(self, db: Session, ctx: AgentContext, *, incident_ids: list[str], radius_km: float = 25.0,
            route_query: dict | None = None) -> dict[str, Any]:
        incidents = list(db.scalars(select(models.Incident).where(models.Incident.id.in_(incident_ids))))
        out = []
        with ctx.tool("response_support", {"incidents": len(incidents), "radius_km": radius_km}) as t:
            for inc in incidents:
                item = {"incident_id": inc.id, "code": inc.code, "guidance": self.guidance(db, inc),
                        "facilities": self.facilities_support(inc, radius_km)}
                if route_query:
                    item["route"] = self.route_assessment(
                        db, inc, from_lat=route_query["from_lat"], from_lon=route_query["from_lon"],
                        to_lat=route_query.get("to_lat", inc.lat), to_lon=route_query.get("to_lon", inc.lon), ctx=ctx)
                out.append(item)
            t["source"] = "openstreetmap"
            t["summary"] = f"response package built for {len(out)} incident(s)"
        return {"agent": self.name, "packages": out,
                "note": "Official emergency guidance outranks all AEGIS output."}


def _point_to_segment_km(plat: float, plon: float, alat: float, alon: float, blat: float, blon: float) -> float:
    """Approximate distance from a point to a great-circle segment (equirectangular)."""
    import math

    lat0 = math.radians((alat + blat) / 2)
    kx = math.cos(lat0)
    px, py = plon * kx, plat
    ax, ay = alon * kx, alat
    bx, by = blon * kx, blat
    dx, dy = bx - ax, by - ay
    seg = dx * dx + dy * dy
    if seg == 0:
        t = 0.0
    else:
        t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / seg))
    cx, cy = ax + t * dx, ay + t * dy
    return geo.haversine_km(plat, plon, cy, cx / kx if kx else cx)


response_agent = ResponseAgent()
