"""Agent 2 — Disaster Classification Agent.

Classifies a detected event into the supported hazard taxonomy **using the
evidence attached to it** (source feeds, payload fields, official products,
citizen reports).  Produces an explicit rationale, a confidence value and an
ambiguity flag.

It is deliberately conservative:
*   a category is only assigned when at least one piece of evidence supports it;
*   conflicting or weak evidence produces `is_ambiguous = True` for human review;
*   the agent never invents sensor readings and never upgrades verification
      status to "confirmed" on its own.
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..services import geo
from ..util import clamp
from .base import AgentContext, BaseAgent

log = logging.getLogger("aegis.agents.classification")

SUPPORTED = ["wildfire", "cyclone", "flood", "tsunami", "landslide", "earthquake", "industrial_fire"]

# Keyword evidence for text-based (citizen report / bulletin) classification.
KEYWORDS = {
    "earthquake": ["earthquake", "quake", "tremor", "seismic", "shaking", "aftershock", "bhookamp", "bhukamp"],
    "tsunami": ["tsunami", "tidal wave", "sea receded", "sea level surge"],
    "cyclone": ["cyclone", "typhoon", "hurricane", "storm surge", "eye of the storm", "toofan"],
    "flood": ["flood", "flooding", "inundat", "waterlogged", "river overflow", "waterlogging", "baadh", "submerged"],
    "landslide": ["landslide", "landslip", "mudslide", "rockfall", "slope failure", "bhukhalan", "hill collapse"],
    "wildfire": ["wildfire", "forest fire", "bushfire", "grass fire", "smoke", "burning forest", "van agni"],
    "industrial_fire": ["factory fire", "industrial fire", "plant fire", "refinery", "chemical fire", "warehouse fire",
                        "smoke from factory", "gas leak fire", "blast at plant"],
}


class ClassificationAgent(BaseAgent):
    name = "classification_agent"
    description = ("Assigns a hazard category from the supported taxonomy using only attached evidence; "
                   "flags ambiguous cases for human review.")
    capabilities = ["evidence_extraction", "category_assignment", "ambiguity_detection"]

    # ------------------------------------------------------------------ #
    def extract_evidence_features(self, db: Session, incident: models.Incident) -> dict[str, Any]:
        """Build the feature set used for classification (all cited to evidence)."""
        evidence = list(db.scalars(select(models.IncidentEvidence).where(models.IncidentEvidence.incident_id == incident.id)))
        observations = list(db.scalars(select(models.Observation).where(models.Observation.incident_id == incident.id)))
        reports = list(db.scalars(select(models.CitizenReport).where(models.CitizenReport.linked_incident_id == incident.id)))
        sources = sorted({e.source_key for e in evidence if e.source_key} | {o.source_key for o in observations})
        official = [e for e in evidence if e.kind == "official_alert"]
        text_blob = " ".join(
            [incident.title or "", incident.summary or ""]
            + [f"{e.title} {e.excerpt}" for e in evidence]
            + [r.description or "" for r in reports]
        ).lower()

        features = {
            "sources": sources,
            "evidence_count": len(evidence),
            "observation_count": len(observations),
            "citizen_report_count": len(reports),
            "official_evidence_count": len(official),
            "has_official_authority": bool([e for e in official if e.source_key in {"nhc", "noaa_tsunami"}]),
            "magnitudes": [o.magnitude for o in observations if o.magnitude is not None],
            "magnitude_unit": next((o.magnitude_unit for o in observations if o.magnitude_unit), ""),
            "payload_keys": sorted({k for o in observations for k in (o.payload or {}).keys()}),
            "keyword_hits": {cat: [kw for kw in kws if kw in text_blob] for cat, kws in KEYWORDS.items()},
            "official_categories": [str((o.payload or {}).get("category", "")) for o in observations
                                    if (o.payload or {}).get("category")],
            "gdacs_eventtypes": [str((o.payload or {}).get("eventtype")) for o in observations
                                 if (o.payload or {}).get("eventtype")],
            "nhc_classification": next((str((o.payload or {}).get("classification")) for o in observations
                                        if o.source_key == "nhc"), ""),
            "is_satellite_hotspot_cluster": any("nasa_firms" == s for s in sources),
            "evidence_dates": [e.observed_at for e in evidence if e.observed_at],
        }
        return {"features": features, "evidence": evidence, "observations": observations, "reports": reports}

    # ------------------------------------------------------------------ #
    def score_categories(self, features: dict[str, Any], incident: models.Incident) -> dict[str, dict]:
        """Transparent per-category scoring. Every score lists the rules that fired."""
        scores: dict[str, dict] = {}

        def add(cat: str, points: float, reason: str) -> None:
            entry = scores.setdefault(cat, {"score": 0.0, "reasons": []})
            entry["score"] += points
            entry["reasons"].append(reason)

        sources: list[str] = features["sources"]
        kw = features["keyword_hits"]
        mags = features["magnitudes"]

        if "usgs_earthquake" in sources:
            add("earthquake", 90, "USGS FDSN catalogue record attached (instrumental seismic solution)")
        if mags:
            add("earthquake", 15, f"magnitude-like value present ({mags[0]:g} {features['magnitude_unit']})")
        if "tsunami_flag" in features["payload_keys"] or "tsunami" in str(features.get("gdacs_eventtypes")).lower():
            add("tsunami", 40, "USGS tsunami flag / GDACS tsunami event type present")
        if "noaa_tsunami" in sources:
            add("tsunami", 95, "Official NOAA tsunami bulletin attached")
        if "nhc" in sources or features["nhc_classification"]:
            add("cyclone", 95, "NOAA NHC active-storm record attached (official basin product)")
        if "TC" in [str(t).upper() for t in features["gdacs_eventtypes"]]:
            add("cyclone", 80, "GDACS tropical-cyclone event attached")
        if "FL" in [str(t).upper() for t in features["gdacs_eventtypes"]]:
            add("flood", 80, "GDACS flood event attached")
        if "WF" in [str(t).upper() for t in features["gdacs_eventtypes"]]:
            add("wildfire", 70, "GDACS wildfire event attached")
        if "TS" in [str(t).upper() for t in features["gdacs_eventtypes"]]:
            add("tsunami", 85, "GDACS tsunami event attached")
        if features["is_satellite_hotspot_cluster"]:
            add("wildfire", 45, "Satellite thermal-anomaly cluster (VIIRS/FIRMS) attached — signal, not confirmation")
            add("industrial_fire", 12, "Thermal anomalies can also be industrial flares/industrial fires")
        for cat, hits in kw.items():
            if hits:
                points = min(60.0, 22.0 * len(hits))
                add(cat, points, f"Report/bulletin text contains {cat.replace('_', ' ')} keyword(s): {', '.join(hits[:4])}")
        if features["citizen_report_count"]:
            add(incident.category, 8, f"{features['citizen_report_count']} linked citizen report(s) — unverified")
        # industrial disambiguation: factory/refinery terms near known industrial landuse
        if kw.get("industrial_fire") and kw.get("wildfire"):
            add("industrial_fire", 10, "Text contains both wildfire and industrial terms → human disambiguation required")
        return scores

    # ------------------------------------------------------------------ #
    def classify(self, db: Session, incident: models.Incident, ctx: AgentContext | None = None) -> dict[str, Any]:
        bundle = self.extract_evidence_features(db, incident)
        features = bundle["features"]
        scores = self.score_categories(features, incident)
        ranked = sorted(scores.items(), key=lambda kv: -kv[1]["score"])
        if not ranked:
            return {
                "category": incident.category, "changed": False, "confidence": incident.confidence,
                "ambiguous": True, "note": "No classification evidence attached — kept as unclassified candidate.",
                "scorecard": {}, "evidence_gap": True,
            }

        best_cat, best = ranked[0]
        second = ranked[1] if len(ranked) > 1 else None
        total = sum(v["score"] for _, v in ranked)
        confidence = clamp(100.0 * best["score"] / total, 5, 97)
        # ambiguity: weak leader, or a strong runner-up
        ambiguous = bool(
            (second and second[1]["score"] >= best["score"] * 0.65)
            or best["score"] < 45
            or (best_cat in {"wildfire", "industrial_fire"} and features["is_satellite_hotspot_cluster"] and features["observation_count"] < 10)
        )
        rationale_parts = [f"{r}" for r in best["reasons"][:5]]
        rationale = (f"Classified as '{best_cat}' from {features['evidence_count']} evidence record(s) across "
                     f"{len(features['sources'])} source(s). Deciding evidence: " + "; ".join(rationale_parts) + ".")
        if second:
            rationale += f" Runner-up: '{second[0]}' (score {second[1]['score']:.0f} vs {best['score']:.0f})."

        changed = incident.category != best_cat
        note = rationale
        if ambiguous:
            note += (" FLAGGED FOR HUMAN REVIEW: evidence is not decisive between competing categories. "
                     "The Aegis categorisation is provisional.")
        if features["official_evidence_count"] and best_cat in {"tsunami", "cyclone"}:
            note += " Official bulletin(s) attached — hazard category follows the issuing authority's product type."

        if ctx:
            ctx.add_finding(note, kind="classification", source=features["sources"][0] if features["sources"] else None,
                            confidence=confidence,
                            extra={"incident_id": incident.id, "category": best_cat, "ambiguous": ambiguous,
                                   "scorecard": {k: round(v["score"], 1) for k, v in scores.items()}})
        return {
            "category": best_cat, "changed": changed, "confidence": round(confidence, 1), "ambiguous": ambiguous,
            "note": note, "scorecard": {k: {"score": round(v["score"], 1), "reasons": v["reasons"]} for k, v in ranked},
            "features": features, "evidence_gap": False,
        }

    # ------------------------------------------------------------------ #
    def apply(self, db: Session, incident: models.Incident, ctx: AgentContext | None = None,
              *, persist: bool = True) -> dict[str, Any]:
        result = self.classify(db, incident, ctx)
        if persist:
            if result["category"] != incident.category:
                from ..util import now

                db.add(models.AuditLog(
                    actor=self.name, actor_role="agent", action="incident.reclassify",
                    entity_type="incident", entity_id=incident.id,
                    before={"category": incident.category}, after={"category": result["category"]},
                    reason=result["note"][:800],
                ))
                incident.category = result["category"]
            incident.classification_agent = self.name
            incident.classification_note = result["note"][:4000]
            incident.confidence = clamp((incident.confidence * 0.6) + (result["confidence"] * 0.4), 0, 100)
            incident.is_ambiguous = bool(result["ambiguous"])
            incident.last_update_at = incident.last_update_at
            if result["ambiguous"]:
                tags = set(incident.tags or [])
                tags.add("needs_human_review")
                incident.tags = sorted(tags)
            db.flush()
        return result

    # ------------------------------------------------------------------ #
    def run(self, db: Session, ctx: AgentContext, *, incident_ids: list[str] | None = None,
            limit: int = 25, only_ambiguous: bool = False) -> dict[str, Any]:
        with ctx.tool("load_incidents_to_classify", {"incident_ids": incident_ids, "limit": limit}) as t:
            if incident_ids:
                incidents = list(db.scalars(select(models.Incident).where(models.Incident.id.in_(incident_ids))))
            else:
                stmt = select(models.Incident).where(models.Incident.status.in_(("active", "monitoring")))
                if only_ambiguous:
                    stmt = stmt.where(models.Incident.is_ambiguous.is_(True))
                incidents = list(db.scalars(stmt.order_by(models.Incident.last_update_at.desc()).limit(limit)))
            t["source"] = "aegis_db"
            t["summary"] = f"{len(incidents)} incident(s) to classify"

        results = []
        with ctx.tool("classify_incidents", {"count": len(incidents)}) as t:
            for inc in incidents:
                if ctx.timed_out():
                    t["status"] = "timeout"
                    t["error"] = "agent deadline exceeded while classifying"
                    break
                res = self.apply(db, inc, ctx)
                results.append({"incident_id": inc.id, "code": inc.code, "category": res["category"],
                                "confidence": res["confidence"], "ambiguous": res["ambiguous"],
                                "changed": res["changed"]})
            db.flush()
            t["source"] = "aegis_classification_rules"
            changed = sum(1 for r in results if r["changed"])
            ambiguous = sum(1 for r in results if r["ambiguous"])
            t["summary"] = f"{len(results)} classified, {changed} re-categorised, {ambiguous} flagged for review"
        return {"agent": self.name, "classified": results,
                "ambiguous_count": sum(1 for r in results if r["ambiguous"]),
                "note": "Classification uses the documented rule table; ambiguous cases require analyst review."}

    # ------------------------------------------------------------------ #
    @staticmethod
    def suggest_for_text(text: str) -> dict[str, Any]:
        """Used by the citizen-intelligence agent for triage hints (not for verification)."""
        low = (text or "").lower()
        hits = {cat: [kw for kw in kws if kw in low] for cat, kws in KEYWORDS.items()}
        hits = {k: v for k, v in hits.items() if v}
        if not hits:
            return {"category": "unknown", "confidence": 20.0, "keywords": {}}
        top = max(hits.items(), key=lambda kv: len(kv[1]))
        conf = clamp(30.0 + 15.0 * len(top[1]), 30, 85)
        return {"category": top[0], "confidence": conf, "keywords": hits}


classification_agent = ClassificationAgent()
