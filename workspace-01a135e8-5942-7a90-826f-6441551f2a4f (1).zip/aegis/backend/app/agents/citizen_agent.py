"""Agent 6 — Citizen Intelligence Agent.

Handles citizen submissions end-to-end:

1.  Input validation (ranges, length, category allow-list, coordinate sanity).
2.  Duplicate detection against recent reports and active incidents.
3.  Triage: keyword-driven priority + optional photo, always marked
    **unverified** until an analyst corroborates it.
4.  Human-review routing for suspicious/high-priority reports.
5.  Privacy: reporter identity is stored as a salted one-way hash; free-text
    contact is only kept if the reporter explicitly opts in; coordinates are
    never returned at full precision to other citizens.

Hard safety rule: this agent CANNOT create or publish a public alert.  A citizen
report can at most (a) raise a review task, and (b) attach as *unverified*
evidence to an existing incident.
"""
from __future__ import annotations

import logging
import re
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..services import geo
from ..util import clamp, now, stable_hash
from .base import AgentContext, BaseAgent
from .classification_agent import SUPPORTED, classification_agent

log = logging.getLogger("aegis.agents.citizen")

DUPLICATE_RADIUS_KM = 2.0
DUPLICATE_WINDOW_HOURS = 6.0
INCIDENT_LINK_RADIUS_KM = 40.0
INCIDENT_LINK_WINDOW_HOURS = 48.0

URGENT_TERMS = ["trapped", "injured", "casualt", "dead", "dying", "collapsed", "swept away", "burning", "critical",
                "missing", "drowning", "bleeding", "explosion", "toxic", "gas leak", "people stuck"]
SUSPICIOUS_PATTERNS = [
    r"https?://\S+", r"\b(crypto|loan|casino|viagra|porn)\b", r"(.{1,4})\1{6,}",
]


class CitizenAgent(BaseAgent):
    name = "citizen_agent"
    description = ("Validates citizen incident reports, detects duplicates, triages priority, protects reporter "
                   "privacy and routes high-priority or suspicious reports for human review.")
    capabilities = ["input_validation", "duplicate_detection", "triage", "privacy_protection", "review_routing"]

    # ------------------------------------------------------------------ #
    def validate(self, payload: dict) -> dict[str, Any]:
        errors: list[str] = []
        warnings: list[str] = []
        lat, lon = payload.get("lat"), payload.get("lon")
        try:
            lat, lon = float(lat), float(lon)
        except (TypeError, ValueError):
            errors.append("Latitude/longitude must be numeric.")
            lat = lon = None
        if lat is not None and not (-90 <= lat <= 90):
            errors.append("Latitude out of range (-90..90).")
        if lon is not None and not (-180 <= lon <= 180):
            errors.append("Longitude out of range (-180..180).")
        if lat == 0 and lon == 0:
            warnings.append("Coordinates (0,0) look like a GPS default — please confirm the location.")

        desc = (payload.get("description") or "").strip()
        if len(desc) < 20:
            errors.append("Please describe what you observed in at least 20 characters (this helps analysts verify it).")
        if len(desc) > 4000:
            errors.append("Description too long (max 4000 characters).")

        category = (payload.get("category") or "unknown").strip().lower()
        if category not in SUPPORTED + ["unknown"]:
            errors.append(f"Unsupported category '{category}'. Supported: {', '.join(SUPPORTED + ['unknown'])}.")
        if category == "unknown":
            warnings.append("Category left as 'unknown' — analysts will classify it from your description.")

        observed_at = payload.get("observed_at")
        flags: list[str] = []
        low = desc.lower()
        for pat in SUSPICIOUS_PATTERNS:
            if re.search(pat, low):
                flags.append(f"suspicious_pattern:{pat[:18]}")
        if len(desc) < 40:
            flags.append("very_short_description")

        priority = "normal"
        urgent_hits = [t for t in URGENT_TERMS if t in low]
        if urgent_hits:
            priority = "critical" if len(urgent_hits) >= 2 else "high"

        return {
            "ok": not errors, "errors": errors, "warnings": warnings, "flags": flags, "priority": priority,
            "urgent_terms": urgent_hits, "lat": lat, "lon": lon, "description": desc, "category": category,
            "observed_at": observed_at,
        }

    # ------------------------------------------------------------------ #
    def detect_duplicates(self, db: Session, *, lat: float, lon: float, description: str,
                          category: str, exclude_id: str | None = None) -> dict[str, Any]:
        from datetime import timedelta

        since = now() - timedelta(hours=DUPLICATE_WINDOW_HOURS)
        candidates = db.scalars(
            select(models.CitizenReport).where(models.CitizenReport.created_at >= since)
        ).all()
        norm = lambda s: re.sub(r"\W+", " ", (s or "").lower()).strip()  # noqa: E731
        mine = set(norm(description).split())
        best = None
        for c in candidates:
            if exclude_id and c.id == exclude_id:
                continue
            d = geo.haversine_km(lat, lon, c.lat, c.lon)
            if d > DUPLICATE_RADIUS_KM:
                continue
            other = set(norm(c.description).split())
            jaccard = len(mine & other) / max(1, len(mine | other))
            same_cat = c.category == category and category != "unknown"
            if jaccard >= 0.45 or (jaccard >= 0.25 and same_cat and d <= 1.0):
                if best is None or d < best["distance_km"]:
                    best = {"report_id": c.id, "public_code": c.public_code, "distance_km": round(d, 2),
                            "similarity": round(jaccard, 2), "same_category": same_cat,
                            "age_hours": round((now() - c.created_at).total_seconds() / 3600, 1)}
        return {"duplicate": bool(best), "match": best,
                "method": f"Token Jaccard similarity within {DUPLICATE_RADIUS_KM} km / {DUPLICATE_WINDOW_HOURS} h window"}

    # ------------------------------------------------------------------ #
    def find_matching_incident(self, db: Session, *, lat: float, lon: float, category: str) -> models.Incident | None:
        from datetime import timedelta

        since = now() - timedelta(hours=INCIDENT_LINK_WINDOW_HOURS)
        incidents = db.scalars(
            select(models.Incident).where(models.Incident.status.in_(("active", "monitoring")),
                                          models.Incident.started_at >= since)
        ).all()
        best, best_d = None, None
        for inc in incidents:
            d = geo.haversine_km(lat, lon, inc.lat, inc.lon)
            if d > INCIDENT_LINK_RADIUS_KM:
                continue
            cat_match = inc.category == category or category == "unknown" or inc.category == "unknown"
            score = d - (15 if cat_match else 0)
            if best_d is None or score < best_d:
                best, best_d = inc, score
        return best

    # ------------------------------------------------------------------ #
    def submit(
        self,
        db: Session,
        *,
        lat: float,
        lon: float,
        description: str,
        category: str = "unknown",
        reporter_id: str | None = None,
        contact_optin: str | None = None,
        photo_path: str | None = None,
        photo_sha256: str | None = None,
        location_source: str = "manual",
        location_accuracy_m: float | None = None,
        observed_at: str | None = None,
        ctx: AgentContext | None = None,
    ) -> dict[str, Any]:
        check = self.validate({"lat": lat, "lon": lon, "description": description, "category": category})
        if not check["ok"]:
            return {"created": False, "errors": check["errors"], "warnings": check["warnings"]}

        dupe = self.detect_duplicates(db, lat=lat, lon=lon, description=description, category=category)
        suggestion = classification_agent.suggest_for_text(description)
        if category == "unknown" and suggestion["category"] != "unknown":
            category = suggestion["category"]

        place_res = self._place_label(lat, lon)
        status = "duplicate" if dupe["duplicate"] else ("under_review" if check["priority"] in {"high", "critical"} else "submitted")
        flags = list(check["flags"])
        if dupe["duplicate"]:
            flags.append("possible_duplicate")

        report = models.CitizenReport(
            public_code=models.new_id("RPT").replace("RPT_", "RPT-").upper(),
            category=category, description=description.strip(), lat=round(lat, 4), lon=round(lon, 4),
            location_accuracy_m=location_accuracy_m, location_source=location_source, place=place_res,
            photo_path=photo_path, photo_sha256=photo_sha256,
            reporter_hash=stable_hash(reporter_id or "anonymous", salt="aegis-reporter"),
            contact_optin=(contact_optin or None) if contact_optin else None,
            status=status, priority=check["priority"], flags=flags,
            duplicate_of_id=(dupe["match"]["report_id"] if dupe["duplicate"] else None),
            confidence=clamp(suggestion["confidence"] * 0.5, 0, 40),  # unverified by definition
            data_origin="live",
        )
        db.add(report)
        db.flush()

        linked_incident = None
        if not dupe["duplicate"]:
            cand = self.find_matching_incident(db, lat=lat, lon=lon, category=category)
            if cand is not None:
                report.linked_incident_id = cand.id
                linked_incident = cand
                db.add(models.IncidentEvidence(
                    incident_id=cand.id, kind="citizen_report", source_key="citizen",
                    source_url="", title=f"Citizen report {report.public_code} (UNVERIFIED)",
                    excerpt=description.strip()[:1200],
                    observed_at=now(), confidence=report.confidence, data_origin="live",
                    added_by=self.name,
                ))
                if report.status == "submitted":
                    report.status = "linked"
        db.flush()

        if ctx:
            ctx.add_finding(
                f"Citizen report {report.public_code} accepted ({report.priority} priority, status {report.status}). "
                + ("Marked as a possible duplicate of " + dupe["match"]["public_code"] + ". " if dupe["duplicate"] else "")
                + ("Linked as UNVERIFIED evidence to incident " + linked_incident.code + ". " if linked_incident else "")
                + "Citizen reports never trigger public alerts without human review.",
                kind="citizen_report", source="citizen",
                extra={"report_id": report.id, "requires_review": report.status in {"under_review", "submitted"}},
            )
        return {
            "created": True, "report_id": report.id, "public_code": report.public_code, "status": report.status,
            "priority": report.priority, "flags": report.flags, "duplicate": dupe,
            "classification_hint": suggestion, "linked_incident_id": linked_incident.id if linked_incident else None,
            "linked_incident_code": linked_incident.code if linked_incident else None,
            "place": place_res,
            "privacy_note": ("Reporter identity stored as a salted one-way hash. Coordinates are stored at 4 decimal "
                             "places (~11 m) and are never displayed at that precision on public views."),
            "verification_note": "This report is UNVERIFIED until an analyst corroborates it.",
            "warnings": check["warnings"],
        }

    # ------------------------------------------------------------------ #
    def _place_label(self, lat: float, lon: float) -> str:
        try:
            from ..services import facilities as fac

            res = fac.reverse_geocode(lat, lon)
            if res.get("ok"):
                parts = [res.get("locality"), res.get("district"), res.get("state"), res.get("country")]
                return ", ".join([p for p in parts if p])
        except Exception:  # noqa: BLE001
            pass
        return geo.place_label(lat, lon)

    # ------------------------------------------------------------------ #
    def review(self, db: Session, report: models.CitizenReport, *, action: str, reviewer: str,
               notes: str = "", incident_id: str | None = None) -> dict[str, Any]:
        """Analyst/admin verification workflow. Actions: verify | reject | mark_duplicate | link."""
        before = {"status": report.status}
        if action == "verify":
            report.status = "verified"
            report.confidence = 75.0
        elif action == "reject":
            report.status = "rejected"
            report.confidence = 0.0
        elif action == "mark_duplicate":
            report.status = "duplicate"
        elif action == "link":
            if not incident_id:
                return {"ok": False, "error": "incident_id required for link action"}
            report.status = "linked"
            report.linked_incident_id = incident_id
        else:
            return {"ok": False, "error": f"unknown action '{action}'"}
        report.reviewed_by = reviewer
        report.reviewed_at = now()
        report.review_notes = (report.review_notes + " " + notes).strip() if report.review_notes else notes
        db.add(models.AuditLog(
            actor=reviewer, actor_role="analyst", action=f"citizen_report.{action}", entity_type="citizen_report",
            entity_id=report.id, before=before, after={"status": report.status}, reason=notes[:500],
        ))
        db.flush()
        return {"ok": True, "report_id": report.id, "public_code": report.public_code, "status": report.status}


citizen_agent = CitizenAgent()
