"""Agent 4 — Risk & Impact Assessment Agent.

Produces a TRANSPARENT, reproducible risk score:

    risk = w_h · hazard_score + w_e · exposure_score + w_v · vulnerability_score

*   hazard_score      : severity band + hazard-specific metrics + official alert level
                        + relevant weather/forecast drivers (Open-Meteo model fields).
*   exposure_score    : modelled population inside the estimated footprint (log scale)
                        + proximity/scale of settlements + mapped critical facilities.
*   vulnerability_score: documented static proxy per hazard (see VULNERABILITY_PROXIES)
                        — AEGIS does NOT integrate sub-national social-vulnerability
                        indices, and says so in the limitations.

Every factor records its value, weight, contribution and provenance, so the UI can
explain exactly why an incident scores what it scores.  The result is a MODEL
ESTIMATE, never an official forecast.
"""
from __future__ import annotations

import logging
import math
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..llm import llm_client
from ..services import geo
from ..services import weather as wx_service
from ..util import clamp, now
from .base import AgentContext, BaseAgent

log = logging.getLogger("aegis.agents.risk")

METHODOLOGY_VERSION = "risk-v1.0"

# Weights per hazard class (must sum to 1.0).
WEIGHTS: dict[str, dict[str, float]] = {
    "earthquake": {"hazard": 0.50, "exposure": 0.35, "vulnerability": 0.15},
    "tsunami": {"hazard": 0.45, "exposure": 0.40, "vulnerability": 0.15},
    "cyclone": {"hazard": 0.45, "exposure": 0.40, "vulnerability": 0.15},
    "flood": {"hazard": 0.40, "exposure": 0.40, "vulnerability": 0.20},
    "wildfire": {"hazard": 0.45, "exposure": 0.40, "vulnerability": 0.15},
    "landslide": {"hazard": 0.45, "exposure": 0.40, "vulnerability": 0.15},
    "industrial_fire": {"hazard": 0.50, "exposure": 0.35, "vulnerability": 0.15},
    "unknown": {"hazard": 0.34, "exposure": 0.33, "vulnerability": 0.33},
}

# Static vulnerability proxies: what structural/financial exposure AEGIS can reason
# about without a live vulnerability dataset.  Values are 0-100 "prior" scores with
# an explicit rationale; they are deliberately conservative and identical for every
# incident of that hazard (i.e. they do not pretend to be location-specific).
VULNERABILITY_PROXIES: dict[str, tuple[float, str]] = {
    "earthquake": (55, "Structural vulnerability prior for unreinforced masonry/brick construction common in many "
                       "seismically active regions; not building-stock specific."),
    "tsunami": (60, "Coastal communities have limited evacuation time and high dependence on vertical evacuation "
                    "structures; inundation depth not modelled."),
    "cyclone": (58, "Wind + storm-surge damage to light-frame housing and power/communications networks; "
                    "building codes vary by region."),
    "flood": (52, "Flood losses concentrate in low-lying housing, roads and agriculture; drainage capacity "
                  "not modelled."),
    "wildfire": (45, "Wildland-urban interface exposure and smoke-health impacts; fuel load and slope not modelled."),
    "landslide": (50, "Slope failure threatens roads and hillside settlements; slope stability not modelled."),
    "industrial_fire": (48, "Hazmat plume, thermal radiation and secondary explosion potential at industrial sites; "
                            "facility-specific inventory not available."),
    "unknown": (40, "No hazard-specific vulnerability prior available."),
}

SEVERITY_LABELS = {1: "minimal", 2: "low", 3: "moderate", 4: "high", 5: "extreme"}

RISK_BANDS = [(80.0, "extreme"), (62.0, "high"), (42.0, "moderate"), (22.0, "low"), (0.0, "minimal")]


class RiskAgent(BaseAgent):
    name = "risk_agent"
    description = ("Computes an explainable hazard/exposure/vulnerability risk score with a documented "
                   "methodology and stated limitations.")
    capabilities = ["hazard_scoring", "exposure_estimation", "vulnerability_prior", "explainability"]

    # ------------------------------------------------------------------ #
    def hazard_score(self, incident: models.Incident, drivers: dict[str, dict]) -> tuple[float, list[dict]]:
        factors: list[dict] = []

        def f(name: str, value: Any, contribution: float, note: str, source: str | None = None) -> None:
            factors.append({"factor": name, "value": value, "contribution": round(contribution, 2), "note": note, "source": source})

        base = {1: 12.0, 2: 28.0, 3: 48.0, 4: 68.0, 5: 86.0}.get(incident.severity, 30.0)
        f("severity_band", f"{incident.severity}/5", base,
          f"Documented severity band for {incident.category.replace('_', ' ')} ({SEVERITY_LABELS.get(incident.severity)})",
          "aegis_thresholds")

        score = base
        # Detections with weak verification carry their uncertainty into hazard scoring.
        if incident.verification_status == "preliminary_detection":
            score -= 8
            f("verification_discount", incident.verification_status, -8.0,
              "Preliminary detection only — hazard score discounted until corroborated", "aegis_methodology")
        elif incident.verification_status in {"officially_confirmed", "human_verified"}:
            score += 5
            f("verification_credit", incident.verification_status, 5.0,
              "Event established by an official product or human verification", "aegis_methodology")
        if incident.is_ambiguous:
            score -= 6
            f("classification_ambiguity", True, -6.0,
              "Category flagged for human review — reduced confidence", "classification_agent")

        # GDACS official alert level (authoritative third-party assessment)
        alert = None
        for key in ("gdacs_alert_level",):
            alert = (incident.external_refs or {}).get(key)
        gdacs_level = (incident.external_refs or {}).get("gdacs_alert_level")
        if gdacs_level in {"Orange", "Red"}:
            boost = 10 if gdacs_level == "Orange" else 18
            score += boost
            f("gdacs_alert_level", gdacs_level, boost, "Official GDACS alert level (JRC) — authoritative input", "gdacs")

        for name, driver in drivers.items():
            if not driver.get("available"):
                continue
            level = driver.get("level")
            contribution = {"low": -6.0, "moderate": 4.0, "high": 12.0, "very_high": 18.0}.get(level, 0.0)
            if abs(contribution) > 0:
                score += contribution
                f(f"{name}_driver", f"{level} (score {driver.get('score')})", contribution,
                  driver.get("rationale", ""), driver.get("source"))

        # earthquake-specific: depth attenuation and tsunami flag
        if incident.category == "earthquake":
            depth = incident.depth_km
            if isinstance(depth, (int, float)):
                if depth <= 30:
                    score += 6
                    f("depth", f"{depth:g} km", 6.0, "Shallow hypocentre (≤30 km) increases shaking at the surface", "usgs")
                elif depth >= 150:
                    score -= 6
                    f("depth", f"{depth:g} km", -6.0, "Deep event (≥150 km) attenuates surface shaking", "usgs")
        return clamp(score, 0, 100), factors

    # ------------------------------------------------------------------ #
    def exposure_score(self, incident: models.Incident, area: dict | None, facilities: dict | None) -> tuple[float, list[dict]]:
        factors: list[dict] = []

        def f(name: str, value: Any, contribution: float, note: str, source: str | None = None) -> None:
            factors.append({"factor": name, "value": value, "contribution": round(contribution, 2), "note": note, "source": source})

        score = 10.0
        pop = (area or {}).get("population_estimate")
        if pop:
            # log10 scale: 1k→~30, 10k→~45, 100k→~60, 1M→~75, 10M→~90
            contrib = clamp((math.log10(max(pop, 1)) - 2.0) * 15.0, 0, 70)
            score += contrib
            f("modelled_population_in_footprint", f"≈{pop:,}", contrib,
              (area or {}).get("population_method", ""), "aegis_geo_model")
        else:
            f("modelled_population_in_footprint", None, 0.0,
              "No population estimate available (offline gazetteer has no places inside the footprint)", "aegis_geo_model")

        places = (area or {}).get("nearby_places") or []
        if places:
            biggest = max(places, key=lambda p: p.get("population") or 0)
            if (biggest.get("population") or 0) >= 500_000:
                score += 8
                f("largest_settlement_nearby", f"{biggest['name']} (pop ≈ {biggest['population']:,})", 8.0,
                  f"Large settlement {biggest['distance_km']} km from the incident centre", "natural_earth")
            elif (biggest.get("population") or 0) >= 50_000:
                score += 4
                f("largest_settlement_nearby", f"{biggest['name']} (pop ≈ {biggest['population']:,})", 4.0,
                  f"Settlement {biggest['distance_km']} km from the incident centre", "natural_earth")

        if facilities and facilities.get("ok"):
            hosp = [x for x in facilities["facilities"] if x["class"] == "hospital"]
            score += min(6.0, 1.5 * len(hosp))
            f("mapped_hospitals_nearby", len(hosp), min(6.0, 1.5 * len(hosp)),
              "Hospitals mapped by OpenStreetMap within the search radius form part of the response baseline", "openstreetmap")
            if len(hosp) == 0:
                score += 4
                f("hospital_coverage_gap", 0, 4.0,
                  "No hospital mapped in OSM within the search radius — either a real coverage gap or OSM incompleteness",
                  "openstreetmap")
        else:
            f("mapped_facilities", None, 0.0, "Facility data unavailable for this incident", "openstreetmap")
        return clamp(score, 0, 100), factors

    # ------------------------------------------------------------------ #
    def vulnerability_score(self, incident: models.Incident) -> tuple[float, list[dict]]:
        value, rationale = VULNERABILITY_PROXIES.get(incident.category, VULNERABILITY_PROXIES["unknown"])
        return float(value), [{
            "factor": "vulnerability_prior", "value": value, "contribution": round(value, 2),
            "note": rationale, "source": "aegis_static_prior",
        }]

    # ------------------------------------------------------------------ #
    def assess(self, db: Session, incident: models.Incident, ctx: AgentContext | None = None,
               *, weather: dict | None = None, area: dict | None = None, facilities: dict | None = None,
               persist: bool = True) -> dict[str, Any]:
        cat = incident.category
        # --- weather drivers (model forecast fields) -------------------- #
        if weather is None:
            weather = wx_service.forecast(incident.lat, incident.lon)
        drivers: dict[str, dict] = {}
        if weather.get("ok"):
            if cat in {"flood", "cyclone", "landslide"}:
                drivers["rainfall"] = wx_service.flood_drivers(weather)
            if cat in {"cyclone", "wildfire", "industrial_fire"}:
                drivers["wind"] = wx_service.wind_drivers(weather)
            if cat == "landslide":
                drivers["slope_rain"] = wx_service.landslide_drivers(weather)
            if cat in {"wildfire", "industrial_fire"}:
                drivers["fire_weather"] = wx_service.heat_dryness_drivers(weather)
        else:
            drivers["weather"] = {"available": False, "reason": weather.get("error")}

        # --- area / facilities (reuse GeoAgent output when supplied) ---- #
        if area is None:
            radius, method = _radius_from_geo(incident)
            pop, places = geo.population_within_km(incident.lat, incident.lon, radius)
            area = {"radius_km": radius, "population_estimate": pop, "nearby_places": places,
                    "population_method": "Static gazetteer estimate (see geo_agent).", "method": method,
                    "area_km2": geo.polygon_area_km2(geo.circle_polygon(incident.lat, incident.lon, radius))}

        hazard, h_factors = self.hazard_score(incident, drivers)
        exposure, e_factors = self.exposure_score(incident, area, facilities)
        vulnerability, v_factors = self.vulnerability_score(incident)
        w = WEIGHTS.get(cat, WEIGHTS["unknown"])
        risk = hazard * w["hazard"] + exposure * w["exposure"] + vulnerability * w["vulnerability"]
        risk = round(clamp(risk, 0, 100), 1)
        level = next(label for threshold, label in RISK_BANDS if risk >= threshold)

        weights_applied = [
            {"component": "hazard", "weight": w["hazard"], "score": round(hazard, 1),
             "contribution": round(hazard * w["hazard"], 2)},
            {"component": "exposure", "weight": w["exposure"], "score": round(exposure, 1),
             "contribution": round(exposure * w["exposure"], 2)},
            {"component": "vulnerability", "weight": w["vulnerability"], "score": round(vulnerability, 1),
             "contribution": round(vulnerability * w["vulnerability"], 2)},
        ]
        factors = h_factors + e_factors + v_factors

        limitations = (
            "MODEL ESTIMATE — not an official forecast. AEGIS risk scores are computed from the factors listed above; "
            "population exposure uses a static ~2011 gazetteer, no real-time census or building-level data; "
            "vulnerability uses a hazard-level static prior, not a sub-national vulnerability index; "
            "weather inputs are model fields, not measurements. Road status, structural condition, and "
            "local response capacity are not modelled. Always defer to the responsible authority "
            "(e.g. NDMA/SDMA and IMD in India, NHC in the US, your national civil-protection agency)."
        )

        llm_used = False
        narrative = ""
        if llm_client.enabled:
            res = llm_client.narrative({
                "incident": {"code": incident.code, "category": cat, "severity_band": incident.severity,
                             "verification_status": incident.verification_status, "region": incident.region,
                             "lat": incident.lat, "lon": incident.lon},
                "risk_score": risk, "risk_level": level,
                "components": weights_applied,
                "top_factors": sorted(factors, key=lambda x: -abs(x["contribution"]))[:8],
                "weather_drivers": drivers,
                "limitations": limitations,
            }, question="Explain the risk assessment in 3 short paragraphs.")
            if res.ok and res.text:
                narrative = res.text.strip()
                llm_used = True
        if not narrative:
            top = sorted(factors, key=lambda x: -abs(x["contribution"]))[:4]
            narrative = (
                f"Risk {risk:.0f}/100 ({level.upper()}) for this {cat.replace('_', ' ')} incident. "
                f"Component scores: hazard {hazard:.0f} (weight {w['hazard']:.0%}), exposure {exposure:.0f} "
                f"(weight {w['exposure']:.0%}), vulnerability {vulnerability:.0f} (weight {w['vulnerability']:.0%}). "
                "The dominant factors are: " + "; ".join(f"{x['factor']} ({x['contribution']:+.0f})" for x in top) + ". "
                "This is an AEGIS model estimate generated from the cited evidence, not an official forecast or warning."
            )

        result = {
            "risk_score": risk, "risk_level": level, "hazard_score": round(hazard, 1),
            "exposure_score": round(exposure, 1), "vulnerability_score": round(vulnerability, 1),
            "confidence": round(clamp(incident.confidence * 0.9, 5, 95), 1),
            "factors": factors, "weights": weights_applied, "drivers": drivers,
            "narrative": narrative, "limitations": limitations, "methodology_version": METHODOLOGY_VERSION,
            "llm_used": llm_used, "estimate": True,
        }

        if persist:
            existing = db.scalar(select(models.RiskAssessment).where(models.RiskAssessment.incident_id == incident.id)
                                 .order_by(models.RiskAssessment.created_at.desc()))
            assessment = models.RiskAssessment(
                incident_id=incident.id, risk_level=level, risk_score=risk,
                hazard_score=round(hazard, 1), exposure_score=round(exposure, 1),
                vulnerability_score=round(vulnerability, 1), confidence=result["confidence"],
                factors=factors + [{"factor": "_weights", "value": weights_applied}],
                methodology_version=METHODOLOGY_VERSION, narrative=narrative, limitations=limitations,
                agent=self.name, llm_used=llm_used, data_origin=incident.data_origin,
            )
            db.add(assessment)
            db.flush()
            result["assessment_id"] = assessment.id
            result["previous_risk_score"] = existing.risk_score if existing else None
            result["risk_delta"] = round(risk - existing.risk_score, 1) if existing else None
        if ctx:
            ctx.add_finding(f"Risk {risk:.0f}/100 ({level}) — hazard {hazard:.0f}, exposure {exposure:.0f}, "
                            f"vulnerability {vulnerability:.0f} ({METHODOLOGY_VERSION}, size of change vs previous: "
                            f"{result.get('risk_delta')}).",
                            kind="estimate", source="aegis_risk_model", confidence=result["confidence"],
                            extra={"incident_id": incident.id, "risk_score": risk, "risk_level": level,
                                   "estimate": True, "llm_used": llm_used})
        return result

    # ------------------------------------------------------------------ #
    def run(self, db: Session, ctx: AgentContext, *, incident_ids: list[str], persist: bool = True) -> dict[str, Any]:
        incidents = list(db.scalars(select(models.Incident).where(models.Incident.id.in_(incident_ids))))
        results = []
        with ctx.tool("risk_assessment", {"incidents": len(incidents)}) as t:
            for inc in incidents:
                if ctx.timed_out():
                    t["status"] = "timeout"
                    t["error"] = "deadline exceeded during risk assessment"
                    break
                res = self.assess(db, inc, ctx, persist=persist)
                results.append({"incident_id": inc.id, "code": inc.code, **res})
            t["source"] = "aegis_risk_model"
            t["summary"] = f"assessed {len(results)} incident(s)"
        return {"agent": self.name, "methodology": METHODOLOGY_VERSION, "weights": WEIGHTS,
                "bands": RISK_BANDS, "results": results}


def _radius_from_geo(incident: models.Incident) -> tuple[float, str]:
    from .geo_agent import estimate_radius_km

    return estimate_radius_km(incident.category, incident.severity, incident.confidence)


risk_agent = RiskAgent()
