"""Agent 3 — Geospatial Intelligence Agent.

*   Resolves an incident to a place (locality / district / country).
*   Estimates the affected area with an explicit, hazard-specific rule table
    (clearly labelled ESTIMATE) or stores an authoritative polygon when the
    provider publishes one (GDACS geometry, NHC forecast cone).
*   Estimates population exposure from an offline static gazetteer
    (first-order estimate, never census-accurate).
*   Finds nearby critical facilities and transport context via OpenStreetMap
    (clearly labelled as community-mapped data with completeness caveats).
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..services import facilities as fac_service
from ..services import geo
from ..sources.http import request_json
from ..util import now
from .base import AgentContext, BaseAgent

log = logging.getLogger("aegis.agents.geo")

# Documented affected-area rule table: base radius (km) per hazard + per severity point.
AREA_RULES: dict[str, dict[str, float]] = {
    "earthquake": {"base_km": 12.0, "per_severity_km": 16.0, "cap_km": 220.0,
                   "method": "Macroseismic-style crude radius: base 12 km + 16 km per severity point "
                             "(M<5≈1-2, M6≈4, M7+≈5). Not a ShakeMap; use USGS ShakeMap/PAGER for operational use."},
    "tsunami": {"base_km": 30.0, "per_severity_km": 60.0, "cap_km": 400.0,
                "method": "Coastal inundation warning radius around the bulletin epicentre; actual inundation depends on "
                          "bathymetry and is mapped by the issuing tsunami centre's travel-time products."},
    "cyclone": {"base_km": 90.0, "per_severity_km": 55.0, "cap_km": 400.0,
                "method": "Wind-field approximation: base 90 km + 55 km per severity point. Official wind radii and the "
                          "forecast cone from the responsible RSMC/NHC supersede this estimate."},
    "flood": {"base_km": 15.0, "per_severity_km": 20.0, "cap_km": 150.0,
              "method": "Floodplain exposure proxy around the reported/observable flood point; actual extent requires "
                        "SAR/optical flood mapping (e.g. Copernicus EMS, MODIS flood product)."},
    "wildfire": {"base_km": 4.0, "per_severity_km": 6.0, "cap_km": 60.0,
                 "method": "Fire-complex proxy: 4 km + 6 km per severity point around hotspot centroid. VIIRS 375 m "
                           "hotspots and burnt-area products (MODIS/VIIRS) give better geometry."},
    "landslide": {"base_km": 1.5, "per_severity_km": 2.0, "cap_km": 25.0,
                  "method": "Local slope-failure footprint proxy; slope, lithology and rainfall thresholds are not modelled."},
    "industrial_fire": {"base_km": 1.5, "per_severity_km": 3.0, "cap_km": 30.0,
                        "method": "Hazard/evacuation-zone proxy around an industrial site (typically 0.5–5 km). "
                                  "On-site incident command zones supersede this estimate."},
    "unknown": {"base_km": 5.0, "per_severity_km": 5.0, "cap_km": 60.0,
                "method": "Generic alert radius pending classification."},
}


def estimate_radius_km(category: str, severity: int, confidence: float) -> tuple[float, str]:
    rule = AREA_RULES.get(category, AREA_RULES["unknown"])
    radius = min(rule["base_km"] + rule["per_severity_km"] * max(0, severity - 1), rule["cap_km"])
    # Low-confidence detections report a smaller, more conservative footprint.
    if confidence < 50:
        radius *= 0.6
    return round(radius, 1), rule["method"]


class GeoAgent(BaseAgent):
    name = "geo_agent"
    description = ("Resolves incident geography, estimates affected areas and population exposure, and finds "
                   "nearby facilities using reliable map data.")
    capabilities = ["region_resolution", "affected_area_estimation", "population_exposure", "facility_lookup", "official_geometry"]

    # ------------------------------------------------------------------ #
    def resolve_region(self, db: Session, incident: models.Incident, ctx: AgentContext | None = None) -> dict[str, Any]:
        """Place name via Nominatim, with offline gazetteer fallback."""
        from ..sources.http import SourceFetch  # local import keeps module import light

        res = fac_service.reverse_geocode(incident.lat, incident.lon)
        label_parts = []
        if res.get("ok"):
            country = res.get("country") or incident.country
            admins = [res.get("locality"), res.get("district"), res.get("state")]
            label_parts = [p for p in admins if p]
            country_iso3 = res.get("country_code") or incident.country_iso3
            source_note = "OpenStreetMap Nominatim reverse geocode"
        else:
            near = geo.nearest_places(incident.lat, incident.lon, limit=1)
            country = (near[0].get("country") if near else incident.country) or incident.country
            country_iso3 = incident.country_iso3
            label_parts = [f"near {near[0]['name']}" for _ in near] if near else []
            source_note = "offline Natural Earth gazetteer (Nominatim unavailable)"

        region = ", ".join(label_parts) if label_parts else geo.place_label(incident.lat, incident.lon)
        incident.region = region or incident.region
        incident.country = country or incident.country
        if country_iso3:
            incident.country_iso3 = str(country_iso3)[:6]
        if ctx:
            ctx.add_finding(f"Incident geolocated to {region or 'unnamed area'}"
                            + (f", {country}" if country else ""), kind="geography",
                            source=("openstreetmap" if res.get("ok") else "offline_gazetteer"))
        return {"region": incident.region, "country": incident.country, "country_iso3": incident.country_iso3,
                "source": source_note, "geocode": res}

    # ------------------------------------------------------------------ #
    def official_geometry(self, incident: models.Incident, ctx: AgentContext | None = None) -> dict | None:
        """Fetch an authoritative boundary/geometry when the provider publishes one (GDACS)."""
        obs = list(incident.source_keys or [])
        if "gdacs" not in obs:
            return None
        geometry_url = None
        for key, val in (incident.external_refs or {}).items():
            if key == "gdacs" and val:
                parts = str(val).split("-")
                if len(parts) == 3:
                    geometry_url = ("https://www.gdacs.org/gdacsapi/api/polygons/getgeometry?"
                                    f"eventtype={parts[0]}&eventid={parts[1]}&episodeid={parts[2]}")
        if not geometry_url:
            return None
        res = request_json(geometry_url, timeout=15.0, retries=1)
        if not res.ok or not isinstance(res.data, dict):
            return None
        feats = res.data.get("features") or []
        if not feats:
            return None
        geom = (feats[0] or {}).get("geometry")
        if not geom:
            return None
        if ctx:
            ctx.add_finding("Authoritative GDACS polygon retrieved for this event.", kind="geography", source="gdacs")
        return {"geojson": geom, "authority": "GDACS (JRC)", "source_url": geometry_url,
                "polygonlabel": (feats[0].get("properties") or {}).get("polygonlabel")}

    # ------------------------------------------------------------------ #
    def estimate_affected_area(self, db: Session, incident: models.Incident, ctx: AgentContext | None = None,
                               *, persist: bool = True) -> dict[str, Any]:
        radius, method = estimate_radius_km(incident.category, incident.severity, incident.confidence)
        population, places = geo.population_within_km(incident.lat, incident.lon, radius)
        polygon = geo.circle_polygon(incident.lat, incident.lon, radius)
        area_km2 = geo.polygon_area_km2(polygon)

        official = self.official_geometry(incident, ctx)
        record: dict[str, Any] = {
            "kind": "estimate",
            "radius_km": radius,
            "area_km2": round(area_km2, 1),
            "geojson": polygon,
            "method": method,
            "method_version": "geo-v1",
            "population_estimate": population,
            "population_method": ("Static gazetteer (Natural Earth 10m populated places, ~2011 population attributes): "
                                  "places whose centres fall inside the radius; edge places weighted 0.5. "
                                  "First-order exposure indicator only — not a census, not real-time."),
            "nearby_places": places[:8],
            "is_estimate": True,
            "authority": "",
            "source_key": "aegis_geo_model",
            "official": None,
        }
        if official:
            record["official"] = {
                "geojson": official["geojson"],
                "authority": official["authority"],
                "source_url": official["source_url"],
                "area_km2": round(geo.polygon_area_km2(official["geojson"]), 1),
                "label": official.get("polygonlabel") or "provider polygon",
            }
        if persist:
            # supersede previous estimate records of the same kind
            for old in db.scalars(select(models.AffectedArea).where(
                    models.AffectedArea.incident_id == incident.id,
                    models.AffectedArea.method_version == "geo-v1")):
                db.delete(old)
            db.add(models.AffectedArea(
                incident_id=incident.id,
                label=f"Estimated affected area — {incident.category.replace('_', ' ')} (model estimate)",
                geometry_geojson=polygon, area_km2=round(area_km2, 1), radius_km=radius,
                population_estimate=population, population_method=record["population_method"],
                method=method, is_estimate=True, source_key="aegis_geo_model", method_version="geo-v1",
            ))
            if official:
                db.add(models.AffectedArea(
                    incident_id=incident.id,
                    label=f"Authoritative polygon — {official['authority']}",
                    geometry_geojson=official["geojson"],
                    area_km2=round(geo.polygon_area_km2(official["geojson"]), 1),
                    radius_km=None, population_estimate=None,
                    population_method="", method=f"Published by {official['authority']} (not an AEGIS estimate)",
                    is_estimate=False, authority=official["authority"], source_key="gdacs",
                    method_version="provider",
                ))
            incident.country_iso3 = incident.country_iso3  # no-op touch to mark dirty
            db.flush()
        if ctx:
            ctx.add_finding(
                f"Estimated affected area: {area_km2:,.0f} km² (radius {radius} km, {incident.severity}/5 severity band). "
                f"Modelled population exposure inside the radius ≈ {population:,} (static gazetteer estimate).",
                kind="estimate", source="aegis_geo_model", confidence=min(incident.confidence, 65),
                extra={"incident_id": incident.id, "estimated": True})
        return record

    # ------------------------------------------------------------------ #
    def nearby_facilities(self, incident: models.Incident, radius_km: float = 25.0,
                          ctx: AgentContext | None = None) -> dict[str, Any]:
        data = fac_service.nearby_facilities(incident.lat, incident.lon, radius_km)
        if ctx:
            ctx.add_finding(
                (f"{data.get('count', 0)} critical facilit(ies) mapped within {radius_km:.0f} km (OpenStreetMap)."
                 if data.get("ok") else f"Facility lookup unavailable: {data.get('error')}"),
                kind="facilities", source="openstreetmap")
        return data

    # ------------------------------------------------------------------ #
    def context_report(self, db: Session, incident: models.Incident, ctx: AgentContext | None = None,
                       radius_km: float = 25.0, *, persist: bool = True,
                       include_facilities: bool = True) -> dict[str, Any]:
        region = self.resolve_region(db, incident, ctx)
        area = self.estimate_affected_area(db, incident, ctx, persist=persist)
        facs = self.nearby_facilities(incident, radius_km, ctx) if include_facilities else None
        transport = None
        if facs and facs.get("ok"):
            transport = self._transport_context(incident, facs.get("facilities") or [])
        return {"agent": self.name, "region": region, "area": area, "facilities": facs, "transport": transport,
                "disclaimer": ("Affected-area geometry is an AEGIS model estimate unless explicitly labelled authoritative. "
                               "Facility locations come from OpenStreetMap and may be incomplete or out of date.")}

    def _transport_context(self, incident: models.Incident, facilities: list[dict]) -> dict:
        """Geometric context for the nearest mapped facilities — no routing claims."""
        items = []
        for f in facilities[:6]:
            b = geo.bearing_deg(incident.lat, incident.lon, f["lat"], f["lon"])
            items.append({
                "facility": f["name"], "class": f["class"], "distance_km": f["distance_km"],
                "direction": geo.compass(b), "osm_url": f["osm_url"],
            })
        return {
            "available": True,
            "straight_line_only": True,
            "items": items,
            "note": ("Straight-line bearing/distance only. AEGIS will not state that a route is safe to travel: "
                     "road status and hazard closure data for this incident are not available."),
        }

    # ------------------------------------------------------------------ #
    def run(self, db: Session, ctx: AgentContext, *, incident_ids: list[str], radius_km: float = 25.0,
            persist: bool = True, include_facilities: bool = True) -> dict[str, Any]:
        incidents = list(db.scalars(select(models.Incident).where(models.Incident.id.in_(incident_ids))))
        reports = []
        with ctx.tool("geo_context", {"incidents": len(incidents), "radius_km": radius_km}) as t:
            for inc in incidents:
                if ctx.timed_out():
                    t["status"] = "timeout"
                    t["error"] = "deadline exceeded during geospatial analysis"
                    break
                reports.append({"incident_id": inc.id, "code": inc.code, **self.context_report(
                    db, inc, ctx, radius_km=radius_km, persist=persist, include_facilities=include_facilities)})
            t["source"] = "openstreetmap"
            t["summary"] = f"geospatial context built for {len(reports)} incident(s)"
        return {"agent": self.name, "reports": reports}


geo_agent = GeoAgent()
