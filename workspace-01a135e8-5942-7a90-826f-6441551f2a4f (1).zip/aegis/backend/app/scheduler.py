"""Background job scheduling (single-process scheduler thread).

Runs in-process so the stack has zero infrastructure dependencies; each job
opens its own DB session and records outcomes, so a failing provider never
takes down the API.  Swap for Celery/RQ/APScheduler in a multi-worker
deployment (the job functions are already self-contained).
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import timedelta
from typing import Any

from sqlalchemy import select

from . import ingest, models
from .config import settings
from .db import session_scope
from .util import now

log = logging.getLogger("aegis.scheduler")

_state: dict[str, Any] = {
    "running": False,
    "started_at": None,
    "last_ingest_at": None,
    "last_ingest_summary": None,
    "last_cycle_ms": None,
    "cycles": 0,
    "errors": [],
    "next_ingest_in_seconds": None,
}
_thread: threading.Thread | None = None
_stop = threading.Event()


def scheduler_state() -> dict:
    st = {k: v for k, v in _state.items() if k != "errors"}
    st["errors"] = _state["errors"][-5:]
    st["enabled"] = settings.scheduler_enabled
    st["interval_minutes"] = settings.ingest_interval_minutes
    return st


def start() -> None:
    global _thread
    if not settings.scheduler_enabled:
        log.info("scheduler disabled by configuration")
        return
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, name="aegis-scheduler", daemon=True)
    _thread.start()
    _state["running"] = True
    _state["started_at"] = now().isoformat() + "Z"
    log.info("scheduler started (interval %s min)", settings.ingest_interval_minutes)


def stop() -> None:
    _stop.set()
    _state["running"] = False


def _loop() -> None:
    # small delay so the API is up before the first fetch
    if _stop.wait(6):
        return
    while not _stop.is_set():
        try:
            run_cycle()
        except Exception as exc:  # noqa: BLE001
            log.exception("scheduler cycle failed")
            _state["errors"].append(f"{now().isoformat()}Z {exc.__class__.__name__}: {exc}")
        interval = max(60, int(settings.ingest_interval_minutes * 60))
        _state["next_ingest_in_seconds"] = interval
        if _stop.wait(interval):
            break


def run_cycle() -> dict:
    """One ingestion + processing cycle."""
    t0 = time.perf_counter()
    _state["cycles"] += 1
    summary: dict[str, Any] = {}
    with session_scope() as db:
        summary["ingest"] = ingest.run_all(db, process=True)

        # refresh detection/classification on recent observations that arrived from other paths
        from .agents.base import AgentContext
        from .agents.classification_agent import classification_agent
        from .agents.detection_agent import detection_agent
        from .agents.geo_agent import geo_agent
        from .agents.risk_agent import risk_agent

        ctx = AgentContext(db=db, agent_name="scheduler_deep_pass",
                           deadline=time.perf_counter() + 90)
        det = detection_agent.run(db, ctx, hours=12)
        summary["detection_pass"] = {"new": det.get("incidents_created_codes", []),
                                     "linked": det.get("observations_linked")}

        # classify anything ambiguous or unclassified (bounded)
        backlog = list(db.scalars(
            select(models.Incident).where(models.Incident.status.in_(("active", "monitoring")),
                                          models.Incident.classification_agent == "")
            .order_by(models.Incident.last_update_at.desc()).limit(8)))
        classified = []
        for inc in backlog:
            res = classification_agent.apply(db, inc, ctx)
            classified.append({"code": inc.code, "category": res["category"], "ambiguous": res["ambiguous"]})
        summary["classified"] = classified

        # geography + risk refresh for active incidents, oldest assessment first (bounded)
        active = list(db.scalars(select(models.Incident)
                                 .where(models.Incident.status == "active")
                                 .order_by(models.Incident.last_update_at.desc()).limit(10)))
        refreshed = []
        for inc in active:
            if ctx.timed_out():
                summary["deadline_hit"] = True
                break
            last_risk = db.scalar(select(models.RiskAssessment)
                                  .where(models.RiskAssessment.incident_id == inc.id)
                                  .order_by(models.RiskAssessment.created_at.desc()))
            if last_risk and (now() - last_risk.created_at) < timedelta(minutes=45):
                continue
            geo = geo_agent.context_report(db, inc, ctx, radius_km=25.0, include_facilities=False)
            risk = risk_agent.assess(db, inc, ctx, area=geo["area"], facilities=geo["facilities"])
            refreshed.append({"code": inc.code, "risk_score": risk["risk_score"], "level": risk["risk_level"]})
        summary["risk_refresh"] = refreshed

        # demonstration dataset only when there is nothing live to show
        from . import demo_data

        seeded = demo_data.seed_demo(db)
        if seeded.get("seeded"):
            summary["demo_seeded"] = seeded["incidents"]
            ingest.ensure_sources(db)

    _state["last_ingest_at"] = now().isoformat() + "Z"
    _state["last_ingest_summary"] = summary
    _state["last_cycle_ms"] = int((time.perf_counter() - t0) * 1000)
    log.info("cycle %s complete in %sms", _state["cycles"], _state["last_cycle_ms"])
    return summary
