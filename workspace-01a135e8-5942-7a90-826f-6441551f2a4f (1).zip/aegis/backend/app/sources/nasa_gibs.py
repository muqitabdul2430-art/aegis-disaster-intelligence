"""NASA GIBS imagery capability probe (WMTS).

GIBS serves NASA satellite imagery tiles without credentials.  AEGIS uses it
as a *visual context* layer (VIIRS true-colour, flood/fire products) on the
map.  This module only probes availability and exposes the documented tile
templates; AEGIS does not auto-detect hazards from imagery.
"""
from __future__ import annotations

import re

from .base import RawSignal  # noqa: F401  (kept for API symmetry)
from .http import SourceFetch, request_text

WMTS_CAPABILITIES = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/1.0.0/WMTSCapabilities.xml"
TILE_TEMPLATE = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/{layer}/default/{time}/GoogleMapsCompatible_Level9/{{z}}/{{y}}/{{x}}.jpg"

# Documented, stable GIBS layers used by AEGIS overlays.
LAYERS = {
    "viirs_true_color": {
        "layer": "VIIRS_SNPP_CorrectedReflectance_TrueColor",
        "label": "VIIRS true colour (daily imagery)",
        "time_mode": "date",
        "attribution": "NASA EOSDIS GIBS",
        "note": "Visual context only — cloud cover and swath gaps are normal.",
    },
    "modis_true_color": {
        "layer": "MODIS_Terra_CorrectedReflectance_TrueColor",
        "label": "MODIS Terra true colour (daily imagery)",
        "time_mode": "date",
        "attribution": "NASA EOSDIS GIBS",
        "note": "Visual context only.",
    },
    "imerg_precipitation": {
        "layer": "IMERG_Precipitation_Rate_30min",
        "label": "IMERG precipitation rate (30 min)",
        "time_mode": "datetime30",
        "attribution": "NASA GPM / GIBS",
        "note": "Model/satellite merged precipitation estimate, 30-minute cadence.",
    },
    "fires_thermal": {
        "layer": "VIIRS_Combined_Thermal_Anomalies_375m_All",
        "label": "VIIRS thermal anomalies (fire detections)",
        "time_mode": "date",
        "attribution": "NASA FIRMS / GIBS",
        "note": "Thermal anomalies from VIIRS — cross-check with FIRMS attribute data.",
    },
    "flood_surface_water": {
        "layer": "MODIS_Combined_Flood_2-Day",
        "label": "MODIS 2-day flood / surface water",
        "time_mode": "date",
        "attribution": "NASA LANCE / GIBS",
        "note": "Observation-based surface water extent where available.",
    },
}


def probe() -> SourceFetch:
    result = request_text(WMTS_CAPABILITIES)
    if result.ok and isinstance(result.data, str):
        result.records = len(re.findall(r"<Layer>", result.data))
    return result


def available_layers() -> list[dict]:
    return [{"key": k, **v, "tile_template": TILE_TEMPLATE.format(layer=v["layer"], time="{time}")}
            for k, v in LAYERS.items()]
