"""USGS FDSN Event API — global earthquake catalogue (public domain).

Docs: https://earthquake.usgs.gov/fdsnws/event/1/
Rate limits: none documented for reasonable use; the service asks heavy users
to use the "comcat" bulk products instead.  We poll at most every few minutes
for a small, bounded window (M>=4.0, last 24h by default).
"""
from __future__ import annotations

from datetime import timedelta

from ..util import now
from .base import RawSignal
from .http import SourceFetch, request_json

API = "https://earthquake.usgs.gov/fdsnws/event/1/query"

# USGS `status` → source confidence (this is instrument/processing confidence,
# NOT a probability of impact).
_STATUS_CONFIDENCE = {"reviewed": 92.0, "automatic": 68.0, "deleted": 10.0}


def fetch(min_magnitude: float = 4.0, hours: int = 24, limit: int = 400) -> SourceFetch:
    start = now() - timedelta(hours=hours)
    params = {
        "format": "geojson",
        "starttime": start.strftime("%Y-%m-%dT%H:%M:%S"),
        "minmagnitude": min_magnitude,
        "orderby": "time",
        "limit": limit,
    }
    return request_json(API, params=params)


def parse(fetch_result: SourceFetch) -> list[RawSignal]:
    if not fetch_result.ok or not isinstance(fetch_result.data, dict):
        return []
    out: list[RawSignal] = []
    for f in fetch_result.data.get("features", []):
        props = f.get("properties") or {}
        geom = f.get("geometry") or {}
        coords = geom.get("coordinates") or []
        if len(coords) < 2 or props.get("mag") is None:
            continue
        eid = f.get("id") or props.get("code") or ""
        tsunami_flag = int(props.get("tsunami") or 0)
        out.append(
            RawSignal(
                source_key="usgs_earthquake",
                external_id=eid,
                hazard_hint="earthquake",
                lat=float(coords[1]),
                lon=float(coords[0]),
                observed_at=props.get("time"),
                place=props.get("place") or "",
                magnitude=float(props.get("mag")),
                magnitude_unit="M" + str(props.get("magType") or ""),
                source_url=props.get("url") or f"https://earthquake.usgs.gov/earthquakes/eventpage/{eid}",
                confidence=_STATUS_CONFIDENCE.get(str(props.get("status")), 60.0),
                payload={
                    "status": props.get("status"),
                    "tsunami_flag": tsunami_flag,
                    "depth_km": coords[2] if len(coords) > 2 else None,
                    "felt_reports": props.get("felt"),
                    "mmi": props.get("mmi"),
                    "cdi": props.get("cdi"),
                    "alert": props.get("alert"),
                    "sig": props.get("sig"),
                    "net": props.get("net"),
                    "nst": props.get("nst"),
                    "gap": props.get("gap"),
                    "dmin": props.get("dmin"),
                    "rms": props.get("rms"),
                    "types": props.get("types"),
                    "updated": props.get("updated"),
                    "title": props.get("title"),
                },
            ).normalized()
        )
    return out
