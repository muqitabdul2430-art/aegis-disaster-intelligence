"""NOAA National Hurricane Center — active storms (public domain).

Source: https://www.nhc.noaa.gov/CurrentStorms.json  (documented, keyless)
This is the OFFICIAL US tropical cyclone feed for the Atlantic and
East/Central Pacific basins.  AEGIS ingests position/intensity/movement and
the advisory URLs; forecast tracks remain NHC products and are always
attributed to NHC.
"""
from __future__ import annotations

from .base import RawSignal
from .http import SourceFetch, request_json

API = "https://www.nhc.noaa.gov/CurrentStorms.json"

_CLASSIFICATION = {
    "TD": "Tropical Depression",
    "TS": "Tropical Storm",
    "HU": "Hurricane",
    "MH": "Major Hurricane",
    "TY": "Typhoon",
    "STD": "Subtropical Depression",
    "STS": "Subtropical Storm",
    "PT": "Post-Tropical Cyclone",
    "PTC": "Potential Tropical Cyclone",
    "DB": "Disturbance",
    "LO": "Low",
    "WV": "Wave",
}

# Advisory-grade official product → high source confidence.
_CONFIDENCE = {"HU": 95.0, "MH": 95.0, "TY": 95.0, "TS": 92.0, "TD": 92.0}


def fetch() -> SourceFetch:
    return request_json(API)


def parse(fetch_result: SourceFetch) -> list[RawSignal]:
    if not fetch_result.ok or not isinstance(fetch_result.data, dict):
        return []
    out: list[RawSignal] = []
    for s in fetch_result.data.get("activeStorms", []) or []:
        lat, lon = s.get("latitudeNumeric"), s.get("longitudeNumeric")
        if lat is None or lon is None:
            continue
        cls = s.get("classification") or ""
        advisory = (s.get("publicAdvisory") or {}).get("url")
        intensity = s.get("intensity")
        try:
            intensity_kt = float(intensity) if intensity is not None else None
        except (TypeError, ValueError):
            intensity_kt = None
        out.append(
            RawSignal(
                source_key="nhc",
                external_id=s.get("id") or s.get("binNumber") or "",
                hazard_hint="cyclone",
                lat=float(lat),
                lon=float(lon),
                observed_at=s.get("lastUpdate"),
                place=f"{_CLASSIFICATION.get(cls, cls)} {s.get('name', '')}".strip(),
                country="",
                magnitude=intensity_kt,
                magnitude_unit="kt (max sustained wind, official NHC)",
                source_url=advisory or "https://www.nhc.noaa.gov/",
                confidence=_CONFIDENCE.get(cls, 80.0),
                payload={
                    "classification": cls,
                    "classification_text": _CLASSIFICATION.get(cls, cls),
                    "intensity_kt": intensity_kt,
                    "intensity_kmh": round(intensity_kt * 1.852, 1) if intensity_kt else None,
                    "pressure_mb": s.get("pressure"),
                    "movement_dir_deg": s.get("movementDir"),
                    "movement_speed_kt": s.get("movementSpeed"),
                    "basin": s.get("binNumber"),
                    "public_advisory": s.get("publicAdvisory"),
                    "forecast_advisory": s.get("forecastAdvisory"),
                    "forecast_track": s.get("forecastTrack"),
                    "forecast_discussion": s.get("forecastDiscussion"),
                    "official": True,
                    "authority": "NOAA National Hurricane Center",
                },
            ).normalized()
        )
    return out
