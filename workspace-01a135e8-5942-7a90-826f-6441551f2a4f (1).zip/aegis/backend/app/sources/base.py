"""Base types + the authoritative source catalogue.

The catalogue documents, per provider: what it is used for, licence/terms,
whether credentials are needed and how it is used by AEGIS.  It is seeded
into the `data_sources` table and drives the Data Sources screen, so the
platform is always explicit about what is live, what needs a key and what is
disabled.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..util import fingerprint, parse_dt


@dataclass
class RawSignal:
    """One normalised observation from an external provider."""

    source_key: str
    external_id: str
    hazard_hint: str            # earthquake|tsunami|cyclone|flood|wildfire|landslide|industrial_fire|drought|volcano|unknown
    lat: float
    lon: float
    observed_at: Any            # ISO string / datetime / epoch
    place: str = ""
    country: str = ""
    magnitude: float | None = None
    magnitude_unit: str = ""
    source_url: str = ""
    confidence: float | None = None
    payload: dict = field(default_factory=dict)
    data_origin: str = "live"
    incident_group: str = ""    # provider-series id used to merge episodes into one incident

    def normalized(self) -> "RawSignal":
        self.observed_at = parse_dt(self.observed_at)
        self.lat = float(self.lat)
        self.lon = float(self.lon)
        return self

    @property
    def fingerprint(self) -> str:
        return fingerprint(self.source_key, self.external_id or f"{self.lat:.4f},{self.lon:.4f}",
                           self.observed_at, self.hazard_hint)


@dataclass
class SourceSpec:
    key: str
    name: str
    provider: str
    homepage: str
    docs_url: str
    license: str
    categories: list[str]
    auth_mode: str            # none|api_key|token|registration|disabled
    credential_env: str = ""
    reliability_note: str = ""
    role: str = "signals"     # signals|enrichment|basemap|facilities|notifications
    connector: str = ""       # module name implementing fetch(), "" = catalogue only


SOURCE_CATALOG: list[SourceSpec] = [
    SourceSpec(
        key="usgs_earthquake",
        name="USGS Earthquake Catalog (FDSN Event API)",
        provider="United States Geological Survey",
        homepage="https://earthquake.usgs.gov/",
        docs_url="https://earthquake.usgs.gov/fdsnws/event/1/",
        license="US Government work — public domain",
        categories=["earthquake", "tsunami"],
        auth_mode="none",
        reliability_note="Authoritative global seismic catalogue. AEGIS polls the last 24h of M>=4.0 events every few minutes; "
                         "USGS 'reviewed' vs 'automatic' status is preserved and shown as confidence.",
        role="signals",
        connector="usgs_earthquake",
    ),
    SourceSpec(
        key="gdacs",
        name="GDACS Multi-Hazard Alerts (JRC)",
        provider="European Commission JRC / UN OCHA",
        homepage="https://www.gdacs.org/",
        docs_url="https://www.gdacs.org/Documents/2023/GDACS_API.pdf",
        license="JRC terms — free for non-commercial use, attribution required",
        categories=["earthquake", "cyclone", "flood", "wildfire", "tsunami", "volcano"],
        auth_mode="none",
        reliability_note="Near-real-time multi-hazard alert feed with official alert levels (Green/Orange/Red) and "
                         "authoritative impact estimates (affected population) where computed.",
        role="signals",
        connector="gdacs",
    ),
    SourceSpec(
        key="nhc",
        name="NOAA National Hurricane Center — CurrentStorms + advisories",
        provider="NOAA / NWS National Hurricane Center",
        homepage="https://www.nhc.noaa.gov/gis/",
        docs_url="https://www.nhc.noaa.gov/",
        license="US Government work — public domain",
        categories=["cyclone", "flood"],
        auth_mode="none",
        reliability_note="Official tropical-cyclone advisories for the Atlantic and East/Central Pacific basins. "
                         "Position/intensity are official NHC values; forecast tracks are NHC forecasts, not AEGIS output.",
        role="signals",
        connector="nhc",
    ),
    SourceSpec(
        key="noaa_tsunami",
        name="NOAA Tsunami Warning Centers (NTWC/PTWC) message feed",
        provider="NOAA / NWS",
        homepage="https://www.tsunami.gov/",
        docs_url="https://www.tsunami.gov/?page=producttypes",
        license="US Government work — public domain",
        categories=["tsunami", "earthquake"],
        auth_mode="none",
        reliability_note="Official tsunami bulletins/statements (Atom). AEGIS ingests the message and its authority; "
                         "it never upgrades or downgrades a bulletin.",
        role="signals",
        connector="noaa_tsunami",
    ),
    SourceSpec(
        key="nasa_firms",
        name="NASA FIRMS / VIIRS + MODIS active fire detections",
        provider="NASA LANCE / EOSDIS",
        homepage="https://firms.modaps.eosdis.nasa.gov/",
        docs_url="https://firms.modaps.eosdis.nasa.gov/api/area/",
        license="NASA open data",
        categories=["wildfire", "industrial_fire"],
        auth_mode="api_key",
        credential_env="AEGIS_FIRMS_MAP_KEY",
        reliability_note="Satellite thermal-anomaly detections. Each detection is a hotspot pixel with confidence; AEGIS "
                         "clusters them, but a single detection is NOT a confirmed wildfire. Requires a free MAP_KEY "
                         "(self-service, instant).",
        role="signals",
        connector="nasa_firms",
    ),
    SourceSpec(
        key="open_meteo",
        name="Open-Meteo forecast + historical weather",
        provider="Open-Meteo (aggregating ECMWF/ICON/GFS/CMA + national models)",
        homepage="https://open-meteo.com/",
        docs_url="https://open-meteo.com/en/docs",
        license="CC-BY 4.0 (non-commercial API tier, free of key)",
        categories=["flood", "cyclone", "landslide", "wildfire"],
        auth_mode="none",
        reliability_note="Model forecast fields (precipitation, wind, soil moisture, temperature) used as hazard drivers. "
                         "Values are MODEL OUTPUT, not measurements — the UI labels them accordingly.",
        role="enrichment",
        connector="open_meteo",
    ),
    SourceSpec(
        key="nasa_gibs",
        name="NASA GIBS / Worldview imagery tiles (WMTS)",
        provider="NASA EOSDIS",
        homepage="https://www.earthdata.nasa.gov/engage/open-data-services-software/earthdata-developer-portal/gibs-api",
        docs_url="https://nasa-gibs.github.io/gibs-api-docs/",
        license="NASA open data",
        categories=["wildfire", "flood", "cyclone"],
        auth_mode="none",
        reliability_note="Satellite imagery layers (VIIRS true colour, flood/fire products) rendered as map overlays. "
                         "Imagery is visual context — AEGIS does not auto-detect hazards from it.",
        role="basemap",
        connector="nasa_gibs",
    ),
    SourceSpec(
        key="openstreetmap",
        name="OpenStreetMap / Overpass API (facilities) + Nominatim (geocoding)",
        provider="OpenStreetMap Foundation contributors",
        homepage="https://www.openstreetmap.org/",
        docs_url="https://wiki.openstreetmap.org/wiki/Overpass_API",
        license="ODbL 1.0 — attribution required",
        categories=["all"],
        auth_mode="none",
        reliability_note="Hospitals, shelters, fire/police stations and road context near incidents. Community-mapped data: "
                         "completeness varies by region and it is not a guarantee of operational availability.",
        role="facilities",
        connector="overpass",
    ),
    SourceSpec(
        key="isro_mosdac",
        name="ISRO MOSDAC (Bhuvan / MOSDAC products)",
        provider="Indian Space Research Organisation",
        homepage="https://www.isro.gov.in/MOSDAC-IN_web_portal.html",
        docs_url="https://www.mosdac.gov.in/",
        license="ISRO terms — registration required",
        categories=["cyclone", "flood", "landslide", "earthquake"],
        auth_mode="registration",
        credential_env="AEGIS_MOSDAC_TOKEN",
        reliability_note="India-specific satellite products (INSAT/SCATSAT/Oceansat, rainfall, cyclone tracks). MOSDAC "
                         "requires an account; AEGIS ships the connector and will activate it when a token is provided. "
                         "Until then this source reports 'no_credentials' rather than guessing data.",
        role="signals",
        connector="",  # catalogue + guarded stub
    ),
    SourceSpec(
        key="copernicus_ems",
        name="Copernicus Emergency Management Service (rapid mapping)",
        provider="European Commission / Copernicus",
        homepage="https://emergency.copernicus.eu/",
        docs_url="https://emergency.copernicus.eu/mapping/activations-rapid",
        license="Copernicus data policy — free, attribution required",
        categories=["flood", "wildfire", "landslide", "earthquake"],
        auth_mode="registration",
        credential_env="AEGIS_CDSE_CLIENT_ID",
        reliability_note="Authoritative activation products where authorities have requested mapping. The full API needs "
                         "Copernicus Data Space credentials; without them AEGIS shows the official activation portal link.",
        role="signals",
        connector="",  # catalogue only
    ),
    SourceSpec(
        key="imd_cyclone",
        name="India Meteorological Department — RSMC tropical cyclone advisories",
        provider="IMD, Ministry of Earth Sciences (Govt. of India)",
        homepage="https://mausam.imd.gov.in/",
        docs_url="https://rsmcnewdelhi.imd.gov.in/",
        license="Government of India — public information",
        categories=["cyclone", "flood"],
        auth_mode="none",
        reliability_note="IMD is the RSMC for the North Indian Ocean. There is no stable public JSON API, so AEGIS links "
                         "official bulletins and cross-checks GDACS; it does not scrape or republish bulletin text.",
        role="signals",
        connector="",
    ),
    SourceSpec(
        key="incois_tsunami",
        name="INCOIS Indian Tsunami Early Warning Centre",
        provider="INCOIS, Ministry of Earth Sciences (Govt. of India)",
        homepage="https://tsunami.incois.gov.in/",
        docs_url="https://www.incois.gov.in/",
        license="Government of India — public information",
        categories=["tsunami"],
        auth_mode="none",
        reliability_note="Official tsunami bulletins for the Indian Ocean. Provided as an authoritative link/contact; "
                         "AEGIS does not machine-ingest this feed (no documented public API).",
        role="signals",
        connector="",
    ),
    SourceSpec(
        key="ndma_sachet",
        name="NDMA SACHET / Alert Hub (India)",
        provider="National Disaster Management Authority, India",
        homepage="https://sachet.ndma.gov.in/",
        docs_url="https://ndma.gov.in/",
        license="Government of India — public information",
        categories=["all"],
        auth_mode="none",
        reliability_note="India's national alert aggregation service. Used for official-capability context and links; "
                         "no public write/read API for third parties.",
        role="signals",
        connector="",
    ),
]


SOURCE_BY_KEY = {s.key: s for s in SOURCE_CATALOG}

# Capability levels used across the UI: what works out of the box vs needs setup
LIVE_NOW = {"usgs_earthquake", "gdacs", "nhc", "noaa_tsunami", "open_meteo", "openstreetmap", "nasa_gibs"}
NEEDS_CREDENTIALS = {"nasa_firms"}
LINK_ONLY = {"isro_mosdac", "copernicus_ems", "imd_cyclone", "incois_tsunami", "ndma_sachet"}
