"""GDACS multi-hazard alert feed (European Commission JRC).

Docs: https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH
Public, keyless, documented.  GDACS alert levels (Green/Orange/Red) and
GDACS impact estimates are authoritative third-party products: AEGIS stores
them as *secondary* evidence and never upgrades them.
"""
from __future__ import annotations

from datetime import timedelta

from ..util import now
from .base import RawSignal
from .http import SourceFetch, request_json

API = "https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH"

# GDACS eventtype → AEGIS hazard
_TYPE_MAP = {
    "EQ": "earthquake",
    "TC": "cyclone",
    "FL": "flood",
    "WF": "wildfire",
    "VO": "volcano",
    "DR": "drought",
    "TS": "tsunami",
}

_ALERT_TO_SEVERITY = {"Green": 1, "Orange": 3, "Red": 5}
_ALERT_CONFIDENCE = {"Green": 82.0, "Orange": 88.0, "Red": 92.0}


def fetch(days: int = 3) -> SourceFetch:
    to_date = now().date()
    from_date = to_date - timedelta(days=days)
    params = {"eventlist": "", "fromDate": from_date.isoformat(), "toDate": to_date.isoformat()}
    return request_json(API, params=params)


def parse(fetch_result: SourceFetch) -> list[RawSignal]:
    if not fetch_result.ok:
        return []
    payload = fetch_result.data
    features = payload if isinstance(payload, list) else (payload or {}).get("features", [])
    out: list[RawSignal] = []
    for f in features or []:
        props = f.get("properties") or {}
        geom = f.get("geometry") or {}
        coords = geom.get("coordinates") or []
        etype = props.get("eventtype") or ""
        hazards = _TYPE_MAP.get(etype, "unknown")
        if len(coords) < 2:
            continue
        sev = props.get("severitydata") or {}
        urls = props.get("url") or {}
        alert = props.get("alertlevel") or "Green"
        out.append(
            RawSignal(
                source_key="gdacs",
                external_id=f"{etype}-{props.get('eventid')}-{props.get('episodeid')}",
                hazard_hint=hazards,
                lat=float(coords[1]),
                lon=float(coords[0]),
                observed_at=props.get("todate") or props.get("fromdate"),
                place=props.get("name") or props.get("description") or "",
                country=props.get("country") or "",
                magnitude=sev.get("severity"),
                magnitude_unit=sev.get("severityunit") or "",
                source_url=urls.get("report") or urls.get("details") or "https://www.gdacs.org/",
                confidence=_ALERT_CONFIDENCE.get(alert, 70.0),
                payload={
                    "alert_level": alert,
                    "alert_score": props.get("alertscore"),
                    "episode_alert_level": props.get("episodealertlevel"),
                    "is_current": props.get("iscurrent"),
                    "from_date": props.get("fromdate"),
                    "to_date": props.get("todate"),
                    "datemodified": props.get("datemodified"),
                    "glide": props.get("glide"),
                    "source": props.get("source"),
                    "eventtype": etype,
                    "eventid": props.get("eventid"),
                    "episodeid": props.get("episodeid"),
                    "severity": sev,
                    "affected_countries": props.get("affectedcountries") or [],
                    "details_url": urls.get("details"),
                    "geometry_url": urls.get("geometry"),
                    "gdacs_severity_class": _ALERT_TO_SEVERITY.get(alert, 1),
                },
            ).normalized()
        )
    return out
