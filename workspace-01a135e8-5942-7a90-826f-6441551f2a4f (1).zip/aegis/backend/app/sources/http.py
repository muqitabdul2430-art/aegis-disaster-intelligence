"""Resilient HTTP client used by every data-source connector.

*   Timeouts, bounded retries with exponential backoff + jitter.
*   Per-host politeness delay (protects public APIs such as OpenStreetMap).
*   Caching of READ-ONLY GETs (short TTL) to avoid hammering providers.
*   Structured `SourceFetch` result so connectors can report honest
    unavailable / error / stale states instead of inventing data.
"""
from __future__ import annotations

import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from ..config import settings

log = logging.getLogger("aegis.http")

_HOST_LAST_CALL: dict[str, float] = {}
MIN_HOST_INTERVAL = {"nominatim.openstreetmap.org": 1.1, "overpass-api.de": 1.5, "overpass.kumi.systems": 1.5}


@dataclass
class SourceFetch:
    ok: bool
    status_code: int | None = None
    data: Any = None
    error: str | None = None
    error_kind: str | None = None  # network|timeout|http|parse|credentials|disabled
    latency_ms: int | None = None
    url: str = ""
    records: int = 0
    fetched_at: float = field(default_factory=time.time)

    @property
    def unavailable(self) -> bool:
        return not self.ok


def _throttle(host: str) -> None:
    interval = MIN_HOST_INTERVAL.get(host)
    if not interval:
        return
    last = _HOST_LAST_CALL.get(host)
    if last is not None:
        wait = interval - (time.time() - last)
        if wait > 0:
            time.sleep(wait)
    _HOST_LAST_CALL[host] = time.time()


def request_json(
    url: str,
    *,
    params: dict | None = None,
    headers: dict | None = None,
    timeout: float | None = None,
    retries: int | None = None,
    method: str = "GET",
    data: dict | None = None,
) -> SourceFetch:
    if not settings.enable_live_network:
        return SourceFetch(ok=False, error="live network access disabled by configuration",
                           error_kind="disabled", url=url)

    timeout = timeout or settings.http_timeout_seconds
    retries = settings.http_retries if retries is None else retries
    hdrs = {"User-Agent": settings.http_user_agent, "Accept": "application/json"}
    if headers:
        hdrs.update(headers)
    host = httpx.URL(url).host or ""
    last_err: str | None = None
    last_kind = "network"
    started = time.perf_counter()
    for attempt in range(retries + 1):
        _throttle(host)
        try:
            t0 = time.perf_counter()
            with httpx.Client(timeout=timeout, follow_redirects=True) as client:
                resp = client.request(method, url, params=params, headers=hdrs, data=data)
            latency = int((time.perf_counter() - t0) * 1000)
            if resp.status_code >= 400:
                snippet = resp.text[:220].replace("\n", " ")
                if resp.status_code in (401, 403):
                    return SourceFetch(ok=False, status_code=resp.status_code, error_kind="credentials",
                                       error=f"HTTP {resp.status_code} (credentials required/rejected): {snippet}",
                                       latency_ms=latency, url=url)
                if resp.status_code == 429:
                    last_err = f"HTTP 429 rate limited: {snippet}"
                    last_kind = "rate_limit"
                else:
                    last_err = f"HTTP {resp.status_code}: {snippet}"
                    last_kind = "http"
                if attempt < retries:
                    time.sleep((0.6 * (2 ** attempt)) + random.random() * 0.4)
                    continue
                return SourceFetch(ok=False, status_code=resp.status_code, error=last_err,
                                   error_kind=last_kind, latency_ms=latency, url=url)
            try:
                payload = resp.json()
            except Exception as exc:  # noqa: BLE001
                return SourceFetch(ok=False, status_code=resp.status_code, error=f"invalid JSON: {exc}",
                                   error_kind="parse", latency_ms=latency, url=url)
            records = 0
            if isinstance(payload, dict):
                for k in ("features", "results", "items", "data", "activeStorms", "alerts"):
                    v = payload.get(k)
                    if isinstance(v, list):
                        records = len(v)
                        break
                else:
                    records = len(payload.get("events", [])) if isinstance(payload.get("events"), list) else 1
            elif isinstance(payload, list):
                records = len(payload)
            return SourceFetch(ok=True, status_code=resp.status_code, data=payload, latency_ms=latency,
                               url=str(resp.url), records=records)
        except httpx.TimeoutException:
            last_err, last_kind = f"timeout after {timeout}s", "timeout"
        except httpx.HTTPError as exc:
            last_err, last_kind = f"network error: {exc.__class__.__name__}: {exc}", "network"
        except Exception as exc:  # noqa: BLE001
            last_err, last_kind = f"unexpected error: {exc}", "network"
        if attempt < retries:
            time.sleep((0.6 * (2 ** attempt)) + random.random() * 0.4)
    return SourceFetch(ok=False, error=last_err, error_kind=last_kind,
                       latency_ms=int((time.perf_counter() - started) * 1000), url=url)


def request_text(url: str, *, headers: dict | None = None, timeout: float | None = None,
                 retries: int = 1) -> SourceFetch:
    if not settings.enable_live_network:
        return SourceFetch(ok=False, error="live network access disabled", error_kind="disabled", url=url)
    hdrs = {"User-Agent": settings.http_user_agent, "Accept": "application/xml,text/xml,*/*"}
    if headers:
        hdrs.update(headers)
    host = httpx.URL(url).host or ""
    last_err, last_kind = None, "network"
    for attempt in range(retries + 1):
        _throttle(host)
        try:
            t0 = time.perf_counter()
            with httpx.Client(timeout=timeout or settings.http_timeout_seconds, follow_redirects=True) as client:
                resp = client.get(url, headers=hdrs)
            latency = int((time.perf_counter() - t0) * 1000)
            if resp.status_code >= 400:
                return SourceFetch(ok=False, status_code=resp.status_code, error=f"HTTP {resp.status_code}",
                                   error_kind="http", latency_ms=latency, url=url)
            return SourceFetch(ok=True, status_code=resp.status_code, data=resp.text, latency_ms=latency,
                               url=str(resp.url))
        except httpx.TimeoutException:
            last_err, last_kind = "timeout", "timeout"
        except Exception as exc:  # noqa: BLE001
            last_err, last_kind = f"network error: {exc}", "network"
        if attempt < retries:
            time.sleep(0.8 * (attempt + 1))
    return SourceFetch(ok=False, error=last_err, error_kind=last_kind, url=url)
