"""NASA FIRMS active fire detections (VIIRS/MODIS) — requires a free MAP_KEY.

Docs: https://firms.modaps.eosdis.nasa.gov/api/area/
Get a key (instant, free) at: https://firms.modaps.eosdis.nasa.gov/api/map_key/

Without a key this connector returns `no_credentials` and the UI shows the
setup instructions — AEGIS never fabricates fire detections.
"""
from __future__ import annotations

import csv
import io

from ..config import settings
from ..util import now
from .base import RawSignal
from .http import SourceFetch, request_text

AREA_API = "https://firms.modaps.eosdis.nasa.gov/api/area/csv"
# Area API source identifiers (documented). VIIRS SNPP NRT is the workhorse.
DEFAULT_SOURCE = "VIIRS_SNPP_NRT"

# FIRMS confidence (l/n/h for VIIRS, 0-100 for MODIS) → numeric source confidence
_VIIRS_CONF = {"l": 40.0, "n": 70.0, "h": 90.0}


def configured() -> bool:
    return bool(settings.firms_map_key.strip())


def fetch(bbox: str = "-180,-90,180,90", day_range: int = 1, source: str = DEFAULT_SOURCE) -> SourceFetch:
    if not configured():
        return SourceFetch(
            ok=False,
            error_kind="credentials",
            error="NASA FIRMS MAP_KEY not configured (set AEGIS_FIRMS_MAP_KEY). "
                  "Free instant key: https://firms.modaps.eosdis.nasa.gov/api/map_key/",
            url="https://firms.modaps.eosdis.nasa.gov/api/area/",
        )
    url = f"{AREA_API}/{settings.firms_map_key.strip()}/{source}/{bbox}/{day_range}"
    result = request_text(url)
    if result.ok and isinstance(result.data, str):
        rows = result.data.strip().splitlines()
        result.records = max(0, len(rows) - 1) if rows and not rows[0].lower().startswith("<!") else 0
        if result.records == 0 and rows and "invalid" in rows[0].lower():
            return SourceFetch(ok=False, error_kind="credentials", error=f"FIRMS rejected the request: {rows[0][:200]}",
                               url=url)
    return result


def parse(fetch_result: SourceFetch, source: str = DEFAULT_SOURCE) -> list[RawSignal]:
    if not fetch_result.ok or not isinstance(fetch_result.data, str):
        return []
    text = fetch_result.data.strip()
    if not text or text.lower().startswith("<"):
        return []
    reader = csv.DictReader(io.StringIO(text))
    out: list[RawSignal] = []
    for row in reader:
        try:
            lat = float(row.get("latitude") or 0)
            lon = float(row.get("longitude") or 0)
        except (TypeError, ValueError):
            continue
        if lat == 0 and lon == 0:
            continue
        conf_raw = str(row.get("confidence") or "").strip().lower()
        if conf_raw in _VIIRS_CONF:
            conf = _VIIRS_CONF[conf_raw]
            conf_label = {"l": "low", "n": "nominal", "h": "high"}[conf_raw]
        else:
            try:
                conf = float(conf_raw)
                conf_label = f"{conf:.0f}/100"
            except ValueError:
                conf = 60.0
                conf_label = "unknown"
        date, time = row.get("acq_date", ""), row.get("acq_time", "")
        observed = None
        if date:
            t = (time or "0000").zfill(4)
            observed = f"{date}T{t[:2]}:{t[2:]}:00Z"
        out.append(
            RawSignal(
                source_key="nasa_firms",
                external_id=f"{source}-{row.get('latitude')}-{row.get('longitude')}-{date}-{time}",
                hazard_hint="wildfire",
                lat=lat,
                lon=lon,
                observed_at=observed,
                place="",
                magnitude=row.get("frp") and float(row.get("frp") or 0) or None,
                magnitude_unit="FRP MW",
                source_url="https://firms.modaps.eosdis.nasa.gov/map/",
                confidence=conf,
                payload={
                    "instrument": source,
                    "brightness_k": row.get("bright_ti4") or row.get("brightness"),
                    "frp_mw": row.get("frp"),
                    "confidence_label": conf_label,
                    "daynight": row.get("daynight"),
                    "satellite": row.get("satellite"),
                    "scan": row.get("scan"),
                    "track": row.get("track"),
                    "version": row.get("version"),
                },
            ).normalized()
        )
    return out


def sample_rows() -> list[dict]:  # used by tests only
    return [
        {"latitude": "17.42", "longitude": "78.51", "bright_ti4": "341.2", "scan": "0.4", "track": "0.4",
         "acq_date": now().date().isoformat(), "acq_time": "0720", "satellite": "N20", "instrument": "VIIRS",
         "confidence": "n", "version": "2.0NRT", "bright_ti5": "290.1", "frp": "12.4", "daynight": "D"},
    ]
