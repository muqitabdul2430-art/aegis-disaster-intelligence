"""NOAA Tsunami Warning Center bulletins (NTWC/PTWC) — public domain.

The public Atom feeds at https://www.tsunami.gov/events/xml/*.xml carry the
latest bulletin per centre (title, category, magnitude, epicentre, issue
time).  AEGIS ingests the feed as AN OFFICIAL PRODUCT: the issuing centre is
stored as the authority and the message category (Warning / Advisory / Watch /
Information) is never altered.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET

from ..util import parse_dt
from .base import RawSignal
from .http import SourceFetch, request_text

FEEDS = {
    "PAAQ": ("https://www.tsunami.gov/events/xml/PAAQAtom.xml", "NWS National Tsunami Warning Center (Palmer, AK)"),
    "PTWC": ("https://www.tsunami.gov/events/xml/PTWCAtom.xml", "NWS Pacific Tsunami Warning Center (Honolulu, HI)"),
}

ATOM = "{http://www.w3.org/2005/Atom}"
GEO = "{http://www.w3.org/2003/01/geo/wgs84_pos#}"

_CATEGORY_CONFIDENCE = {"warning": 98.0, "advisory": 96.0, "watch": 94.0, "information": 90.0}

_DETAIL_RES = {
    "magnitude": re.compile(r"Preliminary Magnitude:\s*<\/strong>\s*([0-9.]+)"),
    "category": re.compile(r"Category:<\/strong>\s*([A-Za-z ]+)"),
    "region": re.compile(r"Affected Region:\s*<\/strong>\s*([^<]+)"),
}


def fetch(centre: str = "PAAQ") -> SourceFetch:
    url, _ = FEEDS.get(centre, FEEDS["PAAQ"])
    result = request_text(url)
    if result.ok and isinstance(result.data, str):
        result.records = 1 if "<entry" in result.data else 0
    return result


def _strip(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", text or "")).strip()


def parse(fetch_result: SourceFetch, centre: str = "PAAQ") -> list[RawSignal]:
    if not fetch_result.ok or not isinstance(fetch_result.data, str):
        return []
    try:
        root = ET.fromstring(fetch_result.data)
    except ET.ParseError:
        return []
    _, authority = FEEDS.get(centre, ("", "NOAA Tsunami Warning Center"))
    out: list[RawSignal] = []
    entries = root.findall(f"{ATOM}entry") or ([root] if root.tag == f"{ATOM}entry" else [])
    for idx, entry in enumerate(entries):
        updated = entry.findtext(f"{ATOM}updated") or root.findtext(f"{ATOM}updated")
        lat_txt = entry.findtext(f"{GEO}lat")
        lon_txt = entry.findtext(f"{GEO}long")
        title = _strip(entry.findtext(f"{ATOM}title") or "Tsunami bulletin")
        summaries = [e.text or "" for e in entry.iter() if e.tag.endswith("summary")]
        raw_summary = " ".join(summaries)
        summary = _strip(raw_summary)
        category = "Information"
        m = _DETAIL_RES["category"].search(raw_summary) or _DETAIL_RES["category"].search(summary)
        if m:
            category = m.group(1).strip()
        mag = None
        mm = _DETAIL_RES["magnitude"].search(raw_summary) or _DETAIL_RES["magnitude"].search(summary)
        if mm:
            try:
                mag = float(mm.group(1))
            except ValueError:
                mag = None
        region = ""
        mr = _DETAIL_RES["region"].search(raw_summary)
        if mr:
            region = _strip(mr.group(1))
        if lat_txt is None or lon_txt is None:
            # No epicentre in feed: keep the bulletin but without a hazard point.
            continue
        try:
            lat, lon = float(lat_txt), float(lon_txt)
        except ValueError:
            continue
        link = ""
        for ln in entry.findall(f"{ATOM}link"):
            if ln.get("rel") == "related" and ln.get("type") == "text/html":
                link = ln.get("href") or ""
        if not link:
            for ln in entry.findall(f"{ATOM}link"):
                if (ln.get("href") or "").startswith("https://www.tsunami.gov/events/"):
                    link = ln.get("href")
                    break
        out.append(
            RawSignal(
                source_key="noaa_tsunami",
                external_id=f"{centre}-{updated}-{idx}",
                hazard_hint="tsunami",
                lat=lat,
                lon=lon,
                observed_at=parse_dt(updated),
                place=region or title,
                country="",
                magnitude=mag,
                magnitude_unit="M (preliminary)",
                source_url=link or FEEDS.get(centre, ("https://www.tsunami.gov/", ""))[0],
                confidence=_CATEGORY_CONFIDENCE.get(category.lower(), 88.0),
                payload={
                    "centre": centre,
                    "authority": authority,
                    "category": category,
                    "title": title,
                    "message_text": summary[:2000],
                    "official": True,
                },
            ).normalized()
        )
    return out
