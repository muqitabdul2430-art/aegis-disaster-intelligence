"""Ingestion pipeline: provider → normalised observations → detections → incidents.

Runs as a background job (see app/scheduler.py) and on demand from the API.
Every step records what it did: source sync logs, observation rows, incident
records, official alerts, and audit entries — so nothing in the UI is a
placeholder.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .agents.classification_agent import classification_agent
from .agents.detection_agent import detection_agent
from .agents.geo_agent import geo_agent
from .agents.risk_agent import risk_agent
from .sources import gdacs, nasa_firms, nasa_gibs, nhc, noaa_tsunami, usgs_earthquake
from .sources.base import SOURCE_CATALOG, SOURCE_BY_KEY, SourceSpec
from .sources.http import SourceFetch
from .util import now

log = logging.getLogger("aegis.ingest")

Connector = tuple[str, Callable[[], Any], Callable[..., list]]

# source_key → (label, fetch(), parse())   parse() receives the SourceFetch
CONNECTORS: dict[str, Connector] = {
    "usgs_earthquake": ("usgs_earthquake", usgs_earthquake.fetch, usgs_earthquake.parse),
    "gdacs": ("gdacs", gdacs.fetch, gdacs.parse),
    "nhc": ("nhc", nhc.fetch, nhc.parse),
    "noaa_tsunami": ("noaa_tsunami", lambda: noaa_tsunami.fetch("PAAQ"), lambda r: noaa_tsunami.parse(r, "PAAQ")),
    "nasa_firms": ("nasa_firms", nasa_firms.fetch, nasa_firms.parse),
}


# --------------------------------------------------------------------------- #
# Source registry / health
# --------------------------------------------------------------------------- #
def _credential_present(spec: SourceSpec) -> bool:
    from .config import settings

    if not spec.credential_env:
        return False
    attr = spec.credential_env.replace("AEGIS_", "").lower()
    return bool(getattr(settings, attr, ""))


def ensure_sources(db: Session) -> None:
    """Seed/refresh the data_sources registry from the catalogue.

    Sources that cannot work yet are marked explicitly (no_credentials /
    disabled / unknown) instead of silently appearing healthy.
    """
    existing = {s.key for s in db.scalars(select(models.DataSource))}
    for spec in SOURCE_CATALOG:
        if spec.key in existing:
            continue
        status, note = "unknown", ""
        if spec.key in {"nasa_firms"} and not _credential_present(spec):
            status = "no_credentials"
            note = "Free MAP_KEY not configured — set AEGIS_FIRMS_MAP_KEY to enable satellite fire detections."
        elif spec.auth_mode in {"registration", "token"} and not _credential_present(spec):
            status = "no_credentials"
            note = f"{spec.auth_mode.title()} required — set {spec.credential_env}."
        elif spec.connector == "":
            status = "disabled"
            note = ("No documented public API — AEGIS provides the authoritative link and does not ingest this feed."
                    if spec.auth_mode == "none" else note or "Connector not enabled.")
        db.add(models.DataSource(
            key=spec.key, name=spec.name, provider=spec.provider, homepage=spec.homepage, docs_url=spec.docs_url,
            license=spec.license, categories=spec.categories, auth_mode=spec.auth_mode,
            credential_env=spec.credential_env, status=status, last_error=note or None,
            reliability_note=spec.reliability_note, is_demo=False,
        ))
    db.flush()


def update_source_health(db: Session, spec: SourceSpec | None, key: str, fetch: SourceFetch, records: int,
                         inserted: int, duration_ms: int, stage: str = "ingest") -> None:
    ds = db.get(models.DataSource, key)
    if ds is None:
        ds = models.DataSource(key=key, name=(spec.name if spec else key))
        db.add(ds)
    ds.last_attempt_at = now()
    ds.latency_ms = fetch.latency_ms if fetch.latency_ms is not None else duration_ms
    ds.records_last_fetch = records
    if fetch.ok:
        ds.status = "ok"
        ds.last_ok_at = now()
        ds.last_error = None
        ds.total_records = (ds.total_records or 0) + max(0, inserted)
    elif fetch.error_kind == "credentials":
        ds.status = "no_credentials"
        ds.last_error = fetch.error
    elif fetch.error_kind == "disabled":
        ds.status = "disabled"
        ds.last_error = fetch.error
    elif fetch.error_kind in {"rate_limit", "timeout", "network"}:
        ds.status = "degraded"
        ds.last_error = fetch.error
    else:
        ds.status = "error"
        ds.last_error = fetch.error
    if spec and spec.auth_mode in {"api_key", "registration", "token"} and fetch.error_kind == "credentials":
        ds.status = "no_credentials"
    db.flush()


def _finish_sync(db: Session, log_row: models.SourceSyncLog, status: str, records: int, t0: float,
                 message: str | None = None) -> None:
    log_row.status = status
    log_row.records = records
    log_row.finished_at = now()
    log_row.duration_ms = int((time.perf_counter() - t0) * 1000)
    log_row.message = (message or "")[:1000]
    db.flush()


# --------------------------------------------------------------------------- #
# Observation persistence
# --------------------------------------------------------------------------- #
def store_observations(db: Session, signals: list, data_origin: str = "live") -> tuple[int, list[models.Observation]]:
    """Idempotent insert (unique on source_key+fingerprint). Returns (inserted, new_rows)."""
    inserted: list[models.Observation] = []
    for sig in signals:
        # Connectors normalise their own signals, but ingestion must not crash if a
        # future connector hands over an ISO string instead of a datetime.
        if not hasattr(sig.observed_at, "isoformat"):
            sig.normalized()
        fp = sig.fingerprint
        exists = db.scalar(select(models.Observation.id).where(
            models.Observation.source_key == sig.source_key, models.Observation.fingerprint == fp))
        if exists:
            # refresh mutable fields (e.g. USGS event revision, GDACS episode update)
            row = db.get(models.Observation, exists)
            if row is not None:
                row.confidence = sig.confidence or row.confidence
                row.payload = sig.payload or row.payload
                row.observed_at = sig.observed_at or row.observed_at
        else:
            row = models.Observation(
                source_key=sig.source_key, external_id=str(sig.external_id or ""), fingerprint=fp,
                hazard_hint=sig.hazard_hint, lat=sig.lat, lon=sig.lon, place=sig.place, country=sig.country,
                magnitude=sig.magnitude, magnitude_unit=sig.magnitude_unit, observed_at=sig.observed_at,
                source_url=sig.source_url, data_origin=data_origin, confidence=sig.confidence, payload=sig.payload,
            )
            db.add(row)
            inserted.append(row)
    db.flush()
    return len(inserted), inserted


# --------------------------------------------------------------------------- #
# Official alert ingestion (verbatim, attributed — never reworded)
# --------------------------------------------------------------------------- #
def ingest_official_alerts(db: Session, observations: list[models.Observation]) -> list[models.Alert]:
    created: list[models.Alert] = []
    for obs in observations:
        payload = obs.payload or {}
        if not payload.get("official"):
            continue
        external_key = f"{obs.source_key}:{obs.external_id}"
        exists = db.scalar(select(models.Alert).where(models.Alert.external_id == external_key))
        if exists:
            continue
        authority = payload.get("authority") or ("NOAA National Hurricane Center" if obs.source_key == "nhc"
                                                 else "NOAA Tsunami Warning Center")
        if obs.source_key == "nhc":
            kmh = payload.get("intensity_kmh")
            title = f"{payload.get('classification_text') or 'Tropical cyclone'} {payload.get('name') or ''}".strip() + \
                    f" — advisory {((payload.get('public_advisory') or {}).get('advNum')) or ''}".strip()
            body = (
                f"OFFICIAL NOAA NHC POSITION/INTENSITY REPORT (verbatim values):\n"
                f"• Position: {abs(obs.lat):.1f}°{'N' if obs.lat >= 0 else 'S'}, {abs(obs.lon):.1f}°{'E' if obs.lon >= 0 else 'W'}\n"
                f"• Maximum sustained winds: {payload.get('intensity_kt')} kt ({kmh} km/h)\n"
                f"• Central pressure: {payload.get('pressure_mb')} mb\n"
                f"• Movement: {payload.get('movement_speed_kt')} kt toward bearing {payload.get('movement_dir_deg')}°\n"
                f"• Advisory issued: {((payload.get('public_advisory') or {}).get('issuance'))}\n"
                f"Read the full official advisory at the linked NHC page. Forecast track and watches/warnings are "
                f"contained in the NHC products, not in this record."
            )
            instructions = [
                "Follow NHC advisory products and local emergency management instructions.",
                "Monitor official watches/warnings for your county/state.",
            ]
        else:  # tsunami bulletins
            category = payload.get("category", "Information")
            title = f"Tsunami {category} — {payload.get('title') or obs.place}"
            body = (f"OFFICIAL BULLETIN TEXT (verbatim excerpt, {authority}):\n\n"
                    f"{payload.get('message_text', '')[:1500]}")
            instructions = [
                "Follow the issuing tsunami warning centre's instructions for your coast.",
                "Evacuate to high ground immediately if you are in an evacuated zone.",
                "Do not return until the centre issues an all-clear.",
            ]
        alert = models.Alert(
            alert_kind="official_ingested", severity=_official_severity(obs), hazard=obs.hazard_hint,
            title=title[:290], body=body, instructions=instructions,
            area_text=obs.place or payload.get("region") or "", lat=obs.lat, lon=obs.lon,
            issued_at=obs.observed_at, authority=authority, source_key=obs.source_key, source_url=obs.source_url,
            confidence=obs.confidence or 90.0, status="published", review_required=False,
            generated_by="ingest_pipeline", data_origin=obs.data_origin, external_id=external_key,
        )
        db.add(alert)
        created.append(alert)
    db.flush()
    return created


def _official_severity(obs: models.Observation) -> str:
    payload = obs.payload or {}
    if obs.source_key == "nhc":
        kmh = payload.get("intensity_kmh") or 0
        if kmh >= 178:
            return "extreme"
        if kmh >= 119:
            return "severe"
        return "moderate"
    cat = str(payload.get("category", "")).lower()
    return {"warning": "extreme", "advisory": "severe", "watch": "severe", "information": "minor"}.get(cat, "moderate")


# --------------------------------------------------------------------------- #
# Source runners
# --------------------------------------------------------------------------- #
def run_source(db: Session, key: str, *, data_origin: str | None = None, process: bool = True,
               classify_limit: int = 12) -> dict[str, Any]:
    """Fetch one source, store observations, ingest official alerts and process detections."""
    if key not in CONNECTORS:
        spec = SOURCE_BY_KEY.get(key)
        reason = ("catalogue-only source (no documented public API)" if spec else "unknown source")
        log_row = models.SourceSyncLog(source_key=key, status="skipped", message=reason, finished_at=now())
        db.add(log_row)
        ds = db.get(models.DataSource, key)
        if ds:
            ds.last_attempt_at = now()
            ds.status = "disabled"
            ds.last_error = reason
        db.flush()
        return {"source": key, "status": "skipped", "reason": reason, "records": 0}

    label, fetch_fn, parse_fn = CONNECTORS[key]
    spec = SOURCE_BY_KEY.get(key)
    t0 = time.perf_counter()
    sync = models.SourceSyncLog(source_key=key, status="running")
    db.add(sync)
    db.flush()

    fetch = fetch_fn()
    signals = parse_fn(fetch) if fetch.ok else []
    origin = data_origin or "live"
    inserted_count, new_obs = store_observations(db, signals, data_origin=origin)
    alerts = ingest_official_alerts(db, new_obs) if new_obs else []
    update_source_health(db, spec, key, fetch, records=len(signals), inserted=inserted_count,
                         duration_ms=int((time.perf_counter() - t0) * 1000))
    _finish_sync(db, sync, "ok" if fetch.ok else (fetch.error_kind or "error"), len(signals),
                 t0, message=(fetch.error or ""))

    result: dict[str, Any] = {
        "source": key, "status": "ok" if fetch.ok else "error", "error": fetch.error,
        "error_kind": fetch.error_kind, "records": len(signals), "new_observations": inserted_count,
        "official_alerts": len(alerts), "latency_ms": fetch.latency_ms,
    }

    if process and new_obs:
        det = detection_agent.run(db, _ctx(db, "detection_agent"), hours=max(1, int(
            (now() - min(o.observed_at for o in new_obs)).total_seconds() // 3600) + 1))
        result["detection"] = {"new_incidents": det.get("incidents_created_codes", []),
                               "linked": det.get("observations_linked", 0)}
        # classify + geospatial + risk for freshly created incidents (bounded)
        new_ids = det.get("incidents_created", [])[:classify_limit]
        if new_ids:
            for inc_id in new_ids:
                inc = db.get(models.Incident, inc_id)
                if inc is None:
                    continue
                try:
                    classification_agent.apply(db, inc, None)
                    geo = geo_agent.context_report(db, inc, None, radius_km=25.0, include_facilities=False)
                    risk_agent.assess(db, inc, None, weather=None, area=geo["area"], facilities=geo["facilities"])
                except Exception as exc:  # noqa: BLE001
                    log.warning("post-detection processing failed for %s: %s", inc_id, exc)
                    result.setdefault("processing_errors", []).append(f"{inc_id}: {exc}")
            result["processed_incidents"] = new_ids
    db.flush()
    return result


def _ctx(db: Session, agent: str):
    from .agents.base import AgentContext

    return AgentContext(db=db, agent_name=agent)


def run_all(db: Session, keys: list[str] | None = None, *, include_firms: bool | None = None,
            data_origin: str | None = None, process: bool = True) -> dict[str, Any]:
    """Run every configured connector; returns a per-source report."""
    ensure_sources(db)
    targets = keys or ["usgs_earthquake", "gdacs", "nhc", "noaa_tsunami"]
    if include_firms is None:
        from .config import settings

        include_firms = bool(settings.firms_map_key)
    if include_firms and "nasa_firms" not in targets:
        targets.append("nasa_firms")

    t0 = time.perf_counter()
    reports = [run_source(db, k, data_origin=data_origin, process=process) for k in targets]
    db.add(models.AuditLog(
        actor="ingest_pipeline", actor_role="system", action="ingest.run_all", entity_type="system", entity_id="-",
        after={"sources": targets, "reports": [{k: r.get(k) for k in ("source", "status", "new_observations", "error")}
                                               for r in reports]},
        reason="scheduled/manual ingestion pass",
    ))
    db.flush()
    return {
        "started_at": now().isoformat() + "Z",
        "duration_ms": int((time.perf_counter() - t0) * 1000),
        "sources": reports,
        "ok": sum(1 for r in reports if r.get("status") == "ok"),
        "failed": sum(1 for r in reports if r.get("status") != "ok"),
        "new_observations": sum(r.get("new_observations", 0) for r in reports),
    }


def probe_source(db: Session, key: str) -> dict[str, Any]:
    """Connectivity check for a single source (used by the Data Sources screen)."""
    spec = SOURCE_BY_KEY.get(key)
    if key not in CONNECTORS:
        stub = _catalogue_probe(key)
        ds = db.get(models.DataSource, key)
        if ds:
            ds.last_attempt_at = now()
            ds.status = stub["status"]
            ds.last_error = stub.get("error")
            db.commit()
        return stub
    label, fetch_fn, parse_fn = CONNECTORS[key]
    t0 = time.perf_counter()
    fetch = fetch_fn()
    signals = parse_fn(fetch) if fetch.ok else []
    update_source_health(db, spec, key, fetch, records=len(signals), inserted=0,
                         duration_ms=int((time.perf_counter() - t0) * 1000))
    db.commit()
    return {"source": key, "status": "ok" if fetch.ok else (fetch.error_kind or "error"),
            "records": len(signals), "latency_ms": fetch.latency_ms, "error": fetch.error,
            "note": spec.reliability_note if spec else ""}


def _catalogue_probe(key: str) -> dict[str, Any]:
    """For catalogue-only sources: report honestly rather than pretend."""
    spec = SOURCE_BY_KEY.get(key)
    if key == "nasa_gibs":
        res = nasa_gibs.probe()
        return {"source": key, "status": "ok" if res.ok else "error", "records": res.records or 0,
                "latency_ms": res.latency_ms, "error": res.error,
                "note": "GIBS WMTS capabilities reachable — imagery overlays available."}
    if not spec:
        return {"source": key, "status": "error", "error": "unknown source"}
    if spec.auth_mode in {"api_key", "registration", "token"}:
        return {"source": key, "status": "no_credentials",
                "error": f"{spec.auth_mode} required — set {spec.credential_env or 'the documented credential'}",
                "note": spec.reliability_note, "setup_url": spec.docs_url}
    return {"source": key, "status": "disabled",
            "error": "no documented public API — provided as an authoritative link only",
            "note": spec.reliability_note, "portal": spec.homepage}


def reconcile_status(db: Session) -> None:
    """Re-evaluate declared status for sources that have not been attempted yet
    (so the Data Sources screen never shows an ambiguous 'unknown')."""
    for spec in SOURCE_CATALOG:
        ds = db.get(models.DataSource, spec.key)
        if ds is None or ds.last_attempt_at is not None:
            continue
        if spec.credential_env and not _credential_present(spec):
            ds.status = "no_credentials"
            ds.last_error = f"Credential not configured — set {spec.credential_env} (see docs/SETUP.md)."
        elif spec.connector == "":
            ds.status = "disabled"
            ds.last_error = ("Catalogue/link-only source: no documented public API to ingest; AEGIS links to the "
                             "official portal instead of guessing data.")
        else:
            ds.status = "unknown"
            ds.last_error = "Not yet attempted — run a connectivity probe."
    db.flush()
