"""Pydantic request/response schemas (input validation for every write path)."""
from __future__ import annotations

from typing import Any, Literal

import re

from pydantic import BaseModel, Field, field_validator, model_validator

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")

HAZARDS = ["wildfire", "cyclone", "flood", "tsunami", "landslide", "earthquake", "industrial_fire", "unknown"]


# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #
class RegisterRequest(BaseModel):
    email: str
    password: str = Field(min_length=8, max_length=200)
    name: str = Field(default="", max_length=120)
    org: str = Field(default="", max_length=160)
    # Self-registration can never claim analyst/admin — privileged roles are
    # provisioned by an administrator (see scripts/create_user.py).
    role: Literal["citizen"] = "citizen"

    @field_validator("email")
    @classmethod
    def _email_ok(cls, v: str) -> str:
        v = (v or "").strip().lower()
        if not EMAIL_RE.match(v):
            raise ValueError("Enter a valid email address (an address on an internal domain is fine, e.g. ops@aegis.local).")
        return v

    @field_validator("password")
    @classmethod
    def _password_strength(cls, v: str) -> str:
        if v.lower() in {"password", "12345678", "aegis-demo-2026"}:
            raise ValueError("Choose a stronger password (not a common/default one).")
        return v


class LoginRequest(BaseModel):
    email: str = Field(min_length=3, max_length=200)
    password: str = Field(min_length=1, max_length=200)

    @field_validator("email")
    @classmethod
    def _email_ok(cls, v: str) -> str:
        return (v or "").strip().lower()


# --------------------------------------------------------------------------- #
# Citizen reports
# --------------------------------------------------------------------------- #
class CitizenReportRequest(BaseModel):
    description: str = Field(min_length=20, max_length=4000)
    category: Literal["wildfire", "cyclone", "flood", "tsunami", "landslide", "earthquake",
                      "industrial_fire", "unknown"] = "unknown"
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    location_source: Literal["manual", "map_click", "gps"] = "map_click"
    location_accuracy_m: float | None = Field(default=None, ge=0, le=100_000)
    observed_at: str | None = None
    contact_optin: str | None = Field(default=None, max_length=200)
    reporter_ref: str | None = Field(default=None, max_length=80,
                                     description="Optional stable pseudonymous client id used only for rate limiting/duplicate grouping.")


class CitizenReportReviewRequest(BaseModel):
    action: Literal["verify", "reject", "mark_duplicate", "link"]
    notes: str = Field(default="", max_length=2000)
    incident_id: str | None = None


# --------------------------------------------------------------------------- #
# Incidents
# --------------------------------------------------------------------------- #
class IncidentVerifyRequest(BaseModel):
    verification_status: Literal["preliminary_detection", "corroborated", "human_verified",
                                 "officially_confirmed", "rejected", "unverified_citizen"]
    note: str = Field(default="", max_length=2000)


class IncidentAssessRequest(BaseModel):
    radius_km: float = Field(default=25.0, ge=1, le=300)
    include_facilities: bool = True
    draft_alerts: bool = True


# --------------------------------------------------------------------------- #
# Agents / assistant
# --------------------------------------------------------------------------- #
class AgentRunRequest(BaseModel):
    goal: str = Field(min_length=3, max_length=2000)
    incident_ids: list[str] = Field(default_factory=list, max_length=10)
    workflow: Literal["freeform", "situation_report", "verify_incident", "escalation_scan",
                      "data_gap_review"] = "freeform"
    force_planner: Literal["rules", "llm"] | None = None


class AssistantAskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
    context: dict[str, Any] = Field(default_factory=dict)


# --------------------------------------------------------------------------- #
# Sources
# --------------------------------------------------------------------------- #
class IngestRequest(BaseModel):
    sources: list[str] | None = None
    data_origin: Literal["live", "demo"] = "live"


# --------------------------------------------------------------------------- #
# Alerts
# --------------------------------------------------------------------------- #
class AlertReviewRequest(BaseModel):
    decision: Literal["approve", "reject", "request_changes", "publish"]
    note: str = Field(default="", max_length=2000)
    notify_channels: list[Literal["in_app", "email", "sms", "push", "webhook"]] = Field(default_factory=lambda: ["in_app"])

    @model_validator(mode="after")
    def _note_required_to_publish(self):
        """Defence in depth: AEGIS advisories may only be published with a written
        human authorisation (who reviewed it and on what basis). This mirrors the
        UI requirement and keeps the audit trail meaningful even for API clients."""
        if self.decision == "publish" and len((self.note or "").strip()) < 10:
            raise ValueError(
                "Publishing an AEGIS advisory requires a reviewer note (at least 10 characters) describing "
                "who authorised it and which official bulletin it was checked against."
            )
        return self


class AlertAckRequest(BaseModel):
    note: str = Field(default="", max_length=1000)


class NotificationTestRequest(BaseModel):
    channel: Literal["in_app", "email", "sms", "push", "webhook"]
    target: str = Field(default="", max_length=200)


# --------------------------------------------------------------------------- #
# Geo utilities
# --------------------------------------------------------------------------- #
class RouteCheckRequest(BaseModel):
    incident_id: str
    from_lat: float = Field(ge=-90, le=90)
    from_lon: float = Field(ge=-180, le=180)
    to_lat: float | None = Field(default=None, ge=-90, le=90)
    to_lon: float | None = Field(default=None, ge=-180, le=180)
