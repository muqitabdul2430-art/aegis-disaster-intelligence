"""Weather intelligence via Open-Meteo (keyless, CC-BY 4.0).

Used to derive hazard *drivers* (rainfall, wind, soil moisture, temperature
anomaly) around an incident.  Open-Meteo aggregates national weather services
(ECMWF IFS, DWD ICON, NOAA GFS, CMA, JMA, Météo-France…).  Values returned by
the forecast endpoint are MODEL OUTPUT — always labelled as such in the UI,
never as measurements.
"""
from __future__ import annotations

import time
from typing import Any

from ..util import clamp, now
from ..sources.http import request_json

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"

_CACHE: dict[str, tuple[float, dict]] = {}
CACHE_TTL = 600  # 10 minutes — forecast fields update hourly

HOURLY_VARS = [
    "precipitation",
    "rain",
    "showers",
    "wind_speed_10m",
    "wind_gusts_10m",
    "wind_direction_10m",
    "temperature_2m",
    "relative_humidity_2m",
    "soil_moisture_0_to_7cm",
    "cape",
    "pressure_msl",
]


def _cache_key(lat: float, lon: float) -> str:
    return f"{lat:.2f},{lon:.2f}"


def forecast(lat: float, lon: float, past_days: int = 2, forecast_days: int = 3) -> dict[str, Any]:
    """Return {ok, error?, model, points, summary, fetched_at, url}."""
    key = _cache_key(lat, lon)
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < CACHE_TTL:
        return {**hit[1], "cached": True}

    params = {
        "latitude": round(lat, 4),
        "longitude": round(lon, 4),
        "hourly": ",".join(HOURLY_VARS),
        "past_days": past_days,
        "forecast_days": forecast_days,
        "timezone": "UTC",
        "wind_speed_unit": "kmh",
    }
    res = request_json(FORECAST_URL, params=params, timeout=15.0, retries=1)
    if not res.ok:
        return {"ok": False, "error": res.error, "error_kind": res.error_kind, "url": str(res.url or FORECAST_URL)}

    data = res.data or {}
    hourly = data.get("hourly") or {}
    times = hourly.get("time") or []
    points = []
    for i, t in enumerate(times):
        points.append({
            "time": t,
            "precip_mm": _at(hourly, "precipitation", i),
            "rain_mm": _at(hourly, "rain", i),
            "showers_mm": _at(hourly, "showers", i),
            "wind_kmh": _at(hourly, "wind_speed_10m", i),
            "gust_kmh": _at(hourly, "wind_gusts_10m", i),
            "wind_dir_deg": _at(hourly, "wind_direction_10m", i),
            "temp_c": _at(hourly, "temperature_2m", i),
            "rh_pct": _at(hourly, "relative_humidity_2m", i),
            "soil_moisture": _at(hourly, "soil_moisture_0_to_7cm", i),
            "cape": _at(hourly, "cape", i),
            "pressure_hpa": _at(hourly, "pressure_msl", i),
        })

    now_iso = now().strftime("%Y-%m-%dT%H:00")
    past24 = [p for p in points if p["time"] <= now_iso][-24:]
    next24 = [p for p in points if p["time"] > now_iso][:24]
    next72 = [p for p in points if p["time"] > now_iso][:72]

    def _sum(rows, field):
        vals = [r[field] for r in rows if isinstance(r.get(field), (int, float))]
        return round(sum(vals), 1) if vals else None

    def _max(rows, field):
        vals = [r[field] for r in rows if isinstance(r.get(field), (int, float))]
        return round(max(vals), 1) if vals else None

    summary = {
        "rain_past_24h_mm": _sum(past24, "precip_mm"),
        "rain_next_24h_mm": _sum(next24, "precip_mm"),
        "rain_next_72h_mm": _sum(next72, "precip_mm"),
        "max_wind_next_24h_kmh": _max(next24, "wind_kmh"),
        "max_gust_next_24h_kmh": _max(next24, "gust_kmh"),
        "temp_next_24h_max_c": _max(next24, "temp_c"),
        "rh_next_24h_min_pct": min([r["rh_pct"] for r in next24 if isinstance(r.get("rh_pct"), (int, float))], default=None),
        "soil_moisture_pct": (lambda v: round(v * 100, 1) if isinstance(v, (int, float)) else None)(past24[-1]["soil_moisture"] if past24 else None),
        "cape_max_next_24h": _max(next24, "cape"),
        "pressure_min_next_24h_hpa": min([r["pressure_hpa"] for r in next24 if isinstance(r.get("pressure_hpa"), (int, float))], default=None),
    }
    out = {
        "ok": True,
        "source": "Open-Meteo (multi-model, keyless)",
        "source_url": "https://open-meteo.com/en/docs",
        "kind": "model_forecast",
        "label": "MODEL OUTPUT — not observed measurements",
        "model_elevation_m": data.get("elevation"),
        "timezone": data.get("timezone"),
        "lat": lat, "lon": lon,
        "points": points,
        "summary": summary,
        "fetched_at": now().isoformat(timespec="seconds") + "Z",
    }
    _CACHE[key] = (time.time(), out)
    return out


def _at(hourly: dict, field: str, i: int):
    arr = hourly.get(field)
    if not isinstance(arr, list) or i >= len(arr):
        return None
    v = arr[i]
    return round(v, 2) if isinstance(v, (int, float)) else None


# --------------------------------------------------------------------------- #
# Composite hazard-driver extraction (used by the risk agent)
# --------------------------------------------------------------------------- #
def flood_drivers(wx: dict) -> dict:
    if not wx.get("ok"):
        return {"available": False, "reason": wx.get("error", "weather unavailable")}
    s = wx["summary"]
    rain24, rain72 = s.get("rain_next_24h_mm") or 0, s.get("rain_next_72h_mm") or 0
    past = s.get("rain_past_24h_mm") or 0
    soil = s.get("soil_moisture_pct")
    # Transparent, documented thresholds (metres of accumulated water, saturated soil amplifies runoff)
    if rain24 >= 115 or rain72 >= 200 or (rain24 >= 80 and (soil or 0) > 35):
        level, rationale = "very_high", "extreme 24-72h accumulation forecast"
    elif rain24 >= 64 or rain72 >= 115:
        level, rationale = "high", "heavy rainfall threshold (IMD 'heavy to very heavy' range) exceeded"
    elif rain24 >= 15 or rain72 >= 40:
        level, rationale = "moderate", "significant rainfall forecast"
    else:
        level, rationale = "low", "no heavy-rain signal in forecast window"
    return {
        "available": True,
        "level": level, "score": {"low": 20, "moderate": 50, "high": 78, "very_high": 92}[level],
        "rationale": rationale,
        "rain_past_24h_mm": past, "rain_next_24h_mm": rain24, "rain_next_72h_mm": rain72,
        "soil_moisture_pct": soil,
        "source": wx.get("source"), "source_url": wx.get("source_url"),
        "kind": "model_forecast",
    }


def wind_drivers(wx: dict) -> dict:
    if not wx.get("ok"):
        return {"available": False, "reason": wx.get("error", "weather unavailable")}
    s = wx["summary"]
    wind = s.get("max_wind_next_24h_kmh") or 0
    gust = s.get("max_gust_next_24h_kmh") or 0
    peak = max(wind, gust or 0)
    if peak >= 118:
        level = "very_high"
    elif peak >= 89:
        level = "high"
    elif peak >= 50:
        level = "moderate"
    else:
        level = "low"
    return {
        "available": True,
        "level": level, "score": {"low": 15, "moderate": 45, "high": 75, "very_high": 92}[level],
        "rationale": f"peak modelled wind/gust in next 24h: {peak} km/h",
        "max_wind_next_24h_kmh": wind, "max_gust_next_24h_kmh": gust,
        "source": wx.get("source"), "source_url": wx.get("source_url"), "kind": "model_forecast",
    }


def heat_dryness_drivers(wx: dict) -> dict:
    """Fire-weather proxy: high temperature + low relative humidity + low recent rain."""
    if not wx.get("ok"):
        return {"available": False, "reason": wx.get("error", "weather unavailable")}
    s = wx["summary"]
    t = s.get("temp_next_24h_max_c")
    rh = s.get("rh_next_24h_min_pct")
    rain = s.get("rain_past_24h_mm") or 0
    if t is None or rh is None:
        return {"available": False, "reason": "temperature/humidity fields missing"}
    score = 0
    score += clamp((t - 25) * 2.2, 0, 40)
    score += clamp((60 - rh) * 0.9, 0, 45)
    score += 15 if rain < 1 else (5 if rain < 5 else 0)
    score = round(clamp(score, 0, 100))
    level = "very_high" if score >= 80 else "high" if score >= 62 else "moderate" if score >= 38 else "low"
    return {
        "available": True, "level": level, "score": score,
        "rationale": f"max temp {t}°C, min RH {rh}%, 24h rain {rain} mm (fire-weather proxy, not an official fire-danger rating)",
        "temp_max_c": t, "rh_min_pct": rh, "rain_past_24h_mm": rain,
        "source": wx.get("source"), "source_url": wx.get("source_url"), "kind": "model_forecast",
    }


def landslide_drivers(wx: dict) -> dict:
    if not wx.get("ok"):
        return {"available": False, "reason": wx.get("error", "weather unavailable")}
    s = wx["summary"]
    rain72 = s.get("rain_next_72h_mm") or 0
    rain_past = s.get("rain_past_24h_mm") or 0
    soil = s.get("soil_moisture_pct") or 0
    score = clamp(rain72 * 0.5 + rain_past * 0.8 + soil * 0.6, 0, 100)
    level = "very_high" if score >= 80 else "high" if score >= 60 else "moderate" if score >= 35 else "low"
    return {
        "available": True, "level": level, "score": round(score),
        "rationale": f"antecedent + forecast rainfall and soil moisture (static, non-slope-aware proxy)",
        "rain_next_72h_mm": rain72, "rain_past_24h_mm": rain_past, "soil_moisture_pct": soil,
        "source": wx.get("source"), "source_url": wx.get("source_url"), "kind": "model_forecast",
    }
