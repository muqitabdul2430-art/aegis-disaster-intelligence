"""Nearby critical facilities via OpenStreetMap Overpass API, plus geocoding
via Nominatim (both OSM, data © OpenStreetMap contributors, ODbL).

Operational notes
-----------------
*   Overpass is a shared community service: results are cached aggressively
    (default 6 h), requests are throttled and timeouts are bounded.
*   OSM completeness varies by country and city.  AEGIS always reports
    `osm_completeness_warning` and never presents this as an authoritative
    emergency-infrastructure inventory.
*   If Overpass is unavailable the facility list is empty and clearly marked
    unavailable — no placeholder facilities are invented.
"""
from __future__ import annotations

import time

from ..sources.http import SourceFetch, request_json

OVERPASS_ENDPOINTS = [
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass-api.de/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]
NOMINATIM = "https://nominatim.openstreetmap.org/reverse"

_CACHE: dict[str, tuple[float, dict]] = {}
FACILITY_TTL = 6 * 3600          # successful lookups
FACILITY_NEGATIVE_TTL = 600      # failed lookups retried after 10 minutes
GEOCODE_TTL = 24 * 3600

# amenity → facility class
_AMENITY_CLASS = {
    "hospital": "hospital",
    "clinic": "clinic",
    "doctors": "clinic",
    "fire_station": "fire_station",
    "police": "police",
    "shelter": "shelter",
    "community_centre": "community_centre",
    "school": "school",
    "townhall": "government",
    "pharmacy": "pharmacy",
    "fuel": "fuel",
    "water_point": "water",
}
_SOCIAL_FACILITY_CLASS = {"shelter": "shelter", "ambulance_station": "ambulance"}


def _overpass(query: str, timeout: float = 25.0) -> SourceFetch:
    """Try mirrors in order; a shared community service can be slow, so the first
    successful response wins and individual attempts are time-bounded."""
    last: SourceFetch | None = None
    for endpoint in OVERPASS_ENDPOINTS:
        res = request_json(endpoint, method="POST", data={"data": query}, timeout=timeout, retries=0)
        if res.ok:
            return res
        last = res
        if res.error_kind == "disabled":
            return res
    if last and last.error:
        last.error = f"{last.error} (tried {len(OVERPASS_ENDPOINTS)} Overpass mirrors)"
    return last or SourceFetch(ok=False, error="no Overpass endpoint available", error_kind="network")


def nearby_facilities(lat: float, lon: float, radius_km: float = 25.0, limit: int = 40) -> dict:
    """Return hospitals, shelters, fire/police stations etc. near a point."""
    key = f"{lat:.3f},{lon:.3f},{radius_km:.0f}"
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < FACILITY_TTL:
        return {**hit[1], "cached": True}

    r = int(radius_km * 1000)
    query = f"""
[out:json][timeout:25];
(
  nwr[amenity~"^(hospital|clinic|fire_station|police|shelter|community_centre|pharmacy|townhall)$"](around:{r},{lat},{lon});
  nwr[emergency=ambulance_station](around:{r},{lat},{lon});
  nwr[healthcare=hospital](around:{r},{lat},{lon});
);
out center {limit};
""".strip()
    res = _overpass(query)
    if not res.ok:
        out = {
            "ok": False,
            "error": res.error, "error_kind": res.error_kind,
            "source": "OpenStreetMap / Overpass API",
            "note": "Facility data unavailable — do not assume facilities shown elsewhere cover this area.",
            "facilities": [],
        }
        _CACHE[key] = (time.time() - FACILITY_TTL + FACILITY_NEGATIVE_TTL, out)  # retry sooner after a failure
        return out

    from ..services.geo import haversine_km

    facilities = []
    for el in (res.data or {}).get("elements", []):
        tags = el.get("tags") or {}
        clat = el.get("lat") or (el.get("center") or {}).get("lat")
        clon = el.get("lon") or (el.get("center") or {}).get("lon")
        if clat is None or clon is None:
            continue
        amenity = tags.get("amenity") or ""
        emergency = tags.get("emergency") or ""
        fclass = _AMENITY_CLASS.get(amenity) or _SOCIAL_FACILITY_CLASS.get(emergency) or tags.get("healthcare") or "other"
        name = tags.get("name") or tags.get("operator") or f"Unnamed {fclass.replace('_', ' ')}"
        facilities.append({
            "osm_id": f"{el.get('type')}/{el.get('id')}",
            "class": fclass,
            "name": name,
            "lat": float(clat), "lon": float(clon),
            "distance_km": round(haversine_km(lat, lon, float(clat), float(clon)), 2),
            "phone": tags.get("phone") or tags.get("contact:phone") or "",
            "beds": tags.get("beds") or "",
            "capacity": tags.get("capacity") or "",
            "operator": tags.get("operator") or "",
            "emergency": tags.get("emergency") or "",
            "osm_url": f"https://www.openstreetmap.org/{el.get('type')}/{el.get('id')}",
        })
    facilities.sort(key=lambda f: f["distance_km"])
    out = {
        "ok": True,
        "source": "OpenStreetMap / Overpass API",
        "source_url": "https://overpass-api.de/",
        "license": "ODbL 1.0 — © OpenStreetMap contributors",
        "radius_km": radius_km,
        "count": len(facilities),
        "facilities": facilities[:limit],
        "osm_completeness_warning": ("Community-mapped data: presence in OSM is not a guarantee that a facility is open, "
                                     "staffed or accepting patients. Always confirm with local authorities (e.g. dial 108/112 in India)."),
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    _CACHE[key] = (time.time(), out)
    return out


def reverse_geocode(lat: float, lon: float) -> dict:
    """Locality / district / country for a point (Nominatim, rate-limited ≤1 rps)."""
    key = f"geo:{lat:.3f},{lon:.3f}"
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < GEOCODE_TTL:
        return {**hit[1], "cached": True}

    res = request_json(
        NOMINATIM,
        params={"lat": round(lat, 5), "lon": round(lon, 5), "format": "jsonv2", "zoom": 10, "addressdetails": 1},
        timeout=12.0, retries=1,
        headers={"Accept-Language": "en"},
    )
    if not res.ok or not isinstance(res.data, dict):
        # Offline graceful degradation: gazetteer-based label
        from .geo import place_label
        out = {"ok": False, "error": res.error, "error_kind": res.error_kind,
               "fallback_label": place_label(lat, lon), "source": "offline gazetteer (Natural Earth)"}
        _CACHE[key] = (time.time(), out)
        return out
    addr = res.data.get("address") or {}
    out = {
        "ok": True,
        "source": "OpenStreetMap Nominatim",
        "license": "ODbL 1.0 — © OpenStreetMap contributors",
        "display_name": res.data.get("display_name"),
        "locality": addr.get("city") or addr.get("town") or addr.get("village") or addr.get("suburb") or addr.get("county"),
        "district": addr.get("state_district") or addr.get("county"),
        "state": addr.get("state"),
        "country": addr.get("country"),
        "country_code": (addr.get("country_code") or "").upper(),
        "postcode": addr.get("postcode"),
    }
    _CACHE[key] = (time.time(), out)
    return out


def clear_cache() -> None:
    _CACHE.clear()
