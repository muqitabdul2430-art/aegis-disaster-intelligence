"""Notification dispatch (in-app by default; email/SMS/push/webhook only when configured).

Design:
*   Nothing is enabled by default — a channel reports `not_configured` rather than
    silently dropping messages.
*   Every dispatch attempt is logged to `notifications` with the outcome, so the
    Alerts Center can show delivery status honestly.
*   Demo alerts and citizen-derived alerts can never be dispatched externally
    (guard in `dispatch`), and nothing is ever sent before human authorisation.
"""
from __future__ import annotations

import logging
import os

from sqlalchemy.orm import Session

from .. import models

from ..util import now

log = logging.getLogger("aegis.notifications")

CHANNELS = {
    "in_app": {"label": "In-app alert feed", "enabled": True, "env": "", "note": "Always available."},
    "email": {"label": "Email", "enabled": bool(os.getenv("AEGIS_SMTP_HOST")), "env": "AEGIS_SMTP_HOST",
              "note": "SMTP relay configured via environment variables."},
    "sms": {"label": "SMS", "enabled": bool(os.getenv("AEGIS_SMS_WEBHOOK_URL")), "env": "AEGIS_SMS_WEBHOOK_URL",
            "note": "Provider-agnostic webhook (e.g. Twilio/msg91/Gupshup adapters). Message content is authored by "
                    "the analyst, not by the LLM."},
    "push": {"label": "Push", "enabled": bool(os.getenv("AEGIS_PUSH_WEBHOOK_URL")), "env": "AEGIS_PUSH_WEBHOOK_URL",
             "note": "FCM/APNs adapter webhook."},
    "webhook": {"label": "Webhook", "enabled": bool(os.getenv("AEGIS_GENERIC_WEBHOOK_URL")),
                "env": "AEGIS_GENERIC_WEBHOOK_URL",
                "note": "Generic JSON webhook for integration with an EOC / incident-management system."},
}


def channel_status() -> dict:
    return {
        "channels": [{"channel": k, "label": v["label"], "enabled": v["enabled"], "env": v["env"], "note": v["note"]}
                     for k, v in CHANNELS.items()],
        "policy": ("External channels are opt-in. AEGIS never sends an unverified or AI-generated alert without "
                   "explicit human authorisation, and demonstration data is never dispatched externally."),
    }


def can_dispatch(alert: models.Alert, channel: str) -> tuple[bool, str]:
    if channel not in CHANNELS:
        return False, f"unknown channel '{channel}'"
    if not CHANNELS[channel]["enabled"]:
        return False, f"channel '{channel}' is not configured (set {CHANNELS[channel]['env'] or 'the documented env vars'})"
    if alert.data_origin == "demo":
        return False, "demonstration data is never dispatched to external channels"
    if alert.status != "published":
        return False, f"alert status is '{alert.status}' — only published alerts may be dispatched"
    if alert.alert_kind in {"ai_advisory", "citizen_derived"} and alert.review_required:
        return False, "advisory requires authorised human review before dispatch"
    return True, "ok"


def send(db: Session, *, channel: str, target: str, subject: str, body: str, alert_id: str | None) -> dict:
    entry = models.NotificationLog(alert_id=alert_id, channel=channel, target=target,
                                   status="queued", detail="", )
    db.add(entry)
    db.flush()
    if channel == "in_app":
        entry.status = "sent"
        entry.sent_at = now()
        entry.detail = "Delivered to the in-app alert feed."
        db.flush()
        return {"channel": channel, "status": "sent", "detail": entry.detail}

    if not CHANNELS.get(channel, {}).get("enabled"):
        entry.status = "not_configured"
        entry.detail = f"{CHANNELS.get(channel, {}).get('env')} is not set"
        db.flush()
        return {"channel": channel, "status": "not_configured", "detail": entry.detail}

    url = None
    if channel == "webhook":
        url = os.getenv("AEGIS_GENERIC_WEBHOOK_URL")
    elif channel == "sms":
        url = os.getenv("AEGIS_SMS_WEBHOOK_URL")
    elif channel == "push":
        url = os.getenv("AEGIS_PUSH_WEBHOOK_URL")
    if url:
        res = _post(url, {
            "subject": subject, "body": body, "channel": channel, "target": target, "alert_id": alert_id,
            "source": "AEGIS",
        })
        if res.get("ok"):
            entry.status = "sent"
            entry.sent_at = now()
            entry.detail = f"webhook accepted ({res.get('status_code')})"
        else:
            entry.status = "failed"
            entry.detail = res.get("error", "webhook failed")
    else:
        # email path (SMTP) — only if explicitly configured
        ok, detail = _send_email(subject, body, target)
        entry.status = "sent" if ok else "failed"
        entry.detail = detail
        if ok:
            entry.sent_at = now()
    db.flush()
    return {"channel": channel, "status": entry.status, "detail": entry.detail}


def dispatch(db: Session, alert: models.Alert, channels: list[str]) -> list[dict]:
    results = []
    for channel in channels:
        allowed, reason = can_dispatch(alert, channel)
        if not allowed:
            db.add(models.NotificationLog(alert_id=alert.id, channel=channel, target="",
                                          status="not_configured" if "not configured" in reason else "failed",
                                          detail=reason))
            results.append({"channel": channel, "status": "blocked", "detail": reason})
            continue
        if channel == "in_app":
            db.add(models.NotificationLog(alert_id=alert.id, channel="in_app", target="", status="sent",
                                          detail="Delivered to the in-app alert feed.", sent_at=now()))
            results.append({"channel": "in_app", "status": "sent", "detail": "Delivered to the in-app feed."})
            continue
        results.append(send(db, channel=channel, target="", subject=alert.title, body=alert.body, alert_id=alert.id))
    db.flush()
    return results


def _post(url: str, payload: dict) -> dict:
    import httpx

    try:
        with httpx.Client(timeout=12.0) as client:
            resp = client.post(url, json=payload)
        if resp.status_code >= 400:
            return {"ok": False, "status_code": resp.status_code, "error": resp.text[:200]}
        return {"ok": True, "status_code": resp.status_code}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"}


def _send_email(subject: str, body: str, target: str) -> tuple[bool, str]:
    import smtplib
    from email.message import EmailMessage

    host = os.getenv("AEGIS_SMTP_HOST")
    if not host:
        return False, "AEGIS_SMTP_HOST not configured"
    port = int(os.getenv("AEGIS_SMTP_PORT", "587"))
    user = os.getenv("AEGIS_SMTP_USER", "")
    password = os.getenv("AEGIS_SMTP_PASSWORD", "")
    sender = os.getenv("AEGIS_SMTP_FROM", user or "aegis@localhost")
    to = target or os.getenv("AEGIS_ALERT_EMAIL_TO", "")
    if not to:
        return False, "no recipient configured (AEGIS_ALERT_EMAIL_TO)"
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = to
    msg.set_content(body)
    try:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.starttls()
            if user:
                smtp.login(user, password)
            smtp.send_message(msg)
        return True, f"sent via {host}:{port}"
    except Exception as exc:  # noqa: BLE001
        return False, f"SMTP error: {exc}"
