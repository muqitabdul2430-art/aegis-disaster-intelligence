"""Geospatial computations — pure, unit-tested functions.

Everything here is deterministic and dependency-free so it can be validated
by tests (see tests/test_geo.py).  Values produced from these functions are
always *model estimates* and are labelled as such in the UI.
"""
from __future__ import annotations

import json
import math
from functools import lru_cache
from pathlib import Path
from typing import Iterable

from ..util import clamp

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
EARTH_R_KM = 6371.0088

# Metres-per-degree at the equator (WGS84 approximations)
_M_PER_DEG_LAT = 110574.0
_M_PER_DEG_LON_EQ = 111320.0


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in kilometres."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_R_KM * math.asin(min(1.0, math.sqrt(a)))


def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def compass(bearing: float) -> str:
    dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
    return dirs[int((bearing % 360) / 22.5 + 0.5) % 16]


def offset_point(lat: float, lon: float, bearing: float, distance_km: float) -> tuple[float, float]:
    """Destination point given start, bearing and distance."""
    br = math.radians(bearing)
    dr = distance_km / EARTH_R_KM
    p1, l1 = math.radians(lat), math.radians(lon)
    p2 = math.asin(math.sin(p1) * math.cos(dr) + math.cos(p1) * math.sin(dr) * math.cos(br))
    l2 = l1 + math.atan2(
        math.sin(br) * math.sin(dr) * math.cos(p1),
        math.cos(dr) - math.sin(p1) * math.sin(p2),
    )
    return math.degrees(p2), (math.degrees(l2) + 540) % 360 - 180


def circle_polygon(lat: float, lon: float, radius_km: float, points: int = 72) -> dict:
    """GeoJSON Polygon approximating a circle (estimate, not a measured boundary)."""
    ring = []
    for i in range(points + 1):
        b = 360.0 * i / points
        plat, plon = offset_point(lat, lon, b, radius_km)
        ring.append([round(plon, 5), round(plat, 5)])
    return {"type": "Polygon", "coordinates": [ring]}


def polygon_centroid(coords: Iterable[Iterable[float]]) -> tuple[float, float]:
    lons = [c[0] for c in coords]
    lats = [c[1] for c in coords]
    return (sum(lats) / len(lats), sum(lons) / len(lons))


def polygon_area_km2(geojson: dict) -> float:
    """Approximate geodesic area of a Polygon/MultiPolygon using an equal-area
    projection around the geometry centroid (good to ~0.5% for regional shapes)."""
    def ring_area(ring: list[list[float]], lat0: float) -> float:
        if len(ring) < 3:
            return 0.0
        kx = _M_PER_DEG_LON_EQ * math.cos(math.radians(lat0))
        total = 0.0
        for i in range(len(ring)):
            x1, y1 = ring[i][0] * kx, ring[i][1] * _M_PER_DEG_LAT
            x2, y2 = ring[(i + 1) % len(ring)][0] * kx, ring[(i + 1) % len(ring)][1] * _M_PER_DEG_LAT
            total += x1 * y2 - x2 * y1
        return abs(total) / 2.0

    gtype = geojson.get("type")
    polys: list[list[list[list[float]]]] = []
    if gtype == "Polygon":
        polys = [geojson["coordinates"]]
    elif gtype == "MultiPolygon":
        polys = geojson["coordinates"]
    total_m2 = 0.0
    for poly in polys:
        if not poly:
            continue
        outer = poly[0]
        lat0, _ = polygon_centroid(outer)
        area = ring_area(outer, lat0)
        for hole in poly[1:]:
            area -= ring_area(hole, lat0)
        total_m2 += max(area, 0.0)
    return total_m2 / 1e6


def bbox_around(lat: float, lon: float, radius_km: float) -> tuple[float, float, float, float]:
    dlat = radius_km / 111.32
    dlon = radius_km / (111.32 * max(0.05, math.cos(math.radians(lat))))
    return (lat - dlat, lon - dlon, lat + dlat, lon + dlon)


def bbox_to_geojson(min_lat: float, min_lon: float, max_lat: float, max_lon: float) -> dict:
    return {
        "type": "Polygon",
        "coordinates": [[
            [min_lon, min_lat], [max_lon, min_lat], [max_lon, max_lat], [min_lon, max_lat], [min_lon, min_lat],
        ]],
    }


def point_in_bbox(lat: float, lon: float, bbox: tuple[float, float, float, float]) -> bool:
    min_lat, min_lon, max_lat, max_lon = bbox
    return min_lat <= lat <= max_lat and min_lon <= lon <= max_lon


# --------------------------------------------------------------------------- #
# Offline gazetteer (Natural Earth 10m populated places, public domain)
# --------------------------------------------------------------------------- #
@lru_cache(maxsize=1)
def _cities() -> list[dict]:
    path = DATA_DIR / "cities_2500.json"
    if not path.exists():
        return []
    return json.loads(path.read_text())["places"]


def nearest_places(lat: float, lon: float, limit: int = 5, max_km: float | None = None) -> list[dict]:
    out = []
    for c in _cities():
        d = haversine_km(lat, lon, c["lat"], c["lon"])
        if max_km is not None and d > max_km:
            continue
        out.append({**c, "distance_km": round(d, 1), "bearing": compass(bearing_deg(lat, lon, c["lat"], c["lon"]))})
    out.sort(key=lambda x: x["distance_km"])
    return out[:limit]


def place_label(lat: float, lon: float) -> str:
    """Human readable 'near X' label from the offline gazetteer."""
    near = nearest_places(lat, lon, limit=1)
    if not near:
        return f"{lat:.3f}, {lon:.3f}"
    c = near[0]
    return f"{c['distance_km']:.0f} km {c['bearing']} of {c['name']}" + (f", {c['country']}" if c.get("country") else "")


def population_within_km(lat: float, lon: float, radius_km: float) -> tuple[int, list[dict]]:
    """Offline first-order population exposure estimate.

    Uses the Natural Earth populated-places gazetteer: any place whose centre
    falls inside the radius contributes its (rounded, 2011-era) population.
    This is a coarse static estimate — NOT a real-time exposure model and not
    official census data.  It is always labelled as a model estimate.
    """
    total = 0
    inside = []
    for c in _cities():
        d = haversine_km(lat, lon, c["lat"], c["lon"])
        if d > radius_km:
            continue
        pop = c.get("pop") or 0
        # weight places near the edge of the radius less (crude area proxy)
        w = 1.0 if d < radius_km * 0.5 else 0.5
        contrib = int(pop * w)
        total += contrib
        inside.append({"name": c["name"], "country": c.get("country"), "distance_km": round(d, 1),
                       "population": pop, "weighted_contribution": contrib})
    inside.sort(key=lambda x: -x["population"])
    return total, inside[:15]


# --------------------------------------------------------------------------- #
# Rough hazard geometry helpers (all estimates)
# --------------------------------------------------------------------------- #
def wind_swath_polygon(lat: float, lon: float, radius_km: float, heading_deg: float | None, length_km: float) -> dict:
    """Simple forward-swath cone for a moving cyclone (estimate)."""
    if heading_deg is None:
        return circle_polygon(lat, lon, radius_km)
    head = offset_point(lat, lon, heading_deg, length_km)
    left = offset_point(head[0], head[1], (heading_deg - 90) % 360, radius_km)
    right = offset_point(head[0], head[1], (heading_deg + 90) % 360, radius_km)
    base_l = offset_point(lat, lon, (heading_deg - 90) % 360, radius_km * 0.6)
    base_r = offset_point(lat, lon, (heading_deg + 90) % 360, radius_km * 0.6)
    ring = [
        [base_l[1], base_l[0]], [base_r[1], base_r[0]], [right[1], right[0]],
        [left[1], left[0]], [base_l[1], base_l[0]],
    ]
    return {"type": "Polygon", "coordinates": [[[round(x, 5), round(y, 5)] for x, y in ring]]}


def simplify_for_transport(coords: list, precision: int = 4) -> list:
    return [[round(c[0], precision), round(c[1], precision)] for c in coords]


def clamp_geo(lat: float, lon: float) -> tuple[float, float]:
    lon = ((lon + 180) % 360) - 180
    return clamp(lat, -90, 90), lon
