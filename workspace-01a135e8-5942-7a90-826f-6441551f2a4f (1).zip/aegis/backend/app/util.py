"""Small shared helpers."""
from __future__ import annotations

import datetime as dt
import hashlib
import math
import re
import secrets
from typing import Any

UTC = dt.timezone.utc


def now() -> dt.datetime:
    """Naive UTC now (single convention for the whole app)."""
    return dt.datetime.now(UTC).replace(tzinfo=None)


def iso(value: dt.datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is not None:
        value = value.astimezone(UTC).replace(tzinfo=None)
    return value.isoformat(timespec="seconds") + "Z"


def parse_dt(value: Any) -> dt.datetime | None:
    """Parse ISO-8601 (with or without timezone) / epoch millis into naive UTC."""
    if value is None or value == "":
        return None
    if isinstance(value, dt.datetime):
        if value.tzinfo is not None:
            return value.astimezone(UTC).replace(tzinfo=None)
        return value
    if isinstance(value, (int, float)):
        # heuristics: ms vs s epoch
        ts = float(value)
        if ts > 1e11:
            ts /= 1000.0
        return dt.datetime.fromtimestamp(ts, UTC).replace(tzinfo=None)
    s = str(value).strip()
    if re.fullmatch(r"\d{10,13}", s):
        return parse_dt(int(s))
    s = s.replace("Z", "+00:00").replace(" ", "T", 1) if "T" not in s and " " in s else s
    s = s.replace("Z", "+00:00")
    try:
        parsed = dt.datetime.fromisoformat(s)
    except ValueError:
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y%m%d%H%M", "%d/%m/%Y %H:%M"):
            try:
                parsed = dt.datetime.strptime(s, fmt)
                break
            except ValueError:
                continue
        else:
            return None
    if parsed.tzinfo is not None:
        return parsed.astimezone(UTC).replace(tzinfo=None)
    return parsed


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def fingerprint(*parts: Any) -> str:
    raw = "|".join("" if p is None else str(p) for p in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:40]


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_hash(value: str, salt: str = "aegis") -> str:
    return hashlib.sha256(f"{salt}:{value}".encode("utf-8")).hexdigest()[:32]


def new_code(prefix: str) -> str:
    return f"{prefix}-{secrets.token_hex(3).upper()}"


def human_age(then: dt.datetime | None) -> str | None:
    if then is None:
        return None
    delta = (now() - then).total_seconds()
    if delta < 60:
        return f"{int(delta)}s ago"
    if delta < 3600:
        return f"{int(delta // 60)}m ago"
    if delta < 86400:
        return f"{int(delta // 3600)}h ago"
    return f"{int(delta // 86400)}d ago"


def slug(text: str, maxlen: int = 60) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return s[:maxlen]


def safe_float(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def round_sig(x: float | None, nd: int = 2) -> float | None:
    if x is None:
        return None
    if x == 0 or not math.isfinite(x):
        return x
    return round(x, nd)
