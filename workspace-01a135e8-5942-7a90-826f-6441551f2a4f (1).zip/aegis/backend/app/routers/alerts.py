"""Alerts Center API — official warnings, AEGIS advisories and the review gate.

Policy enforced here:
*   `official_ingested` alerts are authority products: AEGIS displays them verbatim
    and they do not need AEGIS review to be visible.
*   `ai_advisory` / `citizen_derived` alerts start as `pending_review` and can only
    be published by an authorised analyst/admin.  Publishing is audited and the
    notification fan-out happens only after approval.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import models, presenters, ratelimit
from ..config import settings
from ..db import get_db
from ..schemas import AlertAckRequest, AlertReviewRequest, NotificationTestRequest
from ..security import Principal, get_principal, require_analyst, require_role
from ..services import notifications
from ..util import now

log = logging.getLogger("aegis.api.alerts")
router = APIRouter(prefix="/api/alerts", tags=["alerts"])


@router.get("")
def list_alerts(request: Request, db: Session = Depends(get_db),
                kind: str | None = Query(default=None, description="official_ingested|ai_advisory|citizen_derived|demo_advisory"),
                status_filter: str | None = Query(default=None, alias="status"),
                severity: str | None = None, hazard: str | None = None,
                hours: int = Query(default=168, ge=1, le=24 * 60),
                limit: int = Query(default=100, ge=1, le=300),
                principal: Principal = Depends(get_principal)):
    ratelimit.read_limit(request)
    from datetime import timedelta

    stmt = (select(models.Alert).where(models.Alert.issued_at >= now() - timedelta(hours=hours),
                                       models.Alert.lat.isnot(None))
            .order_by(models.Alert.issued_at.desc()).limit(limit))
    if kind:
        stmt = stmt.where(models.Alert.alert_kind.in_([k.strip() for k in kind.split(",")]))
    if status_filter:
        stmt = stmt.where(models.Alert.status.in_([s.strip() for s in status_filter.split(",")]))
    if severity:
        stmt = stmt.where(models.Alert.severity == severity)
    if hazard:
        stmt = stmt.where(models.Alert.hazard.in_([h.strip() for h in hazard.split(",")]))
    rows = list(db.scalars(stmt))

    # Non-privileged users only see published alerts; drafts and reviews are analyst-only.
    if not principal.at_least("analyst"):
        rows = [a for a in rows if a.status == "published"]

    incident_ids = [a.incident_id for a in rows if a.incident_id]
    incidents = {}
    if incident_ids:
        for inc in db.scalars(select(models.Incident).where(models.Incident.id.in_(incident_ids))):
            incidents[inc.id] = inc
    ack_counts = dict(db.execute(select(models.AlertAcknowledgement.alert_id, func.count())
                                 .group_by(models.AlertAcknowledgement.alert_id)).all())
    acked_by_me = set()
    if principal.authenticated:
        acked_by_me = {a.alert_id for a in db.scalars(
            select(models.AlertAcknowledgement).where(models.AlertAcknowledgement.user_id == principal.id))}
    return {
        "count": len(rows),
        "alerts": [presenters.alert_out(a, incident=incidents.get(a.incident_id),
                                        acknowledged=a.id in acked_by_me, ack_count=ack_counts.get(a.id, 0))
                   for a in rows],
        "pending_review_count": int(db.scalar(
            select(func.count()).select_from(models.Alert)
            .where(models.Alert.status.in_(("pending_review", "draft")))) or 0),
        "policy": notifications.channel_status(),
    }


@router.get("/pending")
def pending(request: Request, db: Session = Depends(get_db), principal: Principal = Depends(require_analyst)):
    """Review queue: drafts and advisories that must not be published without authorisation."""
    ratelimit.read_limit(request)
    rows = list(db.scalars(select(models.Alert).where(models.Alert.status.in_(("pending_review", "draft")))
                           .order_by(models.Alert.created_at.desc()).limit(50)))
    return {"count": len(rows), "alerts": [presenters.alert_out(a) for a in rows],
            "review_requirements": ("An authorised analyst/admin must approve before any AEGIS-generated advisory is "
                                    "published or sent to any external channel.")}


@router.get("/{alert_id}")
def alert_detail(alert_id: str, request: Request, db: Session = Depends(get_db),
                 principal: Principal = Depends(get_principal)):
    ratelimit.read_limit(request)
    alert = db.get(models.Alert, alert_id)
    if alert is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "alert not found")
    if alert.status != "published" and not principal.at_least("analyst"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "This alert is not published yet (analyst access required).")
    incident = db.get(models.Incident, alert.incident_id) if alert.incident_id else None
    notifications_log = list(db.scalars(select(models.NotificationLog).where(models.NotificationLog.alert_id == alert.id)
                                        .order_by(models.NotificationLog.created_at.desc())))
    acks = list(db.scalars(select(models.AlertAcknowledgement).where(models.AlertAcknowledgement.alert_id == alert.id)
                           .order_by(models.AlertAcknowledgement.acknowledged_at.desc())))
    mine = next((a for a in acks if a.user_id == principal.id), None)
    return {"alert": presenters.alert_out(alert, incident=incident, acknowledged=bool(mine), ack_count=len(acks)),
            "incident": presenters.incident_out(incident) if incident else None,
            "notifications": [{"channel": n.channel, "target": n.target, "status": n.status, "detail": n.detail,
                               "created_at": n.created_at.isoformat() + "Z",
                               "sent_at": n.sent_at.isoformat() + "Z" if n.sent_at else None}
                              for n in notifications_log],
            "acknowledgements": [{"user_id": a.user_id, "at": a.acknowledged_at.isoformat() + "Z",
                                  "note": a.note, "status_at_ack": a.status_at_ack} for a in acks]}


@router.post("/{alert_id}/review")
def review(alert_id: str, payload: AlertReviewRequest, request: Request, db: Session = Depends(get_db),
           principal: Principal = Depends(require_analyst)):
    """Human authorisation gate for AEGIS-generated advisories."""
    ratelimit.write_limit(request)
    alert = db.get(models.Alert, alert_id)
    if alert is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "alert not found")
    if alert.alert_kind == "official_ingested":
        raise HTTPException(status.HTTP_409_CONFLICT,
                            "Official warnings are ingested products — they cannot be edited or 'approved' in AEGIS. "
                            "Amendments must come from the issuing authority.")
    before = {"status": alert.status}
    if payload.decision == "approve":
        alert.status = "approved"
    elif payload.decision == "publish":
        alert.status = "published"
        alert.review_required = False
    elif payload.decision == "request_changes":
        alert.status = "draft"
    else:
        alert.status = "rejected"
    alert.reviewed_by = principal.id
    alert.reviewed_at = now()
    alert.review_note = payload.note
    db.add(models.AuditLog(actor=principal.email, actor_role=principal.role, action=f"alert.{payload.decision}",
                           entity_type="alert", entity_id=alert.id, before=before,
                           after={"status": alert.status}, reason=payload.note))
    dispatch = []
    if alert.status == "published" and payload.notify_channels:
        dispatch = notifications.dispatch(db, alert, channels=payload.notify_channels)
    db.commit()
    return {"ok": True, "alert": presenters.alert_out(alert), "decision": payload.decision,
            "notifications": dispatch,
            "note": ("Published to the in-app feed with the AEGIS origin clearly labelled. It is NOT an official "
                     "warning; official warnings come only from the issuing authority.")}


@router.post("/{alert_id}/ack")
def acknowledge(alert_id: str, payload: AlertAckRequest, request: Request, db: Session = Depends(get_db),
                principal: Principal = Depends(require_role("citizen"))):
    ratelimit.write_limit(request)
    alert = db.get(models.Alert, alert_id)
    if alert is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "alert not found")
    if alert.status != "published":
        raise HTTPException(status.HTTP_409_CONFLICT, "Only published alerts can be acknowledged.")
    existing = db.scalar(select(models.AlertAcknowledgement).where(
        models.AlertAcknowledgement.alert_id == alert.id,
        models.AlertAcknowledgement.user_id == principal.id))
    if existing:
        existing.note = payload.note or existing.note
        existing.acknowledged_at = now()
    else:
        db.add(models.AlertAcknowledgement(alert_id=alert.id, user_id=principal.id, note=payload.note,
                                           status_at_ack=alert.status))
    db.add(models.AuditLog(actor=principal.email, actor_role=principal.role, action="alert.acknowledge",
                           entity_type="alert", entity_id=alert.id, after={"status": alert.status},
                           reason=payload.note[:300]))
    db.commit()
    return {"ok": True, "alert_id": alert.id, "acknowledged_by": principal.email,
            "acknowledged_at": now().isoformat() + "Z"}


@router.get("/channels/status")
def channel_status(request: Request, principal: Principal = Depends(require_analyst)):
    """Notification channel configuration (email/SMS/push/webhook) — nothing enabled by default."""
    ratelimit.read_limit(request)
    return notifications.channel_status()


@router.post("/channels/test")
def channel_test(payload: NotificationTestRequest, request: Request, db: Session = Depends(get_db),
                 principal: Principal = Depends(require_role("admin"))):
    """Send a test notification through a configured channel (admin only; never sends real alerts)."""
    ratelimit.write_limit(request)
    result = notifications.send(db, channel=payload.channel, target=payload.target,
                                subject="AEGIS notification channel test",
                                body=("This is a test message from AEGIS. It is not an alert. "
                                      "Configured channels are used only for alerts approved by an authorised user."),
                                alert_id=None)
    db.add(models.AuditLog(actor=principal.email, actor_role=principal.role, action="notifications.test",
                           entity_type="channel", entity_id=payload.channel, after=result,
                           reason="channel test (no alert sent)"))
    db.commit()
    return result


@router.get("/export/geojson")
def export_geojson(request: Request, db: Session = Depends(get_db), kind: str = "published",
                   principal: Principal = Depends(get_principal)):
    """GeoJSON feed of alerts (published only for non-analyst users)."""
    ratelimit.read_limit(request)
    stmt = select(models.Alert).where(models.Alert.lat.isnot(None)).order_by(models.Alert.issued_at.desc()).limit(500)
    if not principal.at_least("analyst") or kind == "published":
        stmt = stmt.where(models.Alert.status == "published")
    features = []
    for a in db.scalars(stmt):
        geom = {"type": "Point", "coordinates": [a.lon, a.lat]} if a.lat is not None and a.lon is not None else None
        if a.area_geojson:
            geom = a.area_geojson
        features.append({"type": "Feature", "geometry": geom, "properties": {
            "id": a.id, "title": a.title, "kind": a.alert_kind, "severity": a.severity, "hazard": a.hazard,
            "authority": a.authority or None, "status": a.status, "issued_at": a.issued_at.isoformat() + "Z",
            "source": a.source_key, "is_official": a.alert_kind == "official_ingested",
            "is_demo": a.data_origin == "demo", "confidence": a.confidence,
        }})
    return {"type": "FeatureCollection", "features": features,
            "generated_at": now().isoformat() + "Z",
            "license_note": ("Official alert content belongs to the issuing authority; AEGIS advisories are labelled "
                             "as such in the 'kind' property.")}
