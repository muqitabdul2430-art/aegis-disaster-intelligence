"""System, taxonomy, safety and observation endpoints."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import ingest, models, presenters, ratelimit
from ..agents.base import AGENT_TIMEOUT_SECONDS, MAX_TOOL_CALLS_PER_TASK
from ..agents.prediction_agent import PROTECTIVE_ACTIONS
from ..agents.response_agent import EMERGENCY_CONTACTS
from ..agents.risk_agent import RISK_BANDS, WEIGHTS, VULNERABILITY_PROXIES
from ..config import settings
from ..db import get_db
from ..llm import llm_client
from ..services import notifications
from ..util import now

router = APIRouter(tags=["system"])


@router.get("/api/health")
def health(request: Request, db: Session = Depends(get_db)):
    """Liveness + readiness. Reports dependency state honestly (never a green light by default)."""
    checks: dict[str, dict] = {}
    ok = True
    try:
        db.execute(select(func.count()).select_from(models.Incident))
        checks["database"] = {"status": "ok", "detail": f"engine={db.bind.dialect.name}"}
    except Exception as exc:  # noqa: BLE001
        ok = False
        checks["database"] = {"status": "error", "detail": str(exc)}
    src_rows = list(db.scalars(select(models.DataSource)))
    now_ = now()
    fresh = [s.key for s in src_rows if s.last_ok_at and (now_ - s.last_ok_at) < timedelta(minutes=120)]
    stale = [s.key for s in src_rows if s.last_ok_at and timedelta(minutes=120) <= (now_ - s.last_ok_at)]
    checks["data_sources"] = {"status": "ok" if fresh else ("stale" if stale else "unknown"),
                              "fresh": fresh, "stale": stale,
                              "unconfigured": [s.key for s in src_rows if s.status in {"no_credentials", "disabled"}]}
    checks["llm"] = {"status": "configured" if llm_client.enabled else "not_configured",
                     "detail": ("LLM narrative layer active" if llm_client.enabled else
                                "Deterministic reasoning layer active (no LLM key)")}
    checks["network"] = {"status": "enabled" if settings.enable_live_network else "disabled"}
    return {"status": "ok" if ok else "degraded", "version": settings.version,
            "environment": settings.environment, "time": now().isoformat(timespec="seconds") + "Z",
            "checks": checks}


@router.get("/api/system/config")
def config(request: Request):
    """Public, non-secret configuration the UI needs (keys are never exposed)."""
    ratelimit.read_limit(request)
    return {
        "app": "AEGIS", "version": settings.version, "environment": settings.environment,
        "demo_mode": settings.demo_mode,
        "features": {
            "live_network": settings.enable_live_network,
            "scheduler": settings.scheduler_enabled,
            "registration_open": settings.allow_registration,
            "osrm_routing": settings.enable_osrm_routing,
            "llm_assistant": llm_client.enabled,
        },
        "limits": {"agent_timeout_seconds": AGENT_TIMEOUT_SECONDS,
                   "max_tool_calls_per_task": MAX_TOOL_CALLS_PER_TASK,
                   "rate_limits_per_minute": {"read": settings.rate_limit_read_per_min,
                                              "write": settings.rate_limit_write_per_min,
                                              "assistant": settings.rate_limit_assistant_per_min}},
        "notifications": notifications.channel_status(),
        "credentials_configured": {
            "nasa_firms": bool(settings.firms_map_key),
            "earthdata_token": bool(settings.earthdata_token),
            "mosdac_token": bool(settings.mosdac_token),
            "copernicus": bool(settings.cdse_client_id),
            "openai_compatible_llm": settings.llm_enabled,
        },
        "disclaimer": ("AEGIS is a decision-support and awareness platform. It is not an official warning service "
                       "and does not replace national/regional emergency authorities."),
    }


@router.get("/api/hazards")
def hazards(request: Request):
    """Supported hazard taxonomy with the documented severity bands and guidance sources."""
    ratelimit.read_limit(request)
    return {
        "hazards": [
            {"key": "earthquake", "label": "Earthquake", "detection": "USGS FDSN catalogue (live)",
             "severity_bands": "M<4.5 discarded · 4.5-4.9 →2 · 5.0-5.9 →3 · 6.0-6.9 →4 · ≥7.0 →5"},
            {"key": "tsunami", "label": "Tsunami", "detection": "NOAA NTWC/PTWC bulletins (live, official)",
             "severity_bands": "Information→excluded · Watch→3 · Advisory→4 · Warning→5"},
            {"key": "cyclone", "label": "Cyclone", "detection": "NOAA NHC current storms + GDACS (live, official)",
             "severity_bands": "wind <63 →2 · 63-118 →3 · 119-177 →4 · ≥178 km/h →5"},
            {"key": "flood", "label": "Flood", "detection": "GDACS flood alerts + model rainfall drivers",
             "severity_bands": "GDACS Green→2 · Orange→4 · Red→5"},
            {"key": "wildfire", "label": "Wildfire", "detection": "NASA FIRMS VIIRS hotspots (needs free MAP_KEY)",
             "severity_bands": "cluster size & FRP → currently capped at 3 until corroborated"},
            {"key": "landslide", "label": "Landslide", "detection": "Citizen reports + rainfall proxies (no public sensor feed)",
             "severity_bands": "analyst-assigned; default 3 while unverified"},
            {"key": "industrial_fire", "label": "Industrial fire", "detection": "Citizen reports + thermal anomalies near industry",
             "severity_bands": "analyst-assigned; default 3-4 pending verification"},
        ],
        "verification_states": [
            {"key": "preliminary_detection", "label": "Preliminary detection",
             "meaning": "A signal was detected but not independently corroborated."},
            {"key": "corroborated", "label": "Corroborated",
             "meaning": "Two or more independent sources agree (signal + authority/instrument)."},
            {"key": "human_verified", "label": "Human verified", "meaning": "An AEGIS analyst confirmed the event."},
            {"key": "officially_confirmed", "label": "Officially confirmed",
             "meaning": "An issuing authority has confirmed the event (or the incident IS an official bulletin)."},
            {"key": "unverified_citizen", "label": "Unverified citizen report",
             "meaning": "Based solely on citizen submissions; never used to trigger public alerts."},
            {"key": "rejected", "label": "Rejected", "meaning": "Reviewed and not accepted; kept for the audit trail."},
        ],
        "risk_methodology": {
            "version": "risk-v1.0",
            "formula": "risk = w_hazard·hazard_score + w_exposure·exposure_score + w_vulnerability·vulnerability_score",
            "weights": WEIGHTS, "bands": RISK_BANDS, "vulnerability_priors": VULNERABILITY_PROXIES,
            "limitations": ("Vulnerability uses a documented static hazard-level prior (no sub-national vulnerability "
                            "index integrated). Exposure uses a static gazetteer population snapshot. Weather inputs "
                            "are model fields. Route/road status is not modelled."),
        },
        "protective_actions": PROTECTIVE_ACTIONS,
        "emergency_contacts": EMERGENCY_CONTACTS,
    }


@router.get("/api/safety")
def safety(request: Request):
    """Public safety statement — what AEGIS is and is not."""
    ratelimit.read_limit(request)
    return {
        "statement": ("AEGIS is an awareness and decision-support platform. It is NOT an official warning service. "
                      "In an emergency, contact your local emergency number immediately "
                      "(India: 112 · US: 911) and follow instructions from your national or state disaster "
                      "management authority."),
        "principles": [
            "Official warnings are displayed with the issuing authority and timestamp, verbatim from the source feed.",
            "AEGIS-generated risk values are model estimates and are labelled as such everywhere they appear.",
            "Citizen reports are unverified until an analyst corroborates them.",
            "AI agents cannot issue, amend or cancel official warnings; publishing an AEGIS advisory requires an "
            "authorised human decision.",
            "AEGIS never states that a route is safe: road closures, debris and flood depth are not available from "
            "the integrated sources.",
            "Data gaps, stale feeds and unavailable sources are shown prominently rather than hidden.",
        ],
        "privacy": ("Citizen reporter identity is stored as a salted one-way hash. Exact report coordinates and any "
                    "optional contact detail are restricted to analyst/admin roles; public views round coordinates "
                    "to ~1 km."),
        "contacts": EMERGENCY_CONTACTS,
        "data_attribution": [
            {"provider": "USGS", "role": "earthquake catalogue", "license": "US Government public domain"},
            {"provider": "NOAA NHC / NWS", "role": "tropical cyclone + tsunami official products",
             "license": "US Government public domain"},
            {"provider": "GDACS (EC JRC / UN OCHA)", "role": "multi-hazard alerts + impact estimates",
             "license": "JRC terms, attribution required"},
            {"provider": "NASA FIRMS / GIBS", "role": "fire hotspots and imagery", "license": "NASA open data"},
            {"provider": "Open-Meteo", "role": "forecast model fields", "license": "CC-BY 4.0"},
            {"provider": "OpenStreetMap contributors", "role": "map tiles, facilities, geocoding", "license": "ODbL 1.0"},
            {"provider": "Natural Earth", "role": "offline basemap + populated places", "license": "Public domain"},
        ],
    }


@router.get("/api/observations")
def observations(request: Request, db: Session = Depends(get_db), source_key: str | None = None,
                 category: str | None = None, hours: int = Query(default=48, ge=1, le=24 * 30),
                 bbox: str | None = None, only_new: bool = False, limit: int = Query(default=200, ge=1, le=1000),
                 include_payload: bool = False):
    """Raw observation feed (provenance-first: source, id, time, payload)."""
    ratelimit.read_limit(request)
    stmt = select(models.Observation).where(models.Observation.observed_at >= now() - timedelta(hours=hours))
    if source_key:
        stmt = stmt.where(models.Observation.source_key.in_([s.strip() for s in source_key.split(",")]))
    if category:
        stmt = stmt.where(models.Observation.hazard_hint.in_([c.strip() for c in category.split(",")]))
    if only_new:
        stmt = stmt.where(models.Observation.incident_id.is_(None))
    if bbox:
        try:
            min_lat, min_lon, max_lat, max_lon = [float(x) for x in bbox.split(",")]
            stmt = stmt.where(models.Observation.lat.between(min_lat, max_lat),
                              models.Observation.lon.between(min_lon, max_lon))
        except ValueError:
            pass
    rows = list(db.scalars(stmt.order_by(models.Observation.observed_at.desc()).limit(limit)))
    by_source = dict(db.execute(
        select(models.Observation.source_key, func.count())
        .where(models.Observation.observed_at >= now() - timedelta(hours=hours))
        .group_by(models.Observation.source_key)).all())
    return {"count": len(rows), "by_source": by_source,
            "observations": [presenters.observation_out(o, include_payload=include_payload) for o in rows],
            "note": ("Observations are raw provider records. A single observation is not a confirmed incident — "
                     "detection and verification happen downstream (see /api/incidents).")}


@router.get("/api/audit")
def audit(request: Request, db: Session = Depends(get_db), limit: int = Query(default=100, ge=1, le=500)):
    ratelimit.read_limit(request)
    rows = list(db.scalars(select(models.AuditLog).order_by(models.AuditLog.at.desc()).limit(limit)))
    return {"count": len(rows), "audit": [presenters.audit_out(a) for a in rows],
            "note": "Audit trail of significant actions: verification changes, alert review decisions, ingestion, runs."}
