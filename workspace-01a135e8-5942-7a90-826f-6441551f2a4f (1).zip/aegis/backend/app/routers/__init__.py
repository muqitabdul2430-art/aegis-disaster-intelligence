"""API routers. Each module owns one prefix of the public surface."""

__all__ = [
    "agents_api", "alerts", "assistant", "auth", "dashboard", "geo",
    "incidents", "reports", "sources", "system",
]
