"""Data-source registry, health, probes and ingestion control."""
from __future__ import annotations

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import ingest, models, presenters, ratelimit
from ..config import settings
from ..db import get_db
from ..schemas import IngestRequest
from ..security import Principal, require_role
from ..sources.base import LINK_ONLY, LIVE_NOW, NEEDS_CREDENTIALS, SOURCE_CATALOG
from ..util import now

router = APIRouter(prefix="/api/sources", tags=["data-sources"])


@router.get("")
def list_sources(request: Request, db: Session = Depends(get_db)):
    ratelimit.read_limit(request)
    ingest.ensure_sources(db)
    ingest.reconcile_status(db)
    db.commit()
    sources = list(db.scalars(select(models.DataSource).order_by(models.DataSource.key)))
    latest_sync = {}
    for row in db.scalars(select(models.SourceSyncLog).order_by(models.SourceSyncLog.started_at.desc()).limit(200)):
        latest_sync.setdefault(row.source_key, row)
    return {
        "count": len(sources),
        "sources": [presenters.source_out(s, sync=latest_sync.get(s.key)) for s in sources],
        "capabilities": {
            "working_without_credentials": sorted(LIVE_NOW),
            "requires_credentials": {
                "nasa_firms": "Free instant MAP_KEY — https://firms.modaps.eosdis.nasa.gov/api/map_key/ "
                              "(set AEGIS_FIRMS_MAP_KEY)",
                "isro_mosdac": "ISRO MOSDAC registration required (set AEGIS_MOSDAC_TOKEN)",
                "copernicus_ems": "Copernicus Data Space credentials (set AEGIS_CDSE_CLIENT_ID / _SECRET)",
            },
            "authoritative_link_only": sorted(LINK_ONLY),
        },
        "policy": ("AEGIS never fabricates observations or warnings. A source that cannot be reached is reported as "
                   "unavailable/stale; demonstration records are labelled data_origin='demo'."),
    }


@router.post("/{source_key}/probe")
def probe(source_key: str, request: Request, db: Session = Depends(get_db),
          principal: Principal = Depends(require_role("analyst"))):
    """Connectivity/credentials check for one source."""
    ratelimit.write_limit(request)
    ingest.ensure_sources(db)
    result = ingest.probe_source(db, source_key)
    if result.get("status") == "error" and result.get("error") == "unknown source":
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Unknown source '{source_key}'.")
    return result


@router.post("/ingest")
def trigger_ingest(payload: IngestRequest, request: Request, db: Session = Depends(get_db),
                   principal: Principal = Depends(require_role("admin"))):
    """Run ingestion now (admin only, audited). Synchronous but bounded."""
    ratelimit.check(request, "ingest", 6)
    result = ingest.run_all(db, keys=payload.sources, data_origin=payload.data_origin)
    db.commit()
    return result


@router.post("/ingest/async")
def trigger_ingest_async(payload: IngestRequest, background: BackgroundTasks, request: Request,
                         principal: Principal = Depends(require_role("admin"))):
    """Queue ingestion as a background task (returns immediately)."""
    ratelimit.check(request, "ingest", 6)

    def _job() -> None:
        from ..db import session_scope

        with session_scope() as db:
            ingest.run_all(db, keys=payload.sources, data_origin=payload.data_origin)

    background.add_task(_job)
    return {"queued": True, "sources": payload.sources or "default set",
            "note": "Ingestion queued in the background; refresh the data-source panel for updates."}


@router.get("/syncs")
def syncs(request: Request, db: Session = Depends(get_db), limit: int = Query(default=50, ge=1, le=300),
          source_key: str | None = None):
    ratelimit.read_limit(request)
    stmt = select(models.SourceSyncLog).order_by(models.SourceSyncLog.started_at.desc()).limit(limit)
    if source_key:
        stmt = stmt.where(models.SourceSyncLog.source_key == source_key)
    rows = list(db.scalars(stmt))
    return {"count": len(rows), "syncs": [{
        "id": r.id, "source_key": r.source_key, "status": r.status, "records": r.records,
        "duration_ms": r.duration_ms, "started_at": r.started_at.isoformat() + "Z",
        "finished_at": r.finished_at.isoformat() + "Z" if r.finished_at else None, "message": r.message,
    } for r in rows]}


@router.get("/catalog")
def catalog(request: Request):
    """Static documentation of every provider AEGIS knows about."""
    ratelimit.read_limit(request)
    return {
        "generated_at": now().isoformat() + "Z",
        "sources": [{
            "key": s.key, "name": s.name, "provider": s.provider, "homepage": s.homepage, "docs_url": s.docs_url,
            "license": s.license, "categories": s.categories, "auth_mode": s.auth_mode,
            "credential_env": s.credential_env or None, "role": s.role, "connector": bool(s.connector),
            "reliability_note": s.reliability_note,
            "capability": ("live_now" if s.key in LIVE_NOW else
                           "needs_credentials" if s.key in NEEDS_CREDENTIALS or s.auth_mode in {"api_key", "registration", "token"} else
                           "link_only" if s.key in LINK_ONLY else "unknown"),
        } for s in SOURCE_CATALOG],
        "network": {"live_network_enabled": settings.enable_live_network,
                    "http_timeout_seconds": settings.http_timeout_seconds,
                    "http_retries": settings.http_retries},
    }
