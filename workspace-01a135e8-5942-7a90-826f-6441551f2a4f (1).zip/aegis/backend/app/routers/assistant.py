"""AI Intelligence Assistant — retrieval-grounded Q&A over AEGIS data.

Every answer is produced by executing real coordinator tool calls (retrieval),
which are returned to the client so the user can inspect exactly what was
retrieved, from which source, and when.  LLM output (if configured) is used for
wording only and is always accompanied by the retrieved evidence.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from .. import ratelimit
from ..agents.coordinator import coordinator_agent
from ..db import get_db
from ..llm import llm_client
from ..schemas import AssistantAskRequest
from ..security import Principal, get_principal

router = APIRouter(prefix="/api/assistant", tags=["assistant"])

SUGGESTED = [
    "What active hazards are reported right now, and which are officially confirmed?",
    "Summarise the latest official cyclone and tsunami bulletins we have ingested.",
    "Explain why the highest-risk incident has that risk rating.",
    "Show earthquake events from the last 48 hours with magnitude 4.5 or above.",
    "Which nearby facilities may be relevant for the current highest-severity incident?",
    "What can AEGIS not currently see (data gaps and stale sources)?",
    "Is it safe to drive to the nearest hospital from 17.40, 78.50 during the active incidents?",
    "Which citizen reports are unverified and awaiting review?",
]


@router.get("/suggestions")
def suggestions(request: Request):
    ratelimit.read_limit(request)
    return {"suggestions": SUGGESTED,
            "note": ("Each suggestion is answered by running the coordinator's tool plan over stored records — "
                     "questions are never answered from a hardcoded script.")}


@router.post("/ask")
def ask(payload: AssistantAskRequest, request: Request, db: Session = Depends(get_db),
        principal: Principal = Depends(get_principal)):
    ratelimit.assistant_limit(request)
    ctx = payload.context or {}
    params: dict = {"force_planner": "rules"} if not llm_client.enabled else {}
    if ctx.get("incident_id"):
        params["incident_ids"] = [str(ctx["incident_id"])]
    if ctx.get("bbox"):
        params.setdefault("bbox", ctx["bbox"])
    report = coordinator_agent.run(db, goal=payload.question, trigger="user_query", user=None, params=params)
    db.commit()
    return {
        "question": payload.question,
        "answer": report["headline"],
        "verified_facts": report["verified_facts"],
        "model_estimates": report["model_estimates"],
        "unverified_reports": report["unverified_reports"],
        "data_gaps": report["data_gaps"],
        "sources": report["sources"],
        "recommended_next_steps": report["recommended_next_steps"],
        "requires_human_approval": report["requires_human_approval"],
        "plan": report["plan"],
        "execution": report["execution"],
        "run_id": report.get("run_id"),
        "run_code": report.get("run_code"),
        "duration_ms": report.get("duration_ms"),
        "llm_used": report.get("llm_used"),
        "llm_note": report.get("llm_note"),
        "separation_note": report.get("separation_note"),
        "retrieval_note": ("The answer above is generated only from the retrieved records listed in this response. "
                           "Open the run to see every tool call, its arguments and its result."),
        "principal": principal.as_dict(),
    }
