"""Geospatial utilities: geocoding, places, facilities, weather, route checks, GIBS layers."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, presenters, ratelimit
from ..config import settings
from ..db import get_db
from ..schemas import RouteCheckRequest
from ..security import Principal, get_principal
from ..services import facilities as fac_service
from ..services import geo
from ..services import weather as wx_service
from ..sources import nasa_gibs

router = APIRouter(prefix="/api/geo", tags=["geospatial"])


@router.get("/places")
def places(request: Request, lat: float, lon: float, limit: int = 5):
    """Nearest populated places from the bundled offline gazetteer (Natural Earth)."""
    ratelimit.check(request, "read", 120)
    return {"source": "Natural Earth 10m populated places (public domain, bundled offline)",
            "query": {"lat": lat, "lon": lon}, "places": geo.nearest_places(lat, lon, limit=min(limit, 25))}


@router.get("/reverse")
def reverse(request: Request, lat: float, lon: float):
    """Reverse geocode (Nominatim, ODbL) with offline gazetteer fallback."""
    ratelimit.check(request, "read", 60)
    return fac_service.reverse_geocode(lat, lon)


@router.get("/facilities")
def facilities(request: Request, lat: float, lon: float, radius_km: float = Query(default=25, ge=1, le=150)):
    """Critical facilities near a point (OpenStreetMap Overpass, cached)."""
    ratelimit.check(request, "read", 40)
    return fac_service.nearby_facilities(lat, lon, radius_km)


@router.get("/weather")
def weather(request: Request, lat: float, lon: float, past_days: int = Query(default=2, ge=0, le=5),
            forecast_days: int = Query(default=3, ge=1, le=7)):
    """Model forecast fields (Open-Meteo). MODEL OUTPUT — not measurements."""
    ratelimit.check(request, "read", 60)
    data = wx_service.forecast(lat, lon, past_days=past_days, forecast_days=forecast_days)
    if not data.get("ok"):
        return {"ok": False, "error": data.get("error"), "error_kind": data.get("error_kind"),
                "note": "Weather model unavailable — hazard-driver enrichment was skipped for this request."}
    data["drivers"] = {
        "flood": wx_service.flood_drivers(data),
        "wind": wx_service.wind_drivers(data),
        "fire_weather": wx_service.heat_dryness_drivers(data),
        "landslide": wx_service.landslide_drivers(data),
    }
    return data


@router.post("/route-check")
def route_check(payload: RouteCheckRequest, request: Request, db: Session = Depends(get_db),
                principal: Principal = Depends(get_principal)):
    """Corridor hazard check between two points. AEGIS never certifies a route as safe."""
    ratelimit.write_limit(request)
    inc = db.get(models.Incident, payload.incident_id) or db.scalar(
        select(models.Incident).where(models.Incident.code == payload.incident_id))
    if inc is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Incident '{payload.incident_id}' not found.")
    from ..agents.response_agent import response_agent

    result = response_agent.route_assessment(
        db, inc, from_lat=payload.from_lat, from_lon=payload.from_lon,
        to_lat=payload.to_lat if payload.to_lat is not None else inc.lat,
        to_lon=payload.to_lon if payload.to_lon is not None else inc.lon)
    return {"incident": {"id": inc.id, "code": inc.code, "category": inc.category},
            "routing_enabled": settings.enable_osrm_routing, **result}


@router.post("/footprint")
def footprint(request: Request, lat: float, lon: float, radius_km: float = Query(ge=1, le=400),
              label: str = "AEGIS estimate"):
    """Standalone footprint estimate + population exposure (model estimate)."""
    ratelimit.write_limit(request)
    polygon = geo.circle_polygon(lat, lon, radius_km)
    pop, places_near = geo.population_within_km(lat, lon, radius_km)
    return {"label": label, "radius_km": radius_km, "geojson": polygon,
            "area_km2": round(geo.polygon_area_km2(polygon), 1),
            "population_estimate": pop,
            "population_method": ("Static gazetteer (Natural Earth population attributes); places inside the radius, "
                                  "edge places weighted 0.5. First-order estimate only."),
            "nearest_places": places_near[:10],
            "is_estimate": True}


@router.get("/gibs-layers")
def gibs_layers(request: Request):
    """NASA GIBS imagery overlays available to the map (attribution included)."""
    ratelimit.check(request, "read", 60)
    return {
        "provider": "NASA EOSDIS GIBS",
        "docs": "https://nasa-gibs.github.io/gibs-api-docs/",
        "note": ("Imagery overlays are visual context. Tile URLs are built client-side; dates must be recent "
                 "(imagery lag is typically 1-2 days)."),
        "layers": nasa_gibs.available_layers(),
    }
