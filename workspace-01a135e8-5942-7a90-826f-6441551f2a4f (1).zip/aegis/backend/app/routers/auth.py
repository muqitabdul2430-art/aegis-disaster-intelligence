"""Auth + session endpoints."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, ratelimit
from ..config import settings
from ..db import get_db
from ..schemas import LoginRequest, RegisterRequest
from ..security import (Principal, authenticate, create_token, get_principal, hash_password,
                        require_user, verify_password)
from ..util import now

log = logging.getLogger("aegis.api.auth")
router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/register")
def register(payload: RegisterRequest, request: Request, db: Session = Depends(get_db)):
    ratelimit.check(request, "register", 10)
    if not settings.allow_registration:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Self-registration is disabled for this deployment.")
    email = payload.email.strip().lower()
    if db.scalar(select(models.User).where(models.User.email == email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists.")
    user = models.User(email=email, name=payload.name or email.split("@")[0], org=payload.org,
                       role="citizen", password_hash=hash_password(payload.password))
    db.add(user)
    db.flush()
    db.add(models.AuditLog(actor=user.email, actor_role=user.role, action="auth.register",
                           entity_type="user", entity_id=user.id, reason="self-registration"))
    db.commit()
    return {"user": {"id": user.id, "email": user.email, "name": user.name, "org": user.org, "role": user.role},
            "token": create_token(user),
            "role_note": ("Self-registered accounts have the 'citizen' role: they can submit reports and read "
                          "published intelligence. Analyst/admin capabilities (verification, alert authorisation, "
                          "ingestion) are provisioned by an administrator.")}


@router.post("/login")
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    ratelimit.check(request, "login", 12)
    user = authenticate(db, payload.email, payload.password)
    if user is None:
        db.add(models.AuditLog(actor=payload.email[:80], actor_role="unknown", action="auth.login_failed",
                               entity_type="user", entity_id="-", reason="invalid credentials"))
        db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password.")
    db.add(models.AuditLog(actor=user.email, actor_role=user.role, action="auth.login", entity_type="user",
                           entity_id=user.id))
    db.commit()
    return {"user": {"id": user.id, "email": user.email, "name": user.name, "org": user.org, "role": user.role},
            "token": create_token(user)}


@router.get("/me")
def me(principal: Principal = Depends(get_principal), db: Session = Depends(get_db)):
    if not principal.authenticated:
        return {"authenticated": False, "role": "guest",
                "capabilities": {"submit_report": True, "read_intel": True, "verify_incident": False,
                                 "publish_alert": False, "trigger_ingest": False}}
    user = db.get(models.User, principal.id)
    return {
        "authenticated": True,
        "user": {"id": user.id, "email": user.email, "name": user.name, "org": user.org, "role": user.role,
                 "created_at": user.created_at.isoformat() + "Z", "last_login_at": user.last_login_at.isoformat() + "Z" if user.last_login_at else None},
        "capabilities": {
            "submit_report": True, "read_intel": True,
            "verify_incident": principal.at_least("analyst"),
            "publish_alert": principal.at_least("analyst"),
            "trigger_ingest": principal.at_least("admin"),
            "manage_users": principal.at_least("admin"),
        },
    }


@router.post("/change-password")
def change_password(payload: dict, principal: Principal = Depends(require_user), db: Session = Depends(get_db)):
    current = str(payload.get("current_password") or "")
    new = str(payload.get("new_password") or "")
    if len(new) < 8:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "New password must be at least 8 characters.")
    user = db.get(models.User, principal.id)
    if not verify_password(current, user.password_hash):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Current password is incorrect.")
    user.password_hash = hash_password(new)
    db.add(models.AuditLog(actor=user.email, actor_role=user.role, action="auth.change_password",
                           entity_type="user", entity_id=user.id, reason="user initiated"))
    db.commit()
    return {"ok": True, "changed_at": now().isoformat() + "Z"}
