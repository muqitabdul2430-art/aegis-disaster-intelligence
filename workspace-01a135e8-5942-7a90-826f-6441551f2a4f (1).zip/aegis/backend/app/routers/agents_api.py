"""Agent operations: registry, execution, run history, workflows."""
from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, presenters, ratelimit
from ..agents.classification_agent import classification_agent
from ..agents.coordinator import coordinator_agent
from ..agents.detection_agent import detection_agent
from ..agents.geo_agent import geo_agent
from ..agents.prediction_agent import prediction_agent
from ..agents.response_agent import response_agent
from ..agents.risk_agent import RISK_BANDS, WEIGHTS, risk_agent
from ..db import get_db
from ..llm import llm_client
from ..schemas import AgentRunRequest
from ..security import Principal, require_role
from ..util import now

router = APIRouter(prefix="/api/agents", tags=["agents"])

REGISTRY = [
    {"name": "detection_agent", "role": "Agent 1 — Detection", "description": detection_agent.description,
     "capabilities": detection_agent.capabilities,
     "inputs": ["observations (USGS/GDACS/NHC/NOAA/FIRMS)", "watch regions"],
     "outputs": ["candidate incidents", "correlated observations", "source references", "confidence"]},
    {"name": "classification_agent", "role": "Agent 2 — Classification", "description": classification_agent.description,
     "capabilities": classification_agent.capabilities,
     "inputs": ["incident evidence records", "observation payloads", "citizen report text"],
     "outputs": ["hazard category", "confidence", "rationale", "ambiguity flag"]},
    {"name": "geo_agent", "role": "Agent 3 — Geospatial Intelligence", "description": geo_agent.description,
     "capabilities": geo_agent.capabilities,
     "inputs": ["coordinates", "OpenStreetMap Overpass", "Nominatim", "offline gazetteer", "GDACS polygons"],
     "outputs": ["region", "estimated footprint", "population exposure", "nearby facilities"]},
    {"name": "risk_agent", "role": "Agent 4 — Risk & Impact", "description": risk_agent.description,
     "capabilities": risk_agent.capabilities,
     "inputs": ["severity band", "evidence", "exposure inputs", "weather drivers (model fields)"],
     "outputs": ["risk score 0-100", "risk level", "factor contributions", "limitations"]},
    {"name": "prediction_agent", "role": "Agent 5 — Prediction & Early Warning",
     "description": prediction_agent.description, "capabilities": prediction_agent.capabilities,
     "inputs": ["risk history", "official forecast products (NHC/GDACS/bulletins)", "Open-Meteo model fields"],
     "outputs": ["trend/escalation", "official forecast links", "labelled AEGIS extrapolation", "draft alerts"]},
    {"name": "citizen_agent", "role": "Agent 6 — Citizen Intelligence",
     "description": "Validates, de-duplicates and triages citizen reports; protects reporter privacy; routes "
                    "high-priority or suspicious submissions to human review.",
     "capabilities": ["input_validation", "duplicate_detection", "triage", "privacy_protection", "review_routing"],
     "inputs": ["report form (text, coordinates, optional photo, optional contact)"],
     "outputs": ["stored report (unverified)", "duplicate decision", "priority", "review routing"]},
    {"name": "response_agent", "role": "Agent 7 — Emergency Response Support",
     "description": response_agent.description, "capabilities": response_agent.capabilities,
     "inputs": ["hazard category", "facility data", "corridor hazard check"],
     "outputs": ["official guidance + contacts", "facility roles", "route assessment (never certified safe)"]},
    {"name": "coordinator_agent", "role": "Agent 8 — Intelligence Coordinator",
     "description": coordinator_agent.description, "capabilities": coordinator_agent.capabilities,
     "inputs": ["operational goal or user question", "allow-listed tool catalogue"],
     "outputs": ["execution plan", "per-step status/results", "intelligence brief", "approval requirements"]},
]

WORKFLOWS = {
    "situation_report": {
        "goal_template": "Produce a situation report: {focus}",
        "description": "Overview + official warnings + data gaps, then detail the highest-severity incident.",
        "steps": ["status_overview", "official_warnings", "list_incidents", "incident_detail", "data_gaps"],
    },
    "verify_incident": {
        "goal_template": "Verify incident {incident_id}: list its evidence, sources and verification status, and "
                         "identify what corroboration is still missing.",
        "description": "Evidence review for a single incident.",
        "steps": ["incident_detail", "official_warnings", "citizen_reports"],
    },
    "escalation_scan": {
        "goal_template": "Scan for escalating hazards and report any incident whose risk is increasing: {focus}",
        "description": "Trend/escalation scan across active incidents.",
        "steps": ["list_incidents", "official_warnings", "data_gaps"],
    },
    "data_gap_review": {
        "goal_template": "Review data-source health and list what AEGIS currently cannot see: {focus}",
        "description": "Integration health and blind-spot review (requires admin).",
        "steps": ["source_health", "data_gaps"],
    },
}


@router.get("")
def list_agents(request: Request, db: Session = Depends(get_db)):
    ratelimit.read_limit(request)
    return {
        "agents": REGISTRY,
        "llm": llm_client.status(),
        "risk_methodology": {"version": "risk-v1.0", "weights": WEIGHTS, "bands": RISK_BANDS},
        "tool_catalogue": [{"tool": name, "agent": spec.agent, "description": spec.description,
                            "params": list(spec.params)}
                           for name, spec in coordinator_agent.tool_catalogue().items()],
        "workflows": WORKFLOWS,
        "execution_limits": {"agent_timeout_seconds": 90, "max_tool_calls_per_task": 24},
        "architecture_note": ("Agents are real backend components: each step executes database queries, provider HTTP "
                              "calls and deterministic scoring models. The LLM (when configured) is used only for "
                              "intent parsing and narrative composition over retrieved evidence."),
    }


@router.get("/runs")
def list_runs(request: Request, db: Session = Depends(get_db), limit: int = Query(default=30, ge=1, le=200),
              status_filter: str | None = Query(default=None, alias="status"),
              trigger: str | None = None):
    ratelimit.read_limit(request)
    stmt = select(models.AgentRun).order_by(models.AgentRun.started_at.desc()).limit(limit)
    if status_filter:
        stmt = stmt.where(models.AgentRun.status == status_filter)
    if trigger:
        stmt = stmt.where(models.AgentRun.trigger == trigger)
    runs = list(db.scalars(stmt))
    return {"count": len(runs), "runs": [presenters.agent_run_out(r) for r in runs]}


@router.get("/runs/{run_id}")
def run_detail(run_id: str, request: Request, db: Session = Depends(get_db)):
    ratelimit.read_limit(request)
    run = db.get(models.AgentRun, run_id) or db.scalar(select(models.AgentRun).where(models.AgentRun.run_code == run_id))
    if run is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Agent run '{run_id}' not found.")
    tasks = list(db.scalars(select(models.AgentTask).where(models.AgentTask.run_id == run.id)
                            .order_by(models.AgentTask.step_index)))
    return presenters.agent_run_out(run, tasks)


@router.post("/run")
def execute(payload: AgentRunRequest, request: Request, db: Session = Depends(get_db),
            principal: Principal = Depends(require_role("analyst"))):
    """Execute a coordinator workflow. Analyst role required (audited)."""
    ratelimit.check(request, "assistant", 20)
    goal = payload.goal
    if payload.workflow != "freeform":
        wf = WORKFLOWS[payload.workflow]
        focus = payload.goal or "all active hazard types"
        goal = wf["goal_template"].format(focus=focus, incident_id=(payload.incident_ids[0] if payload.incident_ids else ""))
        if payload.workflow == "data_gap_review" and not principal.at_least("admin"):
            raise HTTPException(status.HTTP_403_FORBIDDEN, "The data-gap review workflow requires the admin role.")
    report = coordinator_agent.run(db, goal=goal, trigger="manual", user=None, params={
        "incident_ids": payload.incident_ids,
        "force_planner": payload.force_planner,
    })
    db.add(models.AuditLog(actor=principal.email, actor_role=principal.role, action="agent.run",
                           entity_type="agent_run", entity_id=report.get("run_id") or "-",
                           after={"goal": goal, "workflow": payload.workflow,
                                  "steps": [s["tool"] for s in report.get("execution", [])]},
                           reason="manual agent execution"))
    db.commit()
    return report


@router.get("/runs/{run_id}/approvals")
def run_approvals(run_id: str, request: Request, db: Session = Depends(get_db)):
    """Actions a run proposes that require human authorisation."""
    ratelimit.read_limit(request)
    run = db.get(models.AgentRun, run_id)
    if run is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "run not found")
    report = run.report or {}
    return {"run_id": run.id, "run_code": run.run_code,
            "requires_human_approval": report.get("requires_human_approval", []),
            "policy": ("Consequential external actions (publishing an alert, sending notifications, changing an "
                       "incident's verification status) are never executed by agents; they require an authorised "
                       "analyst/admin decision and are written to the audit log.")}


@router.post("/runs/{run_id}/approve")
def approve_run(run_id: str, request: Request, db: Session = Depends(get_db),
                principal: Principal = Depends(require_role("analyst")),
                body: dict = Body(default_factory=dict)):
    """Record explicit approval of a run's proposed actions (approval does not itself publish anything)."""
    ratelimit.write_limit(request)
    run = db.get(models.AgentRun, run_id)
    if run is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "run not found")
    run.requires_approval = False
    run.approved_by = principal.id
    run.approved_at = now()
    db.add(models.AuditLog(actor=principal.email, actor_role=principal.role, action="agent.run.approve",
                           entity_type="agent_run", entity_id=run.id,
                           after={"approved_by": principal.email}, reason=str(body.get("note") or "")[:500]))
    db.commit()
    return {"ok": True, "run_id": run.id, "approved_by": principal.email,
            "note": ("Approval recorded. Publishing any alert still requires an explicit alert review decision.")}
