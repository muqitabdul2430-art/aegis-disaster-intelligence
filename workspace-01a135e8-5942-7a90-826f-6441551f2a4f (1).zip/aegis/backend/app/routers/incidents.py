"""Incident intelligence endpoints (list, detail, evidence, assessment, verification)."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, presenters, ratelimit
from ..agents.classification_agent import classification_agent
from ..agents.geo_agent import geo_agent
from ..agents.prediction_agent import prediction_agent
from ..agents.risk_agent import WEIGHTS, RISK_BANDS, risk_agent
from ..agents.response_agent import response_agent
from ..db import get_db
from ..schemas import IncidentAssessRequest, IncidentVerifyRequest
from ..security import Principal, require_analyst, require_role
from ..util import now

router = APIRouter(prefix="/api/incidents", tags=["incidents"])

VERIFICATION_ORDER = ["preliminary_detection", "corroborated", "human_verified", "officially_confirmed"]


@router.get("")
def list_incidents(
    request: Request,
    db: Session = Depends(get_db),
    status_filter: str | None = Query(default="active,monitoring", alias="status"),
    category: str | None = None,
    verification_status: str | None = None,
    min_severity: int | None = Query(default=None, ge=1, le=5),
    data_origin: str | None = Query(default=None, pattern="^(live|demo)$"),
    hours: int | None = Query(default=None, ge=1, le=24 * 30),
    bbox: str | None = Query(default=None, description="min_lat,min_lon,max_lat,max_lon"),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    sort: str = Query(default="severity", pattern="^(severity|recent|risk)$"),
):
    ratelimit.read_limit(request)
    stmt = select(models.Incident)
    if status_filter:
        stmt = stmt.where(models.Incident.status.in_([s.strip() for s in status_filter.split(",") if s.strip()]))
    if category:
        stmt = stmt.where(models.Incident.category.in_([c.strip() for c in category.split(",") if c.strip()]))
    if verification_status:
        stmt = stmt.where(models.Incident.verification_status.in_([v.strip() for v in verification_status.split(",")]))
    if min_severity:
        stmt = stmt.where(models.Incident.severity >= min_severity)
    if data_origin:
        stmt = stmt.where(models.Incident.data_origin == data_origin)
    if hours:
        stmt = stmt.where(models.Incident.last_update_at >= now() - timedelta(hours=hours))
    if bbox:
        try:
            min_lat, min_lon, max_lat, max_lon = [float(x) for x in bbox.split(",")]
            stmt = stmt.where(models.Incident.lat.between(min_lat, max_lat),
                              models.Incident.lon.between(min_lon, max_lon))
        except ValueError as exc:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "bbox must be 'min_lat,min_lon,max_lat,max_lon'") from exc

    total = len(list(db.scalars(stmt)))
    if sort == "recent":
        stmt = stmt.order_by(models.Incident.last_update_at.desc())
    elif sort == "risk":
        stmt = stmt.order_by(models.Incident.severity.desc(), models.Incident.confidence.desc())
    else:
        stmt = stmt.order_by(models.Incident.severity.desc(), models.Incident.last_update_at.desc())
    rows = list(db.scalars(stmt.limit(limit).offset(offset)))
    risks = presenters.latest_risk_map(db, [r.id for r in rows])
    areas = {}
    if rows:
        for a in db.scalars(select(models.AffectedArea).where(models.AffectedArea.incident_id.in_([r.id for r in rows]))):
            areas.setdefault(a.incident_id, []).append(a)
    return {
        "total": total,
        "count": len(rows),
        "incidents": [presenters.incident_out(r, risks.get(r.id), areas=areas.get(r.id, [])) for r in rows],
        "filters_applied": {"status": status_filter, "category": category, "verification_status": verification_status,
                            "min_severity": min_severity, "data_origin": data_origin, "hours": hours, "bbox": bbox},
    }


@router.get("/{incident_id}")
def incident_detail(incident_id: str, request: Request, db: Session = Depends(get_db)):
    ratelimit.read_limit(request)
    inc = _resolve(db, incident_id)
    evidence = list(db.scalars(select(models.IncidentEvidence)
                               .where(models.IncidentEvidence.incident_id == inc.id)
                               .order_by(models.IncidentEvidence.observed_at.desc().nullslast())))
    observations = list(db.scalars(select(models.Observation).where(models.Observation.incident_id == inc.id)
                                   .order_by(models.Observation.observed_at.desc()).limit(60)))
    risks = list(db.scalars(select(models.RiskAssessment).where(models.RiskAssessment.incident_id == inc.id)
                            .order_by(models.RiskAssessment.created_at.desc()).limit(10)))
    alerts = list(db.scalars(select(models.Alert).where(models.Alert.incident_id == inc.id)
                             .order_by(models.Alert.issued_at.desc()).limit(20)))
    areas = list(db.scalars(select(models.AffectedArea).where(models.AffectedArea.incident_id == inc.id)))
    reports = list(db.scalars(select(models.CitizenReport).where(models.CitizenReport.linked_incident_id == inc.id)
                              .order_by(models.CitizenReport.created_at.desc()).limit(20)))
    audit = list(db.scalars(select(models.AuditLog).where(models.AuditLog.entity_id == inc.id)
                            .order_by(models.AuditLog.at.desc()).limit(20)))
    risk = risks[0] if risks else None
    detail = presenters.incident_out(inc, risk, areas=areas, detail=True)
    detail["evidence"] = [presenters.evidence_out(e) for e in evidence]
    detail["observations"] = [presenters.observation_out(o) for o in observations]
    detail["risk_assessments"] = [presenters.risk_out(r) for r in risks]
    detail["alerts"] = [presenters.alert_out(a, incident=inc) for a in alerts]
    detail["citizen_reports"] = [presenters.report_out(r, privileged=False) for r in reports]
    detail["audit_trail"] = [presenters.audit_out(a) for a in audit]
    detail["risk_history"] = [{"at": r.created_at.isoformat() + "Z", "risk_score": r.risk_score,
                               "risk_level": r.risk_level, "hazard": r.hazard_score,
                               "exposure": r.exposure_score, "vulnerability": r.vulnerability_score}
                              for r in sorted(risks, key=lambda x: x.created_at)]
    detail["recommended_next_steps"] = _next_steps(inc, risk)
    return detail


@router.get("/{incident_id}/context")
def incident_context(incident_id: str, request: Request, db: Session = Depends(get_db), radius_km: float = 25.0):
    """Geospatial intelligence for an incident: region, footprint, facilities."""
    ratelimit.check(request, "read", 60)
    inc = _resolve(db, incident_id)
    report = geo_agent.context_report(db, inc, None, radius_km=radius_km, persist=False, include_facilities=True)
    return {"incident_id": inc.id, "code": inc.code, **report}


@router.get("/{incident_id}/risk")
def incident_risk(incident_id: str, request: Request, db: Session = Depends(get_db)):
    """Latest explainable risk assessment (recomputes if none exists yet)."""
    ratelimit.check(request, "read", 60)
    inc = _resolve(db, incident_id)
    last = db.scalar(select(models.RiskAssessment).where(models.RiskAssessment.incident_id == inc.id)
                     .order_by(models.RiskAssessment.created_at.desc()))
    if last is None:
        result = risk_agent.assess(db, inc, None, persist=True)
        last = db.get(models.RiskAssessment, result["assessment_id"])
    return {"incident_id": inc.id, "code": inc.code, "assessment": presenters.risk_out(last),
            "methodology": {"version": last.methodology_version, "weights": WEIGHTS, "bands": RISK_BANDS,
                            "explanation": ("risk = w_hazard·hazard + w_exposure·exposure + w_vulnerability·vulnerability; "
                                            "each factor's contribution is listed in 'factors'.")}}


@router.get("/{incident_id}/outlook")
def incident_outlook(incident_id: str, request: Request, db: Session = Depends(get_db)):
    """Trend + official forecast products + AEGIS extrapolation (labelled)."""
    ratelimit.check(request, "read", 60)
    inc = _resolve(db, incident_id)
    return {"incident_id": inc.id, "code": inc.code,
            "trend": prediction_agent.trend(db, inc),
            "forecast": prediction_agent.official_forecast(db, inc),
            "validation_note": ("AEGIS extrapolations are not skill-validated and are never labelled as official "
                                "forecast tracks.")}


@router.get("/{incident_id}/response")
def incident_response(incident_id: str, request: Request, db: Session = Depends(get_db), radius_km: float = 25.0):
    """Official guidance, contacts and nearby response facilities."""
    ratelimit.check(request, "read", 60)
    inc = _resolve(db, incident_id)
    return {"incident_id": inc.id, "code": inc.code,
            "guidance": response_agent.guidance(db, inc),
            "facilities": response_agent.facilities_support(inc, radius_km)}


@router.post("/{incident_id}/assess")
def assess(incident_id: str, payload: IncidentAssessRequest, request: Request, db: Session = Depends(get_db),
           principal: Principal = Depends(require_role("analyst"))):
    """Run the full agent chain (classify → geospatial → risk → prediction) for one incident."""
    ratelimit.write_limit(request)
    inc = _resolve(db, incident_id)
    from ..agents.base import AgentContext

    ctx = AgentContext(db=db, agent_name="api_assess")
    classification = classification_agent.apply(db, inc, ctx)
    geo_report = geo_agent.context_report(db, inc, ctx, radius_km=payload.radius_km,
                                         include_facilities=payload.include_facilities)
    risk = risk_agent.assess(db, inc, ctx, area=geo_report["area"], facilities=geo_report["facilities"])
    trend = prediction_agent.trend(db, inc)
    forecast = prediction_agent.official_forecast(db, inc)
    draft = prediction_agent.draft_alert(db, inc, risk, trend, forecast, ctx) if payload.draft_alerts else None
    db.add(models.AuditLog(actor=principal.email, actor_role=principal.role, action="incident.assess",
                           entity_type="incident", entity_id=inc.id,
                           after={"risk_score": risk["risk_score"], "risk_level": risk["risk_level"],
                                  "draft_alert_id": draft.id if draft else None},
                           reason="analyst-triggered full assessment"))
    db.commit()
    return {"incident_id": inc.id, "code": inc.code, "classification": classification,
            "geospatial": geo_report, "risk": risk, "trend": trend, "forecast": forecast,
            "draft_alert": ({"id": draft.id, "status": draft.status, "severity": draft.severity,
                             "note": "Draft requires authorised human review before publication."} if draft else None),
            "findings": ctx.findings, "tool_calls": ctx.tool_calls}


@router.post("/{incident_id}/verify")
def verify(incident_id: str, payload: IncidentVerifyRequest, request: Request, db: Session = Depends(get_db),
           principal: Principal = Depends(require_analyst)):
    """Change verification status — restricted, fully audited."""
    ratelimit.write_limit(request)
    inc = _resolve(db, incident_id)
    before = {"verification_status": inc.verification_status, "is_ambiguous": inc.is_ambiguous, "confidence": inc.confidence}
    if payload.verification_status == "officially_confirmed" and not payload.note.strip():
        raise HTTPException(status.HTTP_400_BAD_REQUEST,
                            "Marking an incident 'officially_confirmed' requires a note citing the official source.")
    inc.verification_status = payload.verification_status
    inc.verified_by = principal.id
    inc.verified_at = now()
    if payload.verification_status in {"human_verified", "officially_confirmed"}:
        inc.is_ambiguous = False
        inc.confidence = max(inc.confidence, 80.0)
    if payload.verification_status == "rejected":
        inc.status = "closed"
        inc.confidence = 0.0
    tags = set(inc.tags or [])
    tags.discard("needs_human_review")
    inc.tags = sorted(tags)
    db.add(models.AuditLog(actor=principal.email, actor_role=principal.role, action="incident.verify",
                           entity_type="incident", entity_id=inc.id, before=before,
                           after={"verification_status": inc.verification_status}, reason=payload.note))
    db.commit()
    return {"ok": True, "incident": presenters.incident_out(inc), "note": payload.note,
            "audited": True}


@router.get("/{incident_id}/observations")
def incident_observations(incident_id: str, request: Request, db: Session = Depends(get_db)):
    ratelimit.check(request, "read", 90)
    inc = _resolve(db, incident_id)
    rows = list(db.scalars(select(models.Observation).where(models.Observation.incident_id == inc.id)
                           .order_by(models.Observation.observed_at.desc())))
    return {"incident_id": inc.id, "count": len(rows),
            "observations": [presenters.observation_out(o) for o in rows]}


def _resolve(db: Session, identifier: str) -> models.Incident:
    inc = db.get(models.Incident, identifier) or db.scalar(
        select(models.Incident).where(models.Incident.code == identifier))
    if inc is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Incident '{identifier}' not found.")
    return inc


def _next_steps(inc: models.Incident, risk: models.RiskAssessment | None) -> list[str]:
    steps = []
    if inc.verification_status == "preliminary_detection":
        steps.append("Detection is preliminary: seek independent corroboration (official bulletin, second source, "
                     "analyst review) before treating the event as established.")
    if inc.is_ambiguous:
        steps.append("Hazard category is ambiguous — an analyst should confirm the classification "
                     "(see the classification rationale in the evidence tab).")
    if risk and risk.risk_level in {"high", "extreme"}:
        steps.append("Risk is high/extreme: review the factor breakdown, confirm exposure figures, and decide whether "
                     "an advisory should be published (requires authorised approval).")
    steps.append("Cross-check official warnings from the responsible authority (see the Alerts tab).")
    steps.append("Open the Geospatial tab for the estimated footprint and nearby facilities; confirm facility "
                 "availability by phone before routing anyone there.")
    return steps
