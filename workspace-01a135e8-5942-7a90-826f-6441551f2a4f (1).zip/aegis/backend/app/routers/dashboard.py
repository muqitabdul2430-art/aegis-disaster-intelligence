"""Dashboard aggregation — every number here is derived from stored records."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import models, presenters, ratelimit
from ..config import settings
from ..db import get_db
from ..llm import llm_client
from ..util import now

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/summary")
def summary(request: Request, db: Session = Depends(get_db), hours: int = 72):
    ratelimit.read_limit(request)
    since = now() - timedelta(hours=hours)
    active = list(db.scalars(
        select(models.Incident).where(models.Incident.status.in_(("active", "monitoring")))
        .order_by(models.Incident.severity.desc(), models.Incident.last_update_at.desc())
    ))
    risks = presenters.latest_risk_map(db, [i.id for i in active])
    alert_counts = dict(db.execute(
        select(models.Alert.incident_id, func.count()).where(models.Alert.alert_kind == "official_ingested",
                                                             models.Alert.status == "published")
        .group_by(models.Alert.incident_id)).all())

    by_category = dict(db.execute(
        select(models.Incident.category, func.count()).where(models.Incident.status.in_(("active", "monitoring")))
        .group_by(models.Incident.category)).all())
    by_verification = dict(db.execute(
        select(models.Incident.verification_status, func.count())
        .where(models.Incident.status.in_(("active", "monitoring")))
        .group_by(models.Incident.verification_status)).all())
    by_risk = {}
    for inc in active:
        r = risks.get(inc.id)
        key = r.risk_level if r else "unassessed"
        by_risk[key] = by_risk.get(key, 0) + 1
    by_region = {}
    for inc in active:
        key = inc.country or ("unresolved" if not inc.region else inc.region.split(",")[-1].strip())
        bucket = by_region.setdefault(key or "unresolved", {"count": 0, "max_severity": 0, "max_risk": 0.0, "categories": {}})
        bucket["count"] += 1
        bucket["max_severity"] = max(bucket["max_severity"], inc.severity)
        r = risks.get(inc.id)
        if r:
            bucket["max_risk"] = max(bucket["max_risk"], r.risk_score)
        bucket["categories"][inc.category] = bucket["categories"].get(inc.category, 0) + 1

    official_warnings = list(db.scalars(
        select(models.Alert).where(models.Alert.alert_kind == "official_ingested",
                                   models.Alert.status == "published",
                                   models.Alert.issued_at >= since)
        .order_by(models.Alert.issued_at.desc()).limit(12)))
    pending_review = list(db.scalars(
        select(models.Alert).where(models.Alert.status.in_(("pending_review", "draft")))
        .order_by(models.Alert.created_at.desc()).limit(10)))

    recent_obs = list(db.scalars(select(models.Observation).order_by(models.Observation.observed_at.desc()).limit(12)))
    recent_reports = list(db.scalars(select(models.CitizenReport).order_by(models.CitizenReport.created_at.desc()).limit(8)))
    recent_runs = list(db.scalars(select(models.AgentRun).order_by(models.AgentRun.started_at.desc()).limit(8)))
    sources = list(db.scalars(select(models.DataSource).order_by(models.DataSource.key)))
    latest_sync = {}
    for row in db.scalars(select(models.SourceSyncLog).order_by(models.SourceSyncLog.started_at.desc()).limit(80)):
        latest_sync.setdefault(row.source_key, row)

    demo_count = sum(1 for i in active if i.data_origin == "demo")
    live_count = sum(1 for i in active if i.data_origin != "demo")

    verification_breakdown = {
        "officially_confirmed": by_verification.get("officially_confirmed", 0),
        "human_verified": by_verification.get("human_verified", 0),
        "corroborated": by_verification.get("corroborated", 0),
        "preliminary_detection": by_verification.get("preliminary_detection", 0),
        "unverified_citizen": by_verification.get("unverified_citizen", 0),
        "rejected": by_verification.get("rejected", 0),
    }

    return {
        "generated_at": now().isoformat(timespec="seconds") + "Z",
        "window_hours": hours,
        "counts": {
            "active_incidents": len(active),
            "live_incidents": live_count,
            "demo_incidents": demo_count,
            "official_warnings_recent": len(official_warnings),
            "alerts_awaiting_review": len(pending_review),
            "citizen_reports_recent": int(db.scalar(
                select(func.count()).select_from(models.CitizenReport)
                .where(models.CitizenReport.created_at >= since)) or 0),
            "observations_recent": int(db.scalar(
                select(func.count()).select_from(models.Observation)
                .where(models.Observation.observed_at >= since)) or 0),
        },
        "distribution_by_category": by_category,
        "distribution_by_verification": verification_breakdown,
        "distribution_by_risk_level": by_risk,
        "risk_by_region": by_region,
        "top_incidents": [presenters.incident_out(i, risks.get(i.id), alert_count=alert_counts.get(i.id, 0))
                          for i in active[:8]],
        "official_warnings": [presenters.alert_out(a) for a in official_warnings],
        "alerts_awaiting_review": [presenters.alert_out(a) for a in pending_review],
        "recent_observations": [presenters.observation_out(o, include_payload=False) for o in recent_obs],
        "recent_citizen_reports": [presenters.report_out(r, privileged=False) for r in recent_reports],
        "agent_activity": [presenters.agent_run_out(r) for r in recent_runs],
        "data_sources": [presenters.source_out(s, sync=latest_sync.get(s.key)) for s in sources],
        "system": system_status(db),
        "demo_mode": settings.demo_mode,
        "labels": {
            "demo": ("Records flagged is_demo are LABELLED DEMONSTRATION DATA generated when no live feed was "
                     "available. They are never presented as live observations or official warnings."),
            "estimates": "AEGIS risk scores and footprints are model estimates, not official forecasts.",
        },
    }


def system_status(db: Session) -> dict:
    from ..scheduler import scheduler_state

    src_rows = list(db.scalars(select(models.DataSource)))
    stale = [s.key for s in src_rows if s.last_ok_at and (now() - s.last_ok_at) > timedelta(minutes=180)]
    failed = [s.key for s in src_rows if s.status in {"error", "degraded"}]
    no_creds = [s.key for s in src_rows if s.status == "no_credentials"]
    runs = db.execute(select(models.AgentRun.status, func.count()).group_by(models.AgentRun.status)).all()
    return {
        "version": settings.version,
        "environment": settings.environment,
        "database": "connected",
        "llm": llm_client.status(),
        "scheduler": scheduler_state(),
        "sources": {
            # Live (operational) sources only — the demonstration feed is counted
            # separately so it can never improve the operational health ratio.
            "total": len([s for s in src_rows if not s.is_demo]),
            "ok": sum(1 for s in src_rows if s.status == "ok" and not s.is_demo),
            "stale": stale,
            "failed": failed,
            "no_credentials": no_creds,
            "demo_feeds": sum(1 for s in src_rows if s.is_demo),
        },
        "agent_runs": dict(runs),
        "routing_enabled": settings.enable_osrm_routing,
        "live_network_enabled": settings.enable_live_network,
    }


@router.get("/agent-activity")
def agent_activity(request: Request, db: Session = Depends(get_db), limit: int = 25):
    ratelimit.read_limit(request)
    runs = list(db.scalars(select(models.AgentRun).order_by(models.AgentRun.started_at.desc()).limit(min(limit, 100))))
    return {"runs": [presenters.agent_run_out(r) for r in runs]}


@router.get("/audit")
def audit(request: Request, db: Session = Depends(get_db), limit: int = 50, action: str | None = None):
    ratelimit.read_limit(request)
    stmt = select(models.AuditLog).order_by(models.AuditLog.at.desc()).limit(min(limit, 200))
    if action:
        stmt = stmt.where(models.AuditLog.action.like(f"{action}%"))
    return {"audit": [presenters.audit_out(a) for a in db.scalars(stmt)]}


@router.get("/source-health")
def source_health(request: Request, db: Session = Depends(get_db)):
    ratelimit.read_limit(request)
    sources = list(db.scalars(select(models.DataSource).order_by(models.DataSource.key)))
    latest_sync = {}
    for row in db.scalars(select(models.SourceSyncLog).order_by(models.SourceSyncLog.started_at.desc()).limit(120)):
        latest_sync.setdefault(row.source_key, row)
    logs = list(db.scalars(select(models.SourceSyncLog).order_by(models.SourceSyncLog.started_at.desc()).limit(40)))
    return {
        "sources": [presenters.source_out(s, sync=latest_sync.get(s.key)) for s in sources],
        "recent_syncs": [{"id": l.id, "source_key": l.source_key, "status": l.status, "records": l.records,
                          "duration_ms": l.duration_ms, "started_at": l.started_at.isoformat() + "Z",
                          "finished_at": l.finished_at.isoformat() + "Z" if l.finished_at else None,
                          "message": l.message} for l in logs],
        "system": system_status(db),
    }
