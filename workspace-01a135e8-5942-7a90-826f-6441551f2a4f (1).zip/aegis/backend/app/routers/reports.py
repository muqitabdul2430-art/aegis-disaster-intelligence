"""Citizen reporting portal API.

*   Submission is open (citizens do not need an account) but rate limited.
*   Photos are validated (type/size), hashed (SHA-256) and stored outside any
    public path; only analyst/admin principals can retrieve them.
*   Full coordinates and contact details are only visible to analyst/admin.
"""
from __future__ import annotations

import hashlib
import logging
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile, status
from fastapi.responses import FileResponse
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, presenters, ratelimit
from ..agents.citizen_agent import citizen_agent
from ..config import REPO_DIR, settings
from ..db import get_db
from ..schemas import CitizenReportRequest, CitizenReportReviewRequest
from ..security import Principal, get_principal, require_analyst
from ..util import now, sha256_hex

logger = logging.getLogger("aegis.api.reports")
router = APIRouter(prefix="/api/reports", tags=["citizen-reports"])

UPLOAD_DIR = REPO_DIR / "backend" / "uploads"
MAX_PHOTO_BYTES = 6 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
ALLOWED_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp"}


@router.post("", status_code=status.HTTP_201_CREATED)
async def submit_report(
    request: Request,
    db: Session = Depends(get_db),
    principal: Principal = Depends(get_principal),
    description: str = Form(...),
    category: str = Form(default="unknown"),
    lat: float = Form(...),
    lon: float = Form(...),
    location_source: str = Form(default="map_click"),
    location_accuracy_m: float | None = Form(default=None),
    observed_at: str | None = Form(default=None),
    contact_optin: str | None = Form(default=None),
    reporter_ref: str | None = Form(default=None),
    photo: UploadFile | None = File(default=None),
):
    """Submit an incident report (multipart, optional photo). Stored as UNVERIFIED."""
    ratelimit.check(request, "report_submit", settings.rate_limit_report_submit_per_min)
    try:
        payload = CitizenReportRequest(description=description, category=category, lat=lat, lon=lon,
                                      location_source=location_source, location_accuracy_m=location_accuracy_m,
                                      observed_at=observed_at, contact_optin=contact_optin, reporter_ref=reporter_ref)
    except ValidationError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, {
            "message": "The report could not be accepted — please correct the highlighted fields.",
            "errors": [f"{'.'.join(str(x) for x in e['loc'])}: {e['msg']}" for e in exc.errors()],
            "note": "Nothing was stored. Citizen reports are validated before they enter the analyst queue.",
        }) from exc
    photo_path = None
    photo_sha = None
    if photo is not None and photo.filename:
        suffix = Path(photo.filename).suffix.lower()
        if photo.content_type not in ALLOWED_TYPES and suffix not in ALLOWED_SUFFIXES:
            raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                                f"Unsupported image type '{photo.content_type or suffix}'. Use JPEG, PNG or WebP.")
        data = await photo.read()
        if len(data) > MAX_PHOTO_BYTES:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                                f"Photo too large ({(len(data) / 1e6):.1f} MB). Maximum is 6 MB — it will be kept "
                                "privately for analysts only.")
        photo_sha = sha256_hex(data)
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        ext = ALLOWED_TYPES.get(photo.content_type or "", suffix or ".jpg")
        fname = f"{now().strftime('%Y%m%d')}-{photo_sha[:16]}{ext}"
        (UPLOAD_DIR / fname).write_bytes(data)
        photo_path = fname

    result = citizen_agent.submit(
        db,
        lat=payload.lat, lon=payload.lon, description=payload.description, category=payload.category,
        reporter_id=(principal.id if principal.authenticated else None) or payload.reporter_ref or "anonymous",
        contact_optin=payload.contact_optin, photo_path=photo_path, photo_sha256=photo_sha,
        location_source=payload.location_source, location_accuracy_m=payload.location_accuracy_m,
        observed_at=payload.observed_at,
    )
    if not result.get("created"):
        db.rollback()
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            {"message": "Report could not be accepted.", "errors": result.get("errors", []),
                             "warnings": result.get("warnings", [])})
    db.add(models.AuditLog(actor=(principal.email or "anonymous"), actor_role=principal.role,
                           action="citizen_report.submit", entity_type="citizen_report",
                           entity_id=result["report_id"],
                           after={"status": result["status"], "priority": result["priority"], "category": category},
                           reason="citizen submission"))
    db.commit()
    return result


@router.get("/track/{public_code}")
def track(public_code: str, request: Request, db: Session = Depends(get_db)):
    """Public status lookup for a submitted report (coarse location, no personal data)."""
    ratelimit.check(request, "read", 60)
    rep = db.scalar(select(models.CitizenReport).where(models.CitizenReport.public_code == public_code))
    if rep is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No report found with that reference code.")
    return {"report": presenters.report_out(rep, privileged=False),
            "status_explanation": {
                "submitted": "Received. Awaiting analyst triage.",
                "under_review": "Flagged for priority human review (high-priority or needs disambiguation).",
                "duplicate": "Matched an existing nearby report — grouped as a duplicate.",
                "linked": "Linked as UNVERIFIED evidence to an active incident.",
                "verified": "An analyst corroborated this report.",
                "rejected": "Reviewed and not accepted as a valid incident report.",
            }.get(rep.status, rep.status)}


@router.get("")
def list_reports(request: Request, db: Session = Depends(get_db), status_filter: str | None = Query(default=None, alias="status"),
                 priority: str | None = None, limit: int = Query(default=50, ge=1, le=200),
                 principal: Principal = Depends(require_analyst)):
    """Analyst queue. Includes exact coordinates and review metadata."""
    ratelimit.read_limit(request)
    stmt = select(models.CitizenReport).order_by(models.CitizenReport.created_at.desc()).limit(limit)
    if status_filter:
        stmt = stmt.where(models.CitizenReport.status.in_([s.strip() for s in status_filter.split(",")]))
    if priority:
        stmt = stmt.where(models.CitizenReport.priority == priority)
    rows = list(db.scalars(stmt))
    return {"count": len(rows), "reports": [presenters.report_out(r, privileged=True) for r in rows],
            "queue_note": ("Reports with status 'under_review' need a human decision. Citizen reports never trigger "
                           "public alerts automatically.")}


@router.post("/{report_id}/review")
def review(report_id: str, payload: CitizenReportReviewRequest, request: Request, db: Session = Depends(get_db),
           principal: Principal = Depends(require_analyst)):
    ratelimit.write_limit(request)
    rep = db.get(models.CitizenReport, report_id)
    if rep is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "report not found")
    result = citizen_agent.review(db, rep, action=payload.action, reviewer=principal.email,
                                  notes=payload.notes, incident_id=payload.incident_id)
    if not result.get("ok"):
        db.rollback()
        raise HTTPException(status.HTTP_400_BAD_REQUEST, result.get("error", "review failed"))
    db.commit()
    return result


@router.get("/{report_id}/photo")
def photo(report_id: str, request: Request, db: Session = Depends(get_db),
          principal: Principal = Depends(require_analyst)):
    """Private photo access (analyst/admin only)."""
    ratelimit.check(request, "read", 40)
    rep = db.get(models.CitizenReport, report_id)
    if rep is None or not rep.photo_path:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No photo stored for this report.")
    path = UPLOAD_DIR / rep.photo_path
    if not path.exists():
        raise HTTPException(status.HTTP_410_GONE, "Photo file is no longer available.")
    return FileResponse(path, filename=rep.photo_path,
                        headers={"Cache-Control": "private, no-store",
                                 "X-Content-Privacy": "citizen-submitted, analyst-only"})
