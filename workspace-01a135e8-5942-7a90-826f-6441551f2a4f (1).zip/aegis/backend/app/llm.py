"""Server-side LLM client (OPENAI-COMPATIBLE) with a safe deterministic fallback.

Design constraints (public-safety):
*   The LLM is used for language tasks only: intent parsing (constrained JSON),
    and composing narrative summaries **strictly from evidence supplied in the
    prompt**.  It never produces sensor values, never issues warnings, and
    never invents incidents.
*   Every structured response is validated against an allow-list before use;
    on any failure AEGIS falls back to deterministic rule-based text.
*   The API key stays on the server; nothing here is exposed to the browser.
"""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass
from typing import Any

from .config import settings

log = logging.getLogger("aegis.llm")

SYSTEM_GUARDRAILS = (
    "You are the language layer of AEGIS, a disaster-intelligence decision-support system. "
    "Hard rules: (1) Use ONLY the evidence provided in the prompt; never invent sensor readings, "
    "locations, magnitudes, casualties or official statements. (2) Never claim an event is confirmed "
    "unless the evidence marks it as officially confirmed. (3) Never issue, amend or cancel an official "
    "warning — only reference official warnings and their issuing authority. (4) Distinguish clearly "
    "between verified facts, model estimates, and unverified citizen reports. (5) State uncertainty and "
    "data limitations. (6) Be concise, factual and operational. (7) If evidence is missing for a claim, "
    "say 'insufficient data' instead of guessing."
)


@dataclass
class LLMResult:
    ok: bool
    text: str = ""
    data: dict | None = None
    model: str = ""
    latency_ms: int | None = None
    error: str | None = None
    used: bool = False


class LLMClient:
    def __init__(self) -> None:
        self.model = settings.llm_model
        self.base_url = settings.llm_base_url.rstrip("/")
        self.enabled = settings.llm_enabled

    # ------------------------------------------------------------------ #
    def status(self) -> dict:
        return {
            "enabled": self.enabled,
            "model": self.model if self.enabled else None,
            "base_url": self.base_url if self.enabled else None,
            "mode": "llm" if self.enabled else "rules",
            "note": ("LLM configured server-side (key never exposed to the browser)."
                     if self.enabled else
                     "No LLM key configured (AEGIS_LLM_API_KEY). AEGIS runs its deterministic rule-based "
                     "reasoning layer instead — all agent steps, risk scoring and retrieval still execute for real."),
        }

    def _post(self, messages: list[dict], *, json_mode: bool = False, max_tokens: int = 900,
              temperature: float | None = None) -> LLMResult:
        if not self.enabled:
            return LLMResult(ok=False, error="llm_not_configured")
        body: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": settings.llm_temperature if temperature is None else temperature,
            "max_tokens": max_tokens,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        attempts = settings.llm_max_retries + 1
        last_err = None
        for attempt in range(attempts):
            t0 = time.perf_counter()
            res = _post_json(f"{self.base_url}/chat/completions", body, settings.llm_timeout_seconds)
            latency = int((time.perf_counter() - t0) * 1000)
            if res.ok and isinstance(res.data, dict):
                try:
                    content = res.data["choices"][0]["message"]["content"]
                except (KeyError, IndexError, TypeError) as exc:
                    last_err = f"malformed LLM response: {exc}"
                else:
                    return LLMResult(ok=True, text=content or "", model=self.model, latency_ms=latency, used=True)
            else:
                last_err = res.error or "unknown LLM error"
            if attempt < attempts - 1:
                time.sleep(1.2 * (attempt + 1))
        return LLMResult(ok=False, error=last_err, model=self.model)

    # ------------------------------------------------------------------ #
    def intent_json(self, question: str, tool_help: str, max_tokens: int = 500) -> LLMResult:
        """Parse a natural-language request into a bounded execution plan."""
        schema = (
            '{"intent": "short label", "reasoning": "one sentence", "tools": '
            '[{"agent": "<agent name>", "tool": "<tool name>", "params": {"category": "wildfire", '
            '"bbox": [min_lat,min_lon,max_lat,max_lon], "hours": 72, "incident_id": "inc_...", "lat": 0, "lon": 0, '
            '"radius_km": 25, "limit": 10}}], "answer_style": "brief|detailed"}'
        )
        messages = [
            {"role": "system", "content": SYSTEM_GUARDRAILS},
            {"role": "system", "content":
                "You are the routing layer. Choose ONLY tools from this catalogue and NEVER invent tool names:\n"
                f"{tool_help}\n\n"
                "Return a single JSON object exactly in this shape (omit unused params):\n" + schema},
            {"role": "user", "content": question[:2000]},
        ]
        res = self._post(messages, json_mode=True, max_tokens=max_tokens)
        if res.ok:
            parsed = _extract_json(res.text)
            if isinstance(parsed, dict) and isinstance(parsed.get("tools"), list):
                res.data = parsed
                return res
            res.error = "intent JSON did not match the required shape"
            res.ok = False
        return res

    def narrative(self, retrieved: dict, question: str = "", max_tokens: int = 700) -> LLMResult:
        """Compose a summary strictly from retrieved evidence."""
        messages = [
            {"role": "system", "content": SYSTEM_GUARDRAILS},
            {"role": "system", "content":
                "Write an operational brief (max 220 words) from the JSON evidence provided. Use short paragraphs "
                "or bullets. Always state data sources and timestamps where present. Mark model estimates with "
                "'estimate:'. End with a one-line 'Limitations:' note based on the evidence's limitations fields. "
                "Do not add facts that are not in the JSON."},
            {"role": "user", "content": json.dumps({"question": question, "evidence": retrieved}, default=str)[:12000]},
        ]
        return self._post(messages, max_tokens=max_tokens, temperature=0.2)


def _post_json(url: str, body: dict, timeout: float):
    import httpx

    try:
        with httpx.Client(timeout=timeout) as client:
            resp = client.post(url, json=body, headers={"Content-Type": "application/json"})
        from .sources.http import SourceFetch

        if resp.status_code >= 400:
            return SourceFetch(ok=False, status_code=resp.status_code, error=f"HTTP {resp.status_code}: {resp.text[:200]}")
        return SourceFetch(ok=True, status_code=resp.status_code, data=resp.json())
    except Exception as exc:  # noqa: BLE001
        from .sources.http import SourceFetch

        return SourceFetch(ok=False, error=f"{exc.__class__.__name__}: {exc}", error_kind="network")


def _extract_json(text: str) -> Any:
    if not text:
        return None
    fenced = re.search(r"```(?:json)?\s*(.+?)```", text, re.S)
    candidate = fenced.group(1) if fenced else text
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass
    start, end = candidate.find("{"), candidate.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(candidate[start:end + 1])
        except json.JSONDecodeError:
            return None
    return None


llm_client = LLMClient()
