"""Idempotent seeding: demo accounts, watch regions, alert-rule defaults.

Demo accounts are created ONLY when the configured demo password is present
(AEGIS_DEMO_PASSWORD, default 'aegis-demo-2026' in development) and the users
do not already exist.  In production set AEGIS_ALLOW_REGISTRATION=false and
provision accounts with scripts/create_user.py.
"""
from __future__ import annotations

import logging

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .config import settings
from .security import hash_password
from .util import now

log = logging.getLogger("aegis.seed")

DEMO_USERS = [
    {"email": "admin@aegis.local", "name": "AEGIS Administrator", "role": "admin",
     "org": "Emergency Operations Centre"},
    {"email": "analyst@aegis.local", "name": "Duty Analyst", "role": "analyst",
     "org": "Disaster Intelligence Cell"},
    {"email": "citizen@aegis.local", "name": "Demo Citizen", "role": "citizen", "org": "Public"},
]

WATCH_REGIONS = [
    {"name": "India — national watch", "min_lat": 6.5, "min_lon": 68.0, "max_lat": 37.5, "max_lon": 97.5,
     "categories": ["cyclone", "flood", "landslide", "earthquake", "wildfire", "tsunami"]},
    {"name": "Telangana & Andhra Pradesh", "min_lat": 12.5, "min_lon": 76.5, "max_lat": 19.9, "max_lon": 84.9,
     "categories": ["flood", "cyclone", "industrial_fire", "wildfire"]},
    {"name": "North Indian Ocean basin", "min_lat": -5.0, "min_lon": 45.0, "max_lat": 25.0, "max_lon": 100.0,
     "categories": ["cyclone", "tsunami"]},
    {"name": "Atlantic & Caribbean", "min_lat": 5.0, "min_lon": -100.0, "max_lat": 45.0, "max_lon": -10.0,
     "categories": ["cyclone", "tsunami"]},
]


def seed(db: Session) -> dict:
    created = {"users": [], "watch_regions": []}
    if settings.demo_password:
        for spec in DEMO_USERS:
            email = spec["email"].lower()
            if db.scalar(select(models.User).where(models.User.email == email)):
                continue
            user = models.User(email=email, name=spec["name"], role=spec["role"], org=spec["org"],
                               password_hash=hash_password(settings.demo_password))
            db.add(user)
            created["users"].append({"email": email, "role": spec["role"]})
    for spec in WATCH_REGIONS:
        if db.scalar(select(models.WatchRegion).where(models.WatchRegion.name == spec["name"])):
            continue
        db.add(models.WatchRegion(**spec))
        created["watch_regions"].append(spec["name"])
    if created["users"] or created["watch_regions"]:
        db.add(models.AuditLog(actor="seed", actor_role="system", action="seed.bootstrap", entity_type="system",
                               entity_id="-", after=created, reason="initial bootstrap"))
    db.flush()
    if created["users"]:
        log.warning("demo accounts created (change AEGIS_DEMO_PASSWORD in production): %s",
                    [u["email"] for u in created["users"]])
    return created


def bootstrap() -> dict:
    """Create tables, seed registry/users/regions. Safe to call repeatedly."""
    from . import ingest
    from .db import init_db, session_scope

    init_db()
    with session_scope() as db:
        ingest.ensure_sources(db)
        result = seed(db)
    return {**result, "seeded_at": now().isoformat() + "Z"}
