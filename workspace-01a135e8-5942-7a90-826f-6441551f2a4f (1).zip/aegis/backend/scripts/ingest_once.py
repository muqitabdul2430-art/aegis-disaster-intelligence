#!/usr/bin/env python3
"""Run one ingestion pass from the command line (no scheduler, no server).

Useful for cron jobs, pre-demo warm-up and CI smoke checks. Every fetch is
recorded in `source_sync_log` exactly as it would be in the running app, so
`/api/sources` reflects the outcome.

Examples
--------
    python scripts/ingest_once.py                      # every reachable source
    python scripts/ingest_once.py --sources usgs_earthquake nhc noaa_tsunami
    python scripts/ingest_once.py --dry-run            # list what would run
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.db import SessionLocal, init_db  # noqa: E402
from app.ingest import reconcile_status, run_all  # noqa: E402
from app.sources.base import SOURCE_CATALOG  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description="Run one AEGIS ingestion pass.")
    ap.add_argument("--sources", nargs="*", help="source keys (default: all credential-free connectors)")
    ap.add_argument("--include-firms", action="store_true", help="also attempt NASA FIRMS (needs AEGIS_FIRMS_MAP_KEY)")
    ap.add_argument("--dry-run", action="store_true", help="print the plan without fetching")
    args = ap.parse_args()

    if args.dry_run:
        for spec in SOURCE_CATALOG:
            marker = "connector" if spec.connector else "link-only"
            print(f"{spec.key:20s} {marker:10s} {spec.auth_mode:12s} {spec.name}")
        return

    init_db()
    with SessionLocal() as db:
        results = run_all(db, keys=args.sources, include_firms=args.include_firms or None)
        reconcile_status(db)

    width = max((len(r.get("source", "")) for r in results), default=10)
    ok = sum(1 for r in results if r.get("status") == "ok")
    new = sum(int(r.get("new_observations") or 0) for r in results)
    print(f"\n{'SOURCE'.ljust(width)}  STATUS      RECORDS   NEW   DETAIL")
    for r in results:
        print(f"{str(r.get('source','')).ljust(width)}  {str(r.get('status','')):<10}  "
              f"{str(r.get('records', '')):<7}  {str(r.get('new_observations','')):<5} {str(r.get('error') or r.get('message') or '')[:70]}")
    print(f"\n{ok}/{len(results)} source(s) ok · {new} new observation(s) stored")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
