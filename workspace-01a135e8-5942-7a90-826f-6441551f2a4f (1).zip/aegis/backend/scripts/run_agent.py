#!/usr/bin/env python3
"""Run an AEGIS coordinator workflow from the command line.

Example
-------
    python scripts/run_agent.py "Which hazards are escalating, and what can we not see?" --workflow escalation_scan
    python scripts/run_agent.py "Reassess this event" --incident inc_cf50876d947d --json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.agents.coordinator import coordinator_agent  # noqa: E402
from app.db import SessionLocal, init_db  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description="Run an AEGIS agent workflow locally.")
    ap.add_argument("goal")
    ap.add_argument("--workflow", default="freeform",
                    choices=["freeform", "situation_report", "verify_incident", "escalation_scan", "data_gap_review"])
    ap.add_argument("--incident", action="append", default=[], help="incident id or code (repeatable)")
    ap.add_argument("--json", action="store_true", help="print the full run document")
    args = ap.parse_args()

    goal = args.goal
    if args.workflow != "freeform":
        from app.routers.agents_api import WORKFLOWS

        wf = WORKFLOWS[args.workflow]
        focus = args.goal or "all active hazard types"
        goal = wf["goal_template"].format(focus=focus,
                                          incident_id=(args.incident[0] if args.incident else ""))

    init_db()
    with SessionLocal() as db:
        payload = coordinator_agent.run(db, goal=goal, trigger="cli",
                                        params={"incident_ids": args.incident})
        db.commit()

    if args.json:
        print(json.dumps(payload, indent=2, default=str))
        return

    print(f"run {payload.get('run_code')} | planner: {(payload.get('plan') or {}).get('planner')} | "
          f"{payload.get('duration_ms')} ms")
    print("\nPLAN")
    for i, step in enumerate((payload.get("plan") or {}).get("steps") or [], 1):
        print(f"  {i}. {step['tool']} — {step['why']}")
    print("\nEXECUTION")
    for step in payload.get("execution") or []:
        summary = step.get("summary")
        if isinstance(summary, dict):
            summary = summary.get("note") or ", ".join(f"{k}={v}" for k, v in list(summary.items())[:3])
        print(f"  - {step['tool']:28s} {step['status']:<8} {summary or step.get('error') or ''}")
    print("\nHEADLINE\n ", payload.get("headline"))
    for title, key in (("VERIFIED / OFFICIAL", "verified_facts"), ("AEGIS MODEL ESTIMATES", "model_estimates"),
                       ("UNVERIFIED CITIZEN INPUT", "unverified_reports"), ("DATA GAPS", "data_gaps")):
        items = payload.get(key) or []
        print(f"\n{title} ({len(items)})")
        for item in items[:8]:
            text = item.get("text") if isinstance(item, dict) else str(item)
            if not text and isinstance(item, dict):
                text = item.get("finding") or item.get("gap") or item.get("note") or json.dumps(item)[:160]
            print("  -", str(text)[:160])
    approvals = payload.get("requires_human_approval") or []
    if approvals:
        print(f"\nREQUIRES HUMAN AUTHORISATION ({len(approvals)})")
        for a in approvals:
            print("  -", a)


if __name__ == "__main__":
    main()
