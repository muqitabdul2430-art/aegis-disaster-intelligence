#!/usr/bin/env python3
"""Seed (or clear) AEGIS demonstration data.

The seven scenarios live in `app/demo_data.py`. Every record they create is
tagged `data_origin="demo"` and rendered with a DEMO badge, so demonstration
content can never be mistaken for a live observation.

    python scripts/seed_demo.py --status
    python scripts/seed_demo.py --seed            # insert the labelled scenarios
    python scripts/seed_demo.py --clear           # remove demo rows only
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import delete, func, select, update  # noqa: E402

from app import models  # noqa: E402
from app.db import SessionLocal, init_db  # noqa: E402
from app.demo_data import DEMO_SOURCE_KEY, SCENARIOS, demo_mode_active, seed_demo  # noqa: E402


def _counts(db) -> dict:
    def c(model, *where):
        return db.scalar(select(func.count()).select_from(model).where(*where)) or 0

    return {
        "incidents (demo)": c(models.Incident, models.Incident.data_origin == "demo"),
        "incidents (live)": c(models.Incident, models.Incident.data_origin != "demo"),
        "observations (demo)": c(models.Observation, models.Observation.data_origin == "demo"),
        "alerts (demo)": c(models.Alert, models.Alert.data_origin == "demo"),
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="Manage labelled AEGIS demonstration data.")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--status", action="store_true")
    g.add_argument("--seed", action="store_true")
    g.add_argument("--clear", action="store_true")
    args = ap.parse_args()

    init_db()
    with SessionLocal() as db:
        if args.status:
            print("scenarios:")
            for s in SCENARIOS:
                print(f"  {s['category']:16s} {s['place']} ({s['severity']}/5)")
            for k, v in _counts(db).items():
                print(f"  {k:22s} {v}")
            print("demo_mode:", demo_mode_active(db))
            return

        if args.seed:
            info = seed_demo(db)
            db.commit()
            print("seeded:", info)
            for k, v in _counts(db).items():
                print(f"  {k:22s} {v}")
            print("NOTE: demo rows are labelled data_origin=demo and are never mixed into live intelligence silently.")
            return

        # ---- clear demonstration rows only. Live data is never touched. ----
        # Deletion order matters because of foreign keys: alerts' children first,
        # then alerts, then everything that points at a demo incident, then the
        # incidents, and finally the demo source itself.
        removed: dict[str, int] = {}
        demo_incidents = [r for (r,) in db.execute(
            select(models.Incident.id).where(models.Incident.data_origin == "demo"))]
        demo_observations = [r for (r,) in db.execute(
            select(models.Observation.id).where(models.Observation.data_origin == "demo"))]
        demo_alerts = [r for (r,) in db.execute(
            select(models.Alert.id).where(models.Alert.data_origin == "demo"))]

        if demo_alerts:
            removed["AlertAcknowledgement"] = db.execute(
                delete(models.AlertAcknowledgement).where(models.AlertAcknowledgement.alert_id.in_(demo_alerts))).rowcount
            removed["NotificationLog"] = db.execute(
                delete(models.NotificationLog).where(models.NotificationLog.alert_id.in_(demo_alerts))).rowcount
            removed["Alert"] = db.execute(delete(models.Alert).where(models.Alert.id.in_(demo_alerts))).rowcount
        # an alert attached to a demo incident but not tagged demo (e.g. an AEGIS
        # draft generated from it) must go as well
        if demo_incidents:
            orphans = [r for (r,) in db.execute(select(models.Alert.id).where(
                models.Alert.incident_id.in_(demo_incidents)))]
            if orphans:
                removed["AlertAcknowledgement"] = (removed.get("AlertAcknowledgement", 0) + db.execute(
                    delete(models.AlertAcknowledgement).where(models.AlertAcknowledgement.alert_id.in_(orphans))).rowcount)
                removed["NotificationLog"] = (removed.get("NotificationLog", 0) + db.execute(
                    delete(models.NotificationLog).where(models.NotificationLog.alert_id.in_(orphans))).rowcount)
                removed["Alert"] = (removed.get("Alert", 0) + db.execute(
                    delete(models.Alert).where(models.Alert.id.in_(orphans))).rowcount)

        if demo_incidents:
            # citizen reports linked to demo incidents are demo reports; unlink any
            # live report that merely referenced one, then delete the demo rows
            removed["CitizenReport (unlinked)"] = db.execute(
                update(models.CitizenReport).where(
                    models.CitizenReport.linked_incident_id.in_(demo_incidents)).values(linked_incident_id=None)).rowcount
            for model in (models.IncidentEvidence, models.RiskAssessment, models.AffectedArea):
                removed[model.__name__] = db.execute(
                    delete(model).where(model.incident_id.in_(demo_incidents))).rowcount
            removed["Observation (linked)"] = db.execute(
                update(models.Observation).where(
                    models.Observation.incident_id.in_(demo_incidents)).values(incident_id=None)).rowcount
            removed["Incident"] = db.execute(
                delete(models.Incident).where(models.Incident.id.in_(demo_incidents))).rowcount

        removed["Observation (demo)"] = db.execute(
            delete(models.Observation).where(models.Observation.data_origin == "demo")).rowcount
        removed["CitizenReport (demo)"] = db.execute(
            delete(models.CitizenReport).where(models.CitizenReport.data_origin == "demo")).rowcount
        removed["RiskAssessment (demo)"] = db.execute(
            delete(models.RiskAssessment).where(models.RiskAssessment.incident_id.is_(None),
                                                models.RiskAssessment.data_origin == "demo")).rowcount \
            if hasattr(models.RiskAssessment, "data_origin") else 0
        removed["SourceSyncLog"] = db.execute(
            delete(models.SourceSyncLog).where(models.SourceSyncLog.source_key == DEMO_SOURCE_KEY)).rowcount
        removed["DataSource"] = db.execute(
            delete(models.DataSource).where(models.DataSource.key == DEMO_SOURCE_KEY)).rowcount
        db.commit()
        print("removed:", removed)
        for k, v in _counts(db).items():
            print(f"  {k:22s} {v}")


if __name__ == "__main__":
    main()
