-- ============================================================================
--  AEGIS — PostgreSQL + PostGIS schema
--
--  The SQLite profile used for local development is created automatically from
--  the SQLAlchemy models.  For production, point AEGIS_DATABASE_URL at
--  PostgreSQL and apply this file:  psql "$DATABASE_URL" -f scripts/postgis_schema.sql
--
--  It mirrors the ORM (backend/app/models.py) and ADDS what SQLite cannot give:
--    * geography(Point,4326) columns kept in sync with lat/lon by triggers
--    * GiST indexes for radius/bbox queries
--    * a real timestamp-with-timezone convention (UTC everywhere)
--
--  Generated columns + triggers are used (instead of dropping lat/lon) so the
--  same application code runs unchanged on both engines.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;      -- fuzzy place/description search

-- ---------------------------------------------------------------- users -----
CREATE TABLE IF NOT EXISTS users (
    id              TEXT PRIMARY KEY,
    email           TEXT UNIQUE NOT NULL,
    name            TEXT NOT NULL DEFAULT '',
    org             TEXT NOT NULL DEFAULT '',
    role            TEXT NOT NULL DEFAULT 'citizen',      -- citizen|analyst|admin
    password_hash   TEXT NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_login_at   TIMESTAMPTZ,
    failed_logins   INTEGER NOT NULL DEFAULT 0
);

-- ----------------------------------------------------- data sources --------
CREATE TABLE IF NOT EXISTS data_sources (
    key                 TEXT PRIMARY KEY,
    name                TEXT NOT NULL,
    provider            TEXT NOT NULL DEFAULT '',
    homepage            TEXT NOT NULL DEFAULT '',
    docs_url            TEXT NOT NULL DEFAULT '',
    license             TEXT NOT NULL DEFAULT '',
    categories          JSONB NOT NULL DEFAULT '[]'::jsonb,
    auth_mode           TEXT NOT NULL DEFAULT 'none',      -- none|api_key|token|registration|disabled
    credential_env      TEXT NOT NULL DEFAULT '',
    status              TEXT NOT NULL DEFAULT 'unknown',   -- ok|degraded|stale|error|no_credentials|disabled
    is_demo             BOOLEAN NOT NULL DEFAULT FALSE,
    reliability_note    TEXT NOT NULL DEFAULT '',
    last_ok_at          TIMESTAMPTZ,
    last_attempt_at     TIMESTAMPTZ,
    last_error          TEXT NOT NULL DEFAULT '',
    latency_ms          INTEGER,
    records_last_fetch  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS source_sync_log (
    id              BIGSERIAL PRIMARY KEY,
    source_key      TEXT NOT NULL REFERENCES data_sources(key) ON DELETE CASCADE,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at     TIMESTAMPTZ,
    status          TEXT NOT NULL DEFAULT 'running',        -- ok|error|skipped|running
    records         INTEGER NOT NULL DEFAULT 0,
    new_observations INTEGER NOT NULL DEFAULT 0,
    duration_ms     INTEGER,
    message         TEXT NOT NULL DEFAULT '',
    error           TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_sync_log_source_started ON source_sync_log (source_key, started_at DESC);

-- ------------------------------------------------ observations / signals ---
CREATE TABLE IF NOT EXISTS observations (
    id              TEXT PRIMARY KEY,
    source_key      TEXT NOT NULL REFERENCES data_sources(key) ON DELETE CASCADE,
    external_id     TEXT NOT NULL DEFAULT '',
    fingerprint     TEXT NOT NULL,                    -- sha256[:40] of source+id+time+hazard
    hazard_hint     TEXT NOT NULL DEFAULT 'unknown',
    lat             DOUBLE PRECISION NOT NULL,
    lon             DOUBLE PRECISION NOT NULL,
    place           TEXT NOT NULL DEFAULT '',
    country         TEXT NOT NULL DEFAULT '',
    magnitude       DOUBLE PRECISION,
    magnitude_unit  TEXT NOT NULL DEFAULT '',
    observed_at     TIMESTAMPTZ,
    ingested_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    source_url      TEXT NOT NULL DEFAULT '',
    data_origin     TEXT NOT NULL DEFAULT 'live',      -- live|demo
    confidence      DOUBLE PRECISION,
    payload         JSONB NOT NULL DEFAULT '{}'::jsonb,
    incident_id     TEXT,
    UNIQUE (source_key, fingerprint)
);
-- Spatial column maintained by trigger, so application code keeps using lat/lon:
ALTER TABLE observations ADD COLUMN IF NOT EXISTS geom geography(Point, 4326)
    GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(lon, lat), 4326)::geography) STORED;
CREATE INDEX IF NOT EXISTS ix_observations_geom ON observations USING GIST (geom);
CREATE INDEX IF NOT EXISTS ix_observations_time ON observations (observed_at DESC);
CREATE INDEX IF NOT EXISTS ix_observations_hazard ON observations (hazard_hint, observed_at DESC);

-- --------------------------------------------------- incidents / events ----
CREATE TABLE IF NOT EXISTS incidents (
    id                  TEXT PRIMARY KEY,
    code                TEXT UNIQUE NOT NULL,
    title               TEXT NOT NULL,
    category            TEXT NOT NULL,                 -- 7 AEGIS hazard classes + unknown
    status              TEXT NOT NULL DEFAULT 'active',
    verification_status TEXT NOT NULL DEFAULT 'preliminary_detection',
    severity            INTEGER NOT NULL DEFAULT 1,
    confidence          DOUBLE PRECISION NOT NULL DEFAULT 40,
    lat                 DOUBLE PRECISION NOT NULL,
    lon                 DOUBLE PRECISION NOT NULL,
    depth_km            DOUBLE PRECISION,
    region              TEXT NOT NULL DEFAULT '',
    country             TEXT NOT NULL DEFAULT '',
    country_iso3        TEXT NOT NULL DEFAULT '',
    started_at          TIMESTAMPTZ NOT NULL,
    last_update_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at           TIMESTAMPTZ,
    summary             TEXT NOT NULL DEFAULT '',
    detection_agent     TEXT NOT NULL DEFAULT 'detection_agent',
    classification_agent TEXT NOT NULL DEFAULT '',
    classification_note TEXT NOT NULL DEFAULT '',
    is_ambiguous        BOOLEAN NOT NULL DEFAULT FALSE,
    primary_source_key  TEXT NOT NULL DEFAULT '',
    source_keys         JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_urls         JSONB NOT NULL DEFAULT '[]'::jsonb,
    data_origin         TEXT NOT NULL DEFAULT 'live',
    merged_into_id      TEXT REFERENCES incidents(id),
    tags                JSONB NOT NULL DEFAULT '[]'::jsonb,
    external_refs       JSONB NOT NULL DEFAULT '{}'::jsonb,
    verified_by         TEXT,
    verified_at         TIMESTAMPTZ
);
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS geom geography(Point, 4326)
    GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(lon, lat), 4326)::geography) STORED;
CREATE INDEX IF NOT EXISTS ix_incidents_geom ON incidents USING GIST (geom);
CREATE INDEX IF NOT EXISTS ix_incidents_category_status ON incidents (category, status);
CREATE INDEX IF NOT EXISTS ix_incidents_started ON incidents (started_at DESC);

-- detections: which observations produced which incident
CREATE TABLE IF NOT EXISTS detections (
    id              TEXT PRIMARY KEY,
    incident_id     TEXT REFERENCES incidents(id) ON DELETE CASCADE,
    observation_id  TEXT REFERENCES observations(id) ON DELETE SET NULL,
    rule            TEXT NOT NULL DEFAULT '',
    reason          TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_detections_incident ON detections (incident_id);

-- explainable risk assessments (one row per calculation, never overwritten)
CREATE TABLE IF NOT EXISTS risk_assessments (
    id                  TEXT PRIMARY KEY,
    incident_id         TEXT REFERENCES incidents(id) ON DELETE CASCADE,
    risk_level          TEXT NOT NULL,
    risk_score          DOUBLE PRECISION NOT NULL,
    hazard_score        DOUBLE PRECISION NOT NULL,
    exposure_score      DOUBLE PRECISION NOT NULL,
    vulnerability_score DOUBLE PRECISION NOT NULL,
    confidence          DOUBLE PRECISION NOT NULL,
    factors             JSONB NOT NULL DEFAULT '[]'::jsonb,   -- every factor: value, weight, contribution, note
    methodology_version TEXT NOT NULL DEFAULT 'risk-v1.0',
    narrative           TEXT NOT NULL DEFAULT '',
    limitations         TEXT NOT NULL DEFAULT '',
    agent               TEXT NOT NULL DEFAULT 'risk_agent',
    llm_used            BOOLEAN NOT NULL DEFAULT FALSE,
    data_origin         TEXT NOT NULL DEFAULT 'live',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_risk_incident_time ON risk_assessments (incident_id, created_at DESC);

-- affected areas / footprints (estimated vs authoritative)
CREATE TABLE IF NOT EXISTS affected_areas (
    id              TEXT PRIMARY KEY,
    incident_id     TEXT REFERENCES incidents(id) ON DELETE CASCADE,
    kind            TEXT NOT NULL DEFAULT 'estimated',   -- estimated|official|forecast
    radius_km       DOUBLE PRECISION,
    area_km2        DOUBLE PRECISION,
    population_estimate BIGINT,
    population_method   TEXT NOT NULL DEFAULT '',
    geojson         JSONB,
    source          TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE affected_areas ADD COLUMN IF NOT EXISTS geom geometry(Geometry, 4326)
    GENERATED ALWAYS AS (ST_SetSRID(ST_GeomFromGeoJSON(geojson::text), 4326)) STORED;
CREATE INDEX IF NOT EXISTS ix_areas_geom ON affected_areas USING GIST (geom);
CREATE INDEX IF NOT EXISTS ix_areas_incident ON affected_areas (incident_id);

-- prediction / outlook rows (official forecasts vs labelled AEGIS extrapolation)
CREATE TABLE IF NOT EXISTS forecast_outlooks (
    id              TEXT PRIMARY KEY,
    incident_id     TEXT REFERENCES incidents(id) ON DELETE CASCADE,
    kind            TEXT NOT NULL DEFAULT 'aegis_extrapolation',  -- official_product|aegis_extrapolation
    horizon_hours   INTEGER,
    summary         TEXT NOT NULL DEFAULT '',
    method          TEXT NOT NULL DEFAULT '',
    limitations     TEXT NOT NULL DEFAULT '',
    payload         JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_url      TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_outlooks_incident ON forecast_outlooks (incident_id, created_at DESC);

-- ------------------------------------------------------------- alerts ------
CREATE TABLE IF NOT EXISTS alerts (
    id              TEXT PRIMARY KEY,
    incident_id     TEXT REFERENCES incidents(id) ON DELETE SET NULL,
    alert_kind      TEXT NOT NULL DEFAULT 'ai_advisory',  -- official_ingested|ai_advisory|citizen_derived|system
    severity        TEXT NOT NULL DEFAULT 'moderate',
    hazard          TEXT NOT NULL DEFAULT 'unknown',
    title           TEXT NOT NULL,
    body            TEXT NOT NULL DEFAULT '',
    instructions    JSONB NOT NULL DEFAULT '[]'::jsonb,
    area_text       TEXT NOT NULL DEFAULT '',
    area_geojson    JSONB,
    lat             DOUBLE PRECISION,
    lon             DOUBLE PRECISION,
    issued_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    effective_from  TIMESTAMPTZ,
    expires_at      TIMESTAMPTZ,
    authority       TEXT NOT NULL DEFAULT '',
    source_key      TEXT NOT NULL DEFAULT '',
    source_url      TEXT NOT NULL DEFAULT '',
    confidence      DOUBLE PRECISION NOT NULL DEFAULT 50,
    -- draft|pending_review|approved|published|rejected|expired
    status          TEXT NOT NULL DEFAULT 'draft',
    review_required BOOLEAN NOT NULL DEFAULT TRUE,
    reviewed_by     TEXT,
    reviewed_at     TIMESTAMPTZ,
    review_note     TEXT NOT NULL DEFAULT '',
    generated_by    TEXT NOT NULL DEFAULT '',
    llm_used        BOOLEAN NOT NULL DEFAULT FALSE,
    data_origin     TEXT NOT NULL DEFAULT 'live',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    external_id     TEXT NOT NULL DEFAULT '',
    -- nothing generated by AEGIS may reach 'published' without a reviewer:
    CONSTRAINT aegis_advice_needs_review CHECK (
        NOT (alert_kind = 'ai_advisory' AND status = 'published' AND reviewed_by IS NULL)
    ),
    CONSTRAINT official_alerts_not_reviewed CHECK (
        NOT (alert_kind = 'official_ingested' AND reviewed_by IS NOT NULL)
    )
);
CREATE INDEX IF NOT EXISTS ix_alerts_status_issued ON alerts (status, issued_at DESC);
CREATE INDEX IF NOT EXISTS ix_alerts_kind ON alerts (alert_kind);

CREATE TABLE IF NOT EXISTS alert_acknowledgements (
    id                  TEXT PRIMARY KEY,
    alert_id            TEXT NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    user_id             TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    note                TEXT NOT NULL DEFAULT '',
    status_at_ack       TEXT NOT NULL DEFAULT '',
    acknowledged_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (alert_id, user_id)
);

CREATE TABLE IF NOT EXISTS notification_log (
    id              BIGSERIAL PRIMARY KEY,
    alert_id        TEXT REFERENCES alerts(id) ON DELETE CASCADE,
    channel         TEXT NOT NULL,                 -- in_app|email|sms|push|webhook
    target          TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'queued',
    detail          TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    sent_at         TIMESTAMPTZ
);

-- ---------------------------------------------------- citizen reports ------
CREATE TABLE IF NOT EXISTS citizen_reports (
    id                  TEXT PRIMARY KEY,
    public_code         TEXT UNIQUE NOT NULL,
    category            TEXT NOT NULL DEFAULT 'unknown',
    description         TEXT NOT NULL,
    lat                 DOUBLE PRECISION NOT NULL,
    lon                 DOUBLE PRECISION NOT NULL,
    location_accuracy_m DOUBLE PRECISION,
    location_source     TEXT NOT NULL DEFAULT 'manual',
    place               TEXT NOT NULL DEFAULT '',
    photo_path          TEXT,                       -- private path, analyst-only retrieval
    photo_sha256        TEXT,
    reporter_hash       TEXT NOT NULL DEFAULT '',   -- salted hash; the raw identity is never stored
    contact_optin       TEXT,
    status              TEXT NOT NULL DEFAULT 'submitted',
    priority            TEXT NOT NULL DEFAULT 'normal',
    flags               JSONB NOT NULL DEFAULT '[]'::jsonb,
    duplicate_of_id     TEXT REFERENCES citizen_reports(id),
    linked_incident_id  TEXT REFERENCES incidents(id),
    review_notes        TEXT NOT NULL DEFAULT '',
    reviewed_by         TEXT,
    reviewed_at         TIMESTAMPTZ,
    confidence          DOUBLE PRECISION NOT NULL DEFAULT 0,
    data_origin         TEXT NOT NULL DEFAULT 'live',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE citizen_reports ADD COLUMN IF NOT EXISTS geom geography(Point, 4326)
    GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(lon, lat), 4326)::geography) STORED;
CREATE INDEX IF NOT EXISTS ix_reports_geom ON citizen_reports USING GIST (geom);
CREATE INDEX IF NOT EXISTS ix_reports_status_time ON citizen_reports (status, created_at DESC);

-- ------------------------------------------- agents, tasks, audit trail ----
CREATE TABLE IF NOT EXISTS agent_runs (
    id              TEXT PRIMARY KEY,
    run_code        TEXT UNIQUE NOT NULL,
    goal            TEXT NOT NULL,
    trigger         TEXT NOT NULL DEFAULT 'manual',
    status          TEXT NOT NULL DEFAULT 'running',
    plan            JSONB NOT NULL DEFAULT '{}'::jsonb,
    report          JSONB NOT NULL DEFAULT '{}'::jsonb,
    llm_mode        TEXT NOT NULL DEFAULT 'rules',
    llm_model       TEXT,
    requested_by    TEXT,
    requires_approval JSONB NOT NULL DEFAULT '[]'::jsonb,
    approved_by     TEXT,
    approved_at     TIMESTAMPTZ,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at     TIMESTAMPTZ,
    duration_ms     INTEGER,
    error           TEXT NOT NULL DEFAULT '',
    data_origin     TEXT NOT NULL DEFAULT 'live'
);
CREATE INDEX IF NOT EXISTS ix_runs_started ON agent_runs (started_at DESC);

CREATE TABLE IF NOT EXISTS agent_tasks (
    id              TEXT PRIMARY KEY,
    run_id          TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
    step_index      INTEGER NOT NULL DEFAULT 0,
    agent           TEXT NOT NULL,
    objective       TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'pending',
    input           JSONB NOT NULL DEFAULT '{}'::jsonb,
    output_summary  JSONB NOT NULL DEFAULT '{}'::jsonb,
    tool_calls      JSONB NOT NULL DEFAULT '[]'::jsonb,
    sources_used    JSONB NOT NULL DEFAULT '[]'::jsonb,
    findings        JSONB NOT NULL DEFAULT '[]'::jsonb,
    error           TEXT NOT NULL DEFAULT '',
    retries         INTEGER NOT NULL DEFAULT 0,
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    latency_ms      INTEGER
);
CREATE INDEX IF NOT EXISTS ix_tasks_run ON agent_tasks (run_id, step_index);

CREATE TABLE IF NOT EXISTS audit_log (
    id          BIGSERIAL PRIMARY KEY,
    at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor       TEXT NOT NULL DEFAULT 'system',
    actor_role  TEXT NOT NULL DEFAULT 'system',
    action      TEXT NOT NULL,
    entity_type TEXT NOT NULL DEFAULT '',
    entity_id   TEXT NOT NULL DEFAULT '',
    before      JSONB,
    after       JSONB,
    reason      TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_audit_action_time ON audit_log (action, at DESC);
CREATE INDEX IF NOT EXISTS ix_audit_entity ON audit_log (entity_type, entity_id);

-- ------------------------------------------------------- watch regions -----
CREATE TABLE IF NOT EXISTS watch_regions (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    min_lat     DOUBLE PRECISION NOT NULL,
    min_lon     DOUBLE PRECISION NOT NULL,
    max_lat     DOUBLE PRECISION NOT NULL,
    max_lon     DOUBLE PRECISION NOT NULL,
    categories  JSONB NOT NULL DEFAULT '[]'::jsonb,
    min_severity INTEGER NOT NULL DEFAULT 3,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------- helper: radius search ---
-- Example (kept as a view so operators can use it directly):
CREATE OR REPLACE VIEW v_incidents_with_distance AS
SELECT i.*, o.id AS near_observation_id,
       ST_Distance(i.geom, o.geom) / 1000.0 AS distance_km
FROM incidents i
JOIN observations o ON ST_DWithin(i.geom, o.geom, 150000);   -- within 150 km

COMMENT ON TABLE alerts IS
  'Official warnings are ingest-only and immutable in AEGIS; AEGIS advisories require a '
  'recorded human review (reviewed_by + review_note) before status may become published.';
