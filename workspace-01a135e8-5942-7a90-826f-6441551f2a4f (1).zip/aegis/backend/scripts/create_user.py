#!/usr/bin/env python3
"""Create an AEGIS operator account (analyst or admin).

Self-registration through the web UI only ever creates `citizen` accounts —
privileged roles must be provisioned deliberately, on the server, by an
operator. This script is that path.

Examples
--------
    # interactive (password prompted, never echoed to shell history)
    python scripts/create_user.py analyst@state.gov.in --role analyst --name "A. Rao" --org "TSDMA"

    # non-interactive (CI / provisioning)
    AEGIS_NEW_PASSWORD='…' python scripts/create_user.py ops@agency.gov --role admin --name "Ops" --password-env AEGIS_NEW_PASSWORD

    # rotate an existing account's password / change its role
    python scripts/create_user.py ops@agency.gov --role admin --reset-password
"""
from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select  # noqa: E402

from app import models  # noqa: E402
from app.db import SessionLocal, init_db  # noqa: E402
from app.security import hash_password  # noqa: E402
from app.util import now  # noqa: E402

ROLES = ("citizen", "analyst", "admin")


def _password(args: argparse.Namespace) -> str:
    if args.password_env:
        value = os.environ.get(args.password_env, "")
        if not value:
            sys.exit(f"error: ${args.password_env} is empty")
        return value
    if args.password:
        return args.password
    first = getpass.getpass("New password: ")
    second = getpass.getpass("Repeat password: ")
    if first != second:
        sys.exit("error: passwords do not match")
    if len(first) < 12:
        sys.exit("error: use at least 12 characters — operator accounts can publish public advisories")
    return first


def main() -> None:
    ap = argparse.ArgumentParser(description="Create or update an AEGIS user account.")
    ap.add_argument("email")
    ap.add_argument("--role", choices=ROLES, default="analyst")
    ap.add_argument("--name", default="")
    ap.add_argument("--org", default="")
    ap.add_argument("--password", help="password (prefer --password-env or the interactive prompt)")
    ap.add_argument("--password-env", help="name of an environment variable holding the password")
    ap.add_argument("--reset-password", action="store_true", help="rotate the password of an existing account")
    args = ap.parse_args()

    email = args.email.strip().lower()
    if "@" not in email or email.endswith("."):
        sys.exit("error: that does not look like an email address")

    init_db()
    with SessionLocal() as db:
        user = db.scalar(select(models.User).where(models.User.email == email))
        if user is None:
            if not (args.password or args.password_env):
                pw = _password(args)
            else:
                pw = _password(args)
            user = models.User(
                email=email,
                name=args.name or email.split("@")[0],
                org=args.org,
                role=args.role,
                password_hash=hash_password(pw),
                is_active=True,
                created_at=now(),
            )
            db.add(user)
            db.commit()
            print(f"created {user.role} account: {user.email} ({user.id})")
            return

        changed = []
        if user.role != args.role:
            changed.append(f"role {user.role} -> {args.role}")
            user.role = args.role
        if args.name and user.name != args.name:
            changed.append("name")
            user.name = args.name
        if args.org and user.org != args.org:
            changed.append("org")
            user.org = args.org
        if args.reset_password or args.password or args.password_env:
            user.password_hash = hash_password(_password(args))
            changed.append("password")
        if not user.is_active:
            user.is_active = True
            changed.append("re-activated")
        if not changed:
            print(f"no changes for {user.email} ({user.role})")
            return
        db.commit()
        print(f"updated {user.email}: " + ", ".join(changed))


if __name__ == "__main__":
    main()
