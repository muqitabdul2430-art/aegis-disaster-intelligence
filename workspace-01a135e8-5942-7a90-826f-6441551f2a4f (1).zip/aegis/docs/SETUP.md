# AEGIS — Setup & Operations

Everything below was executed to build this delivery; commands are copy-paste exact.

---

## 1. Requirements

| Component | Version used | Notes |
|---|---|---|
| Python | 3.13 (3.11+ should work) | `backend/requirements.txt` pinned |
| Node.js | 20.x | only to build/hot-reload the UI |
| SQLite | bundled | zero-config default |
| PostgreSQL + PostGIS | optional | production profile, schema shipped |

## 2. Install

```bash
cd backend
python -m pip install -r requirements.txt

cd ../frontend
npm install
npm run build          # → backend/static  (FastAPI serves this)
```

## 3. Configure

```bash
cp .env.example .env
```

With an empty `.env` AEGIS runs with live credential-free feeds. The settings you are most likely to
touch:

| Variable | Default | Why you'd change it |
|---|---|---|
| `AEGIS_JWT_SECRET` | dev placeholder | **must** be set for any real deployment |
| `AEGIS_DEMO_PASSWORD` | `aegis-demo-2026` | set empty to skip seeding demo accounts |
| `AEGIS_DATABASE_URL` | `sqlite:///./aegis.db` | point at PostgreSQL/PostGIS in production |
| `AEGIS_FIRMS_MAP_KEY` | empty | enables NASA FIRMS active-fire detections |
| `AEGIS_LLM_API_KEY` / `_BASE_URL` / `_MODEL` | empty | natural-language narrative layer |
| `AEGIS_SCHEDULER_ENABLED` | `true` | background ingestion every 10 min / 60 min |
| `AEGIS_ENABLE_LIVE_NETWORK` | `true` | set false for air-gapped deployments |
| `AEGIS_ENABLE_OSRM_ROUTING` | `false` | routes are never certified; leave off unless you accept that |

Secrets stay server-side: no endpoint returns key material, only booleans about presence
(`/api/system/config → credentials_configured`).

## 4. Run

```bash
cd backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

* UI → `http://localhost:8000/`
* API docs → `http://localhost:8000/api/docs`
* Health → `http://localhost:8000/api/health`

For frontend development with hot reload:

```bash
cd frontend && npm run dev     # http://localhost:5173, proxies /api and /data to :8000
```

### This deployment: live data only

`backend/.env` ships with `AEGIS_DEMO_MODE=off`, and the labelled demonstration records have been
removed (`python scripts/seed_demo.py --clear`). What you see is what the providers actually
published:

| Check | Command |
|---|---|
| No demonstration rows anywhere | `python scripts/seed_demo.py --status` → `incidents (demo) 0` |
| Every incident is provider-sourced | `curl -s localhost:8000/api/incidents \| jq '.incidents[].primary_source_key'` |
| Only real official warnings | `curl -s localhost:8000/api/alerts \| jq '.alerts[] \| {kind:.alert_kind, authority}'` |
| Demo mode reported honestly | `curl -s localhost:8000/api/system/config \| jq .demo_mode` → `"off"` |

To show a labelled offline demonstration instead: `AEGIS_DEMO_MODE=force python scripts/seed_demo.py --seed`
(and `--clear` afterwards). Nothing demo-related is ever mixed into live intelligence silently.

### First-run behaviour

1. Creates tables, registers the 13 sources in the catalogue, seeds watch regions.
2. Seeds demo accounts when `AEGIS_DEMO_PASSWORD` is set.
3. If `AEGIS_INGEST_ON_STARTUP=true`, fetches the live feeds immediately, then every 10 minutes
   (60 for slow feeds). Every attempt is recorded in `source_sync_log` and visible on
   **Data sources → Sync log**.

## 5. Users and roles

Self-registration creates **citizens** only (read intelligence, submit/track reports). Operator
accounts are provisioned on the server:

```bash
cd backend
python scripts/create_user.py analyst@state.gov.in --role analyst --name "A. Rao" --org "TSDMA"
python scripts/create_user.py ops@state.gov.in    --role admin   --name "EOC Ops"
python scripts/create_user.py analyst@state.gov.in --role analyst --reset-password
```

Passwords are prompted interactively (never echoed, never in shell history) or supplied through
`--password-env NAME`. Hashing is PBKDF2-HMAC-SHA256, 180 000 iterations, per-user salt.

## 6. Operational CLIs

```bash
cd backend
python scripts/ingest_once.py --dry-run                       # list sources and their state
python scripts/ingest_once.py --sources usgs_earthquake nhc    # one controlled pass
python scripts/run_agent.py "What can AEGIS not currently see?" --workflow data_gap_review
python scripts/run_agent.py "Reassess this event" --incident inc_cf50876d947d --json
python scripts/seed_demo.py --status | --seed | --clear        # labelled demo data only
```

`seed_demo.py --clear` removes **only** rows tagged `data_origin=demo`; live data is never touched.

## 7. PostgreSQL + PostGIS (production profile)

```bash
createdb aegis
psql "$DATABASE_URL" -f backend/scripts/postgis_schema.sql
export AEGIS_DATABASE_URL="postgresql+psycopg://aegis:secret@localhost:5432/aegis"
python -m pip install "psycopg[binary]"
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

The schema mirrors the ORM and adds what SQLite cannot: `geography(Point,4326)` generated columns
for incidents/observations/reports, GiST indexes, a radius-search view, and two CHECK constraints
that make the safety policy structural:

```sql
CHECK (NOT (alert_kind = 'ai_advisory'      AND status = 'published' AND reviewed_by IS NULL))
CHECK (NOT (alert_kind = 'official_ingested' AND reviewed_by IS NOT NULL))
```

## 8. Tests

```bash
cd backend && python -m pytest          # 39 tests, ~1 s, no network required
```

The suite pins `AEGIS_ENABLE_LIVE_NETWORK=false`, `AEGIS_DEMO_MODE=off` and a throw-away SQLite file
in `tests/conftest.py`, so results never depend on the internet or on seeded sample data.

## 9. Deployment notes

* **Reverse proxy**: terminate TLS and forward `/` to `:8000`. The SPA is served by FastAPI, so one
  origin is enough (no CORS). `AEGIS_CORS_ORIGINS` exists for split deployments.
* **Process model**: the scheduler is in-process and intended for a single worker. For multiple
  workers, run one API replica with the scheduler enabled and set `AEGIS_SCHEDULER_ENABLED=false`
  on the rest (or run `scripts/ingest_once.py` from cron and disable it everywhere).
* **Media**: citizen photos are written to `backend/uploads/<date>-<sha16>.<ext>` and served only
  through an analyst-authenticated endpoint. Mount that path on persistent storage; it is the only
  user-supplied content AEGIS stores.
* **Offline / air-gapped**: `AEGIS_ENABLE_LIVE_NETWORK=false`, `AEGIS_DEMO_MODE=force` for a labelled
  demonstration dataset; the map falls back to the bundled Natural Earth vectors.
* **Rate limits** are per-client, in-process. Behind multiple replicas, enforce quotas at the edge
  too (the settings exist so limits can be aligned).

## 10. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Dashboard shows “Offline basemap (Natural Earth)” | No internet from the browser/sandbox — expected; toggle **Streets**/**Imagery** when online |
| A source shows `no_credentials` | Set the matching `AEGIS_*` key and press **Probe** (see the table in README §2) |
| A source shows `disabled` | Link-only authority without a public API — intentional, never faked |
| Assistant answer is terse and says “Deterministic reasoning layer active” | No `AEGIS_LLM_API_KEY`; retrieval/scoring still ran for real |
| Review queue is empty | Correct: advisories are only drafted when an incident is `high`/`extreme` risk or escalating |
| `429` on report submission | Citizen-report anti-abuse limit (`AEGIS_RATE_LIMIT_REPORT_SUBMIT_PER_MIN`) |
| Overpass facilities slow or failing | Public mirrors are best-effort: AEGIS retries mirrors, caches negatives for 10 min, and reports the failure instead of inventing facilities |
