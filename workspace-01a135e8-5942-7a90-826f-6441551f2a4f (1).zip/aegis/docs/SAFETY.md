# AEGIS — Safety, Ethics and Known Limits

AEGIS is decision **support**. It is not an official warning service, and it is built so that it
cannot quietly become one.

---

## 1. Policy controls encoded in software

| Requirement | How it is enforced (not just documented) |
|---|---|
| **No AEGIS-generated advisory reaches the public without a human** | Drafts are created with `status = pending_review`, `review_required = true`. Publishing is an analyst/admin action that **requires a written note ≥ 10 characters** (`AlertReviewRequest` model validator). The PostGIS schema additionally enforces `reviewed_by IS NOT NULL` for published `ai_advisory` rows. |
| **Official warnings are never rewritten or endorsed** | `official_ingested` alerts are copied verbatim with issuer + source URL; any review attempt returns `409` ("Amendments must come from the issuing authority"). A CHECK constraint forbids `reviewed_by` on official rows. |
| **Agents cannot fabricate observations** | Tools read stored records; nothing in the answer path invents events. If a tool fails, the step is marked `error` and the brief degrades — no invented compensation. |
| **Facts, estimates and citizen input stay separated** | Every assistant answer and agent run returns `verified_facts`, `model_estimates`, `unverified_reports` and `data_gaps` as distinct buckets with `separation_note`. The UI renders them as separate columns with badges. |
| **Uncertainty and staleness are visible** | Confidence, `is_ambiguous`, source `status`/`last_ok_at`/`staleness_minutes`, data-gap answers, and "no LLM key" notices are all part of the payloads. |
| **Privileged actions are auditable** | Verification changes, alert decisions, report reviews, agent runs, ingestion passes, notification tests and user provisioning write to `audit_log` with actor, role, before/after and reason. |
| **Route safety is never claimed** | The corridor check reports intersecting hazards and refuses to certify a route; OSRM routing is off by default because AEGIS has no live road-closure feed. |

## 2. Access model

| Role | Can do |
|---|---|
| **citizen** (incl. self-registration) | read intelligence, submit and track reports, acknowledge published alerts |
| **analyst** | everything above + verify incidents, run agents, authorise/publish advisories, review citizen reports, probe sources |
| **admin** | everything above + trigger ingestion, run the data-gap workflow, test notification channels, manage users |

Enforced server-side on every route (`require_analyst`, `require_role`, capability map in
`/api/auth/me`) and mirrored in the UI, which hides actions the session cannot perform rather than
failing after the click.

## 3. Privacy

* Citizen reports are accepted **without an account**; no email is required.
* Reporter identity (logged-in id or a pseudonymous device reference) is stored as a **salted
  hash** — the raw value is never persisted.
* Public/API payloads for non-analysts reduce coordinate precision; the exact point plus
  `location_accuracy_m` is analyst-only.
* Photos are validated (JPEG/PNG/WebP, ≤ 6 MB), SHA-256 hashed, stored outside any public path and
  served only through an analyst-authenticated endpoint.
* Descriptions are screened for personal-data patterns and spam; analysts can reject with reason.
* Deleting a report removes its photo file.

## 4. Anti-abuse

Per-client rate limiting (read 240/min, write 40/min, assistant 12/min, citizen reports 10/min —
all configurable), token-bucket account lockout after repeated failed logins, duplicate detection
via token-Jaccard similarity + geographic proximity, and priority/flags triage surfaced to analysts.

## 5. Known limitations (stated on the Methodology & safety screen too)

* **Population exposure** uses a static ~2011 gazetteer, not a live census; it is an order-of-
  magnitude aid, not a count.
* **Vulnerability** uses a hazard-level static prior, not sub-national building stock.
* **Detection coverage is uneven.** Earthquakes, cyclones and tsunamis have authoritative feeds;
  **landslide, industrial fire and urban flood have no dedicated public sensor feed** in this build —
  they rely on GDACS, derived signals and citizen reports, and AEGIS says so.
* **No radar nowcast** (e.g. IMD radar mosaic) and no live river-gauge thresholds are ingested.
* **Weather drivers** come from NWP model output (Open-Meteo), labelled as such — not measurements.
* **Facilities** come from OpenStreetMap: community mapping may be incomplete; Overpass mirrors are
  best-effort, and failures are reported rather than replaced with invented data.
* **Risk weights and priors** are transparent, documented and deliberately simple — a defensible
  baseline, not a validated loss model.
* **AEGIS cannot see social media, CCTV or telephony**; it does not crawl closed groups.
* **Language coverage** is English-only in this build.

## 6. Failure behaviour

| Failure | Behaviour |
|---|---|
| Provider down / slow | retry + timeout, source marked `error`/`degraded` with the last error shown; other sources keep working |
| All live feeds down | dashboard shows `0` active incidents and the source panel shows why — never synthetic events |
| LLM endpoint unavailable | falls back to the deterministic planner/narrator; `llm_used`/`llm_mode` records which path ran |
| Agent step error | step marked `error`, run marked `completed_with_errors`, rest of the brief still produced |
| Agent deadline exceeded | remaining steps marked `skipped` with "run deadline exceeded" |
| Overpass/Nominatim unavailable | facilities/geocoding endpoints return an explicit failure state; the UI shows it |
| Offline/no internet | UI renders from the offline Natural Earth basemap and reports raster tiles as unavailable |

## 7. What AEGIS deliberately does not do

* It does not issue, replace or second-guess official warnings.
* It does not model evacuation or certify evacuation routes.
* It does not predict earthquakes (no such capability exists to predict).
* It does not present demonstration data as real: demo rows are `data_origin=demo`, badged **DEMO**,
  and `scripts/seed_demo.py --clear` removes only those rows.
* It does not use an LLM to produce facts — only to phrase already-retrieved ones.
