# AEGIS — Architecture

```
┌────────────────────────────── browsers ──────────────────────────────┐
│  React 18 + TypeScript + Tailwind + React-Leaflet                    │
│  Dashboard · Map · Incidents · Incident detail · Assistant ·          │
│  Citizen reporting · Alerts centre · Agents · Sources · About         │
│  (served by FastAPI from backend/static; offline Natural Earth map)   │
└───────────────┬──────────────────────────────────────────────────────┘
                │  JSON / multipart, bearer JWT
┌───────────────▼──────────────────────────────────────────────────────┐
│ FastAPI (app/main.py)                                                │
│  middleware: request timing, structured error envelope, CORS          │
│  routers: /api/auth /api/dashboard /api/incidents /api/geo           │
│           /api/agents /api/assistant /api/reports /api/alerts        │
│           /api/sources /api/health /api/hazards /api/safety …        │
│  security: PBKDF2 passwords · JWT sessions · role checks ·            │
│            per-client rate limiting · audit log                       │
└───┬───────────────┬────────────────────┬───────────────────┬─────────┘
    │               │                    │                   │
┌───▼─────────┐ ┌───▼──────────────┐ ┌───▼──────────────┐ ┌──▼───────────┐
│ ingestion   │ │ agents           │ │ services         │ │ scheduler    │
│ 13 sources  │ │ 8 agents +       │ │ geo maths        │ │ 10 min fast  │
│ 6 live      │ │ coordinator      │ │ Open-Meteo       │ │ 60 min slow  │
│ connectors  │ │ (13-tool         │ │ OSM facilities   │ │ (in-process) │
│ idempotent  │ │  allow-list)     │ │ notifications    │ │              │
└───┬─────────┘ └───┬──────────────┘ └───┬──────────────┘ └──┬───────────┘
    │               │                    │                   │
┌───▼───────────────▼────────────────────▼───────────────────▼──────────┐
│ SQLAlchemy 2.0 → SQLite (default) | PostgreSQL + PostGIS (production) │
│ users · data_sources · source_sync_log · observations · incidents ·    │
│ detections · risk_assessments · affected_areas · forecast_outlooks ·   │
│ alerts · alert_acknowledgements · notification_log · citizen_reports · │
│ agent_runs · agent_tasks · audit_log · watch_regions                   │
└───────────────────────────────────────────────────────────────────────┘
```

## 1. Data flow

1. **Collection** — the scheduler (or `scripts/ingest_once.py`) polls each enabled connector.
   Connectors return a `SourceFetch` (status, latency, records, error) and a list of `RawSignal`s.
   `ingest.store_observations` inserts them idempotently on `(source_key, fingerprint)`,
   refreshing mutable fields when a provider revises an event.
2. **Detection** — `detection_agent` scans new observations inside a bounded window, dedupes,
   groups provider series (e.g. GDACS episodes, FIRMS hotspot clusters) into incidents, and
   correlates across sources: a tsunami bulletin near a recent large quake upgrades verification.
   Every incident keeps `detections` rows pointing at the observations that produced it.
3. **Classification** — `classification_agent` assigns one of the seven hazard classes from the
   attached evidence, writes its reasoning to `classification_note`, and sets `is_ambiguous` when
   the evidence is genuinely mixed.
4. **Context** — `geo_agent` resolves the region/place, builds an affected-area footprint from a
   hazard-specific rule table (marked `estimated`), estimates population exposure from a static
   gazetteer, and pulls nearby facilities from OpenStreetMap. Official polygons (e.g. GDACS, NHC)
   are stored as `official` and drawn differently from estimates.
5. **Risk** — `risk_agent` computes `risk-v1.0`: `risk = w_h·hazard + w_e·exposure + w_v·vulnerability`
   with per-hazard weights, and records **every** factor (value, weight, contribution, provenance)
   plus a narrative and an explicit limitations list.
6. **Prediction** — `prediction_agent` derives trend from stored assessments, links official
   forecast products, and may produce a labelled AEGIS extrapolation. Escalation (risk level
   `high`/`extreme`, or an 8-point rise) causes a **draft** advisory to be created.
7. **Early warning** — drafts are `pending_review` with `review_required=true`. Only an
   analyst/admin decision with a written note can publish, which then dispatches notifications to
   configured channels. Official ingested alerts are immutable (`409` on any review attempt).
8. **Response** — `response_agent` presents official protective actions and contacts, ranks nearby
   facilities by role, and screens corridors for intersecting hazards while explicitly refusing to
   certify a route as safe.

## 2. Agents and the coordinator

Agents are plain Python classes with a shared `AgentContext` that records tool calls, findings,
latency and sources for the audit trail. The coordinator owns a **13-tool allow-list**; anything not
in it is dropped (including LLM suggestions — `test_planner_and_agents.py` asserts this).

Planning is two-tier: a rule planner that always runs (intent keywords, time windows
`last/past N hours|days|weeks`, `magnitude ≥ X`, category and bbox extraction, gap questions), and an
optional LLM planner that may only choose tools from the allow-list. Execution is bounded: 90-second
agent deadline, max 24 tool calls per step, HTTP timeouts with retries, per-step error capture.
Synthesis produces the four separated buckets — verified/official, model estimates, unverified
citizen input, data gaps — plus sources with timestamps and any action needing human authorisation.

## 3. Database

Same ORM on both engines (`app/models.py` ↔ `backend/scripts/postgis_schema.sql`):

* **Evidence** — `observations` (raw, fingerprinted, source-linked), `detections` (observation →
  incident provenance), `incidents` (with `source_keys`, `source_urls`, `external_refs`).
* **Analysis** — `risk_assessments` (append-only, explainable), `affected_areas`
  (`estimated|official|forecast`), `forecast_outlooks` (`official_product|aegis_extrapolation`).
* **Communication** — `alerts` (+ acknowledgements, notification log) with review fields that make
  the human-authorisation step auditable, not decorative.
* **Citizens** — `citizen_reports` with `reporter_hash` (salted, non-reversible), reduced public
  precision, duplicate linkage and a private photo path.
* **Operations** — `agent_runs` + `agent_tasks` (plan, per-step status, findings, sources),
  `audit_log` (actor, role, action, before/after, reason), `source_sync_log`, `data_sources`.

PostGIS adds `geography(Point,4326)` generated columns and GiST indexes on incidents, observations
and reports, plus a `v_incidents_with_distance` radius view — so spatial queries are real, while the
application code keeps using plain `lat`/`lon` and stays portable.

## 4. API surface (abridged)

| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`, `POST /api/auth/change-password` |
| Dashboard | `GET /api/dashboard/summary?hours=`, `/agent-activity`, `/source-health`, `/audit` |
| Incidents | `GET /api/incidents` (category, verification, min_severity, hours, bbox, sort), `GET /api/incidents/{id}`, `…/context`, `…/risk`, `…/outlook`, `…/response`, `…/observations`, `POST …/assess`, `POST …/verify` |
| Geo | `GET /api/geo/facilities`, `/weather`, `/places`, `/reverse`, `/gibs-layers`, `POST /api/geo/footprint`, `/route-check` |
| Agents | `GET /api/agents`, `GET /api/agents/runs`, `GET /api/agents/runs/{id}`, `POST /api/agents/run` |
| Assistant | `GET /api/assistant/suggestions`, `POST /api/assistant/ask` |
| Reports | `POST /api/reports` (multipart + optional photo), `GET /api/reports/track/{code}`, `GET /api/reports` (analyst), `POST /api/reports/{id}/review` (analyst), `GET /api/reports/{id}/photo` (analyst) |
| Alerts | `GET /api/alerts`, `GET /api/alerts/pending`, `GET /api/alerts/{id}`, `POST /api/alerts/{id}/review`, `POST /api/alerts/{id}/ack`, `GET /api/alerts/channels/status`, `POST /api/alerts/channels/test`, `GET /api/alerts/export/geojson` |
| Sources | `GET /api/sources`, `GET /api/sources/catalog`, `GET /api/sources/syncs`, `POST /api/sources/ingest`, `POST /api/sources/{key}/probe` |
| System | `GET /api/health`, `/api/system/config`, `/api/hazards`, `/api/safety`, `/api/observations`, `/api/audit` |

## 5. Front end

* **State**: `AuthProvider` (guest-first principal + capability map) and per-page fetching with
  `AbortSignal`; no global store, which keeps rerender scope tight on a 120-second refresh loop.
* **Map** (`MapView.tsx`): React-Leaflet with an offline-first design — a 6-second tile probe
  decides whether online rasters are usable. Default base layer is the bundled Natural Earth vector
  set (public domain); **Streets** (OpenStreetMap raster, CSS-dark-filtered) and **Imagery** (Esri
  World Imagery) are opt-in. Overlays distinguish solid cyan authoritative polygons from dashed
  AEGIS estimates, and the legend says which is which.
* **Evidence discipline in the UI**: every AI-derived number carries an *estimate* badge, demo rows
  carry a DEMO badge, official warnings render verbatim with issuer and timestamp, and empty states
  say "nothing here" rather than padding with samples.

## 6. Extending AEGIS

* **Add a provider**: append a `SourceSpec` to `app/sources/base.py`, write `fetch()`/`parse()`
  returning `RawSignal`s, and it appears in `/api/sources` with health, credential requirements and
  a probe button. Nothing else changes.
* **Add a tool**: add a `ToolSpec` + method to the coordinator (params are validated), then the rule
  planner and any LLM plan can use it; the allow-list, audit trail and agent screens pick it up
  automatically.
* **Swap the model**: point `AEGIS_LLM_BASE_URL` at any OpenAI-compatible endpoint (OpenAI, Groq,
  OpenRouter, vLLM, Ollama). `llm.py` degrades gracefully on timeout/error and reports the mode used
  in every run payload.
