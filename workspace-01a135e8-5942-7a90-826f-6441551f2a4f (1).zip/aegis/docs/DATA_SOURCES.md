# AEGIS — Data Sources, Licences and Credentials

The source catalogue lives in `backend/app/sources/base.py` (`SOURCE_CATALOG`, 13 entries) and is
served verbatim at `GET /api/sources/catalog`, with live health at `GET /api/sources`.
States: `ok` · `degraded` · `stale` · `error` · `no_credentials` · `disabled`.

---

## Works immediately (no credentials, implemented connectors)

| Key | Provider | Endpoint used | Licence | Role in AEGIS |
|---|---|---|---|---|
| `usgs_earthquake` | USGS | `earthquake.usgs.gov/fdsnws/event/1/query` (GeoJSON, M ≥ 4.0, rolling window) | US Government work — public domain | earthquake detections; `reviewed` vs `automatic` kept as source confidence; tsunamigenic flag feeds correlation |
| `gdacs` | JRC / GDACS | `gdacs.org/gdacsapi/api/events/geteventlist/SEARCH` | JRC — reuse with attribution | multi-hazard events (EQ/TC/FL/WF/VO/DR), alert levels → severity, polygons where provided |
| `nhc` | NOAA National Hurricane Center | `nhc.noaa.gov/CurrentStorms.json` | US Government work — public domain | tropical cyclone positions/intensity, advisory linkage as official forecast product |
| `noaa_tsunami` | NOAA NTWC/PTWC | `tsunami.gov/events/xml/PAAQAtom.xml` (+ centres) | US Government work — public domain | official tsunami bulletins, **ingested verbatim** as `official_ingested` alerts |
| `open_meteo` | Open-Meteo | `api.open-meteo.com/v1/forecast` | CC BY 4.0 (attribution required) | hazard drivers: rain 24/72 h, wind/gust, CAPE, soil moisture, pressure — labelled **MODEL OUTPUT** |
| `openstreetmap` | OpenStreetMap (Overpass + Nominatim) | Overpass mirrors (kumi.systems → overpass-api.de → private.coffee); `nominatim.openstreetmap.org` | ODbL 1.0 — © OpenStreetMap contributors | critical facilities near incidents, place naming for coordinates; Nominatim throttled ≥ 1.1 s with a 24 h cache |
| `nasa_gibs` | NASA GIBS/Worldview | WMTS `gibs.earthdata.nasa.gov` | NASA — open | satellite imagery tiles (imagery layer in the map) |
| `natural_earth` *(bundled)* | Natural Earth | shipped `frontend/public/data/*.json` | Public domain | offline country polygons + populated places so the map never depends on the internet |

## Needs a free key / registration (connector implemented, awaiting credentials)

| Key | Env var | Get it at | Effect once set |
|---|---|---|---|
| `nasa_firms` | `AEGIS_FIRMS_MAP_KEY` | <https://firms.modaps.eosdis.nasa.gov/api/map_key/> | VIIRS/MODIS active-fire detections → wildfire incidents, hotspot clustering |
| `isro_mosdac` | `AEGIS_MOSDAC_TOKEN` | <https://www.mosdac.gov.in/> (registration) | ISRO satellite products (Bhuvan/MOSDAC) |
| `nasa_gibs` (Earthdata products) | `AEGIS_EARTHDATA_TOKEN` | <https://urs.earthdata.nasa.gov/> | additional GIBS/CMR products |
| `copernicus_ems` | `AEGIS_CDSE_CLIENT_ID` / `AEGIS_CDSE_CLIENT_SECRET` | <https://dataspace.copernicus.eu/> | Copernicus EMS rapid-mapping activation lookups |

Until a key is present these appear as `no_credentials` **with the exact variable name shown in the
UI** — no silent failure and no fabricated substitutes.

## Link-only (authoritative portals, no documented public API — never scraped)

| Key | Authority | Why AEGIS links instead of ingesting |
|---|---|---|
| `imd_cyclone` | India Meteorological Department (RSMC) | advisories published as bulletins/PDF; no stable machine endpoint |
| `incois_tsunami` | INCOIS Indian Tsunami Early Warning Centre | warnings distributed through official channels; no public API |
| `ndma_sachet` | NDMA SACHET / Alert Hub (India) | dissemination platform, not a queryable feed |

These render with their official emergency numbers (India: 112 / 108 / 101 / 100 / 1078 · NDMA) as
verified contact points, not as data AEGIS pretends to have read.

## How ingestion treats each record

1. Provider payload → `RawSignal` (source key, external id, hazard hint, coordinates, magnitude +
   unit, observation time, place, source URL, confidence, raw payload).
2. Idempotent upsert on `(source_key, fingerprint)`; revisions refresh confidence/payload/time.
3. `data_origin` is `live` or `demo`. Demo rows are badged **DEMO** everywhere and can be removed
   without touching live data.
4. Official warning records become `official_ingested` alerts: content verbatim, authority and
   source URL attached, no review action permitted.
5. Every fetch writes a `source_sync_log` row (status, records, new observations, latency, error),
   which is what the **Data sources → Sync log** screen displays.

## Attribution requirements when republishing AEGIS output

* **OpenStreetMap** — “© OpenStreetMap contributors”, ODbL 1.0.
* **Open-Meteo** — attribution to Open-Meteo (CC BY 4.0); mark as model output, not measurement.
* **GDACS / JRC** — cite GDACS as the source of multi-hazard event data.
* **USGS / NOAA / NASA** — public domain; still cite the issuing agency.
* **Natural Earth** — public domain, no obligation.
* **Official warning text** — always remains the property of the issuing authority and must be shown
  with that authority's name, never reworded.
* **AEGIS risk scores and footprints** — attribute to AEGIS and label them as model estimates.
