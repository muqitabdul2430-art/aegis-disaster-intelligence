import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { api, setToken, getToken } from "../lib/api";

/**
 * Session context: holds the authenticated principal and capabilities.
 * Anonymous visitors are first-class users (they can read intelligence and
 * submit citizen reports); privileged actions are hidden/disabled in the UI
 * *and* enforced by the API.
 */

export type Principal = {
  id: string | null;
  email: string | null;
  name: string;
  role: "guest" | "citizen" | "analyst" | "admin";
  authenticated: boolean;
  capabilities: Record<string, boolean>;
};

type AuthState = {
  principal: Principal;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (body: { email: string; password: string; name?: string; org?: string }) => Promise<void>;
  logout: () => void;
  refresh: () => Promise<void>;
};

const GUEST: Principal = {
  id: null,
  email: null,
  name: "Guest",
  role: "guest",
  authenticated: false,
  capabilities: {
    submit_report: true,
    read_intel: true,
    verify_incident: false,
    publish_alert: false,
    trigger_ingest: false,
    manage_users: false,
  },
};

const AuthContext = createContext<AuthState>({
  principal: GUEST,
  loading: true,
  login: async () => {},
  register: async () => {},
  logout: () => {},
  refresh: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [principal, setPrincipal] = useState<Principal>(GUEST);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const me = await api.authMe();
      if (me?.authenticated) {
        setPrincipal({
          id: me.user.id,
          email: me.user.email,
          name: me.user.name || me.user.email,
          role: me.user.role,
          authenticated: true,
          capabilities: me.capabilities,
        });
      } else {
        setPrincipal(GUEST);
      }
    } catch {
      setPrincipal(GUEST);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (getToken()) {
      void refresh();
    } else {
      setLoading(false);
    }
  }, [refresh]);

  const login = useCallback(
    async (email: string, password: string) => {
      const res = await api.login(email.trim().toLowerCase(), password);
      setToken(res.token.access_token);
      await refresh();
    },
    [refresh],
  );

  const register = useCallback(
    async (body: { email: string; password: string; name?: string; org?: string }) => {
      const res = await api.register(body);
      setToken(res.token.access_token);
      await refresh();
    },
    [refresh],
  );

  const logout = useCallback(() => {
    setToken(null);
    setPrincipal(GUEST);
  }, []);

  const value = useMemo(
    () => ({ principal, loading, login, register, logout, refresh }),
    [principal, loading, login, register, logout, refresh],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
