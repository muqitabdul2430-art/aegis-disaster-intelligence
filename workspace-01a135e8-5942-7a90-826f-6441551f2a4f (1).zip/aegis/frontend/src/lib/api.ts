/**
 * AEGIS API client.
 *
 * Every screen in the product goes through this module, so error, loading and
 * offline handling are consistent. AEGIS never hides a failed request behind
 * placeholder data — failures surface as typed errors the UI can render.
 */

export type ApiError = {
  status: number;
  message: string;
  detail?: any;
  offline?: boolean;
  rateLimited?: boolean;
};

const TOKEN_KEY = "aegis.token";

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string | null) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* storage may be unavailable (private mode) — session stays in memory only */
  }
}

export class AegisApiError extends Error {
  status: number;
  detail?: any;
  offline?: boolean;
  rateLimited?: boolean;
  constructor(err: ApiError) {
    super(err.message);
    this.status = err.status;
    this.detail = err.detail;
    this.offline = err.offline;
    this.rateLimited = err.rateLimited;
  }
}

type RequestOptions = {
  method?: string;
  body?: any;
  form?: FormData;
  signal?: AbortSignal;
  timeoutMs?: number;
};

const DEFAULT_TIMEOUT = 45000;

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), opts.timeoutMs ?? DEFAULT_TIMEOUT);
  if (opts.signal) {
    opts.signal.addEventListener("abort", () => controller.abort());
  }
  const headers: Record<string, string> = { Accept: "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let body: BodyInit | undefined;
  if (opts.form) {
    body = opts.form;
  } else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }

  let res: Response;
  try {
    res = await fetch(path, {
      method: opts.method ?? (body ? "POST" : "GET"),
      headers,
      body,
      signal: controller.signal,
    });
  } catch (e: any) {
    clearTimeout(timeout);
    throw new AegisApiError({
      status: 0,
      offline: true,
      message:
        e?.name === "AbortError"
          ? "The request timed out. AEGIS is still collecting data — try again."
          : "AEGIS backend is unreachable (offline or starting up). Data shown may be out of date.",
    });
  }
  clearTimeout(timeout);

  const text = await res.text();
  let payload: any = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    payload = text;
  }

  if (!res.ok) {
    const detail = payload?.detail ?? payload;
    let message =
      typeof detail === "string"
        ? detail
        : detail?.message || detail?.error || `Request failed (HTTP ${res.status})`;
    if (Array.isArray(detail)) {
      message = detail.map((d: any) => `${(d.loc || []).join(".")}: ${d.msg}`).join("; ");
    } else if (detail?.errors?.length) {
      message = `${detail.message || "Validation failed"} — ${detail.errors.join("; ")}`;
    }
    throw new AegisApiError({
      status: res.status,
      message,
      detail,
      rateLimited: res.status === 429,
    });
  }
  return payload as T;
}

/** Low-level HTTP helpers (absolute API paths, bearer token attached automatically). */
export const http = {
  get: <T,>(path: string, signal?: AbortSignal) => request<T>(path, { signal }),
  post: <T,>(path: string, body?: any) => request<T>(path, { method: "POST", body }),
  patch: <T,>(path: string, body?: any) => request<T>(path, { method: "PATCH", body }),
  postForm: <T,>(path: string, form: FormData) => request<T>(path, { method: "POST", form }),
};

// --------------------------------------------------------------------------- //
// Typed endpoint helpers
// --------------------------------------------------------------------------- //
export type Hazard =
  | "wildfire" | "cyclone" | "flood" | "tsunami" | "landslide" | "earthquake" | "industrial_fire" | "unknown";

export type RiskSummary = {
  score: number;
  level: string;
  hazard_score: number;
  exposure_score: number;
  vulnerability_score: number;
  confidence: number;
  methodology_version: string;
  assessed_at: string;
  estimate: true;
};

export type AffectedArea = {
  id: string;
  label: string;
  geojson: any;
  area_km2: number | null;
  radius_km: number | null;
  population_estimate: number | null;
  population_method: string;
  method: string;
  is_estimate: boolean;
  authority: string | null;
  source_key: string;
  label_kind: "estimate" | "authoritative";
};

export type Incident = {
  id: string;
  code: string;
  title: string;
  category: Hazard;
  status: string;
  verification_status: string;
  severity: number;
  confidence: number;
  lat: number;
  lon: number;
  depth_km?: number | null;
  region: string;
  country: string;
  country_iso3: string;
  started_at: string;
  last_update_at: string;
  summary: string;
  classification_note: string;
  is_ambiguous: boolean;
  primary_source_key: string;
  source_keys: string[];
  source_urls: string[];
  data_origin: "live" | "demo";
  tags: string[];
  external_refs: Record<string, string>;
  risk: RiskSummary | null;
  is_demo: boolean;
  affected_areas?: AffectedArea[];
  alert_count?: number;
  evidence_count?: number;
};

export type Alert = {
  id: string;
  incident_id: string | null;
  incident_code?: string | null;
  alert_kind: string;
  is_official: boolean;
  is_demo: boolean;
  severity: string;
  hazard: Hazard;
  title: string;
  body: string;
  instructions: string[];
  area_text: string;
  area_geojson?: any;
  lat: number | null;
  lon: number | null;
  issued_at: string;
  expires_at: string | null;
  authority: string | null;
  source_key: string;
  source_url: string;
  confidence: number;
  status: string;
  review_required: boolean;
  reviewed_by: string | null;
  reviewed_at: string | null;
  generated_by: string;
  llm_used: boolean;
  review_note?: string | null;
  effective_from?: string | null;
  created_at: string;
  acknowledged: boolean;
  ack_count: number | null;
  publishable: boolean;
};

export type DataSource = {
  key: string;
  name: string;
  provider: string;
  homepage: string;
  docs_url: string;
  license: string;
  categories: string[];
  auth_mode: string;
  credential_env: string | null;
  status: string;
  last_attempt_at: string | null;
  last_ok_at: string | null;
  last_error: string | null;
  latency_ms: number | null;
  records_last_fetch: number;
  total_records: number;
  reliability_note: string;
  is_demo: boolean;
  staleness_minutes: number | null;
  last_sync?: any;
};

export type CitizenReport = {
  id: string;
  public_code: string;
  category: Hazard;
  description: string;
  lat: number;
  lon: number;
  coordinates_precision: string;
  place: string;
  status: string;
  priority: string;
  flags: string[];
  linked_incident_id: string | null;
  confidence: number;
  created_at: string;
  reviewed_at: string | null;
  reviewed_by?: string | null;
  review_notes?: string;
  photo_available: boolean;
  verified: boolean;
  data_origin: string;
};

export type AgentRun = {
  id: string;
  run_code: string;
  goal: string;
  trigger: string;
  status: string;
  plan: { tool: string; why: string; params?: any }[];
  summary: string;
  report: any;
  llm_mode: string;
  started_at: string;
  finished_at: string | null;
  duration_ms: number | null;
  error: string | null;
  tasks?: AgentTask[];
};

export type AgentTask = {
  id: string;
  step_index: number;
  agent: string;
  objective: string;
  status: string;
  tool_calls: any[];
  sources_used: string[];
  findings: any[];
  error: string | null;
  latency_ms: number | null;
  started_at: string | null;
  finished_at: string | null;
};

export const endpoints = {
  dashboard: (hours = 72) => http.get<any>(`/api/dashboard/summary?hours=${hours}`),
  agentActivity: () => http.get<any>("/api/dashboard/agent-activity"),
  sourceHealth: () => http.get<any>("/api/dashboard/source-health"),
  audit: (limit = 60) => http.get<any>(`/api/dashboard/audit?limit=${limit}`),

  incidents: (q: Record<string, string | number | undefined> = {}) => {
    const params = new URLSearchParams();
    Object.entries(q).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") params.set(k, String(v));
    });
    return http.get<{ total: number; count: number; incidents: Incident[] }>(`/api/incidents?${params}`);
  },
  incident: (id: string) => http.get<any>(`/api/incidents/${id}`),
  incidentContext: (id: string, radius = 25) => http.get<any>(`/api/incidents/${id}/context?radius_km=${radius}`),
  incidentRisk: (id: string) => http.get<any>(`/api/incidents/${id}/risk`),
  incidentOutlook: (id: string) => http.get<any>(`/api/incidents/${id}/outlook`),
  incidentResponse: (id: string, radius = 25) => http.get<any>(`/api/incidents/${id}/response?radius_km=${radius}`),
  assessIncident: (id: string, body: any) => http.post<any>(`/api/incidents/${id}/assess`, body),
  verifyIncident: (id: string, body: any) => http.post<any>(`/api/incidents/${id}/verify`, body),

  observations: (q: Record<string, string | number | undefined>) => {
    const params = new URLSearchParams();
    Object.entries(q).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") params.set(k, String(v));
    });
    return http.get<any>(`/api/observations?${params}`);
  },

  agents: () => http.get<any>("/api/agents"),
  agentRuns: () => http.get<{ runs: AgentRun[] }>("/api/agents/runs"),
  runAgent: (body: any) => http.post<any>("/api/agents/run", body),
  agentRun: (id: string) => http.get<AgentRun>(`/api/agents/runs/${id}`),

  ask: (question: string, context: any = {}) => http.post<any>("/api/assistant/ask", { question, context }),
  suggestions: () => http.get<{ suggestions: string[] }>("/api/assistant/suggestions"),

  submitReport: (form: FormData) => http.postForm<any>("/api/reports", form),
  trackReport: (code: string) => http.get<any>(`/api/reports/track/${code}`),
  reports: (q: Record<string, string | number | undefined> = {}) => {
    const params = new URLSearchParams();
    Object.entries(q).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") params.set(k, String(v));
    });
    return http.get<{ reports: CitizenReport[] }>(`/api/reports?${params}`);
  },
  reviewReport: (id: string, body: any) => http.post<any>(`/api/reports/${id}/review`, body),

  alerts: (q: Record<string, string | number | undefined> = {}) => {
    const params = new URLSearchParams();
    Object.entries(q).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") params.set(k, String(v));
    });
    return http.get<{ alerts: Alert[]; pending_review_count: number }>(`/api/alerts?${params}`);
  },
  pendingAlerts: () => http.get<{ alerts: Alert[] }>("/api/alerts/pending"),
  alert: (id: string) => http.get<any>(`/api/alerts/${id}`),
  reviewAlert: (id: string, body: any) => http.post<any>(`/api/alerts/${id}/review`, body),
  ackAlert: (id: string, note = "") => http.post<any>(`/api/alerts/${id}/ack`, { note }),

  sources: () => http.get<any>("/api/sources"),
  probeSource: (key: string) => http.post<any>(`/api/sources/${key}/probe`),
  runIngest: (body: any = {}) => http.post<any>("/api/sources/ingest", body),
  syncs: (limit = 60) => http.get<any>(`/api/sources/syncs?limit=${limit}`),

  facilities: (lat: number, lon: number, radius = 25) =>
    http.get<any>(`/api/geo/facilities?lat=${lat}&lon=${lon}&radius_km=${radius}`, undefined),
  weather: (lat: number, lon: number) => http.get<any>(`/api/geo/weather?lat=${lat}&lon=${lon}`),
  places: (lat: number, lon: number) => http.get<any>(`/api/geo/places?lat=${lat}&lon=${lon}`),
  reverse: (lat: number, lon: number) => http.get<any>(`/api/geo/reverse?lat=${lat}&lon=${lon}`),
  routeCheck: (body: any) => http.post<any>("/api/geo/route-check", body),
  gibsLayers: () => http.get<any>("/api/geo/gibs-layers"),

  hazards: () => http.get<any>("/api/hazards"),
  safety: () => http.get<any>("/api/safety"),
  config: () => http.get<any>("/api/system/config"),
  health: () => http.get<any>("/api/health"),
  authMe: () => http.get<any>("/api/auth/me"),
  login: (email: string, password: string) => http.post<any>("/api/auth/login", { email, password }),
  register: (body: any) => http.post<any>("/api/auth/register", body),
};

// --------------------------------------------------------------------------- //
// Public surface: every endpoint helper *and* the low-level helpers live on
// `api`, so pages can call api.incidents(...) or api.get("/api/...") alike.
// --------------------------------------------------------------------------- //
export const api = { ...http, ...endpoints };
export default api;
