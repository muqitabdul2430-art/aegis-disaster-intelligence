/** Formatting, hazard metadata and presentation helpers. */

export const HAZARDS = [
  "wildfire",
  "cyclone",
  "flood",
  "tsunami",
  "landslide",
  "earthquake",
  "industrial_fire",
  "unknown",
] as const;

export type HazardKey = (typeof HAZARDS)[number];

export const HAZARD_META: Record<
  string,
  { label: string; short: string; color: string; glyph: string; blurb: string }
> = {
  wildfire: { label: "Wildfire", short: "WF", color: "#f97316", glyph: "🔥", blurb: "Satellite thermal anomalies & fire complexes" },
  cyclone: { label: "Cyclone", short: "CY", color: "#8b5cf6", glyph: "🌀", blurb: "Official basin-centre position & intensity products" },
  flood: { label: "Flood", short: "FL", color: "#3b82f6", glyph: "🌊", blurb: "Multi-hazard alerts + modelled rainfall drivers" },
  tsunami: { label: "Tsunami", short: "TS", color: "#06b6d4", glyph: "🌐", blurb: "NOAA warning-centre bulletins (verbatim)" },
  landslide: { label: "Landslide", short: "LS", color: "#a16207", glyph: "⛰️", blurb: "Citizen reports + rainfall proxies (no public sensor feed)" },
  earthquake: { label: "Earthquake", short: "EQ", color: "#eab308", glyph: "〰️", blurb: "USGS FDSN catalogue (reviewed & automatic)" },
  industrial_fire: { label: "Industrial fire", short: "IF", color: "#ef4444", glyph: "🏭", blurb: "Thermal anomalies near industry + citizen reports" },
  unknown: { label: "Unclassified", short: "UN", color: "#94a3b8", glyph: "❓", blurb: "Awaiting analyst classification" },
};

export const VERIFICATION_META: Record<string, { label: string; tone: string; meaning: string }> = {
  officially_confirmed: {
    label: "Officially confirmed",
    tone: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
    meaning: "Confirmed by an issuing authority, or the incident IS an official bulletin.",
  },
  human_verified: {
    label: "Analyst verified",
    tone: "border-cyan-500/40 bg-cyan-500/10 text-cyan-300",
    meaning: "An AEGIS analyst reviewed the evidence and confirmed the event.",
  },
  corroborated: {
    label: "Corroborated",
    tone: "border-sky-500/40 bg-sky-500/10 text-sky-300",
    meaning: "Two or more independent sources agree (signal + authority/instrument).",
  },
  preliminary_detection: {
    label: "Preliminary detection",
    tone: "border-amber-500/40 bg-amber-500/10 text-amber-300",
    meaning: "Detected from a signal but not independently corroborated yet.",
  },
  unverified_citizen: {
    label: "Unverified report",
    tone: "border-orange-500/40 bg-orange-500/10 text-orange-300",
    meaning: "Based on citizen submissions only. Never triggers public alerts.",
  },
  rejected: {
    label: "Rejected",
    tone: "border-slate-500/40 bg-slate-500/10 text-slate-400",
    meaning: "Reviewed and not accepted. Retained for the audit trail.",
  },
};

export const RISK_TONE: Record<string, { bg: string; text: string; ring: string }> = {
  extreme: { bg: "bg-red-500/15", text: "text-red-300", ring: "ring-red-500/40" },
  high: { bg: "bg-orange-500/15", text: "text-orange-300", ring: "ring-orange-500/40" },
  moderate: { bg: "bg-amber-500/15", text: "text-amber-200", ring: "ring-amber-500/40" },
  low: { bg: "bg-emerald-500/15", text: "text-emerald-300", ring: "ring-emerald-500/40" },
  minimal: { bg: "bg-sky-500/15", text: "text-sky-300", ring: "ring-sky-500/40" },
  unassessed: { bg: "bg-slate-500/15", text: "text-slate-400", ring: "ring-slate-500/30" },
};

export const SEVERITY_LABEL = ["", "Minimal", "Low", "Moderate", "High", "Extreme"];

export function hazardMeta(key?: string) {
  return HAZARD_META[key || "unknown"] || HAZARD_META.unknown;
}

export function riskTone(level?: string) {
  return RISK_TONE[level || "unassessed"] || RISK_TONE.unassessed;
}

export function severityColor(sev: number, category?: string) {
  if (category && HAZARD_META[category] && sev <= 2) return HAZARD_META[category].color;
  return ["#64748b", "#22c55e", "#eab308", "#f97316", "#ef4444", "#b91c1c"][Math.min(Math.max(sev, 0), 5)];
}

export function timeAgo(iso?: string | null): string {
  if (!iso) return "—";
  const then = new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z").getTime();
  const secs = Math.max(1, Math.floor((Date.now() - then) / 1000));
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 45) return `${days}d ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months}mo ago`;
  return `${Math.floor(months / 12)}y ago`;
}

export function utc(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z");
  if (Number.isNaN(d.getTime())) return iso;
  return `${d.toISOString().slice(0, 16).replace("T", " ")}Z`;
}

export function localTime(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z");
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

export function num(value?: number | null, digits = 0): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return value.toLocaleString(undefined, { maximumFractionDigits: digits, minimumFractionDigits: digits });
}

export function compact(value?: number | null): string {
  if (value === null || value === undefined) return "—";
  if (Math.abs(value) >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
  if (Math.abs(value) >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
  if (Math.abs(value) >= 1e3) return `${(value / 1e3).toFixed(1)}k`;
  return `${value}`;
}

export function coords(lat?: number | null, lon?: number | null, digits = 4): string {
  if (lat === null || lat === undefined || lon === null || lon === undefined) return "—";
  const ns = lat >= 0 ? "N" : "S";
  const ew = lon >= 0 ? "E" : "W";
  return `${Math.abs(lat).toFixed(digits)}°${ns} ${Math.abs(lon).toFixed(digits)}°${ew}`;
}

export function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

/** Distance in km between two coordinates (same formula as the backend). */
export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371.0088;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}

export function statusTone(status?: string): string {
  switch (status) {
    case "ok":
      return "border-emerald-500/40 bg-emerald-500/10 text-emerald-300";
    case "degraded":
      return "border-amber-500/40 bg-amber-500/10 text-amber-300";
    case "stale":
      return "border-amber-500/40 bg-amber-500/10 text-amber-200";
    case "error":
      return "border-red-500/40 bg-red-500/10 text-red-300";
    case "no_credentials":
      return "border-violet-500/40 bg-violet-500/10 text-violet-300";
    case "disabled":
      return "border-slate-500/40 bg-slate-500/10 text-slate-400";
    default:
      return "border-slate-600/40 bg-slate-600/10 text-slate-400";
  }
}

export const GDD_CONTACT = [
  { label: "India — all emergencies", value: "112" },
  { label: "India — ambulance", value: "108" },
  { label: "US — emergency", value: "911" },
];
