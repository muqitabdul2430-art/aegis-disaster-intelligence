import React, { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { Activity, AlertOctagon, Bot, FileText, Gauge, Info, LayoutDashboard, LogIn, LogOut, Map as MapIcon, Menu, Radio, ShieldAlert, Users, X } from "lucide-react";
import { api } from "../lib/api";
import { useAuth } from "../state/auth";
import { Banner, Chip, Spinner } from "./ui";

const NAV = [
  { to: "/", label: "Command dashboard", icon: LayoutDashboard, end: true },
  { to: "/map", label: "Disaster map", icon: MapIcon },
  { to: "/incidents", label: "Incident centre", icon: AlertOctagon },
  { to: "/assistant", label: "AI assistant", icon: Bot },
  { to: "/report", label: "Citizen reporting", icon: Users },
  { to: "/alerts", label: "Alerts centre", icon: Radio },
  { to: "/agents", label: "Agent operations", icon: Activity },
  { to: "/sources", label: "Data sources", icon: Gauge },
  { to: "/about", label: "Methodology & safety", icon: Info },
];

function SystemPill() {
  const [state, setState] = useState<{ label: string; tone: string } | null>(null);
  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const h = await api.health();
        if (!alive) return;
        const fresh = h.checks?.data_sources?.fresh?.length ?? 0;
        const stale = h.checks?.data_sources?.stale?.length ?? 0;
        const tone =
          h.status !== "ok"
            ? "border-red-500/40 bg-red-500/10 text-red-300"
            : stale > 0
              ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
              : "border-emerald-500/40 bg-emerald-500/10 text-emerald-300";
        setState({
          label: `SYSTEM ${h.status.toUpperCase()} · ${fresh} live feed${fresh === 1 ? "" : "s"}${stale ? ` · ${stale} stale` : ""}`,
          tone,
        });
      } catch {
        if (alive) setState({ label: "BACKEND OFFLINE", tone: "border-red-500/40 bg-red-500/10 text-red-300" });
      }
    };
    void load();
    const t = window.setInterval(load, 60000);
    return () => {
      alive = false;
      window.clearInterval(t);
    };
  }, []);
  if (!state) return <Chip tone="border-white/10 bg-white/5 text-slate-400"><Spinner label="Checking" /></Chip>;
  return (
    <Chip tone={state.tone} className="font-mono text-[10px] tracking-wider">
      <ShieldAlert className="h-3 w-3" aria-hidden /> {state.label}
    </Chip>
  );
}

function AuthMenu() {
  const { principal, login, logout, loading } = useAuth();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (loading) return <Spinner label="Session" />;

  if (principal.authenticated) {
    return (
      <div className="flex items-center gap-2">
        <div className="hidden text-right sm:block">
          <p className="text-xs font-medium text-slate-200">{principal.name}</p>
          <p className="text-[10px] uppercase tracking-wide text-cyan-400">{principal.role}</p>
        </div>
        <button className="btn-ghost btn-xs" onClick={logout} title="Sign out">
          <LogOut className="h-3 w-3" aria-hidden /> Sign out
        </button>
      </div>
    );
  }

  return (
    <>
      <button className="btn-primary btn-xs" onClick={() => setOpen(true)}>
        <LogIn className="h-3 w-3" aria-hidden /> Sign in
      </button>
      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-navy-950/80 p-4 backdrop-blur-sm" role="dialog" aria-modal>
          <div className="panel w-full max-w-md p-5">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">Sign in to AEGIS</h2>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  Citizens can submit reports without an account. Analyst credentials unlock verification, alert
                  authorisation and agent execution.
                </p>
              </div>
              <button className="btn-ghost btn-xs" onClick={() => setOpen(false)} aria-label="Close">
                <X className="h-3 w-3" aria-hidden />
              </button>
            </div>
            <form
              className="mt-4 space-y-3"
              onSubmit={async (e) => {
                e.preventDefault();
                setBusy(true);
                setError(null);
                try {
                  await login(email, password);
                  setOpen(false);
                } catch (err: any) {
                  setError(err?.message || "Sign-in failed");
                } finally {
                  setBusy(false);
                }
              }}
            >
              <label className="block">
                <span className="label">Email</span>
                <input className="input" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </label>
              <label className="block">
                <span className="label">Password</span>
                <input className="input" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </label>
              {error && (
                <p className="rounded border border-red-500/30 bg-red-500/5 p-2 text-xs text-red-300" role="alert">
                  {error}
                </p>
              )}
              <button className="btn-primary w-full" disabled={busy} type="submit">
                {busy ? "Signing in…" : "Sign in"}
              </button>
            </form>
            <div className="mt-4 rounded-lg border border-white/10 bg-white/[0.03] p-2.5 text-[11px] text-slate-400">
              <p className="font-medium text-slate-300">Demo accounts (development only)</p>
              <p className="mt-0.5">admin@aegis.local · analyst@aegis.local · citizen@aegis.local</p>
              <p>Password: <code className="text-cyan-300">aegis-demo-2026</code> (change AEGIS_DEMO_PASSWORD in production)</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/** Project identity — surfaced in the sidebar, footer and About screen. */
export const TEAM_NAME = "Team OG ciper";
export const TEAM_EVENT = "HACK-X · AEGIS pitch deck";

export default function AppShell({ children }: { children: React.ReactNode }) {
  const [navOpen, setNavOpen] = useState(false);
  const [demoCount, setDemoCount] = useState(0);
  const [liveCount, setLiveCount] = useState(0);
  const location = useLocation();

  useEffect(() => {
    setNavOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    let alive = true;
    api
      .dashboard(72)
      .then((d) => {
        if (alive) {
          setDemoCount(d?.counts?.demo_incidents || 0);
          setLiveCount(d?.counts?.live_incidents || 0);
        }
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen bg-navy-950">
      {/* sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 transform border-r border-white/5 bg-navy-900/95 backdrop-blur transition-transform lg:static lg:translate-x-0 ${
          navOpen ? "translate-x-0" : "-translate-x-full"
        }`}
        aria-label="Primary navigation"
      >
        <div className="flex h-16 items-center justify-between border-b border-white/5 px-4">
          <div className="flex items-center gap-2.5">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-cyan-500/15 ring-1 ring-cyan-400/30">
              <ShieldAlert className="h-4.5 w-4.5 text-cyan-300" aria-hidden />
            </div>
            <div>
              <p className="text-sm font-semibold tracking-wide text-slate-100">AEGIS</p>
              <p className="text-[10px] uppercase tracking-widest text-slate-500">Disaster intelligence</p>
            </div>
          </div>
          <button className="btn-ghost btn-xs lg:hidden" onClick={() => setNavOpen(false)} aria-label="Close navigation">
            <X className="h-3 w-3" aria-hidden />
          </button>
        </div>
        <nav className="space-y-0.5 p-2.5">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] transition-colors ${
                  isActive
                    ? "bg-cyan-500/10 text-cyan-200 ring-1 ring-inset ring-cyan-400/20"
                    : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                }`
              }
            >
              <item.icon className="h-4 w-4 shrink-0" aria-hidden />
              <span className="truncate">{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="mx-2.5 mt-2 rounded-lg border border-white/5 bg-white/[0.02] p-2.5 text-[10px] leading-relaxed text-slate-500">
          <p className="font-semibold text-slate-400">Decision support only</p>
          <p className="mt-1">
            AEGIS is not an official warning service. Follow instructions from your national or state disaster
            management authority. India: <strong className="text-slate-300">112</strong> · US:{" "}
            <strong className="text-slate-300">911</strong>
          </p>
        </div>

        {/* team credit */}
        <div className="mx-2.5 my-2.5 flex items-center gap-2.5 rounded-lg border border-cyan-400/15 bg-cyan-500/[0.06] p-2.5">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-cyan-500/15 ring-1 ring-cyan-400/25">
            <Users className="h-3.5 w-3.5 text-cyan-300" aria-hidden />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-widest text-slate-500">Built by</p>
            <p className="truncate text-[12px] font-semibold text-cyan-200">{TEAM_NAME}</p>
            {TEAM_EVENT && <p className="truncate text-[10px] text-slate-500">{TEAM_EVENT}</p>}
          </div>
        </div>
      </aside>

      {navOpen && (
        <button
          className="fixed inset-0 z-30 bg-navy-950/70 lg:hidden"
          aria-label="Close navigation overlay"
          onClick={() => setNavOpen(false)}
        />
      )}

      {/* main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-white/5 bg-navy-950/85 px-3 backdrop-blur sm:px-5">
          <button className="btn-ghost btn-xs lg:hidden" onClick={() => setNavOpen(true)} aria-label="Open navigation">
            <Menu className="h-4 w-4" aria-hidden />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-sm font-semibold text-slate-100">
              {NAV.find((n) => n.to === location.pathname)?.label || "Incident intelligence"}
            </h1>
            <p className="hidden truncate text-[11px] text-slate-500 sm:block">
              Multi-disaster detection · explainable risk · citizen intelligence · early warning
            </p>
          </div>
          <SystemPill />
          <AuthMenu />
        </header>

        {demoCount > 0 && (
          <div className="px-3 pt-3 sm:px-5">
            <Banner tone="warn" title="Labelled demonstration records are present">
              {demoCount} record{demoCount === 1 ? "" : "s"} carry{" "}
              <code className="text-amber-200">data_origin=demo</code> and a DEMO badge. They are simulated sample
              data for the hazard classes that have no live public sensor feed in this build (landslide, industrial
              fire, urban flood){liveCount > 0 ? " — shown alongside the live records" : ""}. They are never presented
              as observations and never as official warnings; remove them with{" "}
              <code className="text-amber-200">python scripts/seed_demo.py --clear</code>.
            </Banner>
          </div>
        )}

        <main className="min-w-0 flex-1 p-3 sm:p-5">{children}</main>

        <footer className="border-t border-white/5 px-3 py-3 text-[10px] leading-relaxed text-slate-600 sm:px-5">
          <p className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <FileText className="h-3 w-3" aria-hidden />
            Data: USGS · NOAA NHC/NWS · GDACS (JRC) · NASA FIRMS/GIBS · Open-Meteo · OpenStreetMap (ODbL) · Natural
            Earth · ISRO/IMD/INCOIS (link-only). Official warnings belong to their issuing authorities.
          </p>
          <p className="mt-1">
            AEGIS risk scores, footprints and extrapolations are model estimates generated from the cited evidence —
            not official forecasts. Verify anything safety-critical with the responsible agency.
          </p>
          <p className="mt-1.5 flex flex-wrap items-center gap-x-1.5 text-slate-500">
            <span className="font-semibold text-slate-400">{TEAM_NAME}</span>
            {TEAM_EVENT && <span>· {TEAM_EVENT}</span>}
            <span>· built with AEGIS (Agentic AI Multi-Disaster Intelligence &amp; Early-Warning Platform)</span>
          </p>
        </footer>
      </div>
    </div>
  );
}
