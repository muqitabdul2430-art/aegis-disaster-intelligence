import React from "react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, PolarAngleAxis, PolarGrid,
  Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { HAZARD_META, RISK_TONE } from "../lib/format";

const AXIS = { stroke: "#334155", fontSize: 10 };
const GRID = "#16233c";

export function CategoryBar({ data }: { data: Record<string, number> }) {
  const rows = Object.entries(data || {})
    .map(([k, v]) => ({ key: k, label: (HAZARD_META[k] || HAZARD_META.unknown).label, value: v, color: (HAZARD_META[k] || HAZARD_META.unknown).color }))
    .sort((a, b) => b.value - a.value);
  if (!rows.length) return <p className="py-6 text-center text-xs text-slate-500">No active incidents in this window.</p>;
  return (
    <ResponsiveContainer width="100%" height={Math.max(140, rows.length * 34)}>
      <BarChart data={rows} layout="vertical" margin={{ left: 4, right: 16, top: 4, bottom: 4 }}>
        <CartesianGrid stroke={GRID} horizontal={false} />
        <XAxis type="number" {...AXIS} allowDecimals={false} />
        <YAxis type="category" dataKey="label" {...AXIS} width={96} />
        <Tooltip
          contentStyle={{ background: "#0a1224", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }}
          formatter={(v: any) => [`${v} active`, ""]}
        />
        <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={14}>
          {rows.map((r) => (
            <Cell key={r.key} fill={r.color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function RiskDonut({ data }: { data: Record<string, number> }) {
  const order = ["extreme", "high", "moderate", "low", "minimal", "unassessed"];
  const rows = order
    .filter((k) => data?.[k])
    .map((k) => ({ key: k, label: k, value: data[k] }));
  const total = rows.reduce((s, r) => s + r.value, 0);
  if (!total) return <p className="py-6 text-center text-xs text-slate-500">No risk assessments yet.</p>;
  const colors: Record<string, string> = {
    extreme: "#ef4444", high: "#f97316", moderate: "#eab308", low: "#22c55e", minimal: "#38bdf8", unassessed: "#475569",
  };
  let offset = 0;
  const R = 52;
  const C = 2 * Math.PI * R;
  return (
    <div className="flex items-center gap-4">
      <svg viewBox="0 0 140 140" className="h-36 w-36 shrink-0" role="img" aria-label="Risk level distribution">
        <g transform="rotate(-90 70 70)">
          {rows.map((r) => {
            const frac = r.value / total;
            const dash = `${frac * C} ${C - frac * C}`;
            const el = (
              <circle
                key={r.key}
                cx="70"
                cy="70"
                r={R}
                fill="none"
                stroke={colors[r.key]}
                strokeWidth="14"
                strokeDasharray={dash}
                strokeDashoffset={-offset * C}
                strokeLinecap="butt"
              />
            );
            offset += frac;
            return el;
          })}
        </g>
        <text x="70" y="66" textAnchor="middle" className="fill-slate-100" style={{ fontSize: 20, fontWeight: 600 }}>
          {total}
        </text>
        <text x="70" y="84" textAnchor="middle" className="fill-slate-500" style={{ fontSize: 9, letterSpacing: 1 }}>
          ASSESSED
        </text>
      </svg>
      <ul className="space-y-1 text-xs">
        {rows.map((r) => (
          <li key={r.key} className="flex items-center gap-2 text-slate-300">
            <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: colors[r.key] }} />
            <span className="capitalize">{r.label}</span>
            <span className="ml-auto tabular-nums text-slate-400">{r.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function RiskHistoryChart({ series }: { series: { at: string; risk_score: number; risk_level: string }[] }) {
  if (!series?.length) return <p className="py-6 text-center text-xs text-slate-500">No assessment history yet — trend needs at least two assessments.</p>;
  const data = series.map((s) => ({ ...s, label: new Date(s.at).toISOString().slice(11, 16) }));
  return (
    <ResponsiveContainer width="100%" height={160}>
      <LineChart data={data} margin={{ left: -18, right: 10, top: 6, bottom: 0 }}>
        <CartesianGrid stroke={GRID} />
        <XAxis dataKey="label" {...AXIS} />
        <YAxis domain={[0, 100]} {...AXIS} />
        <Tooltip
          contentStyle={{ background: "#0a1224", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }}
          formatter={(v: any) => [`${v}/100`, "AEGIS risk estimate"]}
          labelFormatter={(l) => `assessment at ${l}Z`}
        />
        <Line type="monotone" dataKey="risk_score" stroke="#22d3ee" strokeWidth={2} dot={{ r: 3, fill: "#22d3ee" }} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function RiskComponentsRadar({ components }: { components: { hazard: number; exposure: number; vulnerability: number } }) {
  const data = [
    { subject: "Hazard", value: Math.round(components.hazard) },
    { subject: "Exposure", value: Math.round(components.exposure) },
    { subject: "Vulnerability", value: Math.round(components.vulnerability) },
  ];
  return (
    <ResponsiveContainer width="100%" height={190}>
      <RadarChart data={data} outerRadius="72%">
        <PolarGrid stroke={GRID} />
        <PolarAngleAxis dataKey="subject" tick={{ fill: "#94a3b8", fontSize: 10 }} />
        <Radar dataKey="value" stroke="#22d3ee" fill="#22d3ee" fillOpacity={0.28} />
        <Tooltip contentStyle={{ background: "#0a1224", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }} />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export function WeatherDriversChart({
  points,
  field = "precip_mm",
  label = "Rain (mm/h)",
  color = "#3b82f6",
}: {
  points: any[];
  field?: string;
  label?: string;
  color?: string;
}) {
  const nowIso = new Date().toISOString().slice(0, 13);
  const data = (points || []).map((p: any) => ({ ...p, label: (p.time || "").slice(5, 16).replace("T", " ") }));
  const nowIdx = data.findIndex((d: any) => (d.time || "").slice(0, 13) >= nowIso);
  if (!data.length) return <p className="py-6 text-center text-xs text-slate-500">Weather model unavailable.</p>;
  return (
    <ResponsiveContainer width="100%" height={170}>
      <AreaChart data={data} margin={{ left: -20, right: 8, top: 6, bottom: 0 }}>
        <defs>
          <linearGradient id={`grad-${field}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.5} />
            <stop offset="100%" stopColor={color} stopOpacity={0.03} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={GRID} />
        <XAxis dataKey="label" {...AXIS} minTickGap={26} />
        <YAxis {...AXIS} />
        <Tooltip contentStyle={{ background: "#0a1224", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }} />
        {nowIdx >= 0 && <Line type="monotone" dataKey={() => 0} stroke="transparent" />}
        <Area type="monotone" dataKey={field} name={label} stroke={color} fill={`url(#grad-${field})`} strokeWidth={1.6} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function ObservationsBar({ bySource }: { bySource: Record<string, number> }) {
  const rows = Object.entries(bySource || {}).map(([k, v]) => ({ label: k.replace(/_/g, " "), value: v }));
  if (!rows.length) return <p className="py-6 text-center text-xs text-slate-500">No observations ingested in this window.</p>;
  return (
    <ResponsiveContainer width="100%" height={150}>
      <BarChart data={rows} margin={{ left: -20, right: 10, top: 4, bottom: 0 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="label" {...AXIS} interval={0} angle={-18} textAnchor="end" height={46} />
        <YAxis {...AXIS} allowDecimals={false} />
        <Tooltip contentStyle={{ background: "#0a1224", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }} />
        <Bar dataKey="value" fill="#0891b2" radius={[3, 3, 0, 0]} barSize={22} />
      </BarChart>
    </ResponsiveContainer>
  );
}
