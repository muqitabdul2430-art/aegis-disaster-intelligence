import React from "react";
import { AlertTriangle, Inbox, Loader2, RefreshCw, WifiOff } from "lucide-react";
import { AegisApiError } from "../lib/api";

/** Reusable, accessible primitives shared by every screen. */

export function Card({
  title,
  subtitle,
  actions,
  children,
  className = "",
  bodyClassName = "",
  dense = false,
}: {
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  bodyClassName?: string;
  dense?: boolean;
}) {
  return (
    <section className={`panel ${className}`}>
      {(title || actions) && (
        <header className="panel-head">
          <div className="min-w-0">
            {title && <h2 className="panel-title truncate">{title}</h2>}
            {subtitle && <p className="panel-sub mt-0.5">{subtitle}</p>}
          </div>
          {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
        </header>
      )}
      <div className={`${dense ? "p-3" : "p-4"} ${bodyClassName}`}>{children}</div>
    </section>
  );
}

export function Chip({
  children,
  tone = "border-white/10 bg-white/5 text-slate-300",
  title,
  className = "",
}: {
  children: React.ReactNode;
  tone?: string;
  title?: string;
  className?: string;
}) {
  return (
    <span className={`chip ${tone} ${className}`} title={title}>
      {children}
    </span>
  );
}

export function DemoBadge({ label = "Demo data" }: { label?: string }) {
  return (
    <Chip
      tone="border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-300"
      title="This record is labelled demonstration data generated because no live feed was available. It is never an official warning."
    >
      {label}
    </Chip>
  );
}

export function EstimateBadge({ label = "Model estimate" }: { label?: string }) {
  return (
    <Chip tone="border-sky-500/40 bg-sky-500/10 text-sky-300" title="AEGIS model output, not an official forecast.">
      {label}
    </Chip>
  );
}

export function OfficialBadge({ label = "Official" }: { label?: string }) {
  return (
    <Chip tone="border-emerald-500/40 bg-emerald-500/10 text-emerald-300" title="Ingested verbatim from the issuing authority.">
      {label}
    </Chip>
  );
}

export function SeverityPips({ severity, color }: { severity: number; color?: string }) {
  return (
    <span className="inline-flex items-center gap-0.5" title={`Severity band ${severity}/5`} aria-label={`Severity ${severity} of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span
          key={i}
          className="h-1.5 w-3 rounded-sm"
          style={{ background: i <= severity ? color || "#22d3ee" : "rgba(255,255,255,0.12)" }}
        />
      ))}
    </span>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "text-slate-100",
  icon,
}: {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  tone?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="panel p-3.5">
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] uppercase tracking-wide text-slate-500">{label}</p>
        {icon}
      </div>
      <p className={`mt-1 text-2xl font-semibold tabular-nums ${tone}`}>{value}</p>
      {hint && <p className="mt-1 text-[11px] leading-snug text-slate-500">{hint}</p>}
    </div>
  );
}

export function Spinner({ label = "Loading" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-slate-400" role="status" aria-live="polite">
      <Loader2 className="h-4 w-4 animate-spin text-cyan-400" aria-hidden />
      {label}…
    </div>
  );
}

export function Skeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-2" aria-hidden>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="skeleton" style={{ width: `${90 - i * 8}%` }} />
      ))}
    </div>
  );
}

export function EmptyState({
  title,
  message,
  icon,
  action,
}: {
  title: string;
  message?: React.ReactNode;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
      <div className="text-slate-600">{icon || <Inbox className="h-7 w-7" aria-hidden />}</div>
      <p className="text-sm font-medium text-slate-300">{title}</p>
      {message && <p className="max-w-md text-xs text-slate-500">{message}</p>}
      {action}
    </div>
  );
}

export function ErrorState({
  error,
  onRetry,
  compact = false,
}: {
  error: unknown;
  onRetry?: () => void;
  compact?: boolean;
}) {
  const apiErr = error instanceof AegisApiError ? error : null;
  const offline = apiErr?.offline;
  const rateLimited = apiErr?.rateLimited;
  const message = apiErr?.message || (error as any)?.message || "Something went wrong.";
  return (
    <div
      className={`flex items-start gap-3 rounded-lg border p-3 ${
        offline ? "border-amber-500/30 bg-amber-500/5" : "border-red-500/30 bg-red-500/5"
      }`}
      role="alert"
    >
      {offline ? (
        <WifiOff className="h-4 w-4 mt-0.5 text-amber-400 shrink-0" aria-hidden />
      ) : (
        <AlertTriangle className="h-4 w-4 mt-0.5 text-red-400 shrink-0" aria-hidden />
      )}
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-slate-200">
          {offline ? "Backend unreachable" : rateLimited ? "Rate limit reached" : "Request failed"}
        </p>
        <p className="mt-0.5 text-xs text-slate-400 break-words">{message}</p>
        {!compact && offline && (
          <p className="mt-1 text-[11px] text-slate-500">
            AEGIS shows only what it has actually retrieved. Nothing is substituted with placeholder data while the
            connection is down.
          </p>
        )}
        {onRetry && (
          <button className="btn-ghost btn-xs mt-2" onClick={onRetry}>
            <RefreshCw className="h-3 w-3" aria-hidden /> Retry
          </button>
        )}
      </div>
    </div>
  );
}

export function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { id: string; label: string; count?: number }[];
  active: string;
  onChange: (id: string) => void;
}) {
  return (
    <div role="tablist" className="flex flex-wrap gap-1 border-b border-white/5 pb-px">
      {tabs.map((t) => (
        <button
          key={t.id}
          role="tab"
          aria-selected={active === t.id}
          onClick={() => onChange(t.id)}
          className={`rounded-t-md px-3 py-2 text-[13px] font-medium transition-colors ${
            active === t.id
              ? "bg-white/5 text-cyan-300 border-b-2 border-cyan-400"
              : "text-slate-400 hover:text-slate-200 border-b-2 border-transparent"
          }`}
        >
          {t.label}
          {t.count !== undefined && (
            <span className="ml-1.5 rounded bg-white/10 px-1.5 py-0.5 text-[10px] tabular-nums">{t.count}</span>
          )}
        </button>
      ))}
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
  required,
}: {
  label: string;
  hint?: React.ReactNode;
  children: React.ReactNode;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="label">
        {label} {required && <span className="text-red-400">*</span>}
      </span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-slate-500">{hint}</span>}
    </label>
  );
}

export function Banner({
  tone = "info",
  title,
  children,
  action,
}: {
  tone?: "info" | "warn" | "danger" | "success";
  title?: string;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  const tones: Record<string, string> = {
    info: "border-cyan-500/30 bg-cyan-500/5 text-cyan-100",
    warn: "border-amber-500/30 bg-amber-500/5 text-amber-100",
    danger: "border-red-500/30 bg-red-500/5 text-red-100",
    success: "border-emerald-500/30 bg-emerald-500/5 text-emerald-100",
  };
  return (
    <div className={`rounded-lg border p-3 ${tones[tone]}`}>
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          {title && <p className="text-sm font-semibold">{title}</p>}
          <div className="text-xs leading-relaxed opacity-90">{children}</div>
        </div>
        {action}
      </div>
    </div>
  );
}

export function ProgressBar({ value, tone = "#22d3ee" }: { value: number; tone?: string }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
      <div className="h-full rounded-full transition-all" style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: tone }} />
    </div>
  );
}

export function Tooltip({ text, children }: { text: string; children: React.ReactNode }) {
  return (
    <span className="group relative inline-flex">
      {children}
      <span
        role="tooltip"
        className="pointer-events-none absolute bottom-full left-1/2 z-30 mb-2 w-56 -translate-x-1/2 rounded-md border border-white/10 bg-navy-900 p-2 text-[11px] leading-snug text-slate-300 opacity-0 shadow-lg transition-opacity group-hover:opacity-100 group-focus-within:opacity-100"
      >
        {text}
      </span>
    </span>
  );
}
