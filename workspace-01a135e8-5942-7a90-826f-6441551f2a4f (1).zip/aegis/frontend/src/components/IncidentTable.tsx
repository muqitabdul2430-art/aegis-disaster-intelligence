import React from "react";
import { Link } from "react-router-dom";
import { Incident } from "../lib/api";
import { VERIFICATION_META, coords, hazardMeta, riskTone, severityColor, timeAgo } from "../lib/format";
import { Chip, DemoBadge, SeverityPips } from "./ui";

export function RiskPill({ risk }: { risk?: Incident["risk"] }) {
  const tone = riskTone(risk?.level);
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-[11px] font-medium ring-1 ${tone.bg} ${tone.text} ${tone.ring}`}
      title="AEGIS model estimate (risk-v1.0) — not an official forecast"
    >
      <span className="tabular-nums">{risk ? Math.round(risk.score) : "—"}</span>
      <span className="uppercase tracking-wide">{risk?.level || "unassessed"}</span>
    </span>
  );
}

export function VerificationChip({ status }: { status: string }) {
  const meta = VERIFICATION_META[status] || {
    label: status.replace(/_/g, " "),
    tone: "border-slate-500/40 bg-slate-500/10 text-slate-400",
    meaning: "",
  };
  return (
    <Chip tone={meta.tone} title={meta.meaning}>
      {meta.label}
    </Chip>
  );
}

export function IncidentTable({
  incidents,
  selectedId,
  onSelect,
  emptyMessage = "No incidents match the current filters.",
  compact = false,
}: {
  incidents: Incident[];
  selectedId?: string | null;
  onSelect?: (i: Incident) => void;
  emptyMessage?: string;
  compact?: boolean;
}) {
  if (!incidents.length) {
    return <p className="px-3 py-8 text-center text-xs text-slate-500">{emptyMessage}</p>;
  }
  return (
    <div className="table-wrap">
      <table className="data-table">
        <caption className="sr-only">Active incidents with category, verification status, severity and AEGIS risk estimate</caption>
        <thead>
          <tr>
            <th scope="col">Incident</th>
            <th scope="col">Category</th>
            <th scope="col">Severity</th>
            <th scope="col">Verification</th>
            <th scope="col">AEGIS risk</th>
            {!compact && <th scope="col">Location</th>}
            <th scope="col">Updated</th>
          </tr>
        </thead>
        <tbody>
          {incidents.map((inc) => {
            const meta = hazardMeta(inc.category);
            return (
              <tr
                key={inc.id}
                className={selectedId === inc.id ? "bg-cyan-500/[0.06]" : undefined}
                onClick={() => onSelect?.(inc)}
                style={{ cursor: onSelect ? "pointer" : undefined }}
              >
                <td className="min-w-[240px]">
                  <div className="flex items-start gap-2">
                    <span
                      className="mt-1 inline-block h-2.5 w-2.5 shrink-0 rounded-full"
                      style={{ background: severityColor(inc.severity, inc.category) }}
                      aria-hidden
                    />
                    <div className="min-w-0">
                      <Link
                        to={`/incidents/${inc.id}`}
                        className="line-clamp-2 text-[13px] font-medium text-slate-100 hover:text-cyan-300"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {inc.title}
                      </Link>
                      <p className="mt-0.5 font-mono text-[10px] text-slate-500">
                        {inc.code}
                        {inc.is_ambiguous ? " · ⚠ ambiguous classification" : ""}
                      </p>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="inline-flex items-center gap-1.5 text-xs text-slate-300" title={meta.blurb}>
                    <span aria-hidden>{meta.glyph}</span> {meta.label}
                  </span>
                </td>
                <td>
                  <SeverityPips severity={inc.severity} color={severityColor(inc.severity, inc.category)} />
                </td>
                <td>
                  <div className="flex flex-wrap items-center gap-1">
                    <VerificationChip status={inc.verification_status} />
                    {inc.is_demo && <DemoBadge />}
                  </div>
                </td>
                <td>
                  <RiskPill risk={inc.risk} />
                </td>
                {!compact && (
                  <td className="text-xs text-slate-400">
                    <div className="max-w-[220px] truncate" title={inc.region}>
                      {inc.region || "unresolved"}
                    </div>
                    <div className="font-mono text-[10px] text-slate-500">{coords(inc.lat, inc.lon, 2)}</div>
                  </td>
                )}
                <td className="whitespace-nowrap text-xs text-slate-400">{timeAgo(inc.last_update_at)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
