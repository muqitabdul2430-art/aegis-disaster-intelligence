import React, { useEffect, useMemo, useRef, useState } from "react";
import { GeoJSON, MapContainer, Marker, Polygon, Popup, ScaleControl, TileLayer, Tooltip as LeafletTooltip, useMap, ZoomControl } from "react-leaflet";
import L from "leaflet";
import { Globe, Layers, Locate, MapPin, Satellite, WifiOff } from "lucide-react";
import { Alert, AffectedArea, Incident } from "../lib/api";
import { HAZARD_META, coords, hazardMeta, severityColor, timeAgo } from "../lib/format";
import { Chip, Spinner } from "./ui";

/**
 * AEGIS map.
 *
 * Live street/imagery tiles need internet access; the operational overlays
 * (incidents, footprints, alerts, facilities) come from the AEGIS API. When
 * tile servers are unreachable — offline deployments, air-gapped EOCs, or a
 * sandboxed preview — the map automatically switches to the bundled
 * Natural Earth basemap (public domain, shipped with the app) so geography,
 * incidents and footprints stay fully usable, and says so on screen.
 */

export type Facility = {
  osm_id: string;
  class: string;
  name: string;
  lat: number;
  lon: number;
  distance_km: number;
  phone?: string;
  osm_url?: string;
};

export type MapLayers = {
  countries: boolean;
  cities: boolean;
  incidents: boolean;
  footprints: boolean;
  alerts: boolean;
  facilities: boolean;
  /** Online OpenStreetMap raster tiles (dark-filtered) — needs internet. */
  street: boolean;
  /** Online Esri World Imagery satellite tiles — needs internet. */
  satellite: boolean;
};

type Props = {
  incidents: Incident[];
  alerts?: Alert[];
  facilities?: Facility[];
  selectedId?: string | null;
  onSelect?: (incident: Incident) => void;
  height?: string;
  center?: [number, number];
  zoom?: number;
  showControls?: boolean;
  onMapClick?: (lat: number, lon: number) => void;
  pickMode?: boolean;
  layersOverride?: Partial<MapLayers>;
  extraMarkers?: { lat: number; lon: number; label: string; color?: string }[];
};

const DEFAULT_LAYERS: MapLayers = {
  countries: true,
  cities: true,
  incidents: true,
  footprints: true,
  alerts: false,
  facilities: true,
  // Both online basemaps default OFF: the vector Natural Earth basemap is
  // public-domain, always available and never shows provider watermarks.
  street: false,
  satellite: false,
};

// Online basemaps. Both are keyless and attribution-carrying; the OSM raster is
// dark-filtered in CSS (styles.css .leaflet-tile-dark) so the map keeps the
// command-centre look instead of a bright, out-of-place street map.
const OSM_TILE = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
const SAT_TILE = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";

function markerIcon(incident: Incident, selected: boolean) {
  const color = severityColor(incident.severity, incident.category);
  const pulse = incident.severity >= 4 && incident.status === "active" ? "pulse" : "";
  const size = selected ? 20 : 14;
  const glyph = hazardMeta(incident.category).glyph;
  return L.divIcon({
    className: "aegis-marker",
    html: `<div class="aegis-dot ${pulse} ${selected ? "selected" : ""}" style="color:${color};background:${color};width:${size}px;height:${size}px;display:grid;place-items:center;font-size:${
      selected ? 11 : 8
    }px;line-height:1">${incident.severity >= 3 ? glyph : ""}</div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

function facilityIcon(cls: string) {
  const colors: Record<string, string> = {
    hospital: "#f87171",
    clinic: "#fb923c",
    fire_station: "#fbbf24",
    police: "#60a5fa",
    shelter: "#34d399",
    ambulance: "#f472b6",
    pharmacy: "#a78bfa",
  };
  const color = colors[cls] || "#94a3b8";
  return L.divIcon({
    className: "aegis-marker",
    html: `<div class="aegis-facility" style="background:${color}"></div>`,
    iconSize: [12, 12],
    iconAnchor: [6, 6],
  });
}

function FlyTo({ target }: { target?: [number, number, number] | null }) {
  const map = useMap();
  useEffect(() => {
    if (target) map.flyTo([target[0], target[1]], target[2], { duration: 0.8 });
  }, [target, map]);
  return null;
}

function ClickCapture({ pickMode, onMapClick }: { pickMode?: boolean; onMapClick?: (lat: number, lon: number) => void }) {
  const map = useMap();
  useEffect(() => {
    if (!pickMode || !onMapClick) return;
    const handler = (e: L.LeafletMouseEvent) => onMapClick(e.latlng.lat, e.latlng.lng);
    map.on("click", handler);
    return () => {
      map.off("click", handler);
    };
  }, [map, pickMode, onMapClick]);
  return null;
}

/** Probes a tile tile to decide whether online basemaps are usable. */
function useTileAvailability() {
  const [state, setState] = useState<"checking" | "online" | "offline">("checking");
  useEffect(() => {
    let done = false;
    const img = new Image();
    const timer = window.setTimeout(() => {
      if (!done) {
        done = true;
        setState("offline");
      }
    }, 6000);
    img.onload = () => {
      if (!done) {
        done = true;
        window.clearTimeout(timer);
        setState("online");
      }
    };
    img.onerror = () => {
      if (!done) {
        done = true;
        window.clearTimeout(timer);
        setState("offline");
      }
    };
    img.src = "https://a.tile.openstreetmap.org/2/1/1.png";
    return () => {
      done = true;
      window.clearTimeout(timer);
    };
  }, []);
  return state;
}

export default function MapView({
  incidents,
  alerts = [],
  facilities = [],
  selectedId,
  onSelect,
  height = "520px",
  center = [18, 78],
  zoom = 3,
  showControls = true,
  onMapClick,
  pickMode = false,
  layersOverride,
  extraMarkers = [],
}: Props) {
  const [layers, setLayers] = useState<MapLayers>({ ...DEFAULT_LAYERS, ...layersOverride });
  const [showLayerPanel, setShowLayerPanel] = useState(false);
  const [countries, setCountries] = useState<any>(null);
  const [cities, setCities] = useState<any[]>([]);
  const [flyTarget, setFlyTarget] = useState<[number, number, number] | null>(null);
  const tileState = useTileAvailability();
  const offline = tileState === "offline";
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/data/world_countries_110m.json")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => !cancelled && setCountries(d))
      .catch(() => undefined);
    fetch("/data/cities_2500.json")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => !cancelled && setCities((d?.places || []).filter((p: any) => (p.pop || 0) > 1_000_000)))
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  const alertItems = useMemo(
    () => alerts.filter((a) => a.lat !== null && a.lon !== null && a.status === "published"),
    [alerts],
  );

  const footprints = useMemo(() => {
    const out: { incident: Incident; area: AffectedArea }[] = [];
    incidents.forEach((i) => {
      (i.affected_areas || []).forEach((a) => {
        if (a.geojson) out.push({ incident: i, area: a });
      });
    });
    return out;
  }, [incidents]);

  return (
    <div ref={wrapRef} className="relative overflow-hidden rounded-xl border border-white/5" style={{ height }}>
      <MapContainer
        center={center}
        zoom={zoom}
        minZoom={2}
        worldCopyJump
        zoomControl={false}
        preferCanvas
        style={{ height: "100%", width: "100%" }}
      >
        {tileState === "online" && (layers.street || layers.satellite) && (
          <TileLayer
            key={layers.satellite ? "sat" : "street"}
            className={layers.satellite ? "" : "leaflet-tile-dark"}
            url={layers.satellite ? SAT_TILE : OSM_TILE}
            attribution={
              layers.satellite
                ? "Imagery © Esri, Maxar, Earthstar Geographics"
                : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }
            maxZoom={18}
            errorTileUrl="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
          />
        )}
        {showControls && <ZoomControl position="bottomright" />}
        <ScaleControl position="bottomleft" imperial={false} />
        <FlyTo target={flyTarget} />
        <ClickCapture pickMode={pickMode} onMapClick={onMapClick} />

        {layers.countries && countries && (
          <GeoJSON
            data={countries}
            style={{
              color: offline ? "rgba(120,150,190,0.35)" : "rgba(90,120,160,0.22)",
              weight: 0.6,
              fillColor: offline ? "#0a1224" : "#08101f",
              fillOpacity: offline ? 0.85 : 0.45,
            }}
            interactive={false}
          />
        )}

        {layers.cities &&
          cities.map((c: any, idx: number) => (
            <Marker
              key={`${c.name}-${idx}`}
              position={[c.lat, c.lon]}
              interactive={false}
              icon={L.divIcon({
                className: "",
                html: `<div style="width:3px;height:3px;border-radius:999px;background:rgba(148,163,184,0.55)"></div>`,
                iconSize: [3, 3],
              })}
            >
              <LeafletTooltip direction="right" offset={[4, 0]} opacity={0.9} permanent={false}>
                <span style={{ fontSize: 11 }}>
                  {c.name} {c.country ? `· ${c.country}` : ""} {c.pop ? `· ≈${(c.pop / 1e6).toFixed(1)}M` : ""}
                </span>
              </LeafletTooltip>
            </Marker>
          ))}

        {layers.footprints &&
          footprints.map(({ incident, area }, idx) => {
            const coordsArr = area.geojson?.coordinates?.[0] || [];
            if (!coordsArr.length) return null;
            const positions = coordsArr.map((c: number[]) => [c[1], c[0]] as [number, number]);
            const color = area.is_estimate ? severityColor(incident.severity, incident.category) : "#22d3ee";
            return (
              <Polygon
                key={`${incident.id}-${area.id}-${idx}`}
                positions={positions}
                pathOptions={{
                  color,
                  weight: area.is_estimate ? 1.2 : 2,
                  dashArray: area.is_estimate ? "5 5" : undefined,
                  fillColor: color,
                  fillOpacity: area.is_estimate ? 0.07 : 0.13,
                }}
              >
                <Popup>
                  <div className="space-y-1">
                    <p className="font-semibold">{area.label}</p>
                    <p className="text-[11px] text-slate-300">
                      {area.is_estimate
                        ? "AEGIS model estimate — dashed outline"
                        : `Authoritative polygon · ${area.authority || "provider"}`}
                    </p>
                    {area.area_km2 != null && <p className="text-[11px] text-slate-400">Area ≈ {Math.round(area.area_km2).toLocaleString()} km²</p>}
                    {area.population_estimate != null && (
                      <p className="text-[11px] text-slate-400">
                        Modelled population in footprint ≈ {area.population_estimate.toLocaleString()}
                      </p>
                    )}
                    <p className="text-[10px] text-slate-500">{area.method}</p>
                  </div>
                </Popup>
              </Polygon>
            );
          })}

        {layers.alerts &&
          alertItems.map((a) => (
            <Marker
              key={a.id}
              position={[a.lat as number, a.lon as number]}
              icon={L.divIcon({
                className: "aegis-marker",
                html: `<div style="width:22px;height:22px;border-radius:999px;border:2px solid ${
                  a.is_official ? "#34d399" : "#f59e0b"
                };display:grid;place-items:center;font-size:9px;color:${a.is_official ? "#34d399" : "#f59e0b"};background:rgba(5,10,22,0.75)">${
                  a.is_official ? "OFF" : "AI"
                }</div>`,
                iconSize: [22, 22],
                iconAnchor: [11, 11],
              })}
            >
              <Popup>
                <div className="space-y-1 max-w-[260px]">
                  <p className="font-semibold">{a.title}</p>
                  <p className="text-[11px]">
                    {a.is_official ? `Official · ${a.authority}` : "AEGIS advisory (not an official warning)"}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    {a.severity.toUpperCase()} · issued {timeAgo(a.issued_at)}
                  </p>
                </div>
              </Popup>
            </Marker>
          ))}

        {layers.facilities &&
          facilities.map((f) => (
            <Marker key={f.osm_id} position={[f.lat, f.lon]} icon={facilityIcon(f.class)}>
              <Popup>
                <div className="space-y-0.5">
                  <p className="font-semibold">{f.name}</p>
                  <p className="text-[11px] capitalize text-slate-300">
                    {f.class.replace("_", " ")} · {f.distance_km} km from incident
                  </p>
                  {f.phone && <p className="text-[11px] text-slate-400">☎ {f.phone}</p>}
                  <p className="text-[10px] text-slate-500">Source: OpenStreetMap (community-mapped, verify before travel)</p>
                </div>
              </Popup>
            </Marker>
          ))}

        {layers.incidents &&
          incidents.map((inc) => (
            <Marker
              key={inc.id}
              position={[inc.lat, inc.lon]}
              icon={markerIcon(inc, selectedId === inc.id)}
              eventHandlers={{
                click: () => {
                  setFlyTarget([inc.lat, inc.lon, Math.max(5, 5)]);
                  onSelect?.(inc);
                },
              }}
            >
              <Popup>
                <div className="max-w-[280px] space-y-1.5">
                  <div className="flex items-center gap-1.5">
                    <span
                      className="inline-block h-2.5 w-2.5 rounded-full"
                      style={{ background: hazardMeta(inc.category).color }}
                    />
                    <span className="font-semibold">{inc.title}</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    {hazardMeta(inc.category).label} · severity {inc.severity}/5 ·{" "}
                    {inc.verification_status.replace("_", " ")}
                  </p>
                  {inc.risk && (
                    <p className="text-[11px] text-slate-300">
                      AEGIS risk estimate <strong>{inc.risk.score.toFixed(0)}/100</strong> ({inc.risk.level})
                    </p>
                  )}
                  <p className="text-[10px] text-slate-500">
                    {coords(inc.lat, inc.lon, 3)} · updated {timeAgo(inc.last_update_at)} · sources:{" "}
                    {(inc.source_keys || []).join(", ") || "—"}
                  </p>
                  {inc.is_demo && <p className="text-[10px] text-fuchsia-300">LABELLED DEMONSTRATION DATA</p>}
                  <p className="text-[10px] text-slate-500">Click the marker to open the incident brief.</p>
                </div>
              </Popup>
            </Marker>
          ))}

        {extraMarkers.map((m, i) => (
          <Marker
            key={`extra-${i}`}
            position={[m.lat, m.lon]}
            icon={L.divIcon({
              className: "aegis-marker",
              html: `<div style="width:14px;height:14px;border-radius:4px;background:${m.color || "#22d3ee"};border:2px solid rgba(5,10,22,0.9);box-shadow:0 0 12px -2px ${m.color || "#22d3ee"}"></div>`,
              iconSize: [14, 14],
              iconAnchor: [7, 7],
            })}
          >
            <LeafletTooltip permanent direction="top" offset={[0, -8]}>
              <span style={{ fontSize: 11 }}>{m.label}</span>
            </LeafletTooltip>
          </Marker>
        ))}
      </MapContainer>

      {/* ---------------- overlay chrome ---------------- */}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-2.5">
        <div className="pointer-events-auto flex flex-wrap items-center gap-1.5">
          {!(tileState === "online" && (layers.street || layers.satellite)) && (
            <Chip tone="border-amber-500/40 bg-amber-500/10 text-amber-200">
              <WifiOff className="h-3 w-3" aria-hidden /> Offline basemap (Natural Earth, public domain)
            </Chip>
          )}
          {tileState === "online" && (layers.street || layers.satellite) && (
            <Chip tone="border-white/10 bg-navy-900/80 text-slate-300">
              {layers.satellite ? "Esri World Imagery" : "OpenStreetMap raster"} · live tiles
            </Chip>
          )}
          {pickMode && (
            <Chip tone="border-cyan-500/40 bg-cyan-500/10 text-cyan-200">
              <MapPin className="h-3 w-3" aria-hidden /> Click the map to set the location
            </Chip>
          )}
          {tileState === "checking" && (
            <Chip tone="border-white/10 bg-navy-900/80 text-slate-400">
              <Spinner label="Checking tiles" />
            </Chip>
          )}
        </div>
        {showControls && (
          <div className="pointer-events-auto flex items-center gap-1.5">
            <button
              className={`btn-ghost btn-xs bg-navy-900/80 ${layers.street ? "text-cyan-300" : ""}`}
              onClick={() => setLayers((l) => ({ ...l, street: !l.street }))}
              disabled={offline}
              title={offline ? "Raster tiles unavailable — no internet access detected" : "Toggle OpenStreetMap raster basemap"}
            >
              <Globe className="h-3 w-3" aria-hidden /> Streets
            </button>
            <button
              className={`btn-ghost btn-xs bg-navy-900/80 ${layers.satellite ? "text-cyan-300" : ""}`}
              onClick={() => setLayers((l) => ({ ...l, satellite: !l.satellite }))}
              disabled={offline}
              title={offline ? "Imagery tiles unavailable offline" : "Toggle Esri World Imagery (satellite)"}
            >
              <Satellite className="h-3 w-3" aria-hidden /> Imagery
            </button>
            <button
              className="btn-ghost btn-xs bg-navy-900/80"
              onClick={() => setShowLayerPanel((s) => !s)}
              aria-expanded={showLayerPanel}
            >
              <Layers className="h-3 w-3" aria-hidden /> Layers
            </button>
            <button
              className="btn-ghost btn-xs bg-navy-900/80"
              onClick={() => setFlyTarget([center[0], center[1], zoom])}
              title="Recentre map"
            >
              <Locate className="h-3 w-3" aria-hidden /> Centre
            </button>
          </div>
        )}
      </div>

      {showLayerPanel && (
        <div className="absolute right-2.5 top-12 w-52 rounded-lg border border-white/10 bg-navy-900/95 p-2.5 text-xs shadow-panel">
          <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Map layers</p>
          <p className="mb-1.5 rounded border border-white/5 bg-white/[0.03] p-1.5 text-[10px] leading-snug text-slate-500">
            Base: offline Natural Earth vectors (public domain). “Streets”/“Imagery” add online raster tiles and are
            disabled when no internet is detected.
          </p>
          {[
            ["countries", "Country boundaries (offline)"],
            ["cities", "Major cities (≥1M, offline)"],
            ["incidents", "Incidents"],
            ["footprints", "Affected-area footprints"],
            ["alerts", "Alerts"],
            ["facilities", "Critical facilities (OSM)"],
          ].map(([key, label]) => (
            <label key={key} className="flex cursor-pointer items-center gap-2 py-1 text-slate-300">
              <input
                type="checkbox"
                className="h-3.5 w-3.5 accent-cyan-500"
                checked={(layers as any)[key]}
                onChange={(e) => setLayers((l) => ({ ...l, [key]: e.target.checked }))}
              />
              {label}
            </label>
          ))}
        </div>
      )}

      {/* legend */}
      <div className="absolute bottom-8 left-2.5 max-w-[260px] rounded-lg border border-white/10 bg-navy-900/90 p-2.5 text-[11px] shadow-panel">
        <p className="mb-1 font-semibold uppercase tracking-wide text-slate-400">Legend</p>
        <div className="grid grid-cols-2 gap-x-3 gap-y-1">
          {Object.entries(HAZARD_META)
            .filter(([k]) => k !== "unknown")
            .map(([key, meta]) => (
              <span key={key} className="flex items-center gap-1.5 text-slate-300">
                <span className="inline-block h-2 w-2 rounded-full" style={{ background: meta.color }} />
                {meta.label}
              </span>
            ))}
        </div>
        <p className="mt-1.5 border-t border-white/10 pt-1 text-[10px] text-slate-500">
          Ring size = severity band · dashed outline = AEGIS estimate · solid cyan = authoritative polygon
        </p>
      </div>
    </div>
  );
}
