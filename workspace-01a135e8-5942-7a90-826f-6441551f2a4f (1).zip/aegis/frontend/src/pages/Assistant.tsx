import React, { useEffect, useRef, useState } from "react";
import { Bot, CornerDownLeft, Info, Search, ShieldQuestion, Sparkles } from "lucide-react";
import { api } from "../lib/api";
import { timeAgo } from "../lib/format";
import { Banner, Card, Chip, EmptyState, ErrorState, Skeleton, Spinner } from "../components/ui";

type Turn = {
  id: string;
  question: string;
  answer?: any;
  error?: unknown;
  pending?: boolean;
  startedAt: string;
};

export default function Assistant() {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [question, setQuestion] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [context, setContext] = useState({ incidentId: "", bbox: "" });
  const [busy, setBusy] = useState(false);
  const [showTrace, setShowTrace] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api
      .suggestions()
      .then((r) => setSuggestions(r.suggestions || []))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [turns]);

  const ask = async (q: string) => {
    const text = q.trim();
    if (!text || busy) return;
    const id = `${Date.now()}`;
    setTurns((t) => [...t, { id, question: text, pending: true, startedAt: new Date().toISOString() }]);
    setQuestion("");
    setBusy(true);
    try {
      const payload: any = {};
      if (context.incidentId.trim()) payload.incident_id = context.incidentId.trim();
      if (context.bbox.trim()) {
        const parts = context.bbox.split(",").map(Number);
        if (parts.length === 4 && parts.every((n) => !Number.isNaN(n))) payload.bbox = parts;
      }
      const res = await api.ask(text, payload);
      setTurns((t) => t.map((turn) => (turn.id === id ? { ...turn, answer: res, pending: false } : turn)));
    } catch (e) {
      setTurns((t) => t.map((turn) => (turn.id === id ? { ...turn, error: e, pending: false } : turn)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_320px]">
      <div className="space-y-4">
        <Card
          title="AI intelligence assistant"
          subtitle="Every answer is produced by executing real retrieval tools — the tool calls and their outputs are shown with the answer"
          actions={<Chip tone="border-cyan-500/40 bg-cyan-500/10 text-cyan-300"><Sparkles className="h-3 w-3" aria-hidden /> retrieval-grounded</Chip>}
        >
          <Banner tone="info" title="How this assistant works">
            Your question is turned into a bounded execution plan by the coordinator agent, which then calls real tools
            (incident queries, official-warning lookup, risk explainability, OpenStreetMap facilities, weather model
            fields, corridor checks, data-gap review). The wording of the answer is the only part an LLM may produce —
            and only when a server-side key is configured. Retrieved facts, model estimates and unverified citizen
            reports are always separated.
          </Banner>

          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              void ask(question);
            }}
          >
            <input
              className="input"
              placeholder="e.g. Which active hazards are officially confirmed, and what does AEGIS still not see?"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              aria-label="Ask AEGIS a question"
            />
            <button className="btn-primary" type="submit" disabled={busy || question.trim().length < 3}>
              {busy ? <Spinner label="Thinking" /> : <><Search className="h-4 w-4" aria-hidden /> Ask</>}
            </button>
          </form>

          {suggestions.length > 0 && (
            <div className="mt-3">
              <p className="panel-sub mb-1.5">Suggested operational questions</p>
              <div className="flex flex-wrap gap-1.5">
                {suggestions.map((s) => (
                  <button key={s} className="chip border-white/10 bg-white/5 text-slate-300 hover:border-cyan-400/40 hover:text-cyan-200" onClick={() => void ask(s)}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
        </Card>

        {turns.length === 0 && (
          <Card>
            <EmptyState
              icon={<ShieldQuestion className="h-7 w-7" aria-hidden />}
              title="No questions yet"
              message="Ask about active hazards, why a risk rating is high, official bulletins, nearby facilities, data gaps or route screening. Answers cite the records they were built from."
            />
          </Card>
        )}

        {turns.map((turn) => (
          <Card key={turn.id} bodyClassName="space-y-3">
            <div className="flex items-start gap-2">
              <Chip tone="border-white/10 bg-white/5 text-slate-300">You</Chip>
              <p className="text-sm text-slate-100">{turn.question}</p>
            </div>

            {turn.pending && (
              <div className="space-y-2">
                <Spinner label="Coordinator is planning and executing tools" />
                <Skeleton rows={3} />
              </div>
            )}

            {turn.error && <ErrorState error={turn.error} />}

            {turn.answer && (
              <div className="space-y-3 border-t border-white/5 pt-3">
                <div className="flex items-start gap-2">
                  <Chip tone="border-cyan-500/40 bg-cyan-500/10 text-cyan-300">
                    <Bot className="h-3 w-3" aria-hidden /> AEGIS
                  </Chip>
                  <div className="min-w-0 flex-1">
                    <p className="whitespace-pre-line text-[13px] leading-relaxed text-slate-200">{turn.answer.answer}</p>
                    <p className="mt-1 text-[10px] text-slate-500">
                      {turn.answer.llm_used ? "Narrative: LLM, strictly over retrieved evidence · " : "Narrative: deterministic template · "}
                      {turn.answer.plan?.planner === "llm" ? "plan: LLM intent parsing (allow-listed tools) · " : "plan: rules · "}
                      {turn.answer.duration_ms} ms · run {turn.answer.run_code}
                    </p>
                  </div>
                </div>

                <div className="grid gap-3 lg:grid-cols-3">
                  <Section
                    title={`Verified / official (${(turn.answer.verified_facts || []).length})`}
                    tone="emerald"
                    items={turn.answer.verified_facts}
                  />
                  <Section
                    title={`AEGIS model estimates (${(turn.answer.model_estimates || []).length})`}
                    tone="sky"
                    items={turn.answer.model_estimates}
                  />
                  <Section
                    title={`Unverified citizen input (${(turn.answer.unverified_reports || []).length})`}
                    tone="orange"
                    items={turn.answer.unverified_reports}
                  />
                </div>

                {turn.answer.data_gaps?.length ? (
                  <div>
                    <p className="panel-sub mb-1">Data gaps & limitations that apply to this answer</p>
                    <ul className="space-y-1 text-[11px] text-amber-200/90">
                      {turn.answer.data_gaps.slice(0, 6).map((g: any, i: number) => (
                        <li key={i}>
                          <span className="font-mono text-[10px] text-amber-300/80">{g.source}</span> — {g.gap}
                          {g.detail ? `: ${String(g.detail).slice(0, 120)}` : ""}
                          {g.fix ? ` (fix: ${g.fix})` : ""}
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}

                {turn.answer.sources?.length ? (
                  <div>
                    <p className="panel-sub mb-1">Retrieved sources</p>
                    <ul className="flex flex-wrap gap-1.5">
                      {turn.answer.sources.map((s: any) => (
                        <Chip key={s.source} tone="border-white/10 bg-white/5 font-mono text-[10px] text-slate-300">
                          {s.source}
                          {s.last_data_at ? ` · ${timeAgo(s.last_data_at)}` : ""}
                        </Chip>
                      ))}
                    </ul>
                  </div>
                ) : null}

                {turn.answer.recommended_next_steps?.length ? (
                  <div>
                    <p className="panel-sub mb-1">Suggested next steps</p>
                    <ul className="list-disc space-y-1 pl-4 text-[11px] text-slate-300">
                      {turn.answer.recommended_next_steps.map((s: string, i: number) => (
                        <li key={i}>{s}</li>
                      ))}
                    </ul>
                  </div>
                ) : null}

                {turn.answer.requires_human_approval?.length ? (
                  <Banner tone="warn" title="Human authorisation required">
                    <ul className="list-disc space-y-0.5 pl-4">
                      {turn.answer.requires_human_approval.map((a: any, i: number) => (
                        <li key={i}>
                          {a.action} — {a.reason}
                        </li>
                      ))}
                    </ul>
                  </Banner>
                ) : null}

                <div>
                  <button className="btn-ghost btn-xs" onClick={() => setShowTrace((s) => (s === turn.id ? null : turn.id))}>
                    <Info className="h-3 w-3" aria-hidden /> {showTrace === turn.id ? "Hide" : "Show"} tool execution trace
                  </button>
                  {showTrace === turn.id && (
                    <div className="mt-2 space-y-1.5">
                      {(turn.answer.plan?.steps || []).map((s: any, i: number) => {
                        const exec = (turn.answer.execution || []).find((e: any) => e.tool === s.tool);
                        return (
                          <div key={i} className="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
                            <div className="flex flex-wrap items-center gap-2 text-[11px]">
                              <span className="font-mono text-cyan-300">{i + 1}. {s.tool}</span>
                              <Chip tone={exec?.status === "ok" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-red-500/40 bg-red-500/10 text-red-300"}>
                                {exec?.status || "not run"}
                              </Chip>
                              {exec?.latency_ms != null && <span className="text-slate-500">{exec.latency_ms} ms</span>}
                            </div>
                            <p className="mt-1 text-[11px] text-slate-400">{s.why}</p>
                            {exec?.summary && <p className="mt-0.5 font-mono text-[10px] text-slate-500">→ {exec.summary}</p>}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}
          </Card>
        ))}
        <div ref={endRef} />
      </div>

      <div className="space-y-4">
        <Card title="Optional context" subtitle="Narrow the question to an incident or a bounding box">
          <div className="space-y-2">
            <label className="block">
              <span className="label">Incident ID or code</span>
              <input
                className="input"
                placeholder="inc_… or AEGIS-CYC-…"
                value={context.incidentId}
                onChange={(e) => setContext((c) => ({ ...c, incidentId: e.target.value }))}
              />
            </label>
            <label className="block">
              <span className="label">Bounding box</span>
              <input
                className="input"
                placeholder="min_lat,min_lon,max_lat,max_lon"
                value={context.bbox}
                onChange={(e) => setContext((c) => ({ ...c, bbox: e.target.value }))}
              />
            </label>
            <p className="text-[11px] text-slate-500">
              Context is passed as tool parameters — it never changes what the tools are allowed to return.
            </p>
          </div>
        </Card>

        <Card title="Guardrails" subtitle="Enforced in code, not just in the prompt">
          <ul className="space-y-1.5 text-[11px] leading-relaxed text-slate-400">
            <li>Tool allow-list — the planning layer can only call registered tools; unknown names are dropped.</li>
            <li>Bounded execution — 90 s agent deadline, max 24 tool calls per step, per-call timeouts and retries.</li>
            <li>No fabricated observations — tools read stored records; nothing is generated by the model.</li>
            <li>No official-warning generation — agents can only draft advisories, which require human authorisation.</li>
            <li>Uncertainty is surfaced — data gaps, stale sources and limitations are part of every answer payload.</li>
            <li>Memory isolation — each question runs in its own run record, visible in the Agent operations screen.</li>
          </ul>
          <p className="mt-2 text-[10px] text-slate-500">
            Every run is persisted with its plan, per-step status, latency, findings and the sources touched.
          </p>
        </Card>
      </div>
    </div>
  );
}

function Section({ title, tone, items }: { title: string; tone: "emerald" | "sky" | "orange"; items: any[] }) {
  const tones: Record<string, string> = {
    emerald: "border-emerald-500/20 bg-emerald-500/5",
    sky: "border-sky-500/20 bg-sky-500/5",
    orange: "border-orange-500/20 bg-orange-500/5",
  };
  return (
    <div className={`rounded-lg border p-2.5 ${tones[tone]}`}>
      <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{title}</p>
      {items?.length ? (
        <ul className="mt-1.5 space-y-1 text-[11px] leading-relaxed text-slate-300">
          {items.slice(0, 6).map((it: any, i: number) => (
            <li key={i} className="border-b border-white/5 pb-1 last:border-0">
              {it.text}
              {it.at && <span className="ml-1 text-slate-500">({timeAgo(it.at)})</span>}
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-1 text-[11px] text-slate-500">Nothing in this category for this question.</p>
      )}
    </div>
  );
}
