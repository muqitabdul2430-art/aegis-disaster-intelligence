import React, { useEffect, useState } from "react";
import { BookOpen, Database, GitBranch, Scale, ShieldAlert, Siren, Users, Workflow } from "lucide-react";
import { api } from "../lib/api";
import { TEAM_EVENT, TEAM_NAME } from "../components/AppShell";
import { Card, Chip, ErrorState, Skeleton, Tabs } from "../components/ui";

export default function About() {
  const [tab, setTab] = useState("safety");
  const [hazards, setHazards] = useState<any>(null);
  const [safety, setSafety] = useState<any>(null);
  const [config, setConfig] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.hazards(), api.safety(), api.config()])
      .then(([h, s, c]) => {
        setHazards(h);
        setSafety(s);
        setConfig(c);
      })
      .catch(setError)
      .finally(() => setLoading(false));
  }, []);

  if (error) return <ErrorState error={error} />;
  if (loading) {
    return (
      <Card>
        <Skeleton rows={6} />
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold text-slate-100">Methodology, safety and limitations</h2>
        <p className="text-xs text-slate-500">
          AEGIS is a decision-support platform. This page states plainly what it does, what it cannot do, and how each
          number is produced.
        </p>
      </div>

      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-cyan-500/15 ring-1 ring-cyan-400/30">
              <Users className="h-5 w-5 text-cyan-300" aria-hidden />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-slate-500">Built by</p>
              <p className="text-base font-semibold text-cyan-200">{TEAM_NAME}</p>
              <p className="text-[11px] text-slate-400">{TEAM_EVENT}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <Chip tone="border-cyan-500/30 bg-cyan-500/10 text-cyan-200">Agentic AI · 8 agents</Chip>
            <Chip tone="border-white/10 bg-white/5 text-slate-300">Real multi-source ingestion</Chip>
            <Chip tone="border-white/10 bg-white/5 text-slate-300">Explainable risk (risk-v1.0)</Chip>
            <Chip tone="border-emerald-500/30 bg-emerald-500/10 text-emerald-300">Human-authorised warnings</Chip>
          </div>
        </div>
      </Card>

      <Tabs
        tabs={[
          { id: "safety", label: "Safety statement" },
          { id: "pipeline", label: "Intelligence pipeline" },
          { id: "hazards", label: "Hazard taxonomy & thresholds" },
          { id: "risk", label: "Risk methodology" },
          { id: "sources", label: "Attribution" },
          { id: "deployment", label: "Deployment & configuration" },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "safety" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="What AEGIS is not" subtitle="Read this before acting on anything here" bodyClassName="space-y-3">
            <div className="rounded-lg border border-red-500/25 bg-red-500/5 p-3 text-xs leading-relaxed text-red-100">
              <Siren className="mb-1 h-4 w-4" aria-hidden />
              {safety?.statement}
            </div>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {safety?.principles?.map((p: string, i: number) => (
                <li key={i} className="flex gap-2">
                  <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-cyan-400" aria-hidden />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
            <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Privacy handling</p>
              <p className="mt-1 text-xs text-slate-300">{safety?.privacy}</p>
            </div>
          </Card>

          <Card title="Emergency contacts" subtitle="From the configured contact dataset" bodyClassName="space-y-3">
            {(safety?.contacts || []).map((c: any) => (
              <div key={c.region} className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
                <p className="text-xs font-semibold text-slate-200">{c.region}</p>
                <p className="text-[10px] text-slate-500">{c.authority}</p>
                <ul className="mt-1 space-y-0.5 text-[11px] text-slate-300">
                  {c.numbers?.map((n: any) => (
                    <li key={n.number}>
                      {n.label}: <span className="font-mono text-cyan-200">{n.number}</span>
                    </li>
                  ))}
                </ul>
                <a className="link text-[11px]" href={c.url} target="_blank" rel="noreferrer">
                  Authority website ↗
                </a>
              </div>
            ))}
          </Card>
        </div>
      )}

      {tab === "pipeline" && (
        <Card title="Intelligence pipeline" subtitle="Data collection → detection → classification → context → risk → prediction → warning → response" bodyClassName="space-y-3">
          <ol className="space-y-3">
            {[
              ["Data collection", "Background jobs poll USGS (seismic), GDACS (multi-hazard), NOAA NHC (tropical cyclones), NOAA tsunami centres (bulletins), NASA FIRMS (fire hotspots, with key) and Open-Meteo (forecast drivers). Every fetch is logged with status, latency, record count and error."],
              ["Detection", "The detection agent scans new observations, suppresses duplicates, groups related signals (e.g. FIRMS hotspots into complexes), and correlates across sources — a tsunami bulletin within 400 km and 6 h upgrades an earthquake to 'corroborated'."],
              ["Classification", "The classification agent scores each supported category from the attached evidence only, records its reasoning, and flags ambiguous cases for human review instead of guessing."],
              ["Context analysis", "The geospatial agent resolves the region, estimates the affected footprint with a hazard-specific rule table, estimates population exposure from a static gazetteer, and pulls nearby facilities from OpenStreetMap."],
              ["Risk & impact", "The risk agent combines hazard, exposure and a documented vulnerability prior into a 0–100 score, listing every factor's value, weight and contribution (risk-v1.0)."],
              ["Prediction", "The prediction agent computes trends from stored assessments, links official forecast products (NHC advisories, GDACS alert levels) and — only when labelled — publishes an AEGIS extrapolation with its method and limitations."],
              ["Early warning", "Escalations produce DRAFT advisories with location, hazard, timestamp, evidence, confidence and protective actions. Agents cannot publish: an authorised analyst must approve, and the decision is audited."],
              ["Response support", "The response agent presents official guidance and contacts, ranks nearby facilities by role, and screens movement corridors for intersecting hazards while explicitly refusing to certify a route as safe."],
            ].map(([title, body], i) => (
              <li key={title} className="flex gap-3">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-cyan-500/15 text-[11px] font-semibold text-cyan-300 ring-1 ring-cyan-400/30">
                  {i + 1}
                </span>
                <div>
                  <p className="text-sm font-medium text-slate-100">{title}</p>
                  <p className="text-xs leading-relaxed text-slate-400">{body}</p>
                </div>
              </li>
            ))}
          </ol>
          <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3 text-[11px] leading-relaxed text-slate-400">
            <Workflow className="mb-1 h-3.5 w-3.5 text-cyan-400" aria-hidden />
            Agents execute through a bounded orchestrator: 90-second agent deadline, maximum 24 tool calls per step, HTTP
            timeouts with retries, and per-step error capture. Failures degrade the output and are surfaced — they never
            produce invented data.
          </div>
        </Card>
      )}

      {tab === "hazards" && (
        <>
          <Card title="Supported hazards and detection basis" bodyClassName="p-0">
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th scope="col">Hazard</th>
                    <th scope="col">Detection basis</th>
                    <th scope="col">Severity mapping</th>
                  </tr>
                </thead>
                <tbody>
                  {(hazards?.hazards || []).map((h: any) => (
                    <tr key={h.key}>
                      <td className="text-[13px] font-medium text-slate-100">{h.label}</td>
                      <td className="text-[11px] text-slate-300">{h.detection}</td>
                      <td className="text-[11px] text-slate-400">{h.severity_bands}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <Card title="Verification states" subtitle="How AEGIS distinguishes evidence quality" bodyClassName="p-0">
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th scope="col">State</th>
                    <th scope="col">Meaning</th>
                  </tr>
                </thead>
                <tbody>
                  {(hazards?.verification_states || []).map((v: any) => (
                    <tr key={v.key}>
                      <td className="font-mono text-[11px] text-cyan-300">{v.key}</td>
                      <td className="text-[11px] text-slate-300">{v.meaning}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}

      {tab === "risk" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Formula & weights" subtitle={`Methodology ${hazards?.risk_methodology?.version}`} bodyClassName="space-y-3">
            <p className="rounded-lg border border-white/10 bg-white/[0.02] p-3 font-mono text-[11px] text-cyan-200">
              {hazards?.risk_methodology?.formula}
            </p>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th scope="col">Hazard</th>
                    <th scope="col">Hazard w.</th>
                    <th scope="col">Exposure w.</th>
                    <th scope="col">Vulnerability w.</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(hazards?.risk_methodology?.weights || {}).map(([k, w]: any) => (
                    <tr key={k}>
                      <td className="text-[11px] text-slate-200">{k.replace("_", " ")}</td>
                      <td className="text-[11px] tabular-nums text-slate-300">{w.hazard}</td>
                      <td className="text-[11px] tabular-nums text-slate-300">{w.exposure}</td>
                      <td className="text-[11px] tabular-nums text-slate-300">{w.vulnerability}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div>
              <p className="panel-sub mb-1">Bands</p>
              <div className="flex flex-wrap gap-1.5">
                {(hazards?.risk_methodology?.bands || []).map((b: any) => (
                  <Chip key={b[1]} tone="border-white/10 bg-white/5 text-slate-300">
                    {b[1]} ≥ {b[0]}
                  </Chip>
                ))}
              </div>
            </div>
            <p className="text-[11px] leading-relaxed text-amber-200/90">{hazards?.risk_methodology?.limitations}</p>
          </Card>

          <Card title="Vulnerability priors" subtitle="Static, documented, deliberately transparent" bodyClassName="p-0">
            <ul className="divide-y divide-white/5">
              {Object.entries(hazards?.risk_methodology?.vulnerability_priors || {}).map(([k, v]: any) => (
                <li key={k} className="p-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[12px] font-medium text-slate-200">{k.replace("_", " ")}</span>
                    <Chip tone="border-white/10 bg-white/5 tabular-nums text-slate-300">{v[0]}</Chip>
                  </div>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-400">{v[1]}</p>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}

      {tab === "sources" && (
        <Card title="Data attribution & licensing" subtitle="Respect these terms when you reuse AEGIS output" bodyClassName="p-0">
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Provider</th>
                  <th scope="col">Role in AEGIS</th>
                  <th scope="col">Licence</th>
                </tr>
              </thead>
              <tbody>
                {(safety?.data_attribution || []).map((d: any) => (
                  <tr key={d.provider}>
                    <td className="text-[12px] text-slate-200">{d.provider}</td>
                    <td className="text-[11px] text-slate-400">{d.role}</td>
                    <td className="text-[11px] text-slate-400">{d.license}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="border-t border-white/5 p-3 text-[11px] leading-relaxed text-slate-400">
            <Scale className="mb-1 h-3.5 w-3.5 text-cyan-400" aria-hidden />
            Official warning content remains the property of the issuing authority. AEGIS-generated risk estimates are
            provided for situational awareness and must be attributed to AEGIS when republished.
          </div>
        </Card>
      )}

      {tab === "deployment" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Runtime configuration" subtitle="Secrets are server-side only" bodyClassName="space-y-2">
            <ul className="space-y-1 text-[11px] text-slate-300">
              <li>
                <strong className="text-slate-200">Environment:</strong> {config?.environment}
              </li>
              <li>
                <strong className="text-slate-200">Version:</strong> {config?.version}
              </li>
              <li>
                <strong className="text-slate-200">Demonstration data:</strong>{" "}
                {config?.demo_mode === "off" ? (
                  <span className="text-emerald-300">
                    disabled — every record shown is live, provider-sourced data
                  </span>
                ) : (
                  <>
                    {config?.demo_mode} (<span className="font-mono">off</span> shows live data only)
                  </>
                )}
              </li>
              <li>
                <strong className="text-slate-200">Live network access:</strong> {String(config?.features?.live_network)}
              </li>
              <li>
                <strong className="text-slate-200">Scheduler:</strong> {String(config?.features?.scheduler)}
              </li>
              <li>
                <strong className="text-slate-200">LLM assistant:</strong> {String(config?.features?.llm_assistant)} — with
                no key, the deterministic planner and template narrator are used
              </li>
              <li>
                <strong className="text-slate-200">Routing (OSRM):</strong> {String(config?.features?.osrm_routing)} —
                disabled by default because AEGIS has no live road-closure feed
              </li>
            </ul>
            <div className="mt-2">
              <p className="panel-sub mb-1">Credential presence</p>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(config?.credentials_configured || {}).map(([k, v]: any) => (
                  <Chip key={k} tone={v ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-slate-500/40 bg-slate-500/10 text-slate-400"}>
                    {k}: {v ? "configured" : "not set"}
                  </Chip>
                ))}
              </div>
            </div>
          </Card>

          <Card title="Guard rails and limits" subtitle="What constrains the system" bodyClassName="space-y-2 text-[11px] text-slate-300">
            <p>
              <strong className="text-slate-200">Rate limits:</strong> read{" "}
              {config?.limits?.rate_limits_per_minute?.read}/min · write {config?.limits?.rate_limits_per_minute?.write}
              /min · assistant {config?.limits?.rate_limits_per_minute?.assistant}/min (per client, in-process bucket).
            </p>
            <p>
              <strong className="text-slate-200">Agent limits:</strong> {config?.limits?.agent_timeout_seconds}s deadline,
              max {config?.limits?.max_tool_calls_per_task} tool calls per step.
            </p>
            <p>
              <strong className="text-slate-200">Role separation:</strong> citizens may read intelligence and submit
              reports; analysts may verify incidents, authorise advisories and run agents; only admins may trigger
              ingestion, run the data-gap workflow or test notification channels.
            </p>
            <p>
              <strong className="text-slate-200">Audit:</strong> verification changes, alert review decisions, agent runs,
              citizen-report reviews, ingestion passes and notification tests are all written to the audit log with actor,
              timestamp, before/after values and a reason.
            </p>
            <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
              <Database className="mb-1 h-3.5 w-3.5 text-cyan-400" aria-hidden />
              <p>
                Database: SQLite for local/testing by default; a PostgreSQL + PostGIS schema with geography columns and
                GiST indexes is shipped in <span className="font-mono">backend/scripts/postgis_schema.sql</span> for
                production spatial workloads.
              </p>
            </div>
            <p className="text-slate-500">{config?.disclaimer}</p>
          </Card>
        </div>
      )}

      <Card title="Planned enhancements (not implemented)" subtitle="Explicit, so nothing here is mistaken for a shipped feature">
        <ul className="grid gap-1.5 text-[11px] text-slate-400 sm:grid-cols-2">
          <li>• MOSDAC / Bhuvan ingestion once an ISRO token is provisioned</li>
          <li>• Copernicus EMS rapid-mapping activation ingestion</li>
          <li>• IMD radar nowcast and CWC river-gauge thresholds</li>
          <li>• INSAT/SCATSAT cyclone intensity fusion</li>
          <li>• Flood inundation mapping from Sentinel-1 / MODIS products</li>
          <li>• ShakeMap/PAGER-grade exposure modelling for earthquakes</li>
          <li>• Learned classifier for citizen-report triage (with human review retained)</li>
          <li>• Multi-worker queue (Celery/RQ) and shared rate limiting</li>
          <li>• SMS/email provider adapters beyond generic webhooks</li>
          <li>• Offline-first mobile field app with sync</li>
        </ul>
      </Card>

      <Card title="Repository & documentation" subtitle="For operators and reviewers">
        <ul className="space-y-1 text-[11px] text-slate-400">
          <li className="flex items-center gap-2">
            <BookOpen className="h-3.5 w-3.5 text-cyan-400" aria-hidden /> <span className="font-mono">docs/SETUP.md</span> — install, run, credentials, PostGIS
          </li>
          <li className="flex items-center gap-2">
            <BookOpen className="h-3.5 w-3.5 text-cyan-400" aria-hidden /> <span className="font-mono">docs/ARCHITECTURE.md</span> — agents, data flow, database schema
          </li>
          <li className="flex items-center gap-2">
            <BookOpen className="h-3.5 w-3.5 text-cyan-400" aria-hidden /> <span className="font-mono">docs/SAFETY.md</span> — policy controls and known limits
          </li>
          <li className="flex items-center gap-2">
            <GitBranch className="h-3.5 w-3.5 text-cyan-400" aria-hidden /> <span className="font-mono">.env.example</span> — every configurable value, no secrets
          </li>
          <li className="flex items-center gap-2">
            <GitBranch className="h-3.5 w-3.5 text-cyan-400" aria-hidden /> <span className="font-mono">backend/tests</span> — geo maths, parsers, risk scoring, workflows
          </li>
        </ul>
      </Card>
    </div>
  );
}
