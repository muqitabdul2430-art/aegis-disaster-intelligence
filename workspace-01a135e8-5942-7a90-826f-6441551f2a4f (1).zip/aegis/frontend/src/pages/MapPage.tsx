import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Filter, Layers3, ListFilter, RefreshCw, X } from "lucide-react";
import { api, Alert, Incident } from "../lib/api";
import { HAZARDS, hazardMeta, timeAgo, utc } from "../lib/format";
import MapView, { Facility } from "../components/MapView";
import { Card, Chip, DemoBadge, EmptyState, ErrorState, Skeleton } from "../components/ui";
import { IncidentTable } from "../components/IncidentTable";

const VERIFICATIONS = [
  "officially_confirmed",
  "human_verified",
  "corroborated",
  "preliminary_detection",
  "unverified_citizen",
];

export default function MapPage() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [selected, setSelected] = useState<Incident | null>(null);
  const [loading, setLoading] = useState(true);
  const [facilityLoading, setFacilityLoading] = useState(false);
  const [facilityError, setFacilityError] = useState<unknown>(null);
  const [error, setError] = useState<unknown>(null);

  // filters
  const [categories, setCategories] = useState<string[]>([]);
  const [verifications, setVerifications] = useState<string[]>([]);
  const [minSeverity, setMinSeverity] = useState(1);
  const [hours, setHours] = useState(168);
  const [origin, setOrigin] = useState<"all" | "live" | "demo">("all");
  const [facilityRadius, setFacilityRadius] = useState(25);
  const [showFilters, setShowFilters] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [inc, al] = await Promise.all([
        api.incidents({
          category: categories.join(",") || undefined,
          verification_status: verifications.join(",") || undefined,
          min_severity: minSeverity > 1 ? minSeverity : undefined,
          hours,
          data_origin: origin === "all" ? undefined : origin,
          limit: 300,
        }),
        api.alerts({ hours: Math.max(hours, 168), limit: 200 }),
      ]);
      setIncidents(inc.incidents || []);
      setAlerts(al.alerts || []);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, [categories, verifications, minSeverity, hours, origin]);

  useEffect(() => {
    void load();
  }, [load]);

  const loadFacilities = useCallback(
    async (inc: Incident) => {
      setFacilityLoading(true);
      setFacilityError(null);
      try {
        const res = await api.facilities(inc.lat, inc.lon, facilityRadius);
        if (!res.ok) {
          setFacilities([]);
          setFacilityError(new Error(res.error || "OpenStreetMap facility lookup unavailable"));
        } else {
          setFacilities(res.facilities || []);
        }
      } catch (e) {
        setFacilities([]);
        setFacilityError(e);
      } finally {
        setFacilityLoading(false);
      }
    },
    [facilityRadius],
  );

  useEffect(() => {
    if (selected) void loadFacilities(selected);
    else setFacilities([]);
  }, [selected, loadFacilities]);

  const toggle = (list: string[], setList: (v: string[]) => void, value: string) => {
    setList(list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);
  };

  const stats = useMemo(() => {
    const byCat: Record<string, number> = {};
    incidents.forEach((i) => {
      byCat[i.category] = (byCat[i.category] || 0) + 1;
    });
    return byCat;
  }, [incidents]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Interactive disaster map</h2>
          <p className="text-xs text-slate-500">
            {loading ? "Loading incidents…" : `${incidents.length} incident(s)`} ·{" "}
            {alerts.filter((a) => a.status === "published").length} published alert(s) · facility lookup via OpenStreetMap
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-ghost btn-xs" onClick={() => setShowFilters((s) => !s)} aria-expanded={showFilters}>
            <ListFilter className="h-3 w-3" aria-hidden /> Filters
          </button>
          <button className="btn-ghost btn-xs" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} aria-hidden /> Reload
          </button>
        </div>
      </div>

      {error && <ErrorState error={error} onRetry={load} />}

      <div className={`grid gap-4 ${showFilters ? "xl:grid-cols-[280px_1fr_320px]" : "xl:grid-cols-[1fr_320px]"}`}>
        {showFilters && (
          <Card title="Map filters" subtitle="Filters apply to the API query, not just the view" bodyClassName="space-y-3 p-3.5">
            <div>
              <p className="label">Hazard category</p>
              <div className="flex flex-wrap gap-1.5">
                {HAZARDS.filter((h) => h !== "unknown").map((h) => {
                  const meta = hazardMeta(h);
                  const active = categories.includes(h);
                  return (
                    <button
                      key={h}
                      onClick={() => toggle(categories, setCategories, h)}
                      className={`chip ${active ? "border-cyan-400/50 bg-cyan-500/15 text-cyan-200" : "border-white/10 bg-white/5 text-slate-400"}`}
                      aria-pressed={active}
                    >
                      <span aria-hidden>{meta.glyph}</span> {meta.label}
                      <span className="ml-1 tabular-nums opacity-70">{stats[h] || 0}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <p className="label">Verification status</p>
              <div className="flex flex-wrap gap-1.5">
                {VERIFICATIONS.map((v) => (
                  <button
                    key={v}
                    onClick={() => toggle(verifications, setVerifications, v)}
                    className={`chip ${verifications.includes(v) ? "border-cyan-400/50 bg-cyan-500/15 text-cyan-200" : "border-white/10 bg-white/5 text-slate-400"}`}
                    aria-pressed={verifications.includes(v)}
                  >
                    {v.replace(/_/g, " ")}
                  </button>
                ))}
              </div>
            </div>

            <label className="block">
              <span className="label">Minimum severity: {minSeverity}/5</span>
              <input
                type="range"
                min={1}
                max={5}
                value={minSeverity}
                onChange={(e) => setMinSeverity(Number(e.target.value))}
                className="w-full accent-cyan-500"
              />
            </label>

            <label className="block">
              <span className="label">Time window</span>
              <select className="input py-1.5 text-xs" value={hours} onChange={(e) => setHours(Number(e.target.value))}>
                <option value={24}>Last 24 h</option>
                <option value={72}>Last 72 h</option>
                <option value={168}>Last 7 days</option>
                <option value={720}>Last 30 days</option>
              </select>
            </label>

            <div>
              <p className="label">Data origin</p>
              <div className="flex gap-1.5">
                {(["all", "live", "demo"] as const).map((o) => (
                  <button
                    key={o}
                    onClick={() => setOrigin(o)}
                    className={`chip ${origin === o ? "border-cyan-400/50 bg-cyan-500/15 text-cyan-200" : "border-white/10 bg-white/5 text-slate-400"}`}
                    aria-pressed={origin === o}
                  >
                    {o}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-lg border border-white/5 bg-white/[0.02] p-2.5 text-[11px] leading-relaxed text-slate-400">
              <Filter className="mb-1 h-3 w-3 text-cyan-400" aria-hidden />
              Filters map directly onto API parameters, so what you see matches what was retrieved. Empty results are
              reported as empty — never padded with samples.
            </div>
          </Card>
        )}

        <div className="min-w-0 space-y-4">
          <MapView
            incidents={incidents}
            alerts={alerts}
            facilities={facilities}
            selectedId={selected?.id || null}
            onSelect={(i) => setSelected(i)}
            height="min(70vh, 680px)"
            center={selected ? [selected.lat, selected.lon] : [18, 78]}
            zoom={selected ? 6 : 3}
          />
          <Card title="Incidents in view" subtitle="Click a row to focus the map" bodyClassName="p-0">
            {loading ? (
              <div className="p-4">
                <Skeleton rows={4} />
              </div>
            ) : (
              <IncidentTable incidents={incidents} selectedId={selected?.id || null} onSelect={(i) => setSelected(i)} compact />
            )}
          </Card>
        </div>

        <div className="space-y-4">
          {selected ? (
            <>
              <Card
                title="Selected incident"
                subtitle={selected.code}
                actions={
                  <button className="btn-ghost btn-xs" onClick={() => setSelected(null)} aria-label="Clear selection">
                    <X className="h-3 w-3" aria-hidden />
                  </button>
                }
              >
                <h3 className="text-sm font-semibold text-slate-100">{selected.title}</h3>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  <Chip tone="border-white/10 bg-white/5 text-slate-300">{hazardMeta(selected.category).label}</Chip>
                  <Chip tone="border-white/10 bg-white/5 text-slate-300">{selected.verification_status.replace(/_/g, " ")}</Chip>
                  {selected.is_demo && <DemoBadge />}
                </div>
                <p className="mt-2 text-xs leading-relaxed text-slate-400">{selected.summary}</p>
                <dl className="mt-3 space-y-0.5">
                  <div className="kv">
                    <dt className="kv-key">Coordinates</dt>
                    <dd className="kv-val font-mono text-xs">
                      {selected.lat.toFixed(4)}, {selected.lon.toFixed(4)}
                    </dd>
                  </div>
                  <div className="kv">
                    <dt className="kv-key">Started</dt>
                    <dd className="kv-val">{utc(selected.started_at)}</dd>
                  </div>
                  <div className="kv">
                    <dt className="kv-key">Last update</dt>
                    <dd className="kv-val">{timeAgo(selected.last_update_at)}</dd>
                  </div>
                  <div className="kv">
                    <dt className="kv-key">Sources</dt>
                    <dd className="kv-val text-xs">{(selected.source_keys || []).join(", ") || "—"}</dd>
                  </div>
                  <div className="kv">
                    <dt className="kv-key">AEGIS risk</dt>
                    <dd className="kv-val text-xs">
                      {selected.risk ? `${Math.round(selected.risk.score)}/100 (${selected.risk.level})` : "not assessed"}
                    </dd>
                  </div>
                </dl>
                <a className="link mt-3 inline-block text-xs" href={`/incidents/${selected.id}`}>
                  Open full intelligence brief →
                </a>
              </Card>

              <Card
                title="Nearby facilities"
                subtitle="OpenStreetMap · community-mapped"
                actions={
                  <select
                    className="input w-auto py-1 text-[11px]"
                    value={facilityRadius}
                    onChange={(e) => setFacilityRadius(Number(e.target.value))}
                    aria-label="Facility search radius"
                  >
                    {[10, 25, 50, 100].map((r) => (
                      <option key={r} value={r}>
                        {r} km
                      </option>
                    ))}
                  </select>
                }
                bodyClassName="p-0"
              >
                {facilityLoading && (
                  <div className="p-3.5">
                    <Skeleton rows={3} />
                  </div>
                )}
                {!facilityLoading && facilityError && (
                  <div className="p-3.5">
                    <ErrorState error={facilityError} compact />
                    <p className="mt-2 text-[11px] text-slate-500">
                      Overpass is a shared community service and can time out. AEGIS reports the failure instead of
                      substituting an incomplete facility list.
                    </p>
                  </div>
                )}
                {!facilityLoading && !facilityError && (
                  <ul className="divide-y divide-white/5">
                    {facilities.slice(0, 12).map((f) => (
                      <li key={f.osm_id} className="flex items-start justify-between gap-2 px-3.5 py-2">
                        <div className="min-w-0">
                          <p className="truncate text-xs text-slate-200">{f.name}</p>
                          <p className="text-[10px] capitalize text-slate-500">
                            {f.class.replace("_", " ")} · {f.phone || "no phone mapped"}
                          </p>
                        </div>
                        <span className="shrink-0 text-[10px] text-slate-400">{f.distance_km} km</span>
                      </li>
                    ))}
                    {!facilities.length && (
                      <li className="p-3.5">
                        <EmptyState
                          title="No facilities returned"
                          message="Either the area is unmapped in OpenStreetMap or the lookup failed — this list is never invented."
                        />
                      </li>
                    )}
                  </ul>
                )}
                <p className="border-t border-white/5 p-3 text-[10px] leading-relaxed text-slate-500">
                  Presence in OSM is not proof a facility is open, staffed or able to accept patients. Confirm by phone
                  before travelling. © OpenStreetMap contributors (ODbL).
                </p>
              </Card>
            </>
          ) : (
            <Card title="Incident inspector">
              <EmptyState
                icon={<Layers3 className="h-7 w-7" aria-hidden />}
                title="Select an incident"
                message="Click a marker or a table row to load its footprint estimate, facilities and source attribution."
              />
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
