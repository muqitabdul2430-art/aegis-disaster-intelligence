import React, { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Activity, AlertTriangle, ActivitySquare, Bell, Bot, Database, Globe2, MapPin, Radio, RefreshCw, ShieldCheck,
  Users, Waves,
} from "lucide-react";
import { api } from "../lib/api";
import { compact, hazardMeta, statusTone, timeAgo, utc } from "../lib/format";
import { CategoryBar, ObservationsBar, RiskDonut } from "../components/charts";
import { IncidentTable, RiskPill, VerificationChip } from "../components/IncidentTable";
import MapView from "../components/MapView";
import { Card, Chip, DemoBadge, EmptyState, ErrorState, OfficialBadge, Skeleton, Stat } from "../components/ui";
import { useAuth } from "../state/auth";

export default function Dashboard() {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [hours, setHours] = useState(72);
  const [selected, setSelected] = useState<string | null>(null);
  const { principal } = useAuth();

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const d = await api.dashboard(hours);
      setData(d);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, [hours]);

  useEffect(() => {
    void load();
    const t = window.setInterval(load, 120000);
    return () => window.clearInterval(t);
  }, [load]);

  if (error) {
    return (
      <div className="mx-auto max-w-3xl space-y-3">
        <ErrorState error={error} onRetry={load} />
        <Card title="What this means">
          <p className="text-xs leading-relaxed text-slate-400">
            The dashboard reads exclusively from the AEGIS API. When the API is unreachable the screen shows no
            fabricated numbers — reconnect and retry, or check{" "}
            <Link className="link" to="/sources">
              data-source health
            </Link>
            . If the backend is starting up, ingestion may still be running.
          </p>
        </Card>
      </div>
    );
  }

  const counts = data?.counts || {};
  const system = data?.system || {};

  return (
    <div className="space-y-4">
      {/* header strip */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Situation overview</h2>
          <p className="text-xs text-slate-500">
            Window: last {hours}h · generated {data ? utc(data.generated_at) : "—"} ·{" "}
            {system.llm?.mode === "llm" ? "LLM narrative layer active" : "deterministic reasoning layer (no LLM key)"}
            {system.scheduler?.last_ingest_at ? ` · last ingest ${timeAgo(system.scheduler.last_ingest_at)}` : ""}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select className="input w-auto py-1.5 text-xs" value={hours} onChange={(e) => setHours(Number(e.target.value))} aria-label="Time window">
            <option value={24}>Last 24 h</option>
            <option value={72}>Last 72 h</option>
            <option value={168}>Last 7 days</option>
            <option value={720}>Last 30 days</option>
          </select>
          <button className="btn-ghost btn-xs" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} aria-hidden /> Refresh
          </button>
        </div>
      </div>

      {/* stats */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 xl:grid-cols-6">
        <Stat
          label="Active incidents"
          value={loading ? "—" : counts.active_incidents ?? 0}
          hint={`${counts.live_incidents ?? 0} live · ${counts.demo_incidents ?? 0} demo`}
          icon={<AlertTriangle className="h-3.5 w-3.5 text-orange-400" aria-hidden />}
        />
        <Stat
          label="Official warnings"
          value={loading ? "—" : counts.official_warnings_recent ?? 0}
          hint="Ingested from issuing authorities"
          icon={<Radio className="h-3.5 w-3.5 text-emerald-400" aria-hidden />}
        />
        <Stat
          label="Awaiting review"
          value={loading ? "—" : counts.alerts_awaiting_review ?? 0}
          hint="AEGIS advisories needing human authorisation"
          tone={(counts.alerts_awaiting_review || 0) > 0 ? "text-amber-300" : "text-slate-100"}
          icon={<ShieldCheck className="h-3.5 w-3.5 text-amber-400" aria-hidden />}
        />
        <Stat
          label="Citizen reports"
          value={loading ? "—" : counts.citizen_reports_recent ?? 0}
          hint="All unverified until corroborated"
          icon={<Users className="h-3.5 w-3.5 text-cyan-400" aria-hidden />}
        />
        <Stat
          label="Observations"
          value={loading ? "—" : compact(counts.observations_recent ?? 0)}
          hint="Raw provider records in window"
          icon={<ActivitySquare className="h-3.5 w-3.5 text-sky-400" aria-hidden />}
        />
        <Stat
          label="Data sources OK"
          value={loading ? "—" : `${system.sources?.ok ?? 0}/${system.sources?.total ?? 0}`}
          hint={
            (system.sources?.failed?.length || 0) + (system.sources?.stale?.length || 0) > 0
              ? `${system.sources?.failed?.length || 0} failing · ${system.sources?.stale?.length || 0} stale`
              : system.sources?.demo_feeds
                ? `All reachable live feeds healthy · +${system.sources.demo_feeds} demo feed (excluded)`
                : "All reachable sources healthy"
          }
          icon={<Database className="h-3.5 w-3.5 text-slate-400" aria-hidden />}
        />
      </div>

      {/* map + incidents */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Card
          className="xl:col-span-2"
          title="Live incident map"
          subtitle="Marker colour = hazard · size/pulse = severity · dashed outline = AEGIS estimate"
          actions={
            <Link to="/map" className="btn-ghost btn-xs">
              <Globe2 className="h-3 w-3" aria-hidden /> Full map
            </Link>
          }
          bodyClassName="p-2.5"
        >
          {loading && !data ? (
            <div className="grid h-[420px] place-items-center">
              <Skeleton rows={4} />
            </div>
          ) : (
            <MapView
              incidents={data?.top_incidents || []}
              alerts={data?.official_warnings || []}
              selectedId={selected}
              height="420px"
              onSelect={(i) => setSelected(i.id)}
            />
          )}
        </Card>

        <div className="space-y-4">
          <Card title="Distribution by category" subtitle="Active + monitoring incidents">
            {loading && !data ? <Skeleton rows={4} /> : <CategoryBar data={data?.distribution_by_category || {}} />}
          </Card>
          <Card title="Risk levels" subtitle="Latest AEGIS assessment per incident">
            {loading && !data ? <Skeleton rows={3} /> : <RiskDonut data={data?.distribution_by_risk_level || {}} />}
          </Card>
        </div>
      </div>

      {/* official warnings + verification mix */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Card
          className="xl:col-span-2"
          title="Official warnings & bulletins"
          subtitle="Displayed verbatim with the issuing authority and issue time"
          actions={
            <Link to="/alerts" className="btn-ghost btn-xs">
              <Bell className="h-3 w-3" aria-hidden /> Alerts centre
            </Link>
          }
          bodyClassName="p-0"
        >
          {(data?.official_warnings || []).length === 0 ? (
            <EmptyState
              title="No official warnings in this window"
              message="AEGIS only shows bulletins it actually ingested from NOAA NHC/NWS and GDACS. An empty list is a real result, not a placeholder."
            />
          ) : (
            <ul className="divide-y divide-white/5">
              {data.official_warnings.map((a: any) => (
                <li key={a.id} className="p-3.5">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <OfficialBadge />
                    <Chip tone="border-white/10 bg-white/5 text-slate-300">{a.severity}</Chip>
                    {a.is_demo && <DemoBadge />}
                    <span className="ml-auto text-[11px] text-slate-500">{timeAgo(a.issued_at)}</span>
                  </div>
                  <p className="mt-1.5 text-[13px] font-medium text-slate-100">{a.title}</p>
                  <p className="text-[11px] text-slate-500">
                    {a.authority} · issued {utc(a.issued_at)} · source: {a.source_key}
                  </p>
                  <p className="mt-1 line-clamp-3 whitespace-pre-line text-xs text-slate-400">{a.body}</p>
                  {a.source_url && (
                    <a className="link mt-1 inline-block text-[11px]" href={a.source_url} target="_blank" rel="noreferrer">
                      Official product ↗
                    </a>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Evidence quality mix" subtitle="How well established the active events are" bodyClassName="p-3.5">
          <ul className="space-y-2">
            {Object.entries(data?.distribution_by_verification || {}).map(([k, v]) => (
              <li key={k} className="flex items-center justify-between gap-2">
                <VerificationChip status={k} />
                <span className="text-sm tabular-nums text-slate-300">{v as number}</span>
              </li>
            ))}
          </ul>
          <div className="mt-3 border-t border-white/5 pt-3">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Agent activity</p>
            <ul className="mt-2 space-y-1.5">
              {(data?.agent_activity || []).slice(0, 5).map((r: any) => (
                <li key={r.id} className="flex items-start gap-2 text-[11px]">
                  <Bot className="mt-0.5 h-3 w-3 shrink-0 text-cyan-400" aria-hidden />
                  <div className="min-w-0">
                    <p className="truncate text-slate-300" title={r.goal}>
                      {r.goal || "(scheduled pass)"}
                    </p>
                    <p className="text-slate-500">
                      {r.status} · {r.duration_ms ?? "—"} ms · {(r.plan || []).length} step(s) · {timeAgo(r.started_at)}
                    </p>
                  </div>
                </li>
              ))}
              {!(data?.agent_activity || []).length && <li className="text-[11px] text-slate-500">No runs recorded yet.</li>}
            </ul>
            <Link to="/agents" className="link mt-2 inline-block text-[11px]">
              Open agent operations →
            </Link>
          </div>
        </Card>
      </div>

      {/* incidents table + feeds */}
      <Card
        title="Priority incidents"
        subtitle="Ordered by severity band then recency — click a row for the full intelligence brief"
        actions={
          <Link to="/incidents" className="btn-ghost btn-xs">
            <Activity className="h-3 w-3" aria-hidden /> Incident centre
          </Link>
        }
        bodyClassName="p-0"
      >
        {loading && !data ? (
          <div className="p-4">
            <Skeleton rows={5} />
          </div>
        ) : (
          <IncidentTable incidents={data?.top_incidents || []} selectedId={selected} onSelect={(i) => setSelected(i.id)} />
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
        <Card title="Recent detections" subtitle="Raw provider observations (provenance first)">
          <ul className="space-y-2">
            {(data?.recent_observations || []).slice(0, 8).map((o: any) => (
              <li key={o.id} className="flex items-start justify-between gap-3 border-b border-white/5 pb-2 last:border-0">
                <div className="min-w-0">
                  <p className="truncate text-xs text-slate-200">
                    {hazardMeta(o.hazard_hint).glyph} {o.hazard_hint.replace("_", " ")}
                    {o.magnitude != null ? ` · ${o.magnitude}` : ""} {o.magnitude_unit}
                  </p>
                  <p className="truncate font-mono text-[10px] text-slate-500">
                    {o.source_key} · {o.external_id || "—"} · {utc(o.observed_at)}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[10px] text-slate-400">{timeAgo(o.observed_at)}</p>
                  {o.incident_id ? (
                    <Link className="link text-[10px]" to={`/incidents/${o.incident_id}`}>
                      linked →
                    </Link>
                  ) : (
                    <span className="text-[10px] text-slate-600">unlinked</span>
                  )}
                </div>
              </li>
            ))}
            {!(data?.recent_observations || []).length && (
              <li className="text-xs text-slate-500">No observations ingested in this window.</li>
            )}
          </ul>
          <div className="mt-3 border-t border-white/5 pt-2">
            <ObservationsBar bySource={{} /* populated on the data-sources page */} />
          </div>
        </Card>

        <Card title="Citizen reports" subtitle="Unverified by default — triaged by the citizen-intelligence agent">
          <ul className="space-y-2.5">
            {(data?.recent_citizen_reports || []).map((r: any) => (
              <li key={r.id} className="border-b border-white/5 pb-2 last:border-0">
                <div className="flex items-center gap-1.5">
                  <Chip tone="border-orange-500/40 bg-orange-500/10 text-orange-300">{r.status.replace("_", " ")}</Chip>
                  {r.priority !== "normal" && (
                    <Chip tone="border-red-500/40 bg-red-500/10 text-red-300">{r.priority} priority</Chip>
                  )}
                  <span className="ml-auto text-[10px] text-slate-500">{timeAgo(r.created_at)}</span>
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-slate-300">{r.description}</p>
                <p className="text-[10px] text-slate-500">
                  {r.public_code} · {hazardMeta(r.category).label} · {r.place || "location pending"} · coords withheld to{" "}
                  {r.coordinates_precision}
                </p>
              </li>
            ))}
            {!(data?.recent_citizen_reports || []).length && (
              <li className="text-xs text-slate-500">
                No citizen reports yet. The reporting portal is open to everyone —{" "}
                <Link className="link" to="/report">
                  submit an observation
                </Link>
                .
              </li>
            )}
          </ul>
        </Card>

        <Card title="Data source health" subtitle="Freshness, latency and honest failure states" bodyClassName="p-0">
          <ul className="divide-y divide-white/5">
            {(data?.data_sources || []).map((s: any) => (
              <li key={s.key} className="flex items-start justify-between gap-3 px-3.5 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-xs text-slate-200">{s.name}</p>
                  <p className="truncate text-[10px] text-slate-500">
                    {s.provider} · {s.last_ok_at ? `last ok ${timeAgo(s.last_ok_at)}` : "never fetched"}
                    {s.latency_ms ? ` · ${s.latency_ms} ms` : ""}
                  </p>
                  {s.last_error && <p className="mt-0.5 line-clamp-2 text-[10px] text-amber-400/80">{s.last_error}</p>}
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  <Chip tone={statusTone(s.status)}>{s.status.replace("_", " ")}</Chip>
                  {s.records_last_fetch ? <span className="text-[10px] text-slate-500">{s.records_last_fetch} rec</span> : null}
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      {principal.authenticated && principal.capabilities?.trigger_ingest && (
        <Card title="Operations" subtitle="Analyst/admin actions">
          <div className="flex flex-wrap gap-2">
            <Link className="btn-ghost btn-xs" to="/sources">
              <Database className="h-3 w-3" aria-hidden /> Run ingestion / probes
            </Link>
            <Link className="btn-ghost btn-xs" to="/agents">
              <Bot className="h-3 w-3" aria-hidden /> Execute agent workflow
            </Link>
            <Link className="btn-ghost btn-xs" to="/map">
              <MapPin className="h-3 w-3" aria-hidden /> Geospatial analysis
            </Link>
          </div>
        </Card>
      )}
    </div>
  );
}
