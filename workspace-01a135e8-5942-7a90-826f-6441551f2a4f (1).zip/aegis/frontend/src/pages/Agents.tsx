import React, { useCallback, useEffect, useState } from "react";
import { Activity, Bot, ChevronRight, PlayCircle, RefreshCw, ShieldCheck, Terminal } from "lucide-react";
import { api, endpoints } from "../lib/api";
import { timeAgo, utc } from "../lib/format";
import { Banner, Card, Chip, EmptyState, ErrorState, Field, Skeleton, Stat, Tabs } from "../components/ui";
import { useAuth } from "../state/auth";

export default function Agents() {
  const { principal } = useAuth();
  const [tab, setTab] = useState("registry");
  const [registry, setRegistry] = useState<any>(null);
  const [runs, setRuns] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [goal, setGoal] = useState("");
  const [workflow, setWorkflow] = useState("freeform");
  const [incidentIds, setIncidentIds] = useState("");
  const [busy, setBusy] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);

  const canRun = principal.authenticated && (principal.capabilities?.verify_incident || principal.capabilities?.trigger_ingest);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [reg, r] = await Promise.all([api.agents(), api.agentRuns()]);
      setRegistry(reg);
      setRuns(r.runs || []);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(load, 45000);
    return () => window.clearInterval(t);
  }, [load]);

  const openRun = async (id: string) => {
    try {
      const detail = await api.agentRun(id);
      setSelected(detail);
      setTab("timeline");
    } catch (e) {
      setFlash(`Could not open run: ${(e as any)?.message}`);
    }
  };

  const execute = async () => {
    setBusy(true);
    setFlash(null);
    try {
      const res = await endpoints.runAgent({
        goal: goal.trim() || "Produce a situation report for all active hazards",
        workflow,
        incident_ids: incidentIds.trim() ? incidentIds.split(",").map((s) => s.trim()).filter(Boolean) : [],
      });
      setFlash(
        `Run ${res.run_code} finished in ${res.duration_ms} ms with ${res.execution.length} step(s): ` +
          res.execution.map((e: any) => `${e.tool}:${e.status}`).join(", "),
      );
      await load();
      if (res.run_id) await openRun(res.run_id);
    } catch (e: any) {
      setFlash(`Execution failed: ${e?.message || e}`);
    } finally {
      setBusy(false);
    }
  };

  const llm = registry?.llm || {};
  const stats = (() => {
    const byStatus: Record<string, number> = {};
    runs.forEach((r) => {
      byStatus[r.status] = (byStatus[r.status] || 0) + 1;
    });
    const avg = runs.length ? Math.round(runs.reduce((s, r) => s + (r.duration_ms || 0), 0) / runs.length) : 0;
    return { byStatus, avg };
  })();

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Agent operations</h2>
          <p className="text-xs text-slate-500">
            Eight specialised agents plus the coordinator. Every step is a real function call over the database, provider
            APIs and deterministic scoring models — not scripted chat.
          </p>
        </div>
        <button className="btn-ghost btn-xs" onClick={load} disabled={loading}>
          <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} aria-hidden /> Refresh
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Runs recorded" value={runs.length} hint="latest first" icon={<Activity className="h-3.5 w-3.5 text-cyan-400" aria-hidden />} />
        <Stat
          label="Average duration"
          value={`${stats.avg} ms`}
          hint="plan + tool execution"
          icon={<Terminal className="h-3.5 w-3.5 text-slate-400" aria-hidden />}
        />
        <Stat
          label="Reasoning layer"
          value={llm.mode === "llm" ? "LLM + rules" : "Deterministic"}
          hint={llm.mode === "llm" ? `model: ${llm.model}` : "no LLM key configured"}
          tone={llm.mode === "llm" ? "text-cyan-300" : "text-slate-100"}
          icon={<Bot className="h-3.5 w-3.5 text-violet-400" aria-hidden />}
        />
        <Stat
          label="Guard rails"
          value={registry?.execution_limits ? `${registry.execution_limits.agent_timeout_seconds}s` : "—"}
          hint={registry?.execution_limits ? `max ${registry.execution_limits.max_tool_calls_per_task} tool calls/step` : ""}
          icon={<ShieldCheck className="h-3.5 w-3.5 text-emerald-400" aria-hidden />}
        />
      </div>

      {flash && <Banner tone="info" title="Execution">{flash}</Banner>}
      {error && <ErrorState error={error} onRetry={load} />}

      <Tabs
        tabs={[
          { id: "registry", label: "Agent registry" },
          { id: "execute", label: "Execute workflow" },
          { id: "runs", label: "Run history", count: runs.length },
          ...(selected ? [{ id: "timeline", label: `Timeline · ${selected.run_code}` }] : []),
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "registry" && (
        <div className="space-y-4">
          {loading && !registry ? (
            <Card>
              <Skeleton rows={6} />
            </Card>
          ) : (
            <>
              <div className="grid gap-3 md:grid-cols-2">
                {(registry?.agents || []).map((a: any) => (
                  <Card key={a.name} title={a.role} subtitle={a.name} bodyClassName="space-y-2">
                    <p className="text-xs leading-relaxed text-slate-300">{a.description}</p>
                    <div>
                      <p className="panel-sub mb-1">Capabilities</p>
                      <div className="flex flex-wrap gap-1">
                        {a.capabilities?.map((c: string) => (
                          <Chip key={c} tone="border-white/10 bg-white/5 font-mono text-[10px] text-slate-300">
                            {c}
                          </Chip>
                        ))}
                      </div>
                    </div>
                    <div className="grid gap-1 text-[11px] text-slate-400 sm:grid-cols-2">
                      <div>
                        <p className="text-slate-500">Inputs</p>
                        <ul className="list-disc pl-4">
                          {a.inputs?.map((i: string) => (
                            <li key={i}>{i}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-slate-500">Outputs</p>
                        <ul className="list-disc pl-4">
                          {a.outputs?.map((i: string) => (
                            <li key={i}>{i}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <Card title="Coordinator tool catalogue" subtitle="The only functions agents may call — enforced by allow-list">
                <div className="table-wrap">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th scope="col">Tool</th>
                        <th scope="col">Owning agent</th>
                        <th scope="col">Purpose</th>
                        <th scope="col">Parameters</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(registry?.tool_catalogue || []).map((t: any) => (
                        <tr key={t.tool}>
                          <td className="font-mono text-[11px] text-cyan-300">{t.tool}</td>
                          <td className="text-[11px] text-slate-300">{t.agent}</td>
                          <td className="text-[11px] text-slate-400">{t.description}</td>
                          <td className="font-mono text-[10px] text-slate-500">{t.params.join(", ") || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              <Card title="Workflows" subtitle="Pre-built plans for common operational goals">
                <div className="grid gap-3 md:grid-cols-2">
                  {Object.entries(registry?.workflows || {}).map(([key, wf]: any) => (
                    <div key={key} className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
                      <p className="text-xs font-semibold text-slate-200">{key}</p>
                      <p className="mt-0.5 text-[11px] text-slate-400">{wf.description}</p>
                      <p className="mt-1 font-mono text-[10px] text-slate-500">{wf.steps.join(" → ")}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Architecture note">
                <p className="text-xs leading-relaxed text-slate-400">{registry?.architecture_note}</p>
                <p className="mt-2 text-[11px] text-slate-500">
                  Risk methodology: {registry?.risk_methodology?.version} · weights per hazard class · bands:{" "}
                  {(registry?.risk_methodology?.bands || []).map((b: any) => `${b[1]}≥${b[0]}`).join(", ")}
                </p>
              </Card>
            </>
          )}
        </div>
      )}

      {tab === "execute" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Execute a coordinator workflow" subtitle={canRun ? "Analyst/admin role — audited" : "Sign in with an analyst account to execute"}>
            {!canRun && (
              <Banner tone="warn" title="Read-only session">
                You can inspect agents and runs without an account. Execution requires an analyst or admin session
                (privilege escalation is deliberate: agent runs can create advisories pending human review).
              </Banner>
            )}
            <div className="mt-3 space-y-3">
              <Field label="Operational goal" hint="Plain language — the rule planner (or the LLM planner when configured) turns it into tool calls.">
                <textarea
                  className="input min-h-[90px]"
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder="e.g. Summarise the latest verified cyclone warnings and list the facilities near the highest-risk incident"
                  disabled={!canRun}
                />
              </Field>
              <Field label="Workflow">
                <select className="input" value={workflow} onChange={(e) => setWorkflow(e.target.value)} disabled={!canRun}>
                  <option value="freeform">Freeform (planner decides)</option>
                  {Object.keys(registry?.workflows || {}).map((k) => (
                    <option key={k} value={k}>
                      {k}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Incident IDs (optional)" hint="Comma-separated — focuses tools such as explain_risk or facilities_near.">
                <input className="input" value={incidentIds} onChange={(e) => setIncidentIds(e.target.value)} placeholder="inc_…, AEGIS-EQ-…" disabled={!canRun} />
              </Field>
              <button className="btn-primary w-full" onClick={execute} disabled={!canRun || busy}>
                <PlayCircle className="h-4 w-4" aria-hidden /> {busy ? "Executing…" : "Execute workflow"}
              </button>
            </div>
          </Card>

          <Card title="What execution actually does" bodyClassName="space-y-2 text-xs text-slate-300">
            <p>1. Resolve the goal to candidate incidents and parse any explicit time/magnitude constraints.</p>
            <p>2. Plan: rule-based planner always; LLM intent parsing when a key is configured (unknown tools are dropped).</p>
            <p>3. Execute each step through the allow-listed tool functions, persisting inputs, outputs, latency, findings and sources.</p>
            <p>4. Synthesise a brief with three strictly separated buckets: verified/official, AEGIS model estimates, unverified citizen input.</p>
            <p>5. Attach data gaps, source citations (with timestamps) and any action requiring human authorisation.</p>
            <p className="text-[11px] text-slate-500">
              Failure handling: per-tool try/except with error capture, retry at the HTTP layer, a 90 s deadline and a
              tool-call budget. A failing tool degrades the brief instead of fabricating output.
            </p>
          </Card>
        </div>
      )}

      {tab === "runs" && (
        <Card title="Run history" subtitle="Click a run to inspect its execution timeline" bodyClassName="p-0">
          {loading && !runs.length ? (
            <div className="p-4">
              <Skeleton rows={5} />
            </div>
          ) : runs.length === 0 ? (
            <EmptyState title="No runs yet" message="Execute a workflow, ask the assistant a question, or wait for a scheduled ingestion cycle." />
          ) : (
            <ul className="divide-y divide-white/5">
              {runs.map((r) => (
                <li key={r.id}>
                  <button className="flex w-full items-start gap-3 p-3.5 text-left hover:bg-white/[0.03]" onClick={() => openRun(r.id)}>
                    <Bot className="mt-0.5 h-4 w-4 shrink-0 text-cyan-400" aria-hidden />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] text-slate-200">{r.goal || "(scheduled pass)"}</p>
                      <p className="text-[11px] text-slate-500">
                        <span className="font-mono">{r.run_code}</span> · {r.trigger} · {r.llm_mode} ·{" "}
                        {(r.plan || []).length} step(s) · {r.duration_ms ?? "—"} ms · {timeAgo(r.started_at)}
                      </p>
                    </div>
                    <Chip
                      tone={
                        r.status === "completed"
                          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                          : r.status === "completed_with_errors"
                            ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                            : r.status === "failed"
                              ? "border-red-500/40 bg-red-500/10 text-red-300"
                              : "border-white/10 bg-white/5 text-slate-300"
                      }
                    >
                      {r.status.replace(/_/g, " ")}
                    </Chip>
                    <ChevronRight className="h-4 w-4 text-slate-600" aria-hidden />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}

      {tab === "timeline" && selected && (
        <div className="space-y-4">
          <Card
            title={`Run ${selected.run_code}`}
            subtitle={selected.goal}
            actions={
              <button className="btn-ghost btn-xs" onClick={() => setTab("runs")}>
                Back to list
              </button>
            }
          >
            <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
              <Chip tone="border-white/10 bg-white/5">{selected.status.replace(/_/g, " ")}</Chip>
              <Chip tone="border-white/10 bg-white/5">{selected.trigger}</Chip>
              <Chip tone="border-white/10 bg-white/5">{selected.llm_mode}</Chip>
              <span>started {utc(selected.started_at)}</span>
              <span>· {selected.duration_ms} ms</span>
            </div>
            {selected.report?.headline && (
              <div className="mt-3 rounded-lg border border-cyan-500/20 bg-cyan-500/5 p-3 text-xs leading-relaxed text-cyan-50">
                {selected.report.headline}
              </div>
            )}
            <div className="mt-3 grid gap-3 lg:grid-cols-3">
              {[
                ["Verified / official", selected.report?.verified_facts],
                ["AEGIS model estimates", selected.report?.model_estimates],
                ["Unverified citizen input", selected.report?.unverified_reports],
              ].map(([label, items]: any) => (
                <div key={label} className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                    {label} ({(items || []).length})
                  </p>
                  <ul className="mt-1 space-y-1 text-[11px] text-slate-300">
                    {(items || []).slice(0, 6).map((f: any, i: number) => (
                      <li key={i} className="border-b border-white/5 pb-1 last:border-0">
                        {f.text}
                      </li>
                    ))}
                    {!(items || []).length && <li className="text-slate-500">none</li>}
                  </ul>
                </div>
              ))}
            </div>
          </Card>

          <Card title="Execution timeline" subtitle="Per-step status, tool calls, findings and sources" bodyClassName="p-0">
            <ol className="divide-y divide-white/5">
              {(selected.tasks || []).map((t: any) => (
                <li key={t.id} className="p-3.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] text-slate-500">#{t.step_index + 1}</span>
                    <Chip tone="border-white/10 bg-white/5 font-mono text-[10px] text-cyan-300">{t.agent}</Chip>
                    <Chip
                      tone={
                        t.status === "ok"
                          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                          : t.status === "error"
                            ? "border-red-500/40 bg-red-500/10 text-red-300"
                            : "border-white/10 bg-white/5 text-slate-300"
                      }
                    >
                      {t.status}
                    </Chip>
                    <span className="text-[11px] text-slate-500">{t.latency_ms ?? "—"} ms</span>
                    {t.error && <span className="text-[11px] text-red-300">{t.error}</span>}
                  </div>
                  <p className="mt-1 text-[11px] text-slate-400">{t.objective}</p>
                  {t.sources_used?.length ? (
                    <p className="mt-0.5 font-mono text-[10px] text-slate-500">sources: {t.sources_used.join(", ")}</p>
                  ) : null}
                  {t.tool_calls?.length ? (
                    <details className="mt-1.5">
                      <summary className="cursor-pointer text-[11px] text-slate-400">
                        {t.tool_calls.length} tool call(s)
                      </summary>
                      <ul className="mt-1 space-y-1">
                        {t.tool_calls.map((c: any, i: number) => (
                          <li key={i} className="rounded border border-white/5 bg-white/[0.02] p-2 font-mono text-[10px] text-slate-400">
                            <span className="text-cyan-300">{c.tool}</span> · {c.status} · {c.latency_ms ?? "—"} ms
                            {c.args && Object.keys(c.args).length ? ` · args ${JSON.stringify(c.args).slice(0, 160)}` : ""}
                            {c.summary ? ` → ${c.summary}` : ""}
                            {c.error ? ` · ERROR ${c.error}` : ""}
                          </li>
                        ))}
                      </ul>
                    </details>
                  ) : null}
                  {t.findings?.length ? (
                    <ul className="mt-1.5 space-y-1 text-[11px] text-slate-300">
                      {t.findings.map((f: any, i: number) => (
                        <li key={i} className="border-l-2 border-cyan-500/40 pl-2">
                          {f.finding}
                          {f.source ? <span className="ml-1 font-mono text-[10px] text-slate-500">[{f.source}]</span> : null}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </li>
              ))}
              {!(selected.tasks || []).length && (
                <li className="p-4">
                  <EmptyState title="No step records" message="This run was executed in a non-persisting context (for example an internal assessment)." />
                </li>
              )}
            </ol>
          </Card>
        </div>
      )}
    </div>
  );
}
