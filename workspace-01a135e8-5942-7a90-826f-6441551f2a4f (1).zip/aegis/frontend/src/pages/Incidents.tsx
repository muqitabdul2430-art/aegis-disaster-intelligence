import React, { useCallback, useEffect, useState } from "react";
import { Filter, RefreshCw } from "lucide-react";
import { api, Incident } from "../lib/api";
import { HAZARDS, hazardMeta } from "../lib/format";
import { IncidentTable } from "../components/IncidentTable";
import { Card, ErrorState, Skeleton } from "../components/ui";

const SORTS = [
  { id: "severity", label: "Severity" },
  { id: "recent", label: "Most recent" },
  { id: "risk", label: "Confidence" },
];

export default function Incidents() {
  const [rows, setRows] = useState<Incident[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [filters, setFilters] = useState({
    category: "",
    status: "active,monitoring,closed",
    verification_status: "",
    min_severity: 1,
    hours: "",
    sort: "severity",
    data_origin: "",
  });

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.incidents({
        category: filters.category || undefined,
        status: filters.status || undefined,
        verification_status: filters.verification_status || undefined,
        min_severity: filters.min_severity > 1 ? filters.min_severity : undefined,
        hours: filters.hours || undefined,
        sort: filters.sort,
        data_origin: filters.data_origin || undefined,
        limit: 250,
      });
      setRows(res.incidents || []);
      setTotal(res.total || 0);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Incident intelligence centre</h2>
          <p className="text-xs text-slate-500">
            {loading ? "Querying incidents…" : `${rows.length} shown of ${total} matching record(s)`} — every row is a
            stored detection with source references and a verification status.
          </p>
        </div>
        <button className="btn-ghost btn-xs" onClick={load} disabled={loading}>
          <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} aria-hidden /> Refresh
        </button>
      </div>

      <Card
        title="Filters"
        subtitle="Server-side filtering on the stored records"
        actions={<Filter className="h-3.5 w-3.5 text-cyan-400" aria-hidden />}
        bodyClassName="grid gap-3 p-3.5 sm:grid-cols-2 lg:grid-cols-6"
      >
        <label className="block">
          <span className="label">Hazard</span>
          <select className="input py-1.5 text-xs" value={filters.category} onChange={(e) => setFilters((f) => ({ ...f, category: e.target.value }))}>
            <option value="">All hazards</option>
            {HAZARDS.filter((h) => h !== "unknown").map((h) => (
              <option key={h} value={h}>
                {hazardMeta(h).label}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="label">Lifecycle</span>
          <select className="input py-1.5 text-xs" value={filters.status} onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}>
            <option value="active,monitoring,closed">Active + monitoring + closed</option>
            <option value="active">Active only</option>
            <option value="monitoring">Monitoring only</option>
            <option value="closed">Closed only</option>
          </select>
        </label>
        <label className="block">
          <span className="label">Verification</span>
          <select
            className="input py-1.5 text-xs"
            value={filters.verification_status}
            onChange={(e) => setFilters((f) => ({ ...f, verification_status: e.target.value }))}
          >
            <option value="">Any status</option>
            <option value="officially_confirmed">Officially confirmed</option>
            <option value="human_verified">Analyst verified</option>
            <option value="corroborated">Corroborated</option>
            <option value="preliminary_detection">Preliminary detection</option>
            <option value="unverified_citizen">Unverified citizen</option>
            <option value="rejected">Rejected</option>
          </select>
        </label>
        <label className="block">
          <span className="label">Min severity: {filters.min_severity}</span>
          <input
            type="range"
            min={1}
            max={5}
            value={filters.min_severity}
            onChange={(e) => setFilters((f) => ({ ...f, min_severity: Number(e.target.value) }))}
            className="w-full accent-cyan-500"
          />
        </label>
        <label className="block">
          <span className="label">Updated within</span>
          <select className="input py-1.5 text-xs" value={filters.hours} onChange={(e) => setFilters((f) => ({ ...f, hours: e.target.value }))}>
            <option value="">Any time</option>
            <option value="24">24 hours</option>
            <option value="72">72 hours</option>
            <option value="168">7 days</option>
            <option value="720">30 days</option>
          </select>
        </label>
        <label className="block">
          <span className="label">Sort</span>
          <select className="input py-1.5 text-xs" value={filters.sort} onChange={(e) => setFilters((f) => ({ ...f, sort: e.target.value }))}>
            {SORTS.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
        </label>
      </Card>

      {error && <ErrorState error={error} onRetry={load} />}

      <Card bodyClassName="p-0">
        {loading ? (
          <div className="p-4">
            <Skeleton rows={6} />
          </div>
        ) : (
          <IncidentTable incidents={rows} emptyMessage="No incidents match these filters. Try widening the time window or lowering the severity threshold." />
        )}
      </Card>

      <Card title="How to read this list" subtitle="Evidence discipline">
        <ul className="space-y-1.5 text-xs text-slate-400">
          <li>
            <strong className="text-slate-300">Preliminary detection</strong> — a signal was detected (satellite, seismic
            or alert feed) but not independently corroborated. Treat as unconfirmed.
          </li>
          <li>
            <strong className="text-slate-300">Corroborated</strong> — two or more independent sources agree, e.g. a
            seismic solution plus an official tsunami bulletin.
          </li>
          <li>
            <strong className="text-slate-300">Officially confirmed</strong> — the issuing authority has confirmed the
            event, or the record itself is an official bulletin.
          </li>
          <li>
            <strong className="text-slate-300">AEGIS risk</strong> — a model estimate (risk-v1.0) computed from severity,
            exposure and a documented vulnerability prior. Not an official forecast.
          </li>
        </ul>
      </Card>
    </div>
  );
}
