import React, { useCallback, useEffect, useRef, useState } from "react";
import { Camera, CheckCircle2, ClipboardCheck, Crosshair, MapPin, Search, Send, ShieldCheck } from "lucide-react";
import { api } from "../lib/api";
import { HAZARDS, hazardMeta, timeAgo, utc } from "../lib/format";
import MapView from "../components/MapView";
import { Banner, Card, Chip, EmptyState, ErrorState, Field, Skeleton, Spinner, Tabs } from "../components/ui";

export default function ReportPage() {
  const [tab, setTab] = useState("submit");
  const [form, setForm] = useState({
    description: "",
    category: "unknown",
    lat: "" as string | number,
    lon: "" as string | number,
    location_source: "map_click",
  });
  const [photo, setPhoto] = useState<File | null>(null);
  const [contact, setContact] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [locating, setLocating] = useState(false);
  const [place, setPlace] = useState<string | null>(null);

  // tracking
  const [trackCode, setTrackCode] = useState("");
  const [tracked, setTracked] = useState<any>(null);
  const [trackError, setTrackError] = useState<unknown>(null);

  const setLocation = useCallback(async (lat: number, lon: number, source = "map_click") => {
    setForm((f) => ({ ...f, lat: Number(lat.toFixed(5)), lon: Number(lon.toFixed(5)), location_source: source }));
    try {
      const res = await api.reverse(lat, lon);
      setPlace(res?.display_name || res?.fallback_label || null);
    } catch {
      setPlace(null);
    }
  }, []);

  const useGps = () => {
    if (!navigator.geolocation) {
      setError(new Error("This browser does not expose a GPS/geolocation API. Pick the location on the map instead."));
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        void setLocation(pos.coords.latitude, pos.coords.longitude, "gps");
        setLocating(false);
      },
      (err) => {
        setError(new Error(`Location permission unavailable (${err.message}). Choose the point on the map instead.`));
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const fd = new FormData();
      fd.append("description", form.description);
      fd.append("category", form.category);
      fd.append("lat", String(form.lat));
      fd.append("lon", String(form.lon));
      fd.append("location_source", form.location_source);
      if (contact.trim()) fd.append("contact_optin", contact.trim());
      if (photo) fd.append("photo", photo);
      const res = await api.submitReport(fd);
      setResult(res);
      setForm((f) => ({ ...f, description: "", category: "unknown" }));
      setPhoto(null);
      setContact("");
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };

  const track = async () => {
    setTrackError(null);
    setTracked(null);
    try {
      const res = await api.trackReport(trackCode.trim().toUpperCase());
      setTracked(res);
    } catch (e) {
      setTrackError(e);
    }
  };

  const hasLocation = form.lat !== "" && form.lon !== "";

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold text-slate-100">Citizen reporting portal</h2>
        <p className="text-xs text-slate-500">
          Field observations strengthen detection, especially for landslides, urban flooding and industrial fires where no
          public sensor feed exists. Reports are <strong className="text-slate-300">unverified</strong> until an analyst
          corroborates them and never trigger public alerts on their own.
        </p>
      </div>

      <Tabs
        tabs={[
          { id: "submit", label: "Submit a report" },
          { id: "track", label: "Track my report" },
          { id: "privacy", label: "Privacy & verification" },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "submit" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Incident report" subtitle="Required fields are validated before anything is stored">
            {result && (
              <div className="mb-3">
                <Banner tone="success" title={`Report ${result.public_code} received — status: ${result.status.replace("_", " ")}`}>
                  <p>{result.verification_note}</p>
                  {result.linked_incident_code && (
                    <p className="mt-1">
                      Linked as unverified evidence to <span className="font-mono">{result.linked_incident_code}</span>.
                    </p>
                  )}
                  {result.duplicate?.duplicate && (
                    <p className="mt-1">
                      Possible duplicate of <span className="font-mono">{result.duplicate.match.public_code}</span> (
                      {result.duplicate.match.distance_km} km away, similarity {result.duplicate.match.similarity}) — grouped
                      for analyst review.
                    </p>
                  )}
                  {result.classification_hint?.category !== "unknown" && (
                    <p className="mt-1">
                      Triage hint: the citizen-intelligence agent suggests{" "}
                      <strong>{hazardMeta(result.classification_hint.category).label}</strong> (unverified, confidence{" "}
                      {result.classification_hint.confidence.toFixed(0)}%). An analyst confirms the final category.
                    </p>
                  )}
                  <p className="mt-1">
                    Keep this reference code to check status: <span className="font-mono text-cyan-200">{result.public_code}</span>
                  </p>
                </Banner>
              </div>
            )}
            {error && (
              <div className="mb-3">
                <ErrorState error={error} />
              </div>
            )}

            <form className="space-y-3" onSubmit={submit}>
              <Field label="What did you observe?" required hint="Include what you saw, when, and any safety context (people at risk, road blocked, smoke direction).">
                <textarea
                  className="input min-h-[120px]"
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  placeholder="e.g. Water is rising fast across the main road near the bus stand; two autos are stuck, no injuries yet."
                  minLength={20}
                  required
                />
              </Field>

              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Hazard type" hint="Leave as 'not sure' if uncertain — analysts will classify it.">
                  <select className="input" value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}>
                    <option value="unknown">Not sure</option>
                    {HAZARDS.filter((h) => h !== "unknown").map((h) => (
                      <option key={h} value={h}>
                        {hazardMeta(h).label}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Photo (optional)" hint="JPEG/PNG/WebP up to 6 MB. Stored privately — analysts only.">
                  <label className="btn-ghost w-full cursor-pointer justify-start">
                    <Camera className="h-4 w-4" aria-hidden />
                    {photo ? photo.name.slice(0, 26) : "Attach an image"}
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={(e) => setPhoto(e.target.files?.[0] || null)}
                    />
                  </label>
                </Field>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Latitude" required>
                  <input
                    className="input"
                    type="number"
                    step="0.00001"
                    value={form.lat}
                    onChange={(e) => setForm((f) => ({ ...f, lat: e.target.value, location_source: "manual" }))}
                    required
                  />
                </Field>
                <Field label="Longitude" required>
                  <input
                    className="input"
                    type="number"
                    step="0.00001"
                    value={form.lon}
                    onChange={(e) => setForm((f) => ({ ...f, lon: e.target.value, location_source: "manual" }))}
                    required
                  />
                </Field>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button type="button" className="btn-ghost btn-xs" onClick={useGps} disabled={locating}>
                  <Crosshair className="h-3 w-3" aria-hidden /> {locating ? "Locating…" : "Use my location"}
                </button>
                <span className="text-[11px] text-slate-500">
                  {hasLocation ? (
                    <>
                      <MapPin className="inline h-3 w-3" aria-hidden /> {place || `${form.lat}, ${form.lon}`} ·{" "}
                      source: {form.location_source}
                    </>
                  ) : (
                    "Pick the point on the map or enter coordinates."
                  )}
                </span>
              </div>

              <Field
                label="Contact (optional)"
                hint="Only if you want to be contacted for verification. We store a one-way hash of your identity otherwise."
              >
                <input
                  className="input"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="phone or email — leave blank to stay anonymous"
                />
              </Field>

              <button className="btn-primary w-full" type="submit" disabled={busy || !hasLocation}>
                {busy ? <Spinner label="Submitting" /> : <><Send className="h-4 w-4" aria-hidden /> Submit report</>}
              </button>
              <p className="text-[10px] leading-relaxed text-slate-500">
                Submissions are rate limited, validated, de-duplicated and triaged. Malicious or spam submissions are
                flagged for human review and cannot trigger any public alert.
              </p>
            </form>
          </Card>

          <div className="space-y-4">
            <Card title="Pick the location" subtitle="Click the map to set coordinates (works offline with the bundled basemap)">
              <MapView
                incidents={[]}
                height="320px"
                center={hasLocation ? [Number(form.lat), Number(form.lon)] : [17.385, 78.4867]}
                zoom={hasLocation ? 11 : 5}
                pickMode
                onMapClick={(lat, lon) => void setLocation(lat, lon, "map_click")}
                layersOverride={{ cities: true, facilities: false, incidents: false, alerts: false }}
                extraMarkers={hasLocation ? [{ lat: Number(form.lat), lon: Number(form.lon), label: "Report location" }] : []}
              />
            </Card>

            <Card title="What happens next" subtitle="Transparent processing pipeline">
              <ol className="list-decimal space-y-1.5 pl-5 text-xs text-slate-300">
                <li>Validation — coordinates, description length and category are checked; invalid submissions are rejected with reasons.</li>
                <li>Duplicate check — token-similarity comparison against reports within 2 km / 6 h; suspected duplicates are grouped.</li>
                <li>Triage — urgency keywords raise priority; suspicious patterns are flagged for human review.</li>
                <li>Linking — if an active incident is nearby, your report attaches as UNVERIFIED evidence.</li>
                <li>Human review — an analyst verifies, rejects or links the report; the decision is written to the audit log.</li>
              </ol>
            </Card>
          </div>
        </div>
      )}

      {tab === "track" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Track a report" subtitle="Enter the reference code you received">
            <div className="flex gap-2">
              <input
                className="input"
                placeholder="RPT-XXXXXXXX"
                value={trackCode}
                onChange={(e) => setTrackCode(e.target.value)}
              />
              <button className="btn-primary" onClick={track} disabled={trackCode.trim().length < 6}>
                <Search className="h-4 w-4" aria-hidden /> Track
              </button>
            </div>
            {trackError && (
              <div className="mt-3">
                <ErrorState error={trackError} compact />
              </div>
            )}
            {tracked?.report && (
              <div className="mt-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Chip tone="border-white/10 bg-white/5 font-mono text-[11px] text-slate-200">{tracked.report.public_code}</Chip>
                  <Chip tone="border-cyan-500/40 bg-cyan-500/10 text-cyan-300">{tracked.report.status.replace("_", " ")}</Chip>
                </div>
                <p className="text-xs text-slate-300">{tracked.status_explanation}</p>
                <p className="text-[11px] text-slate-500">
                  {hazardMeta(tracked.report.category).label} · submitted {timeAgo(tracked.report.created_at)} · location
                  shown at {tracked.report.coordinates_precision}
                </p>
                <p className="text-[11px] text-slate-400">{tracked.report.description}</p>
                {tracked.report.linked_incident_id && (
                  <a className="link text-[11px]" href={`/incidents/${tracked.report.linked_incident_id}`}>
                    Linked incident →
                  </a>
                )}
              </div>
            )}
          </Card>

          <Card title="Verification states" subtitle="What each status means">
            <ul className="space-y-2 text-xs">
              {[
                ["submitted", "Received and awaiting analyst triage."],
                ["under_review", "Flagged for priority human review (urgency keywords or ambiguity)."],
                ["duplicate", "Matched an existing nearby report — grouped, not discarded."],
                ["linked", "Attached as unverified evidence to an active incident."],
                ["verified", "An analyst corroborated the report (independently or from the linked evidence)."],
                ["rejected", "Reviewed and not accepted; retained for the audit trail."],
              ].map(([k, v]) => (
                <li key={k} className="flex gap-2">
                  <ClipboardCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-cyan-400" aria-hidden />
                  <span>
                    <span className="font-mono text-[11px] text-slate-200">{k}</span> — <span className="text-slate-400">{v}</span>
                  </span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}

      {tab === "privacy" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Privacy handling" bodyClassName="space-y-2 text-xs text-slate-300">
            <p><strong className="text-slate-200">Identity:</strong> we store a salted one-way SHA-256 hash of the reporter reference (or your account id) — never your raw contact details unless you opt in.</p>
            <p><strong className="text-slate-200">Coordinates:</strong> public views (this portal, the dashboard, the map) round report coordinates to ~1 km. Full precision is restricted to analyst/admin roles.</p>
            <p><strong className="text-slate-200">Photos:</strong> stored outside any public path, only retrievable by analysts, with a SHA-256 hash recorded for integrity.</p>
            <p><strong className="text-slate-200">Retention:</strong> reports remain linked to the incident they corroborate and stay in the audit trail; rejected reports are kept only for accountability.</p>
            <Banner tone="info" title="Emergency situations">
              AEGIS cannot dispatch help. If someone is in danger, call the emergency services now — India 112 (ambulance
              108) · US 911 — and submit your report afterwards.
            </Banner>
          </Card>

          <Card title="Anti-abuse design" bodyClassName="space-y-2 text-xs text-slate-300">
            <p>• Submissions are rate limited per client (default 10 per minute) and validated server-side.</p>
            <p>• Text heuristics flag spam markers (bulk links, repeated characters, promotional content) for human review.</p>
            <p>• Urgency keywords escalate priority but never bypass human verification.</p>
            <p>• No citizen report — verified or not — can create a public alert; only an authorised analyst can publish.</p>
            <p>• Every review decision is recorded with the reviewer identity, timestamp and note.</p>
            <p className="text-[11px] text-slate-500">
              These controls are documented rather than hidden so the platform can be audited by the agencies that rely on it.
            </p>
          </Card>
        </div>
      )}
    </div>
  );
}
