import React, { useCallback, useEffect, useState } from "react";
import { Bell, BellRing, Check, Mail, MessageSquare, RefreshCw, Send, ShieldCheck, Smartphone, X } from "lucide-react";
import { api, Alert } from "../lib/api";
import { hazardMeta, timeAgo, utc } from "../lib/format";
import { Banner, Card, Chip, DemoBadge, EmptyState, ErrorState, OfficialBadge, Skeleton, Tabs } from "../components/ui";
import { useAuth } from "../state/auth";

const CHANNEL_ICON: Record<string, any> = { email: Mail, sms: MessageSquare, push: Smartphone, webhook: Send, in_app: Bell };

export default function Alerts() {
  const { principal } = useAuth();
  const [tab, setTab] = useState("feed");
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [pending, setPending] = useState<Alert[]>([]);
  const [channels, setChannels] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [flash, setFlash] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);

  const canReview = principal.authenticated && principal.capabilities?.publish_alert;

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.alerts({ hours: 720, limit: 200 });
      setAlerts(res.alerts || []);
      setChannels((res as any).policy || null);
      if (canReview) {
        const p = await api.pendingAlerts();
        setPending(p.alerts || []);
      }
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, [canReview]);

  useEffect(() => {
    void load();
  }, [load]);

  const review = async (alert: Alert, decision: string, channelsToNotify: string[] = ["in_app"]) => {
    const note = decision === "publish" ? window.prompt("Reviewer note (recorded in the audit log):") || "" : "";
    if (decision === "publish" && !note.trim()) {
      setFlash("Publishing requires a reviewer note explaining the authorisation decision.");
      return;
    }
    try {
      const res = await api.reviewAlert(alert.id, { decision, note, notify_channels: channelsToNotify });
      setFlash(
        `Alert ${decision === "publish" ? "published" : decision} by ${principal.email}. ` +
          (res.notifications?.length
            ? `Notification fan-out: ${res.notifications.map((n: any) => `${n.channel}:${n.status}`).join(", ")}.`
            : ""),
      );
      await load();
    } catch (e: any) {
      setFlash(`Action failed: ${e?.message || e}`);
    }
  };

  const acknowledge = async (alert: Alert) => {
    try {
      await api.ackAlert(alert.id, "");
      await load();
    } catch (e: any) {
      setFlash(`Acknowledgement failed: ${e?.message || e}`);
    }
  };

  const official = alerts.filter((a) => a.is_official);
  const advisories = alerts.filter((a) => !a.is_official && a.status === "published");
  const rest = alerts.filter((a) => !a.is_official && a.status !== "published");

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Alerts centre</h2>
          <p className="text-xs text-slate-500">
            Official warnings are ingested verbatim from issuing authorities. AEGIS advisories are clearly separated and
            require authorised human review before publication.
          </p>
        </div>
        <button className="btn-ghost btn-xs" onClick={load} disabled={loading}>
          <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} aria-hidden /> Refresh
        </button>
      </div>

      {flash && <Banner tone="info" title="Action recorded">{flash}</Banner>}

      <Tabs
        tabs={[
          { id: "feed", label: "Official warnings", count: official.length },
          { id: "advisories", label: "AEGIS advisories", count: advisories.length },
          ...(canReview ? [{ id: "review", label: "Review queue", count: pending.length }] : []),
          { id: "channels", label: "Notification channels" },
        ]}
        active={tab}
        onChange={setTab}
      />

      {error && <ErrorState error={error} onRetry={load} />}
      {loading && !alerts.length && (
        <Card>
          <Skeleton rows={5} />
        </Card>
      )}

      {tab === "feed" && (
        <Card
          title="Official warnings & bulletins"
          subtitle="Source of truth: the issuing authority. AEGIS never edits, rewords or supersedes these products."
          bodyClassName="p-0"
        >
          {official.length === 0 ? (
            <EmptyState
              title="No official warnings ingested in the last 30 days"
              message="This is a real, verifiable state: AEGIS only lists bulletins it actually retrieved from NOAA NHC/NWS, GDACS or similar feeds."
            />
          ) : (
            <ul className="divide-y divide-white/5">
              {official.map((a) => (
                <li key={a.id} className="p-4">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <OfficialBadge />
                    <Chip tone="border-white/10 bg-white/5 text-slate-300">{a.hazard.replace("_", " ")}</Chip>
                    <Chip tone="border-white/10 bg-white/5 text-slate-300">{a.severity}</Chip>
                    {a.is_demo && <DemoBadge />}
                    <span className="ml-auto text-[11px] text-slate-500">
                      issued {utc(a.issued_at)} ({timeAgo(a.issued_at)})
                    </span>
                  </div>
                  <h3 className="mt-2 text-sm font-semibold text-slate-100">{a.title}</h3>
                  <p className="text-[11px] text-slate-500">
                    Issuing authority: <span className="text-slate-400">{a.authority || "—"}</span> · feed:{" "}
                    <span className="font-mono">{a.source_key}</span>
                  </p>
                  <div className="mt-2 whitespace-pre-line rounded-lg border border-white/5 bg-white/[0.02] p-3 text-[11px] leading-relaxed text-slate-300">
                    {open === a.id ? a.body : `${a.body.slice(0, 420)}${a.body.length > 420 ? "…" : ""}`}
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-3">
                    {a.body.length > 420 && (
                      <button className="btn-ghost btn-xs" onClick={() => setOpen(open === a.id ? null : a.id)}>
                        {open === a.id ? "Collapse" : "Read full bulletin text"}
                      </button>
                    )}
                    {a.source_url && (
                      <a className="link text-[11px]" href={a.source_url} target="_blank" rel="noreferrer">
                        Official product ↗
                      </a>
                    )}
                    {principal.authenticated && (
                      <button className="btn-ghost btn-xs" onClick={() => acknowledge(a)} disabled={a.acknowledged}>
                        <Check className="h-3 w-3" aria-hidden /> {a.acknowledged ? "Acknowledged" : "Acknowledge"}
                      </button>
                    )}
                    {a.ack_count != null && <span className="text-[10px] text-slate-500">{a.ack_count} acknowledgement(s)</span>}
                  </div>
                  {a.instructions?.length ? (
                    <details className="mt-2 text-[11px] text-slate-400">
                      <summary className="cursor-pointer text-slate-300">Recommended protective actions</summary>
                      <ul className="mt-1 list-disc pl-5">
                        {a.instructions.map((i, k) => (
                          <li key={k}>{i}</li>
                        ))}
                      </ul>
                    </details>
                  ) : null}
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}

      {tab === "advisories" && (
        <Card
          title="AEGIS-generated advisories"
          subtitle="Drafted by the prediction agent from risk assessments — published only after authorised review"
          bodyClassName="p-0"
        >
          {advisories.length === 0 ? (
            <EmptyState
              title="No published AEGIS advisories"
              message="Advisories are only drafted when the assessed risk is high/extreme or the trend is escalating, and they stay unpublished until an analyst authorises them."
            />
          ) : (
            <ul className="divide-y divide-white/5">
              {advisories.map((a) => (
                <li key={a.id} className="p-4">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Chip tone="border-amber-500/40 bg-amber-500/10 text-amber-300">AEGIS advisory — NOT an official warning</Chip>
                    <Chip tone="border-white/10 bg-white/5 text-slate-300">{a.severity}</Chip>
                    {a.llm_used && <Chip tone="border-violet-500/40 bg-violet-500/10 text-violet-300">LLM narrative</Chip>}
                    <span className="ml-auto text-[11px] text-slate-500">{utc(a.issued_at)}</span>
                  </div>
                  <h3 className="mt-2 text-sm font-semibold text-slate-100">{a.title}</h3>
                  <p className="text-[11px] text-slate-500">
                    Generated by <span className="font-mono">{a.generated_by}</span> · reviewed by{" "}
                    <span className="font-mono">{a.reviewed_by || "—"}</span>
                  </p>
                  <div className="mt-2 whitespace-pre-line rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 text-[11px] leading-relaxed text-amber-100/90">
                    {a.body}
                  </div>
                  {a.instructions?.length ? (
                    <ul className="mt-2 list-disc space-y-0.5 pl-5 text-[11px] text-slate-300">
                      {a.instructions.map((i, k) => (
                        <li key={k}>{i}</li>
                      ))}
                    </ul>
                  ) : null}
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}

      {tab === "review" && canReview && (
        <Card
          title="Human authorisation queue"
          subtitle="AEGIS agents cannot publish. Every action here is audited with your identity."
          bodyClassName="p-0"
        >
          {pending.length === 0 ? (
            <EmptyState title="Nothing awaiting review" message="No agent-drafted advisory is pending authorisation." />
          ) : (
            <ul className="divide-y divide-white/5">
              {pending.map((a) => (
                <li key={a.id} className="p-4">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Chip tone="border-red-500/40 bg-red-500/10 text-red-300">requires authorisation</Chip>
                    <Chip tone="border-white/10 bg-white/5 text-slate-300">{a.severity}</Chip>
                    {a.is_demo && <DemoBadge />}
                    <span className="ml-auto text-[11px] text-slate-500">created {timeAgo(a.created_at)}</span>
                  </div>
                  <h3 className="mt-2 text-sm font-semibold text-slate-100">{a.title}</h3>
                  <pre className="mt-2 whitespace-pre-wrap rounded-lg border border-white/5 bg-white/[0.02] p-3 text-[11px] leading-relaxed text-slate-300">
                    {a.body}
                  </pre>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button className="btn-primary btn-xs" onClick={() => review(a, "publish", ["in_app"])}>
                      <ShieldCheck className="h-3 w-3" aria-hidden /> Publish (in-app only)
                    </button>
                    <button className="btn-ghost btn-xs" onClick={() => review(a, "publish", ["in_app", "email", "sms"])}>
                      Publish + notify configured channels
                    </button>
                    <button className="btn-ghost btn-xs" onClick={() => review(a, "request_changes")}>
                      Return for revision
                    </button>
                    <button className="btn-danger btn-xs" onClick={() => review(a, "reject")}>
                      <X className="h-3 w-3" aria-hidden /> Reject
                    </button>
                  </div>
                  <p className="mt-2 text-[10px] leading-relaxed text-slate-500">
                    Publishing as an AEGIS advisory keeps the origin label visible in the feed. Official warnings can only
                    come from the issuing authority — AEGIS cannot amend or cancel them.
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}

      {tab === "channels" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Notification channels" subtitle="Opt-in integrations — nothing is sent by default">
            <ul className="space-y-2">
              {((channels?.channels as any[]) || []).map((c) => {
                const Icon = CHANNEL_ICON[c.channel] || Bell;
                return (
                  <li key={c.channel} className="flex items-start justify-between gap-3 rounded-lg border border-white/5 bg-white/[0.02] p-3">
                    <div className="min-w-0">
                      <p className="flex items-center gap-2 text-xs font-medium text-slate-200">
                        <Icon className="h-3.5 w-3.5 text-cyan-400" aria-hidden /> {c.label}
                      </p>
                      <p className="mt-0.5 text-[11px] text-slate-500">{c.note}</p>
                      {c.env && <p className="font-mono text-[10px] text-slate-600">{c.env}</p>}
                    </div>
                    <Chip tone={c.enabled ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-slate-500/40 bg-slate-500/10 text-slate-400"}>
                      {c.enabled ? "configured" : "not configured"}
                    </Chip>
                  </li>
                );
              })}
            </ul>
            {channels?.policy && <p className="mt-3 text-[11px] leading-relaxed text-slate-400">{channels.policy}</p>}
          </Card>

          <Card title="Alert history & acknowledgement" subtitle="Who saw what, and when">
            <ul className="space-y-2 text-xs">
              {alerts.slice(0, 10).map((a) => (
                <li key={a.id} className="flex items-start justify-between gap-3 border-b border-white/5 pb-1.5 last:border-0">
                  <div className="min-w-0">
                    <p className="truncate text-slate-200">{a.title}</p>
                    <p className="text-[10px] text-slate-500">
                      {a.is_official ? `official · ${a.authority}` : "AEGIS advisory"} · {utc(a.issued_at)}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <Chip tone={a.status === "published" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-slate-500/40 bg-slate-500/10 text-slate-400"}>
                      {a.status.replace("_", " ")}
                    </Chip>
                    <p className="mt-0.5 text-[10px] text-slate-500">
                      {a.ack_count ? `${a.ack_count} ack` : "no acks"}
                      {a.acknowledged ? " · you" : ""}
                    </p>
                  </div>
                </li>
              ))}
              {!alerts.length && <li className="text-slate-500">No alerts recorded.</li>}
            </ul>
            <div className="mt-3">
              <Banner tone="info" title="Deliverability is not assumed">
                Channels report <span className="font-mono">not_configured</span> until the corresponding environment
                variables exist. AEGIS records every dispatch attempt in the notification log rather than claiming success.
              </Banner>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
