import React, { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  AlertTriangle, Bot, ClipboardList, Compass, FileSearch, Gauge, MapPinned, Radio, RefreshCw, ShieldCheck, Siren,
} from "lucide-react";
import { api } from "../lib/api";
import { VERIFICATION_META, coords, hazardMeta, localTime, num, timeAgo, utc } from "../lib/format";
import { RiskComponentsRadar, RiskHistoryChart, WeatherDriversChart } from "../components/charts";
import MapView, { Facility } from "../components/MapView";
import { RiskPill, VerificationChip } from "../components/IncidentTable";
import {
  Banner, Card, Chip, DemoBadge, EmptyState, ErrorState, EstimateBadge, Field, OfficialBadge, ProgressBar,
  SeverityPips, Skeleton, Tabs,
} from "../components/ui";
import { useAuth } from "../state/auth";

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "evidence", label: "Evidence" },
  { id: "risk", label: "Risk assessment" },
  { id: "geo", label: "Geospatial" },
  { id: "outlook", label: "Prediction & warning" },
  { id: "response", label: "Response support" },
  { id: "audit", label: "Audit trail" },
];

export default function IncidentDetail() {
  const { id = "" } = useParams();
  const { principal } = useAuth();
  const [tab, setTab] = useState("overview");
  const [detail, setDetail] = useState<any>(null);
  const [context, setContext] = useState<any>(null);
  const [response, setResponse] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);
  const [facilities, setFacilities] = useState<Facility[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const d = await api.incident(id);
      setDetail(d);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (tab === "geo" && !context && detail) {
      api.incidentContext(id, 25).then(setContext).catch(() => undefined);
    }
    if (tab === "response" && !response && detail) {
      api.incidentResponse(id, 25).then((r) => {
        setResponse(r);
        setFacilities(r?.facilities?.facilities || []);
      }).catch(() => undefined);
    }
  }, [tab, context, response, id, detail]);

  const canAct = principal.authenticated && principal.capabilities?.verify_incident;

  const runAssessment = async () => {
    setBusy("assess");
    setFlash(null);
    try {
      const res = await api.assessIncident(id, { radius_km: 25, include_facilities: true, draft_alerts: true });
      setFlash(
        `Assessment complete — risk ${Math.round(res.risk.risk_score)}/100 (${res.risk.risk_level}). ` +
          (res.draft_alert
            ? `An advisory draft (${res.draft_alert.severity}) was created and is awaiting authorised review in the Alerts Centre.`
            : "No alert draft was created (risk below the escalation threshold)."),
      );
      await load();
    } catch (e: any) {
      setFlash(`Assessment failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  };

  const setVerification = async (status: string) => {
    const note = status === "officially_confirmed" ? window.prompt("Cite the official source (required):") || "" : "Analyst decision";
    if (status === "officially_confirmed" && !note.trim()) return;
    setBusy("verify");
    try {
      await api.verifyIncident(id, { verification_status: status, note });
      setFlash(`Verification status updated to '${status.replace("_", " ")}' and written to the audit log.`);
      await load();
    } catch (e: any) {
      setFlash(`Update failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  };

  if (loading && !detail) {
    return (
      <Card>
        <Skeleton rows={6} />
      </Card>
    );
  }
  if (error) return <ErrorState error={error} onRetry={load} />;
  if (!detail) return null;

  const risk = detail.risk;
  const meta = hazardMeta(detail.category);
  const latestAssessment = (detail.risk_assessments || [])[0];
  const latestFactors = (latestAssessment?.factors || []).filter((f: any) => f.factor !== "_weights");

  return (
    <div className="space-y-4">
      {/* header */}
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <Chip tone="border-white/10 bg-white/5 font-mono text-[10px] text-slate-300">{detail.code}</Chip>
              <Chip tone="border-white/10 bg-white/5 text-slate-300">
                {meta.glyph} {meta.label}
              </Chip>
              <VerificationChip status={detail.verification_status} />
              {detail.is_demo && <DemoBadge />}
              {detail.is_ambiguous && (
                <Chip tone="border-amber-500/40 bg-amber-500/10 text-amber-300" title="Classification evidence is not decisive — human review required.">
                  ⚠ Ambiguous classification
                </Chip>
              )}
              <Chip tone="border-white/10 bg-white/5 text-slate-400">{detail.status}</Chip>
            </div>
            <h2 className="mt-2 text-lg font-semibold text-slate-100">{detail.title}</h2>
            <p className="mt-1 text-xs text-slate-400">{detail.summary}</p>
          </div>
          <div className="shrink-0 space-y-2 text-right">
            <RiskPill risk={risk} />
            <div className="text-[11px] text-slate-500">
              <p>detected {utc(detail.started_at)}</p>
              <p>updated {timeAgo(detail.last_update_at)}</p>
            </div>
            <button className="btn-ghost btn-xs" onClick={load} disabled={loading}>
              <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} aria-hidden /> Refresh
            </button>
          </div>
        </div>

        {flash && (
          <div className="mt-3">
            <Banner tone="info">{flash}</Banner>
          </div>
        )}

        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          <div className="kv !border-0 rounded-lg bg-white/[0.02] px-3 py-2">
            <span className="kv-key">Coordinates</span>
            <span className="kv-val font-mono text-xs">{coords(detail.lat, detail.lon, 4)}</span>
          </div>
          <div className="kv !border-0 rounded-lg bg-white/[0.02] px-3 py-2">
            <span className="kv-key">Affected region</span>
            <span className="kv-val text-xs">{detail.region || "not resolved"}</span>
          </div>
          <div className="kv !border-0 rounded-lg bg-white/[0.02] px-3 py-2">
            <span className="kv-key">Severity band</span>
            <span className="kv-val text-xs">
              <SeverityPips severity={detail.severity} color={meta.color} />
            </span>
          </div>
          <div className="kv !border-0 rounded-lg bg-white/[0.02] px-3 py-2">
            <span className="kv-key">Detection confidence</span>
            <span className="kv-val text-xs">{detail.confidence.toFixed(0)}/100 (source-based)</span>
          </div>
        </div>

        {canAct && (
          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-white/5 pt-3">
            <span className="text-[11px] uppercase tracking-wide text-slate-500">Analyst actions</span>
            <button className="btn-primary btn-xs" onClick={runAssessment} disabled={busy === "assess"}>
              <Bot className="h-3 w-3" aria-hidden /> {busy === "assess" ? "Running agents…" : "Run full assessment"}
            </button>
            <button className="btn-ghost btn-xs" onClick={() => setVerification("human_verified")} disabled={busy === "verify"}>
              <ShieldCheck className="h-3 w-3" aria-hidden /> Mark analyst-verified
            </button>
            <button className="btn-ghost btn-xs" onClick={() => setVerification("officially_confirmed")} disabled={busy === "verify"}>
              Mark officially confirmed
            </button>
            <button className="btn-danger btn-xs" onClick={() => setVerification("rejected")} disabled={busy === "verify"}>
              Reject incident
            </button>
          </div>
        )}
      </Card>

      <Tabs tabs={TABS.map((t) => ({ ...t, count: t.id === "evidence" ? (detail.evidence || []).length : undefined }))} active={tab} onChange={setTab} />

      {/* ---------------- overview ---------------- */}
      {tab === "overview" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2" title="What we know" subtitle="Facts, sources and stated limitations" bodyClassName="space-y-3">
            <div>
              <p className="panel-sub mb-1">Classification rationale (agent)</p>
              <p className="text-xs leading-relaxed text-slate-300">{detail.classification_note || "—"}</p>
            </div>
            <div>
              <p className="panel-sub mb-1">Source attribution</p>
              <ul className="flex flex-wrap gap-1.5">
                {(detail.source_keys || []).map((s: string) => (
                  <Chip key={s} tone="border-white/10 bg-white/5 font-mono text-[10px] text-slate-300">
                    {s}
                  </Chip>
                ))}
              </ul>
              <div className="mt-1.5 space-y-0.5">
                {(detail.source_urls || []).slice(0, 4).map((u: string) => (
                  <a key={u} className="link block truncate text-[11px]" href={u} target="_blank" rel="noreferrer">
                    {u} ↗
                  </a>
                ))}
              </div>
            </div>
            {risk && (
              <div>
                <p className="panel-sub mb-1">Known limitations of this assessment</p>
                <p className="text-[11px] leading-relaxed text-slate-400">{detail.limitations || risk.estimate}</p>
              </div>
            )}
            <div>
              <p className="panel-sub mb-1">Recommended next steps</p>
              <ul className="list-disc space-y-1 pl-4 text-xs text-slate-300">
                {(detail.recommended_next_steps || []).map((s: string, i: number) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
          </Card>

          <div className="space-y-4">
            <Card title="Official warnings for this incident" bodyClassName="p-0">
              {(detail.alerts || []).filter((a: any) => a.is_official).length === 0 ? (
                <EmptyState
                  title="No official warning linked"
                  message="AEGIS has not ingested an official bulletin for this event. Absence of a warning is not evidence of safety — check the issuing authority directly."
                />
              ) : (
                <ul className="divide-y divide-white/5">
                  {detail.alerts.filter((a: any) => a.is_official).map((a: any) => (
                    <li key={a.id} className="p-3.5">
                      <div className="flex items-center gap-1.5">
                        <OfficialBadge />
                        <span className="ml-auto text-[10px] text-slate-500">{timeAgo(a.issued_at)}</span>
                      </div>
                      <p className="mt-1 text-[13px] font-medium text-slate-100">{a.title}</p>
                      <p className="text-[11px] text-slate-500">{a.authority}</p>
                      <p className="mt-1 whitespace-pre-line text-[11px] leading-relaxed text-slate-400">
                        {String(a.body || "").slice(0, 700)}
                      </p>
                      {a.source_url && (
                        <a className="link text-[11px]" href={a.source_url} target="_blank" rel="noreferrer">
                          Official product ↗
                        </a>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </Card>

            <Card title="AEGIS advisories" subtitle="Agent-generated, human-authorised" bodyClassName="p-0">
              {(detail.alerts || []).filter((a: any) => !a.is_official).length === 0 ? (
                <EmptyState title="No AEGIS advisory" message="No advisory draft has been raised for this incident." />
              ) : (
                <ul className="divide-y divide-white/5">
                  {detail.alerts.filter((a: any) => !a.is_official).map((a: any) => (
                    <li key={a.id} className="p-3.5">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <Chip tone="border-amber-500/40 bg-amber-500/10 text-amber-300">
                          {a.status === "published" ? "Published advisory" : a.status.replace("_", " ")}
                        </Chip>
                        {a.review_required && (
                          <Chip tone="border-red-500/40 bg-red-500/10 text-red-300">awaits human authorisation</Chip>
                        )}
                      </div>
                      <p className="mt-1 text-[13px] font-medium text-slate-100">{a.title}</p>
                      <p className="mt-1 whitespace-pre-line text-[11px] leading-relaxed text-slate-400">
                        {String(a.body || "").slice(0, 600)}
                      </p>
                      <Link className="link text-[11px]" to="/alerts">
                        Open in Alerts Centre →
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </div>
      )}

      {/* ---------------- evidence ---------------- */}
      {tab === "evidence" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title={`Evidence (${(detail.evidence || []).length})`} subtitle="Everything the classification and risk agents relied on" bodyClassName="p-0">
            <ul className="divide-y divide-white/5">
              {(detail.evidence || []).map((e: any) => (
                <li key={e.id} className="p-3.5">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Chip tone="border-white/10 bg-white/5 text-slate-300">{e.kind.replace(/_/g, " ")}</Chip>
                    <Chip tone="border-white/10 bg-white/5 font-mono text-[10px] text-slate-400">{e.source_key}</Chip>
                    {e.kind === "official_alert" && <OfficialBadge />}
                    {e.kind === "citizen_report" && (
                      <Chip tone="border-orange-500/40 bg-orange-500/10 text-orange-300">unverified citizen input</Chip>
                    )}
                    {e.data_origin === "demo" && <DemoBadge />}
                    <span className="ml-auto text-[10px] text-slate-500">
                      {e.observed_at ? utc(e.observed_at) : "time unknown"} · confidence {e.confidence ?? "—"}
                    </span>
                  </div>
                  <p className="mt-1 text-[13px] font-medium text-slate-100">{e.title}</p>
                  <p className="mt-0.5 whitespace-pre-line text-[11px] leading-relaxed text-slate-400">{e.excerpt}</p>
                  {e.source_url && (
                    <a className="link text-[11px]" href={e.source_url} target="_blank" rel="noreferrer">
                      source ↗
                    </a>
                  )}
                </li>
              ))}
              {!(detail.evidence || []).length && (
                <li className="p-3.5">
                  <EmptyState title="No evidence attached" message="This incident has no evidence records — it should not be trusted until reviewed." />
                </li>
              )}
            </ul>
          </Card>

          <Card title={`Raw observations (${(detail.observations || []).length})`} subtitle="Provider records, unmodified" bodyClassName="p-0">
            <ul className="divide-y divide-white/5">
              {(detail.observations || []).map((o: any) => (
                <li key={o.id} className="p-3">
                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <Chip tone="border-white/10 bg-white/5 font-mono text-[10px] text-slate-300">{o.source_key}</Chip>
                    <span className="text-slate-400">{o.external_id}</span>
                    <span className="ml-auto text-slate-500">{utc(o.observed_at)}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-slate-400">
                    <span>{o.magnitude != null ? `${o.magnitude} ${o.magnitude_unit}` : "no magnitude"}</span>
                    {o.payload?.depth_km != null && <span>depth {o.payload.depth_km} km</span>}
                    {o.payload?.status && <span>status: {o.payload.status}</span>}
                    {o.payload?.alert_level && <span>GDACS alert: {o.payload.alert_level}</span>}
                    {o.confidence != null && <span>confidence {o.confidence}</span>}
                  </div>
                  {o.source_url && (
                    <a className="link text-[11px]" href={o.source_url} target="_blank" rel="noreferrer">
                      provider record ↗
                    </a>
                  )}
                </li>
              ))}
              {!(detail.observations || []).length && (
                <li className="p-3.5">
                  <EmptyState title="No raw observations" message="This incident was created from non-observation evidence (e.g. a citizen report)." />
                </li>
              )}
            </ul>
          </Card>
        </div>
      )}

      {/* ---------------- risk ---------------- */}
      {tab === "risk" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2" title="Explainable risk assessment" subtitle="risk = w₁·hazard + w₂·exposure + w₃·vulnerability" bodyClassName="space-y-3">
            {!latestAssessment ? (
              <EmptyState
                title="No assessment stored yet"
                message={canAct ? "Run a full assessment to compute the risk score with the documented methodology." : "No risk assessment has been computed for this incident yet."}
                action={
                  canAct ? (
                    <button className="btn-primary btn-xs mt-2" onClick={runAssessment} disabled={busy === "assess"}>
                      {busy === "assess" ? "Running…" : "Run assessment now"}
                    </button>
                  ) : undefined
                }
              />
            ) : (
              <>
                <div className="flex flex-wrap items-center gap-3">
                  <RiskPill risk={{ ...latestAssessment, score: latestAssessment.risk_score } as any} />
                  <EstimateBadge label={`methodology ${latestAssessment.methodology_version}`} />
                  {latestAssessment.llm_used && <Chip tone="border-violet-500/40 bg-violet-500/10 text-violet-300">narrative written by LLM from retrieved evidence</Chip>}
                  <span className="text-[11px] text-slate-500">assessed {timeAgo(latestAssessment.created_at)}</span>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  {[
                    ["Hazard", latestAssessment.hazard_score, (latestAssessment.weights || []).find((w: any) => w.component === "hazard")?.weight],
                    ["Exposure", latestAssessment.exposure_score, (latestAssessment.weights || []).find((w: any) => w.component === "exposure")?.weight],
                    ["Vulnerability", latestAssessment.vulnerability_score, (latestAssessment.weights || []).find((w: any) => w.component === "vulnerability")?.weight],
                  ].map(([label, score, weight]: any) => (
                    <div key={label} className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
                      <p className="text-[11px] uppercase tracking-wide text-slate-500">{label}</p>
                      <p className="text-xl font-semibold tabular-nums text-slate-100">{(score as number).toFixed(0)}</p>
                      <p className="text-[10px] text-slate-500">weight {weight != null ? `${(weight * 100).toFixed(0)}%` : "—"}</p>
                      <div className="mt-2">
                        <ProgressBar value={score as number} />
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <p className="panel-sub mb-1">Narrative</p>
                  <p className="text-xs leading-relaxed text-slate-300">{latestAssessment.narrative}</p>
                </div>

                <div>
                  <p className="panel-sub mb-1">Factor contributions ({latestFactors.length})</p>
                  <div className="table-wrap rounded-lg border border-white/5">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th scope="col">Factor</th>
                          <th scope="col">Value</th>
                          <th scope="col">Contribution</th>
                          <th scope="col">Provenance / note</th>
                        </tr>
                      </thead>
                      <tbody>
                        {latestFactors
                          .slice()
                          .sort((a: any, b: any) => Math.abs(b.contribution) - Math.abs(a.contribution))
                          .map((f: any, i: number) => (
                            <tr key={i}>
                              <td className="font-mono text-[11px] text-slate-300">{f.factor}</td>
                              <td className="text-[11px] text-slate-300">{String(f.value)}</td>
                              <td className={`text-[11px] tabular-nums ${f.contribution >= 0 ? "text-orange-300" : "text-emerald-300"}`}>
                                {f.contribution > 0 ? "+" : ""}
                                {f.contribution?.toFixed(1)}
                              </td>
                              <td className="text-[11px] text-slate-400">
                                {f.note}
                                {f.source ? <span className="ml-1 font-mono text-[10px] text-slate-500">[{f.source}]</span> : null}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <Banner tone="warn" title="Limitations (verbatim from the assessment)">
                  {latestAssessment.limitations}
                </Banner>
              </>
            )}
          </Card>

          <div className="space-y-4">
            <Card title="Component balance">
              <RiskComponentsRadar
                components={{
                  hazard: latestAssessment?.hazard_score || 0,
                  exposure: latestAssessment?.exposure_score || 0,
                  vulnerability: latestAssessment?.vulnerability_score || 0,
                }}
              />
            </Card>
            <Card title="Risk history" subtitle="Each point is a stored assessment">
              <RiskHistoryChart series={detail.risk_history || []} />
            </Card>
          </div>
        </div>
      )}

      {/* ---------------- geospatial ---------------- */}
      {tab === "geo" && (
        <div className="space-y-4">
          {!context ? (
            <Card>
              <Skeleton rows={4} />
            </Card>
          ) : (
            <>
              <div className="grid gap-4 lg:grid-cols-3">
                <Card className="lg:col-span-2" title="Footprint & facilities" subtitle="Dashed = AEGIS estimate · solid cyan = authoritative polygon" bodyClassName="p-2.5">
                  <MapView
                    incidents={[detail]}
                    facilities={facilities}
                    height="420px"
                    center={[detail.lat, detail.lon]}
                    zoom={7}
                    layersOverride={{ alerts: false }}
                  />
                </Card>
                <div className="space-y-4">
                  <Card title="Region resolution" subtitle={context.region?.source}>
                    <p className="text-sm text-slate-200">{context.region?.region || "—"}</p>
                    <p className="text-[11px] text-slate-500">
                      {context.region?.country} {context.region?.country_iso3 ? `(${context.region.country_iso3})` : ""}
                    </p>
                    {context.region?.geocode?.display_name && (
                      <p className="mt-1 text-[11px] text-slate-400">{context.region.geocode.display_name}</p>
                    )}
                  </Card>
                  <Card title="Affected-area estimate">
                    <div className="flex items-center gap-2">
                      <EstimateBadge />
                      {context.area?.official && <OfficialBadge label="Authoritative polygon available" />}
                    </div>
                    <dl className="mt-2 space-y-0.5">
                      <div className="kv">
                        <dt className="kv-key">Radius</dt>
                        <dd className="kv-val">{num(context.area?.radius_km, 1)} km</dd>
                      </div>
                      <div className="kv">
                        <dt className="kv-key">Area</dt>
                        <dd className="kv-val">{num(context.area?.area_km2, 0)} km²</dd>
                      </div>
                      <div className="kv">
                        <dt className="kv-key">Modelled population</dt>
                        <dd className="kv-val">≈ {num(context.area?.population_estimate)}</dd>
                      </div>
                      <div className="kv">
                        <dt className="kv-key">Nearby places</dt>
                        <dd className="kv-val text-xs">{(context.area?.nearby_places || []).slice(0, 3).map((p: any) => p.name).join(", ") || "—"}</dd>
                      </div>
                    </dl>
                    <p className="mt-2 text-[10px] leading-relaxed text-slate-500">{context.area?.method}</p>
                    <p className="mt-1 text-[10px] leading-relaxed text-slate-500">{context.area?.population_method}</p>
                  </Card>
                </div>
              </div>

              <Card
                title="Facility intelligence"
                subtitle="Roles and orientation relative to the incident (OpenStreetMap)"
                bodyClassName="p-0"
              >
                {context.facilities?.ok ? (
                  <div className="table-wrap">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th scope="col">Facility</th>
                          <th scope="col">Class</th>
                          <th scope="col">Distance</th>
                          <th scope="col">Direction</th>
                          <th scope="col">Phone</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(context.facilities.facilities || []).map((f: any) => (
                          <tr key={f.osm_id}>
                            <td className="text-xs text-slate-200">{f.name}</td>
                            <td className="text-[11px] capitalize text-slate-400">{f.class.replace("_", " ")}</td>
                            <td className="text-[11px] text-slate-300">{f.distance_km} km</td>
                            <td className="text-[11px] text-slate-400">—</td>
                            <td className="text-[11px] text-slate-400">{f.phone || "—"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="p-3.5">
                    <ErrorState error={new Error(context.facilities?.error || "Facility lookup unavailable")} compact />
                  </div>
                )}
                <p className="border-t border-white/5 p-3 text-[10px] leading-relaxed text-slate-500">
                  {context.facilities?.osm_completeness_warning ||
                    "Community-mapped data: confirm facility availability with local authorities before routing anyone there."}
                </p>
              </Card>

              {context.transport && (
                <Card title="Movement context" subtitle="Straight-line geometry only — AEGIS does not certify route safety">
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {(context.transport.items || []).map((t: any, i: number) => (
                      <li key={i}>
                        {t.facility} — {t.distance_km} km {t.direction} of the incident centre
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2 text-[11px] text-slate-500">{context.transport.note}</p>
                </Card>
              )}
            </>
          )}
        </div>
      )}

      {/* ---------------- outlook ---------------- */}
      {tab === "outlook" && <OutlookTab id={id} />}

      {/* ---------------- response ---------------- */}
      {tab === "response" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2" title="Official guidance & contacts" subtitle="Issued authorities take precedence over AEGIS output" bodyClassName="space-y-3">
            {!response ? (
              <Skeleton rows={4} />
            ) : (
              <>
                <Banner tone="info" title={`Authoritative guidance: ${response.guidance?.guidance_authority}`}>
                  {response.guidance?.precedence_note}
                </Banner>
                <ol className="list-decimal space-y-1.5 pl-5 text-xs text-slate-200">
                  {(response.guidance?.actions || []).map((a: string, i: number) => (
                    <li key={i}>{a}</li>
                  ))}
                </ol>
                <div>
                  <p className="panel-sub mb-1">Emergency contacts</p>
                  <div className="grid gap-2 sm:grid-cols-3">
                    {(response.guidance?.contacts || []).map((c: any) => (
                      <div key={c.region} className="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
                        <p className="text-[11px] font-semibold text-slate-200">{c.region}</p>
                        <ul className="mt-1 space-y-0.5 text-[11px] text-slate-400">
                          {c.numbers.map((n: any) => (
                            <li key={n.number}>
                              {n.label}: <span className="font-mono text-slate-200">{n.number}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
                {response.guidance?.official_alerts_in_force?.length ? (
                  <div>
                    <p className="panel-sub mb-1">Official bulletins in force</p>
                    <ul className="space-y-1.5">
                      {response.guidance.official_alerts_in_force.map((a: any) => (
                        <li key={a.title} className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-2.5 text-[11px]">
                          <p className="font-medium text-emerald-200">{a.title}</p>
                          <p className="text-slate-400">
                            {a.authority} · {utc(a.issued_at)}
                          </p>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
              </>
            )}
          </Card>

          <div className="space-y-4">
            <Card title="Response facilities" subtitle="Roles and caveats" bodyClassName="space-y-3">
              {!response ? (
                <Skeleton rows={3} />
              ) : response.facilities?.ok ? (
                (response.facilities.groups || []).map((g: any) => (
                  <div key={g.class}>
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                      {g.class.replace("_", " ")} ({g.count})
                    </p>
                    <p className="text-[11px] text-slate-500">{g.role}</p>
                    <ul className="mt-1 space-y-0.5 text-[11px] text-slate-300">
                      {g.closest.map((f: any) => (
                        <li key={f.osm_id}>
                          {f.name} — {f.distance_km} km {f.phone ? `· ${f.phone}` : ""}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))
              ) : (
                <ErrorState error={new Error(response.facilities?.error || "unavailable")} compact />
              )}
              <p className="text-[10px] text-slate-500">{FACILITY_CAVEAT}</p>
            </Card>

            <RouteCheck incidentId={id} lat={detail.lat} lon={detail.lon} />
          </div>
        </div>
      )}

      {/* ---------------- audit ---------------- */}
      {tab === "audit" && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Audit trail" subtitle="Verification changes, agent actions and review decisions" bodyClassName="p-0">
            <ul className="divide-y divide-white/5">
              {(detail.audit_trail || []).map((a: any) => (
                <li key={a.id} className="p-3">
                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <Chip tone="border-white/10 bg-white/5 font-mono text-[10px] text-slate-300">{a.action}</Chip>
                    <span className="text-slate-400">
                      {a.actor} ({a.actor_role})
                    </span>
                    <span className="ml-auto text-slate-500">{utc(a.at)}</span>
                  </div>
                  {a.reason && <p className="mt-1 text-[11px] text-slate-400">{a.reason}</p>}
                  {a.before || a.after ? (
                    <p className="mt-1 font-mono text-[10px] text-slate-500">
                      {a.before ? JSON.stringify(a.before) : "—"} → {a.after ? JSON.stringify(a.after) : "—"}
                    </p>
                  ) : null}
                </li>
              ))}
              {!(detail.audit_trail || []).length && (
                <li className="p-3.5">
                  <EmptyState title="No audit entries" message="No verification or review action has been recorded for this incident." />
                </li>
              )}
            </ul>
          </Card>
          <Card title="Linked citizen reports" subtitle="Unverified unless verified by an analyst" bodyClassName="p-0">
            <ul className="divide-y divide-white/5">
              {(detail.citizen_reports || []).map((r: any) => (
                <li key={r.id} className="p-3">
                  <div className="flex items-center gap-1.5">
                    <Chip tone={r.verified ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-orange-500/40 bg-orange-500/10 text-orange-300"}>
                      {r.status.replace("_", " ")}
                    </Chip>
                    <span className="text-[10px] text-slate-500">{r.public_code}</span>
                    <span className="ml-auto text-[10px] text-slate-500">{timeAgo(r.created_at)}</span>
                  </div>
                  <p className="mt-1 text-[11px] text-slate-300">{r.description.slice(0, 240)}</p>
                  <p className="text-[10px] text-slate-500">
                    {r.place} · coordinates shown at {r.coordinates_precision}
                  </p>
                </li>
              ))}
              {!(detail.citizen_reports || []).length && (
                <li className="p-3.5">
                  <EmptyState title="No linked reports" message="No citizen submission has been linked to this incident." />
                </li>
              )}
            </ul>
          </Card>
        </div>
      )}

      <Card title="Traceability" subtitle="How this record was produced" bodyClassName="space-y-1.5 text-[11px] text-slate-400">
        <p>
          Detection agent: <span className="font-mono text-slate-300">{detail.detection_agent}</span> · classification agent:{" "}
          <span className="font-mono text-slate-300">{detail.classification_agent || "—"}</span>
        </p>
        <p>
          Primary source: <span className="font-mono text-slate-300">{detail.primary_source_key}</span> · external refs:{" "}
          <span className="font-mono text-slate-300">{JSON.stringify(detail.external_refs || {})}</span>
        </p>
        <p>
          Verification status changes are restricted to analyst/admin roles and every change is written to the audit log.
          AEGIS does not upgrade a detection to "confirmed" without corroborating evidence.
        </p>
      </Card>
    </div>
  );
}

const FACILITY_CAVEAT =
  "OpenStreetMap completeness varies by region; a mapped facility may be closed, unstaffed or unable to accept patients. Confirm by phone (India: 108 ambulance / 112 emergency).";

function OutlookTab({ id }: { id: string }) {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [weather, setWeather] = useState<any>(null);
  const [detail, setDetail] = useState<any>(null);

  useEffect(() => {
    api.incident(id).then(setDetail).catch(() => undefined);
    api
      .incidentOutlook(id)
      .then(setData)
      .catch(setError);
  }, [id]);

  useEffect(() => {
    if (detail) {
      api.weather(detail.lat, detail.lon).then(setWeather).catch(() => undefined);
    }
  }, [detail]);

  if (error) return <ErrorState error={error} />;
  if (!data) {
    return (
      <Card>
        <Skeleton rows={4} />
      </Card>
    );
  }

  const forecast = data.forecast || {};
  const trend = data.trend || {};

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="lg:col-span-2" title="Official forecast products" subtitle="Authoritative products are attributed, never redrawn" bodyClassName="space-y-3">
        {forecast.available ? (
          <ul className="space-y-2">
            {(forecast.items || []).map((it: any, i: number) => (
              <li key={i} className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <OfficialBadge label={it.kind.replace(/_/g, " ")} />
                  <span className="text-[11px] text-slate-400">{forecast.authority}</span>
                </div>
                <p className="mt-1 text-[13px] font-medium text-emerald-100">{it.label}</p>
                <p className="text-[11px] text-slate-400">{it.note}</p>
                {it.url && (
                  <a className="link text-[11px]" href={it.url} target="_blank" rel="noreferrer">
                    Open official product ↗
                  </a>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <Banner tone="warn" title="No official forecast product linked for this hazard">
            For earthquakes, floods, wildfires, landslides and industrial fires there is no equivalent of an official
            cyclone forecast track. AEGIS therefore reports what it has and nothing more.
          </Banner>
        )}

        {forecast.extrapolation && (
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
            <div className="flex flex-wrap items-center gap-2">
              <Chip tone="border-amber-500/40 bg-amber-500/10 text-amber-200">
                {forecast.extrapolation.label}
              </Chip>
              <span className="text-[11px] text-slate-400">confidence {forecast.extrapolation.confidence}/100</span>
            </div>
            <ul className="mt-2 space-y-0.5 text-[11px] text-slate-300">
              {(forecast.extrapolation.points || []).map((p: any) => (
                <li key={p.hour}>
                  +{p.hour} h → {p.lat.toFixed(2)}, {p.lon.toFixed(2)}
                </li>
              ))}
            </ul>
            <p className="mt-2 text-[11px] leading-relaxed text-slate-400">{forecast.extrapolation.method}</p>
          </div>
        )}

        {forecast.model_outlook && (
          <div>
            <p className="panel-sub mb-1">Model driver outlook — {forecast.model_outlook.label}</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {Object.entries(forecast.model_outlook.summary || {}).slice(0, 8).map(([k, v]) => (
                <div key={k} className="rounded-lg border border-white/5 bg-white/[0.02] p-2">
                  <p className="text-[10px] uppercase tracking-wide text-slate-500">{k.replace(/_/g, " ")}</p>
                  <p className="text-sm tabular-nums text-slate-200">{v === null ? "—" : String(v)}</p>
                </div>
              ))}
            </div>
            <p className="mt-1 text-[10px] text-slate-500">
              Source: {forecast.model_outlook.source} ·{" "}
              <a className="link" href={forecast.model_outlook.source_url} target="_blank" rel="noreferrer">
                provider docs ↗
              </a>
            </p>
          </div>
        )}
      </Card>

      <div className="space-y-4">
        <Card title="Trend & escalation" subtitle="Computed from stored assessments, not estimated">
          <div className="flex items-center gap-2">
            <Chip
              tone={
                trend.direction === "escalating"
                  ? "border-red-500/40 bg-red-500/10 text-red-300"
                  : trend.direction === "de-escalating"
                    ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                    : "border-white/10 bg-white/5 text-slate-300"
              }
            >
              {trend.direction?.replace(/_/g, " ") || "unknown"}
            </Chip>
            {trend.risk_delta != null && (
              <span className={`text-xs tabular-nums ${trend.risk_delta >= 0 ? "text-orange-300" : "text-emerald-300"}`}>
                {trend.risk_delta > 0 ? "+" : ""}
                {trend.risk_delta} pts
              </span>
            )}
          </div>
          <p className="mt-2 text-[11px] leading-relaxed text-slate-400">{trend.note}</p>
          <p className="mt-2 text-[11px] text-slate-500">
            Observations: {trend.observation_cadence?.last_6h ?? 0} in the last 6 h ·{" "}
            {trend.observation_cadence?.previous_18h ?? 0} in the previous 18 h
          </p>
          <RiskHistoryChart series={trend.risk_series || []} />
        </Card>

        <Card title="Model weather drivers" subtitle="Open-Meteo aggregated NWP — model output, not measurements">
          {weather?.ok ? (
            <>
              <WeatherDriversChart points={weather.points} field="precip_mm" label="Rain (mm/h)" />
              <div className="mt-2 grid grid-cols-3 gap-2 text-[11px]">
                <div>
                  <p className="text-slate-500">Rain next 24 h</p>
                  <p className="text-slate-200">{weather.summary?.rain_next_24h_mm ?? "—"} mm</p>
                </div>
                <div>
                  <p className="text-slate-500">Max wind 24 h</p>
                  <p className="text-slate-200">{weather.summary?.max_wind_next_24h_kmh ?? "—"} km/h</p>
                </div>
                <div>
                  <p className="text-slate-500">Soil moisture</p>
                  <p className="text-slate-200">{weather.summary?.soil_moisture_pct ?? "—"} %</p>
                </div>
              </div>
              <p className="mt-1 text-[10px] text-slate-500">{weather.label} · fetched {localTime(weather.fetched_at)}</p>
            </>
          ) : (
            <ErrorState error={new Error(weather?.error || "Weather model unavailable")} compact />
          )}
        </Card>
      </div>
    </div>
  );
}

function RouteCheck({ incidentId, lat, lon }: { incidentId: string; lat: number; lon: number }) {
  const [from, setFrom] = useState({ lat: lat + 0.35, lon: lon - 0.35 });
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await api.routeCheck({
        incident_id: incidentId,
        from_lat: from.lat,
        from_lon: from.lon,
        to_lat: lat,
        to_lon: lon,
      });
      setResult(res);
    } catch (e) {
      setError(e);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card title="Movement check" subtitle="Corridor hazard screening — safety is never certified">
      <div className="space-y-2">
        <Field label="Start latitude" hint="Your position (or any point of interest)">
          <input className="input" type="number" step="0.0001" value={from.lat} onChange={(e) => setFrom((f) => ({ ...f, lat: Number(e.target.value) }))} />
        </Field>
        <Field label="Start longitude">
          <input className="input" type="number" step="0.0001" value={from.lon} onChange={(e) => setFrom((f) => ({ ...f, lon: Number(e.target.value) }))} />
        </Field>
        <p className="text-[11px] text-slate-500">
          Destination is the incident centre ({lat.toFixed(3)}, {lon.toFixed(3)}).
        </p>
        <button className="btn-primary btn-xs w-full" onClick={run} disabled={busy}>
          <Compass className="h-3 w-3" aria-hidden /> {busy ? "Checking corridor…" : "Run corridor check"}
        </button>
      </div>
      {error && (
        <div className="mt-2">
          <ErrorState error={error} compact />
        </div>
      )}
      {result && (
        <div className="mt-3 space-y-2">
          <Chip
            tone={
              result.status === "hazard_intersects_corridor"
                ? "border-red-500/40 bg-red-500/10 text-red-300"
                : "border-amber-500/40 bg-amber-500/10 text-amber-300"
            }
          >
            {result.status.replace(/_/g, " ")}
          </Chip>
          <p className="text-[11px] leading-relaxed text-slate-300">{result.verdict}</p>
          <p className="text-[11px] text-slate-500">
            Straight-line distance: {result.straight_line_km} km · routing {result.routing_enabled ? "enabled" : "disabled"} ·
            live road-closure data: {result.current_road_data ? "available" : "NOT available"}
          </p>
          {result.hazards_in_corridor?.length ? (
            <ul className="space-y-1 text-[11px] text-slate-300">
              {result.hazards_in_corridor.map((h: any) => (
                <li key={h.incident_id}>
                  {h.code} — {h.category.replace("_", " ")} (severity {h.severity}), {h.distance_to_corridor_km} km from
                  corridor
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      )}
    </Card>
  );
}
