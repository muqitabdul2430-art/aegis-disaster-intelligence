import React, { useCallback, useEffect, useState } from "react";
import { CheckCircle2, Database, ExternalLink, PlayCircle, RefreshCw, Upload, Zap } from "lucide-react";
import { api, DataSource } from "../lib/api";
import { statusTone, timeAgo, utc } from "../lib/format";
import { ObservationsBar } from "../components/charts";
import { Banner, Card, Chip, EmptyState, ErrorState, Skeleton, Stat, Tabs } from "../components/ui";
import { useAuth } from "../state/auth";

export default function Sources() {
  const { principal } = useAuth();
  const [tab, setTab] = useState("health");
  const [data, setData] = useState<any>(null);
  const [syncs, setSyncs] = useState<any[]>([]);
  const [observations, setObservations] = useState<any>(null);
  const [catalog, setCatalog] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);

  const canProbe = principal.authenticated && principal.capabilities?.verify_incident;
  const canIngest = principal.authenticated && principal.capabilities?.trigger_ingest;

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, sy, obs, cat] = await Promise.all([
        api.sources(),
        api.syncs(60),
        api.observations({ hours: 48, limit: 200, include_payload: "false" as any }),
        api.get("/api/sources/catalog"),
      ]);
      setData(s);
      setSyncs(sy.syncs || []);
      setObservations(obs);
      setCatalog(cat);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(load, 90000);
    return () => window.clearInterval(t);
  }, [load]);

  const probe = async (key: string) => {
    setBusy(key);
    setFlash(null);
    try {
      const res = await api.probeSource(key);
      setFlash(
        `${key}: ${res.status}${res.records !== undefined ? ` · ${res.records} record(s)` : ""}${
          res.latency_ms ? ` · ${res.latency_ms} ms` : ""
        }${res.error ? ` — ${res.error}` : ""}`,
      );
      await load();
    } catch (e: any) {
      setFlash(`${key}: probe failed — ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  };

  const ingest = async (sources?: string[]) => {
    setBusy("ingest");
    setFlash(null);
    try {
      const res = await api.runIngest({ sources: sources || null, data_origin: "live" });
      setFlash(
        `Ingestion complete in ${res.duration_ms} ms — ${res.ok} source(s) ok, ${res.failed} failed, ` +
          `${res.new_observations} new observation(s).`,
      );
      await load();
    } catch (e: any) {
      setFlash(`Ingestion failed: ${e?.message || e}`);
    } finally {
      setBusy(null);
    }
  };

  const sources: DataSource[] = data?.sources || [];
  const okCount = sources.filter((s) => s.status === "ok").length;
  const degraded = sources.filter((s) => ["degraded", "error", "stale"].includes(s.status));
  const missing = sources.filter((s) => s.status === "no_credentials");
  const disabled = sources.filter((s) => s.status === "disabled");

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Data sources & integrations</h2>
          <p className="text-xs text-slate-500">
            Every provider AEGIS knows about, with its licence, credential requirement, freshness and last error — plus a
            connectivity probe you can run yourself.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-ghost btn-xs" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} aria-hidden /> Refresh
          </button>
          {canIngest && (
            <button className="btn-primary btn-xs" onClick={() => ingest()} disabled={busy === "ingest"}>
              <PlayCircle className="h-3 w-3" aria-hidden /> {busy === "ingest" ? "Ingesting…" : "Run ingestion now"}
            </button>
          )}
        </div>
      </div>

      {flash && <Banner tone="info" title="Source operation">{flash}</Banner>}
      {error && <ErrorState error={error} onRetry={load} />}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Healthy" value={okCount} hint={`${sources.length} registered sources`} tone="text-emerald-300" icon={<CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" aria-hidden />} />
        <Stat label="Degraded / stale" value={degraded.length} hint={degraded.map((d) => d.key).join(", ") || "none"} tone={degraded.length ? "text-amber-300" : "text-slate-100"} />
        <Stat label="Awaiting credentials" value={missing.length} hint={missing.map((d) => d.credential_env).filter(Boolean).join(", ") || "none"} tone={missing.length ? "text-violet-300" : "text-slate-100"} />
        <Stat label="Link-only sources" value={disabled.length} hint="Authoritative portals without a public API" />
      </div>

      <Tabs
        tabs={[
          { id: "health", label: "Source health", count: sources.length },
          { id: "observations", label: "Observation feed", count: observations?.count },
          { id: "syncs", label: "Sync log" },
          { id: "catalog", label: "Provider catalogue" },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "health" && (
        <>
          {loading && !sources.length ? (
            <Card>
              <Skeleton rows={6} />
            </Card>
          ) : (
            <Card bodyClassName="p-0">
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th scope="col">Source</th>
                      <th scope="col">Status</th>
                      <th scope="col">Credentials</th>
                      <th scope="col">Freshness</th>
                      <th scope="col">Last fetch</th>
                      <th scope="col">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sources.map((s) => (
                      <tr key={s.key}>
                        <td className="min-w-[260px]">
                          <p className="text-[13px] font-medium text-slate-100">{s.name}</p>
                          <p className="text-[11px] text-slate-500">{s.provider}</p>
                          <p className="mt-0.5 text-[10px] leading-snug text-slate-500">{s.reliability_note}</p>
                          <div className="mt-1 flex gap-2">
                            {s.homepage && (
                              <a className="link inline-flex items-center gap-1 text-[10px]" href={s.homepage} target="_blank" rel="noreferrer">
                                Portal <ExternalLink className="h-2.5 w-2.5" aria-hidden />
                              </a>
                            )}
                            {s.docs_url && (
                              <a className="link inline-flex items-center gap-1 text-[10px]" href={s.docs_url} target="_blank" rel="noreferrer">
                                Docs <ExternalLink className="h-2.5 w-2.5" aria-hidden />
                              </a>
                            )}
                          </div>
                          <p className="mt-0.5 text-[10px] text-slate-600">Licence: {s.license}</p>
                        </td>
                        <td>
                          <Chip tone={statusTone(s.status)}>{s.status.replace(/_/g, " ")}</Chip>
                          {s.last_error && <p className="mt-1 max-w-[220px] text-[10px] leading-snug text-amber-400/80">{s.last_error}</p>}
                          {s.is_demo && <p className="mt-1 text-[10px] text-fuchsia-300">demonstration source</p>}
                        </td>
                        <td className="text-[11px] text-slate-400">
                          {s.auth_mode === "none" ? "none required" : `${s.auth_mode} · ${s.credential_env || "—"}`}
                        </td>
                        <td className="text-[11px] text-slate-300">
                          {s.last_ok_at ? (
                            <>
                              <span className="text-slate-200">{timeAgo(s.last_ok_at)}</span>
                              {s.staleness_minutes != null && s.staleness_minutes > 180 && (
                                <span className="ml-1 text-amber-300">(stale)</span>
                              )}
                            </>
                          ) : (
                            <span className="text-slate-500">never</span>
                          )}
                        </td>
                        <td className="text-[11px] text-slate-400">
                          {s.records_last_fetch ?? 0} rec
                          {s.latency_ms ? ` · ${s.latency_ms} ms` : ""}
                          {s.last_sync?.status ? <p className="text-[10px] text-slate-500">sync {s.last_sync.status}</p> : null}
                        </td>
                        <td>
                          {canProbe && !s.is_demo && (
                            <button className="btn-ghost btn-xs" onClick={() => probe(s.key)} disabled={busy === s.key}>
                              <Zap className="h-3 w-3" aria-hidden /> {busy === s.key ? "Probing…" : "Probe"}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="border-t border-white/5 p-3 text-[11px] leading-relaxed text-slate-400">{data?.policy}</div>
            </Card>
          )}

          <Card title="Setup guidance" subtitle="What works immediately vs what needs a key">
            <div className="grid gap-3 lg:grid-cols-3">
              <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
                <p className="text-xs font-semibold text-emerald-200">Works immediately (no credentials)</p>
                <ul className="mt-1 list-disc space-y-0.5 pl-4 text-[11px] text-slate-300">
                  {(data?.capabilities?.working_without_credentials || []).map((k: string) => (
                    <li key={k} className="font-mono">
                      {k}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-lg border border-violet-500/20 bg-violet-500/5 p-3">
                <p className="text-xs font-semibold text-violet-200">Requires credentials</p>
                <ul className="mt-1 space-y-1 text-[11px] text-slate-300">
                  {Object.entries(data?.capabilities?.requires_credentials || {}).map(([k, v]: any) => (
                    <li key={k}>
                      <span className="font-mono text-violet-200">{k}</span> — {v}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-[10px] text-slate-500">
                  Keys live server-side only (AEGIS_* environment variables). The browser never receives them.
                </p>
              </div>
              <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
                <p className="text-xs font-semibold text-slate-200">Authoritative links only</p>
                <ul className="mt-1 list-disc space-y-0.5 pl-4 text-[11px] text-slate-300">
                  {(data?.capabilities?.authoritative_link_only || []).map((k: string) => (
                    <li key={k} className="font-mono">
                      {k}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-[10px] text-slate-500">
                  These agencies publish advisories without a machine-readable API. AEGIS links to them and never guesses
                  their content.
                </p>
              </div>
            </div>
          </Card>
        </>
      )}

      {tab === "observations" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2" title="Raw observation feed (48 h)" subtitle="Provider records as ingested — a single observation is not a confirmed incident" bodyClassName="p-0">
            {!observations ? (
              <div className="p-4">
                <Skeleton rows={6} />
              </div>
            ) : observations.count === 0 ? (
              <EmptyState title="No observations in the last 48 hours" message="Run an ingestion pass, or check the source health tab for failing feeds." />
            ) : (
              <div className="table-wrap max-h-[560px] overflow-y-auto">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th scope="col">Observed</th>
                      <th scope="col">Source</th>
                      <th scope="col">Hazard</th>
                      <th scope="col">Magnitude</th>
                      <th scope="col">Location</th>
                      <th scope="col">Incident</th>
                    </tr>
                  </thead>
                  <tbody>
                    {observations.observations.map((o: any) => (
                      <tr key={o.id}>
                        <td className="whitespace-nowrap text-[11px] text-slate-400">{utc(o.observed_at)}</td>
                        <td className="font-mono text-[10px] text-cyan-300">{o.source_key}</td>
                        <td className="text-[11px] text-slate-300">{o.hazard_hint.replace("_", " ")}</td>
                        <td className="text-[11px] text-slate-300">
                          {o.magnitude != null ? `${o.magnitude} ${o.magnitude_unit}` : "—"}
                        </td>
                        <td className="text-[11px] text-slate-400">
                          {o.place || `${o.lat.toFixed(2)}, ${o.lon.toFixed(2)}`}
                          {o.data_origin === "demo" && <span className="ml-1 text-fuchsia-300">DEMO</span>}
                        </td>
                        <td className="text-[11px]">
                          {o.incident_id ? (
                            <a className="link" href={`/incidents/${o.incident_id}`}>
                              linked
                            </a>
                          ) : (
                            <span className="text-slate-500">unlinked</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <div className="space-y-4">
            <Card title="Volume by source (48 h)">
              <ObservationsBar bySource={observations?.by_source || {}} />
              <p className="mt-1 text-[10px] text-slate-500">{observations?.note}</p>
            </Card>
            <Card title="Provenance">
              <p className="text-[11px] leading-relaxed text-slate-400">
                Each observation stores: source key, provider external id, a dedupe fingerprint, hazard hint, coordinates,
                magnitude/unit, observation time, ingestion time, source URL, confidence and the raw provider payload.
                Detections reference the observation rows that produced them, so every incident is traceable back to
                provider data.
              </p>
            </Card>
          </div>
        </div>
      )}

      {tab === "syncs" && (
        <Card title="Synchronisation log" subtitle="Last 60 ingestion attempts across all sources" bodyClassName="p-0">
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Started</th>
                  <th scope="col">Source</th>
                  <th scope="col">Status</th>
                  <th scope="col">Records</th>
                  <th scope="col">Duration</th>
                  <th scope="col">Message</th>
                </tr>
              </thead>
              <tbody>
                {syncs.map((s) => (
                  <tr key={s.id}>
                    <td className="whitespace-nowrap text-[11px] text-slate-400">{utc(s.started_at)}</td>
                    <td className="font-mono text-[10px] text-cyan-300">{s.source_key}</td>
                    <td>
                      <Chip tone={statusTone(s.status === "ok" ? "ok" : s.status === "skipped" ? "disabled" : "error")}>{s.status}</Chip>
                    </td>
                    <td className="text-[11px] tabular-nums text-slate-300">{s.records}</td>
                    <td className="text-[11px] tabular-nums text-slate-400">{s.duration_ms ? `${s.duration_ms} ms` : "—"}</td>
                    <td className="max-w-[320px] text-[11px] text-slate-500">{s.message || "—"}</td>
                  </tr>
                ))}
                {!syncs.length && (
                  <tr>
                    <td colSpan={6} className="p-6 text-center text-xs text-slate-500">
                      No sync attempts recorded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {tab === "catalog" && (
        <div className="grid gap-3 md:grid-cols-2">
          {(catalog?.sources || []).map((s: any) => (
            <Card key={s.key} title={s.name} subtitle={s.provider}>
              <div className="flex flex-wrap gap-1.5">
                <Chip
                  tone={
                    s.capability === "live_now"
                      ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                      : s.capability === "needs_credentials"
                        ? "border-violet-500/40 bg-violet-500/10 text-violet-300"
                        : "border-slate-500/40 bg-slate-500/10 text-slate-400"
                  }
                >
                  {s.capability.replace(/_/g, " ")}
                </Chip>
                <Chip tone="border-white/10 bg-white/5 text-slate-300">{s.role}</Chip>
                {s.categories?.slice(0, 4).map((c: string) => (
                  <Chip key={c} tone="border-white/10 bg-white/5 text-slate-400">
                    {c}
                  </Chip>
                ))}
              </div>
              <p className="mt-2 text-[11px] leading-relaxed text-slate-400">{s.reliability_note}</p>
              <p className="mt-1 text-[10px] text-slate-500">Licence: {s.license}</p>
              <div className="mt-1 flex gap-3 text-[11px]">
                <a className="link" href={s.homepage} target="_blank" rel="noreferrer">
                  Portal ↗
                </a>
                <a className="link" href={s.docs_url} target="_blank" rel="noreferrer">
                  Documentation ↗
                </a>
                {s.credential_env && <span className="font-mono text-[10px] text-violet-300">{s.credential_env}</span>}
              </div>
            </Card>
          ))}
        </div>
      )}

      <Card title="Deployment note" subtitle="Honest capability reporting">
        <p className="text-xs leading-relaxed text-slate-400">
          AEGIS distinguishes three states for every provider: <strong className="text-emerald-300">live now</strong>{" "}
          (keyless public API, ingested continuously), <strong className="text-violet-300">needs credentials</strong>{" "}
          (connector implemented, waiting for a key you provide) and{" "}
          <strong className="text-slate-300">link-only</strong> (authoritative portal without a documented machine API —
          shown as a reference, never scraped or paraphrased). Demonstration records, when present, are always labelled{" "}
          <code className="font-mono text-fuchsia-300">data_origin=demo</code> in the API and given a DEMO badge in the UI.
        </p>
      </Card>
    </div>
  );
}
