import React from "react";
import { Route, Routes } from "react-router-dom";
import AppShell from "./components/AppShell";
import Dashboard from "./pages/Dashboard";
import MapPage from "./pages/MapPage";
import Incidents from "./pages/Incidents";
import IncidentDetail from "./pages/IncidentDetail";
import Assistant from "./pages/Assistant";
import ReportPage from "./pages/ReportPage";
import Alerts from "./pages/Alerts";
import Agents from "./pages/Agents";
import Sources from "./pages/Sources";
import About from "./pages/About";

export default function App() {
  return (
    <AppShell>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/map" element={<MapPage />} />
        <Route path="/incidents" element={<Incidents />} />
        <Route path="/incidents/:id" element={<IncidentDetail />} />
        <Route path="/assistant" element={<Assistant />} />
        <Route path="/report" element={<ReportPage />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/agents" element={<Agents />} />
        <Route path="/sources" element={<Sources />} />
        <Route path="/about" element={<About />} />
        <Route path="*" element={<Dashboard />} />
      </Routes>
    </AppShell>
  );
}
