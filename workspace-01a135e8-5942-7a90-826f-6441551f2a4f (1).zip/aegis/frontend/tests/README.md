# UI smoke tests (optional)

These Playwright scripts drive the real application in a real browser. They are **not** part of the
application build — they exist so a reviewer can reproduce the UI verification quickly.

```bash
npm install                       # playwright is a devDependency
npx playwright install chromium   # ~165 MB, cached outside the repo

# against a running instance (API on :8000, Vite dev server on :5173)
node tests/pwtest.mjs             # every route renders; reports console/page errors
node tests/shot.mjs /map map      # screenshot one route → /home/user/screens/map.png (env WAIT=ms)
node tests/e2e1.mjs               # assistant Q&A, incident tabs, sign-in
node tests/e2e2.mjs               # admin flows: agent run, alerts tabs, source probe
node tests/e2e3.mjs               # assessment/verify actions + review-queue state
node tests/e2e4.mjs               # citizen report through the real UI + tracking + analyst session
node tests/served-and-mobile.mjs  # served build (no dev server) + 390px mobile pass
```

Screenshots are written to `/home/user/screens/`; committed copies of the verification pass
live in `docs/screens/` (dashboard, map, incident tabs, assistant answer, mobile views, served build). The scripts assume the dev server proxies `/api`
to the backend (see `vite.config.ts`), and e2e2/e2e3 inject an admin token into `localStorage`
(`aegis.token`) obtained from `POST /api/auth/login`.
