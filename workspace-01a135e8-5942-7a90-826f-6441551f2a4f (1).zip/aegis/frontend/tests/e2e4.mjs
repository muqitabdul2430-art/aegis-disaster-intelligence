import { chromium } from 'playwright';
const B = 'http://127.0.0.1:8000';           // served build, no dev-server dependency
const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const ctx = await browser.newContext({ viewport: { width: 1512, height: 950 } });
const p = await ctx.newPage();
const errs = [];
p.on('pageerror', (e) => errs.push(e.message));
p.on('console', (m) => { if (m.type() === 'error' && !/defaultProps/.test(m.text())) errs.push(m.text().slice(0, 140)); });

// ---- 1. citizen report submitted from the real UI (no auth) ----
await p.goto(`${B}/report`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(2500);
const before = p.getByRole('tab', { name: /Submit|Report an incident/i }).first();
if (await before.count()) await before.click();
await p.waitForTimeout(500);
await p.locator('textarea').first().fill('Playwright UI check: storm drain overflowing across the service road near the market.');
await p.locator('input[type="number"]').first().fill('17.3985');
await p.locator('input[type="number"]').nth(1).fill('78.4902');
await p.waitForTimeout(1200);
const submit = p.getByRole('button', { name: /Submit report|Send report/i }).first();
await submit.click();
await p.waitForTimeout(6000);
await p.screenshot({ path: '/home/user/screens/ui-report-submitted.png' });
const t = (await p.innerText('body')).replace(/\s+/g, ' ');
const code = (t.match(/RPT-[A-Z0-9]+/) || ['(no code visible)'])[0];
console.log('1. UI citizen report →', code);
console.log('   success text:', t.slice(t.indexOf('RPT-') - 160, t.indexOf('RPT-') + 200).slice(0, 300));

// ---- 2. tracking lookup with that code ----
if (code.startsWith('RPT-')) {
  const trackTab = p.getByRole('tab', { name: /Track/i }).first();
  if (await trackTab.count()) {
    await trackTab.click(); await p.waitForTimeout(600);
    await p.locator('input').first().fill(code);
    await p.getByRole('button', { name: /track|look up|check status/i }).first().click().catch(() => {});
    await p.waitForTimeout(3000);
    const tt = (await p.innerText('body')).replace(/\s+/g, ' ');
    console.log('2. tracking result contains code:', tt.includes(code), '| unverified label present:', /unverified/i.test(tt));
    await p.screenshot({ path: '/home/user/screens/ui-report-tracked.png' });
  }
}

// ---- 3. analyst reviews that report in the UI ----
const token = await fetch(`${B}/api/auth/login`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'analyst@aegis.local', password: 'aegis-demo-2026' }),
}).then((r) => r.json()).then((j) => j.token.access_token);
await ctx.addInitScript((tok) => window.localStorage.setItem('aegis.token', tok), token);
await p.goto(`${B}/alerts`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(2000);
console.log('3. analyst session can see AEGIS advisories tab:', await p.getByRole('tab', { name: /AEGIS advisories/i }).count() > 0);

console.log('errors:', errs.length); errs.slice(0, 6).forEach((e) => console.log('  *', e));
await browser.close();
