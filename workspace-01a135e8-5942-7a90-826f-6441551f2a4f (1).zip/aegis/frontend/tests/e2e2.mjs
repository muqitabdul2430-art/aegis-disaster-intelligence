import { chromium } from 'playwright';

const B = 'http://127.0.0.1:5173';
const login = await fetch(`${B}/api/auth/login`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'admin@aegis.local', password: 'aegis-demo-2026' }),
}).then((r) => r.json());
const token = login.token.access_token;
console.log('token ok, role:', login.user.role);

const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const ctx = await browser.newContext({ viewport: { width: 1512, height: 950 } });
await ctx.addInitScript((t) => window.localStorage.setItem('aegis.token', t), token);
const p = await ctx.newPage();
const errs = [];
p.on('pageerror', (e) => errs.push('[pageerror] ' + e.message));
p.on('console', (m) => { if (m.type() === 'error' && !/defaultProps/.test(m.text())) errs.push('[console] ' + m.text().slice(0, 180)); });

// ---- incident: analyst re-assessment
await p.goto(`${B}/incidents/inc_cf50876d947d`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3500);
const hasAnalyst = await p.getByText(/Re-assess|Verify|Mark verified/i).count();
console.log('analyst action controls visible:', hasAnalyst);
const btn = p.getByRole('button', { name: /Re-?assess/i }).first();
if (await btn.count()) {
  await btn.click();
  await p.waitForTimeout(6000);
  const t = (await p.innerText('body')).replace(/\s+/g, ' ');
  const i = t.indexOf('assess');
  console.log('assess result snippet:', t.slice(Math.max(0, i - 120), i + 380));
  await p.screenshot({ path: '/home/user/screens/assess-result.png' });
} else {
  console.log('no re-assess button found; buttons:', (await p.$$eval('button', (b) => b.map((x) => x.textContent.trim()).slice(0, 25))).join(' | '));
}

// ---- agents: execute a workflow
await p.goto(`${B}/agents`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3000);
await p.screenshot({ path: '/home/user/screens/agents.png' });
const execTab = p.getByRole('tab', { name: /Execute workflow/i }).first();
if (await execTab.count()) {
  await execTab.click();
  await p.waitForTimeout(800);
  await p.locator('textarea').first().fill('Summarise the latest verified cyclone warnings and flag what needs analyst attention');
  await p.waitForTimeout(300);
  await p.getByRole('button', { name: /Execute workflow/i }).last().click();
  await p.waitForTimeout(9000);
  await p.screenshot({ path: '/home/user/screens/agents-executed.png' });
  const txt = (await p.innerText('body')).replace(/\s+/g, ' ');
  const k = txt.indexOf('Run RUN-');
  console.log('agent run snippet:', txt.slice(k >= 0 ? k : 0, (k >= 0 ? k : 0) + 420));
  const runsTab = p.getByRole('tab', { name: /Run history/i }).first();
  if (await runsTab.count()) { await runsTab.click(); await p.waitForTimeout(2500); await p.screenshot({ path: '/home/user/screens/agents-runs.png' }); }
}

// ---- alerts centre
await p.goto(`${B}/alerts`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(4000);
await p.screenshot({ path: '/home/user/screens/alerts-signedin.png' });
for (const name of ['Review queue', 'Notification channels', 'AEGIS advisories']) {
  const t = p.getByRole('tab', { name: new RegExp(name, 'i') }).first();
  if (await t.count()) { await t.click(); await p.waitForTimeout(2200); await p.screenshot({ path: `/home/user/screens/alerts-${name.split(' ')[0].toLowerCase()}.png` }); console.log('captured alerts tab:', name); }
}

// ---- sources: probe one
await p.goto(`${B}/sources`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3500);
const probe = p.getByRole('button', { name: /^Probe$/ }).first();
if (await probe.count()) {
  await probe.click();
  await p.waitForTimeout(9000);
  const txt = (await p.innerText('body')).replace(/\s+/g, ' ');
  const i = txt.indexOf('probe');
  console.log('probe result:', txt.slice(Math.max(0, i - 200), i + 260));
}
await p.screenshot({ path: '/home/user/screens/sources-signedin.png' });

// ---- report tracking lookup
await p.goto(`${B}/report`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(2500);
const trackTab = p.getByRole('tab', { name: /Track/i }).first();
if (await trackTab.count()) {
  await trackTab.click(); await p.waitForTimeout(700);
  await p.locator('input').first().fill('RPT-25849B4AB35E');
  await p.getByRole('button', { name: /track|look up|check/i }).first().click().catch(() => {});
  await p.waitForTimeout(3000);
  await p.screenshot({ path: '/home/user/screens/report-track.png' });
  const t = (await p.innerText('body')).replace(/\s+/g, ' ');
  console.log('track snippet:', t.slice(t.indexOf('Track') >= 0 ? t.indexOf('Track') : 0, 700).slice(0, 500));
}
console.log('errors:', errs.length); errs.slice(0, 10).forEach((e) => console.log(' *', e));
await browser.close();
