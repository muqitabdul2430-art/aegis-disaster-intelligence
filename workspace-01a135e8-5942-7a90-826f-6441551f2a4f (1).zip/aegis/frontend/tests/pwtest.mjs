import { chromium } from 'playwright';

const PAGES = [
  ['/', 'dashboard'],
  ['/map', 'map'],
  ['/incidents', 'incidents'],
  ['/assistant', 'assistant'],
  ['/report', 'report'],
  ['/alerts', 'alerts'],
  ['/agents', 'agents'],
  ['/sources', 'sources'],
  ['/about', 'about'],
];

const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const ctx = await browser.newContext({ viewport: { width: 1512, height: 950 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`));
page.on('console', (m) => { if (m.type() === 'error') errors.push(`[console] ${m.text().slice(0, 200)}`); });

for (const [route, name] of PAGES) {
  const before = errors.length;
  await page.goto(`http://127.0.0.1:5173${route}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForTimeout(3500);
  const text = (await page.innerText('body')).replace(/\s+/g, ' ');
  await page.screenshot({ path: `/home/user/screens/${name}.png`, fullPage: false });
  console.log(`\n=== ${route} → screens/${name}.png  (${text.length} chars text, ${errors.length - before} new errors)`);
  console.log(text.slice(0, 320));
}
await browser.close();
console.log('\n---- total console/page errors:', errors.length);
errors.slice(0, 25).forEach((e) => console.log(' *', e));
