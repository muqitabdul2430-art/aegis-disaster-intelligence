import { chromium } from 'playwright';
const B = 'http://127.0.0.1:8000';   // the REAL served app (FastAPI + backend/static)
const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });

// ---- mobile pass ----
const m = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const mp = await m.newPage();
const errs = [];
mp.on('pageerror', (e) => errs.push(e.message));
for (const [route, name] of [['/', 'm-dashboard'], ['/incidents', 'm-incidents'], ['/report', 'm-report'], ['/alerts', 'm-alerts']]) {
  await mp.goto(`${B}${route}`, { waitUntil: 'domcontentloaded' });
  await mp.waitForTimeout(3500);
  await mp.screenshot({ path: `/home/user/screens/${name}.png`, fullPage: false });
}
const overflow = await mp.evaluate(() => ({ docW: document.documentElement.scrollWidth, winW: window.innerWidth }));
console.log('mobile horizontal overflow check:', overflow, overflow.docW <= overflow.winW + 2 ? 'OK' : 'OVERFLOWS');
console.log('mobile errors:', errs.length, errs.slice(0, 3));

// ---- desktop pass against the SERVED build (not the dev server) ----
const d = await browser.newContext({ viewport: { width: 1512, height: 950 } });
const dp = await d.newPage();
const derrs = [];
dp.on('pageerror', (e) => derrs.push(e.message));
dp.on('console', (x) => { if (x.type() === 'error' && !/defaultProps/.test(x.text())) derrs.push(x.text().slice(0, 140)); });
const pages = ['/', '/map', '/incidents', '/assistant', '/report', '/alerts', '/agents', '/sources', '/about'];
for (const [i, route] of pages.entries()) {
  const before = derrs.length;
  await dp.goto(`${B}${route}`, { waitUntil: 'domcontentloaded' });
  await dp.waitForTimeout(3000);
  const text = (await dp.innerText('body')).replace(/\s+/g, ' ');
  await dp.screenshot({ path: `/home/user/screens/served-${route === '/' ? 'dashboard' : route.slice(1)}.png` });
  console.log(`${route.padEnd(12)} ${String(text.length).padStart(5)} chars shown | new errors: ${derrs.length - before}`);
}
console.log('served-build errors:', derrs.length); derrs.slice(0, 6).forEach(e => console.log('  *', e));
await browser.close();
