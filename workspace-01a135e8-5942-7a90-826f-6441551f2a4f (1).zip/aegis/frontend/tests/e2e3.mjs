import { chromium } from 'playwright';
const B = 'http://127.0.0.1:5173';
const login = await fetch(`${B}/api/auth/login`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'admin@aegis.local', password: 'aegis-demo-2026' }),
}).then((r) => r.json());
const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const ctx = await browser.newContext({ viewport: { width: 1512, height: 950 } });
await ctx.addInitScript((t) => window.localStorage.setItem('aegis.token', t), login.token.access_token);
const p = await ctx.newPage();
const errs = [];
p.on('pageerror', (e) => errs.push(e.message));
p.on('console', (m) => { if (m.type() === 'error' && !/defaultProps/.test(m.text())) errs.push(m.text().slice(0, 160)); });

// ---------- 1. incidents list -> highest risk -> full assessment (drafts advisory) ----------
await p.goto(`${B}/incidents?sort=risk_desc`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3500);
const link = await p.evaluate(() => document.querySelector('a[href^="/incidents/inc_"]')?.getAttribute('href'));
console.log('highest-risk incident:', link);
await p.goto(`${B}${link}`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3500);
const assessBtn = p.getByRole('button', { name: /Run full assessment/i }).first();
await assessBtn.click();
await p.waitForTimeout(9000);
await p.screenshot({ path: '/home/user/screens/assessment-run.png' });
const t1 = (await p.innerText('body')).replace(/\s+/g, ' ');
const k1 = t1.search(/assessment (complete|updated)|risk|draft/i);
console.log('assessment feedback:', t1.slice(k1 >= 0 ? k1 : 0, (k1 >= 0 ? k1 : 0) + 320));

// ---------- 2. verify as analyst ----------
const verifyBtn = p.getByRole('button', { name: /Mark analyst-verified/i }).first();
if (await verifyBtn.count()) {
  await verifyBtn.click();
  await p.waitForTimeout(4000);
  await p.screenshot({ path: '/home/user/screens/incident-verified.png' });
  const t2 = (await p.innerText('body')).replace(/\s+/g, ' ');
  const k2 = t2.search(/verification|verified|audit/i);
  console.log('verify feedback:', t2.slice(k2 >= 0 ? k2 : 0, (k2 >= 0 ? k2 : 0) + 260));
}

// ---------- 3. alerts review queue -> publish with note ----------
await p.goto(`${B}/alerts`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3000);
await p.getByRole('tab', { name: /Review queue/i }).first().click();
await p.waitForTimeout(3000);
await p.screenshot({ path: '/home/user/screens/review-queue.png' });
const queueText = (await p.innerText('body')).replace(/\s+/g, ' ');
console.log('queue contains:', /Nothing awaiting review/.test(queueText) ? 'EMPTY' : queueText.slice(queueText.indexOf('HUMAN AUTHORISATION'), queueText.indexOf('HUMAN AUTHORISATION') + 700));
console.log('errors:', errs.length); errs.slice(0, 6).forEach((e) => console.log(' *', e));
await browser.close();
