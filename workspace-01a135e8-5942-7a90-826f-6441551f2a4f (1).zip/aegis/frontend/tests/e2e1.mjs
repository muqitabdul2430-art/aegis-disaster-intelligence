import { chromium } from 'playwright';
const b = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const ctx = await b.newContext({ viewport: { width: 1512, height: 950 } });
const p = await ctx.newPage();
const errs = [];
p.on('pageerror', (e) => errs.push('[pageerror] ' + e.message));
p.on('console', (m) => { if (m.type() === 'error') errs.push('[console] ' + m.text().slice(0, 160)); });
const step = async (label, fn) => {
  try { await fn(); console.log('OK  ', label); }
  catch (e) { console.log('FAIL', label, '::', e.message.split('\n')[0]); }
};

// 1. assistant: ask a suggested question
await p.goto('http://127.0.0.1:5173/assistant', { waitUntil: 'domcontentloaded' });
await step('ask suggested question', async () => {
  await p.getByText('What active hazards are reported right now, and which are officially confirmed?').first().click();
  await p.waitForSelector('text=/tool|Verified|estimate/i', { timeout: 45000 });
  await p.waitForTimeout(4000);
});
await p.screenshot({ path: '/home/user/screens/assistant-answer.png' });
const answerText = (await p.innerText('body')).replace(/\s+/g, ' ');
console.log('   answer excerpt:', answerText.slice(answerText.indexOf('You asked') > 0 ? answerText.indexOf('You asked') : 600, 1600).slice(0, 700));

// 2. incident detail via incidents table
await p.goto('http://127.0.0.1:5173/incidents', { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3500);
const href = await p.evaluate(() => {
  const a = document.querySelector('a[href^="/incidents/inc_"], a[href*="/incidents/"]');
  return a ? a.getAttribute('href') : null;
});
console.log('   incident link:', href);
if (href) {
  await p.goto(`http://127.0.0.1:5173${href}`, { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(4000);
  await p.screenshot({ path: '/home/user/screens/incident-overview.png' });
  const tabs = await p.$$eval('button[role="tab"], .tab', (els) => els.map((e) => e.textContent?.trim()).slice(0, 10));
  console.log('   tabs:', tabs);
  // click each tab and screenshot two of them
  for (const name of ['Evidence', 'Risk', 'Outlook', 'Response', 'Audit trail']) {
    const t = p.getByRole('tab', { name: new RegExp(name, 'i') }).first();
    if (await t.count()) {
      await t.click().catch(() => {});
      await p.waitForTimeout(2500);
      await p.screenshot({ path: `/home/user/screens/incident-${name.split(' ')[0].toLowerCase()}.png` });
      console.log('   tab captured:', name);
    }
  }
}

// 3. sign-in flow
await step('sign in as admin', async () => {
  await p.goto('http://127.0.0.1:5173/', { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(2500);
  await p.getByRole('button', { name: /sign in/i }).first().click();
  await p.waitForTimeout(700);
  const modal = p.locator('form, [role="dialog"]').last();
  await p.locator('input[type="email"], input[name="email"]').last().fill('admin@aegis.local');
  await p.locator('input[type="password"]').last().fill('aegis-demo-2026');
  await p.locator('button[type="submit"], button:has-text("Sign in")').last().click();
  await p.waitForTimeout(4000);
  await p.screenshot({ path: '/home/user/screens/signed-in.png' });
});
const bodyAfter = (await p.innerText('body')).slice(0, 200).replace(/\s+/g, ' ');
console.log('   after sign-in header:', bodyAfter);
console.log('errors:', errs.length); errs.slice(0, 8).forEach((e) => console.log(' *', e));
await b.close();
