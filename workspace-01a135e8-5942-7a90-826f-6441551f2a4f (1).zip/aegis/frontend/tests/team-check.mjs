import { chromium } from 'playwright';
const B = 'http://127.0.0.1:8000';
const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const ctx = await browser.newContext({ viewport: { width: 1512, height: 950 } });
const p = await ctx.newPage();
const errs = [];
p.on('pageerror', (e) => errs.push(e.message));
p.on('console', (m) => { if (m.type() === 'error' && !/defaultProps/.test(m.text())) errs.push(m.text().slice(0, 140)); });

for (const [route, name] of [['/', 'nodemo-dashboard'], ['/about', 'nodemo-about'], ['/incidents', 'nodemo-incidents'], ['/alerts', 'nodemo-alerts']]) {
  await p.goto(`${B}${route}`, { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(3500);
  await p.screenshot({ path: `/home/user/screens/${name}.png` });
  const txt = (await p.innerText('body')).replace(/\s+/g, ' ');
  console.log(`${route.padEnd(11)} team shown: ${txt.includes('Team OG ciper')} | demo banner: ${/demonstration records are present/i.test(txt)} | DEMO chip: ${/\\bDEMO\\b/.test(txt)}`);
}
// document title + about page team card text
await p.goto(`${B}/about`, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(2500);
console.log('document.title:', await p.title());
const t = (await p.innerText('body')).replace(/\s+/g, ' ');
const i = t.indexOf('Built by');
console.log('about card:', t.slice(i, i + 150));
console.log('errors:', errs.length, errs.slice(0, 4));
await browser.close();
