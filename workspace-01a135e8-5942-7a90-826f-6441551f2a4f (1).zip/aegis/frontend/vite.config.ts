import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Build output goes to backend/static (a persisted directory, unlike dist/)
// so the FastAPI app can serve the built SPA in environments without node.
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "../backend/static",
    emptyOutDir: true,
    sourcemap: false,
    chunkSizeWarningLimit: 1600,
  },
  server: {
    host: "0.0.0.0",
    port: 5173,
    strictPort: false,
    allowedHosts: true,
    proxy: {
      "/api": { target: "http://127.0.0.1:8000", changeOrigin: true },
      "/data": { target: "http://127.0.0.1:8000", changeOrigin: true },
    },
  },
});
