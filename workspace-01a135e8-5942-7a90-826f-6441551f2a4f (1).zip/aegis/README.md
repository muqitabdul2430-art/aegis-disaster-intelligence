# AEGIS — Agentic AI Multi-Disaster Intelligence & Early-Warning Platform

AEGIS ingests real multi-hazard feeds, runs a pipeline of specialised AI agents over them, and
presents the result as a command-centre console for disaster-management operators and the public.

**Team OG ciper** · HACK-X (AEGIS pitch deck)

**Decision support only.** AEGIS is *not* an official warning service. Official warnings are shown
verbatim with their issuing authority; AEGIS risk numbers are always labelled *model estimates*, and
no AEGIS-generated advisory can reach the public without a recorded human authorisation.

> **This deployment runs on live data only.** Demonstration records have been removed and
> `AEGIS_DEMO_MODE=off` is set in `backend/.env`, so every incident, observation and warning shown
> comes from a real provider feed (USGS, NOAA NHC, GDACS, NOAA tsunami centres). Nothing is simulated.
> The seven labelled sample scenarios remain available in `app/demo_data.py` for offline demos —
> re-enable deliberately with `AEGIS_DEMO_MODE=force python scripts/seed_demo.py --seed`, and remove
> them again with `python scripts/seed_demo.py --clear`.

```
            DATA COLLECTION → DETECTION → CLASSIFICATION → CONTEXT → RISK → PREDICTION → EARLY WARNING → RESPONSE
            ───────────────   ─────────   ──────────────   ───────   ────   ──────────   ─────────────   ────────
 providers   USGS · GDACS · NOAA NHC · NOAA tsunami · NASA FIRMS/GIBS · Open-Meteo · OpenStreetMap
 agents       detection → classification → geospatial → risk/impact → prediction/early-warning
              → citizen intelligence → emergency response →    intelligence coordinator (13-tool allow-list)
```

---

## 1. Quick start (5 minutes, no credentials)

```bash
# 1. backend: API + agents + scheduler + built UI
cd backend
python -m pip install -r requirements.txt
cp ../.env.example ../.env            # optional — defaults work as-is
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
#    → http://localhost:8000          (UI)
#    → http://localhost:8000/api/docs (OpenAPI)

# 2. frontend (only needed if you want hot reload / to rebuild the UI)
cd ../frontend
npm install
npm run build        # emits into backend/static (served by FastAPI)
npm run dev          # or: Vite dev server on :5173, proxying /api and /data
```

The first start seeds the database, registers the 13 data sources and — if `AEGIS_SCHEDULER_ENABLED`
is on — immediately begins polling the credential-free feeds. Within a minute or two the dashboard
shows **live** earthquakes, tropical cyclones and official tsunami/hurricane bulletins.

### Demo accounts

Created only when `AEGIS_DEMO_PASSWORD` is set (it has a development default).

| Account | Role | What it can do |
|---|---|---|
| `admin@aegis.local` | admin | everything: ingestion control, user management, data-gap workflow |
| `analyst@aegis.local` | analyst | verify incidents, run agents, authorise + publish advisories |
| `citizen@aegis.local` | citizen | read intelligence, submit and track reports, acknowledge alerts |

Create real operators deliberately (self-registration only ever makes citizens):

```bash
python scripts/create_user.py ops@your-agency.gov --role analyst --name "Duty Officer" --org "SDMA"
```

---

## 2. What is genuinely working (and what needs you)

AEGIS is explicit about integration state — the **Data sources** screen and `/api/sources` report,
per provider, one of: `ok`, `degraded`, `stale`, `error`, `no_credentials`, `disabled`.

### Works immediately — no key, live data in this build

| Source | What AEGIS uses it for |
|---|---|
| **USGS FDSN Event API** | global earthquake catalogue (M ≥ 4.0, rolling window) → earthquake incidents, tsunami correlation |
| **GDACS (JRC)** | multi-hazard alerts incl. flood, cyclone, wildfire, drought, volcano → cross-checking and event staging |
| **NOAA NHC** | active tropical cyclones + advisories → cyclone incidents and official forecast products |
| **NOAA tsunami centres** | NTWC/PTWC bulletins → official tsunami warnings, ingested verbatim |
| **Open-Meteo** | rainfall, wind, gusts, CAPE, soil moisture, pressure → hazard drivers, explicitly labelled *model output* |
| **OpenStreetMap** (Overpass + Nominatim) | hospitals/shelters/fire stations around an incident; place naming for coordinates |
| **Natural Earth** | offline public-domain basemap so the map works with no internet at all |
| **NASA GIBS** | satellite imagery tiles (WMTS) for the map |

### Needs a free key/registration — connector implemented, awaiting credentials

| Source | Env var | Where to get it |
|---|---|---|
| **NASA FIRMS / VIIRS** active fire detections | `AEGIS_FIRMS_MAP_KEY` | <https://firms.modaps.eosdis.nasa.gov/api/map_key/> (email) |
| **ISRO MOSDAC / Bhuvan** products | `AEGIS_MOSDAC_TOKEN` | <https://www.mosdac.gov.in/> (registration) |
| **NASA Earthdata** (extra GIBS/CMR products) | `AEGIS_EARTHDATA_TOKEN` | <https://urs.earthdata.nasa.gov/> |
| **Copernicus Data Space** (EMS activations) | `AEGIS_CDSE_CLIENT_ID` / `_SECRET` | <https://dataspace.copernicus.eu/> |

Set the variable and restart (or hit **Probe** on the Data sources screen) — the source flips to
`ok` and starts ingesting. Until then AEGIS reports `no_credentials` and never fabricates.

### Link-only — authoritative portals without a documented machine API

IMD (RSMC cyclone advisories), INCOIS (Indian tsunami warning centre) and NDMA SACHET are listed as
reference links with their official numbers. AEGIS does not scrape or paraphrase them.

### Optional LLM narrative layer

Runs without any LLM key using a deterministic planner + template narrator — every tool call, risk
score and retrieval still executes for real. Add any OpenAI-compatible endpoint
(`AEGIS_LLM_API_KEY`, `AEGIS_LLM_BASE_URL`, `AEGIS_LLM_MODEL`) to get natural-language phrasing on
top of **the same** retrieved facts. The LLM never sees a blank cheque: it can only choose from the
13-tool allow-list and its output is always shown next to the underlying evidence.

---

## 3. The eight agents

| # | Agent | What it actually does |
|---|---|---|
| 1 | **Detection** | scans new observations, dedupes by fingerprint, groups provider series into incidents, correlates across sources (e.g. tsunami bulletin + quake ⇒ corroborated) |
| 2 | **Classification** | assigns one of the 7 hazard classes from the attached evidence only; records its reasoning; flags ambiguity for humans instead of guessing |
| 3 | **Geospatial** | region resolution, hazard-specific footprint estimation, population exposure from a static gazetteer, nearby facilities from OpenStreetMap |
| 4 | **Risk & Impact** | explainable 0–100 score (`risk-v1.0`): hazard / exposure / vulnerability components, every factor with value, weight, contribution and provenance |
| 5 | **Prediction & Early-Warning** | trend detection from stored assessments, official forecast linkage (NHC/GDACS), labelled AEGIS extrapolation, **draft** advisories only |
| 6 | **Citizen Intelligence** | intake, anti-abuse, salted identity hashing, coordinate reduction, duplicate detection, triage for analysts |
| 7 | **Emergency Response** | official protective actions, ranked nearby facilities, corridor screening that never certifies a route as safe |
| 8 | **Intelligence Coordinator** | plans and executes bounded workflows over a 13-tool allow-list, separates verified facts / model estimates / unverified input, states data gaps, flags approvals |

---

## 4. Safety model (short version — full text in [`docs/SAFETY.md`](docs/SAFETY.md))

* **Agents cannot publish.** They create `pending_review` drafts. Publishing requires an
  analyst/admin decision *with a written note*, enforced by the API schema and audited.
  Official warnings are ingest-only: AEGIS refuses to edit or "approve" them (`409`).
* **Nothing is invented.** Retrieved facts, model estimates and unverified citizen reports are
  separated in every answer, on every incident, and in the API payloads themselves.
* **Uncertainty is first-class.** Data gaps, stale-source flags, ambiguity flags and explicit
  limitations ship with the data, not in a footnote.
* **Privacy by default.** Citizen reports are unverified; identities are salted hashes; public
  payloads reduce coordinate precision; photos are analyst-only; privileged actions are audited.
* **Adverse conditions are stated, not hidden.** With extreme risk, no LLM key, failed feeds or an
  empty review queue, AEGIS says so plainly.

---

## 5. Layout

```
aegis/
├── backend/
│   ├── app/
│   │   ├── main.py              FastAPI app: API + built SPA + offline /data
│   │   ├── config.py            every setting (12-factor, AEGIS_* env vars)
│   │   ├── models.py            SQLAlchemy schema (mirrors scripts/postgis_schema.sql)
│   │   ├── security.py          PBKDF2 passwords, JWT sessions, role checks
│   │   ├── agents/              8 agents + coordinator (planner, allow-list, synthesis)
│   │   ├── sources/             6 live connectors + the 13-entry source catalogue
│   │   ├── services/            geo maths, weather, facilities (OSM), notifications
│   │   ├── routers/             auth, dashboard, incidents, geo, agents, assistant,
│   │   │                        reports, alerts, sources, system
│   │   └── ingest.py            idempotent ingestion, health tracking, official alerts
│   ├── scripts/                 create_user.py · ingest_once.py · seed_demo.py ·
│   │                            run_agent.py · postgis_schema.sql
│   ├── tests/                   39 offline tests (pytest)
│   └── static/                  built UI (produced by `npm run build`)
├── frontend/                    React + TypeScript + Tailwind + React-Leaflet
│   ├── src/pages/               dashboard, map, incidents, incident detail, assistant,
│   │                            citizen reporting, alerts centre, agents, sources, about
│   └── src/components/          MapView (offline basemap + live tiles), charts, tables, UI kit
├── docs/                        SETUP · ARCHITECTURE · SAFETY · DATA_SOURCES
├── .env.example                 every setting, no secrets
└── README.md
```

## 6. Tests

```bash
cd backend && python -m pytest        # 39 tests, ~1 s, fully offline
```

Coverage highlights: geometry/risk maths, provider parsers (USGS/GDACS/NHC/tsunami), ingestion
dedupe, planner intent parsing, the human-authorisation gate, RBAC, citizen-report validation and
privacy, and the "never fabricate" guarantees.

## 7. Licence & attribution

AEGIS source code: your project licence. Data remains the property of the providers listed in
[`docs/DATA_SOURCES.md`](docs/DATA_SOURCES.md) — USGS/GDACS/NHC/NOAA/NASA are public-domain or
openly licensed; OpenStreetMap is ODbL (© OpenStreetMap contributors); Natural Earth is public
domain. Official warning text is always attributed to the issuing authority.
